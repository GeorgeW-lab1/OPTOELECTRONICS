#!/usr/bin/env python3
"""
lcd_transmitter.py - show the SELECT bit stream on an LCD screen.

Author: George Wagenknecht

Draws a large black/white patch that changes once per clock period, sending
[ preamble | nbits data bits, MSB first ] over and over - the same signal the
74HC74 SELECT output would put on an LED. Point the camera at the screen and run
predict_number.py.

  python lcd_transmitter.py --secret 0xA5 --nbits 8
  python lcd_transmitter.py --secret 0xA5 --nbits 8 --fullscreen

Press ESC or q in the window to quit. Needs:  pip install opencv-python numpy
"""
import argparse
import sys
import time

import numpy as np

PREAMBLE = "1110010"


class TimeCodeLatch:
    def __init__(self, value, nbits):
        self.value, self.nbits = value, nbits

    def bit(self, slot):
        return (self.value >> (self.nbits - 1 - slot)) & 1


def build_stream(secret, nbits, preamble):
    latch = TimeCodeLatch(secret, nbits)
    return [int(c) for c in preamble] + [latch.bit(i) for i in range(nbits)]


def bit_at(stream, elapsed, clock_hz):
    """Bit shown at `elapsed` seconds after start (one bit per clock period)."""
    return stream[int(elapsed * clock_hz) % len(stream)]


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--secret", type=lambda s: int(s, 0), required=True, help="the number to transmit")
    ap.add_argument("--nbits", type=int, default=8)
    ap.add_argument("--clock", type=float, default=10.0, help="clock in Hz (default 10)")
    ap.add_argument("--preamble", default=PREAMBLE)
    ap.add_argument("--fullscreen", action="store_true")
    ap.add_argument("--size", default="960x600", help="window size WxH when not fullscreen")
    args = ap.parse_args()

    if args.secret >> args.nbits:
        sys.exit(f"--secret does not fit in {args.nbits} bits")
    try:
        import cv2
    except ImportError:
        sys.exit("OpenCV is required:  pip install opencv-python")

    stream = build_stream(args.secret, args.nbits, args.preamble)
    w, h = (int(x) for x in args.size.lower().split("x"))
    name = "SELECT"
    cv2.namedWindow(name, cv2.WINDOW_NORMAL)
    if args.fullscreen:
        cv2.setWindowProperty(name, cv2.WND_PROP_FULLSCREEN, cv2.WINDOW_FULLSCREEN)
    else:
        cv2.resizeWindow(name, w, h)

    # Mid-grey surround, large centred patch (about 60% x 70% of the window).
    frames = {}
    for b, level in ((0, 0), (1, 255)):
        img = np.full((h, w, 3), 90, np.uint8)
        img[int(0.15 * h):int(0.85 * h), int(0.2 * w):int(0.8 * w)] = level
        frames[b] = img

    print(f"Transmitting {args.secret} (0x{args.secret:X}) as {args.preamble}+"
          f"{args.secret:0{args.nbits}b} at {args.clock} Hz. ESC or q to quit.")
    t0 = time.perf_counter()
    last = None
    while True:
        b = bit_at(stream, time.perf_counter() - t0, args.clock)
        if b != last:
            cv2.imshow(name, frames[b])
            last = b
        key = cv2.waitKey(1) & 0xFF
        if key in (27, ord("q")):
            break
    cv2.destroyAllWindows()


if __name__ == "__main__":
    main()
