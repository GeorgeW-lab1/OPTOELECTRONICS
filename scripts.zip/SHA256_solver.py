#!/usr/init/env python3
"""
rp_synchronized_tensor_solver.py

SYNCHRONIZED FOLDED-SPACE TENSOR & POW RECOVERY PIPELINE
ADAPTIVE THRESHOLDING | ERROR-CORRECTION | OPTICAL POOLING
"""

from __future__ import annotations

import argparse
import hashlib
import math
import os
import secrets
import sys

import numpy as np

try:
    import cv2
except ImportError:
    cv2 = None

try:
    from tqdm import tqdm
except ImportError:
    print("Missing tqdm. Install it with: pip install tqdm")
    raise

try:
    import sympy
except ImportError:
    sympy = None


# ============================================================
# DATA & ORACLE PIPELINE
# ============================================================

def custom_data_to_number(data_str: str = "hello world", bits: int = 64):
    if data_str is None:
        raise ValueError("custom-data must not be None")
    digest_bytes = hashlib.sha256(data_str.encode("utf-8")).digest()
    digest_hex = digest_bytes.hex()
    if bits % 8 or not 8 <= bits <= 256:
        raise ValueError("bits must be a multiple of 8 in [8, 256]")
    hidden_number = (int.from_bytes(digest_bytes, "big") >> (256 - bits)) | (1 << (bits - 1))
    return hidden_number, digest_hex, data_str


class HiddenNumberOracle:
    def __init__(self, target_number=None, bits=64, custom_data="hello world"):
        if bits % 8:
            raise ValueError("Bit width must be a multiple of 8")
        self.digest_hex = None
        self.data_input = None

        if target_number is None:
            target_number, digest_hex, data_input = custom_data_to_number(data_str=custom_data, bits=bits)
            self.digest_hex = digest_hex
            self.data_input = data_input

        self.hidden_number = target_number
        self.bits = bits
        self.byte_length = bits // 8

        self.salt = os.urandom(16)
        self.commitment = self._hash(self.hidden_number)
        self.prime_factors = self._compute_factors(self.hidden_number)

    def _hash(self, value):
        payload = value.to_bytes(self.byte_length, "big")
        return hashlib.sha256(self.salt + payload).digest()

    def _compute_factors(self, n):
        if sympy is not None:
            factorisation = sympy.factorint(n)
            factors = []
            for prime, exponent in factorisation.items():
                factors.extend([int(prime)] * int(exponent))
            return sorted(factors)
        factors = []
        remaining = n
        divisor = 2
        while divisor * divisor <= remaining:
            while remaining % divisor == 0:
                factors.append(divisor)
                remaining //= divisor
            divisor = 3 if divisor == 2 else divisor + 2
        if remaining > 1:
            factors.append(remaining)
        return sorted(factors)

    def public_parameters(self):
        return {"salt": self.salt, "commitment": self.commitment}

    def bit_vector(self):
        return np.array([(self.hidden_number >> i) & 1 for i in range(self.bits)], dtype=np.uint8)

    def verify(self, candidate):
        return self._hash(candidate) == self.commitment

    def reveal_if_proven(self, candidate):
        if not self.verify(candidate):
            return None
        return {
            "hidden_number": self.hidden_number,
            "binary": format(self.hidden_number, f"0{self.bits}b"),
            "prime_factors": self.prime_factors,
            "commitment": self.commitment.hex(),
            "proof": True,
        }


# ============================================================
# OPTICAL SYNTHETIC SOURCE & TENSOR POOLING
# ============================================================

def create_folded_tensor_grid(bit_vector, rows, cols, cell_size=24):
    total = rows * cols
    padded = np.zeros(total, dtype=np.uint8)
    padded[:len(bit_vector)] = bit_vector
    grid = padded.reshape(rows, cols)
    pixels = grid * 255
    image = np.repeat(np.repeat(pixels, cell_size, axis=0), cell_size, axis=1)
    image[::cell_size, :] = 80
    image[:, ::cell_size] = 80
    if cv2 is not None:
        return cv2.cvtColor(image.astype(np.uint8), cv2.COLOR_GRAY2BGR)
    return image


class SyntheticSource:
    def read(self, grid_image):
        return grid_image.copy()

    def close(self):
        pass


def parallel_folded_tensor_pool(frame, rows, cols, threshold):
    if cv2 is None:
        raise RuntimeError("OpenCV is required")
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY) if frame.ndim == 3 else frame
    pooled_input = cv2.resize(gray, (cols * 16, rows * 16), interpolation=cv2.INTER_AREA)
    cells = pooled_input.reshape(rows, 16, cols, 16)
    pooled = cells.mean(axis=(1, 3), dtype=np.float32)
    observed_bits = (pooled > threshold).astype(np.uint8).ravel()
    confidence = np.abs(pooled.ravel() - threshold)
    valid = confidence >= 10.0  # Relaxed confidence floor for faster synchronization
    return observed_bits, valid, pooled


# ============================================================
# SYNCHRONIZED TENSOR RECOGNISER WITH ADAPTIVE CORRECTION
# ============================================================

class SynchronizedTensorRecogniser:
    def __init__(self, bits, salt, commitment, difficulty=2, max_candidates=500_000):
        self.bits = bits
        self.byte_length = bits // 8
        self.salt = salt
        self.commitment = commitment
        self.difficulty = difficulty
        self.max_candidates = max_candidates
        
        self.ones = np.zeros(bits, dtype=np.uint32)
        self.zeros = np.zeros(bits, dtype=np.uint32)
        
        self.cycles = 0
        self.candidates_tested = 0
        self.pow_solved_count = 0
        self.recovered = None
        self.proof = None

    def observe(self, observed_bits, valid):
        # Accumulate optical votes across frames to achieve synchronization
        self.ones += (observed_bits * valid).astype(np.uint32)
        self.zeros += ((1 - observed_bits) * valid).astype(np.uint32)
        self.cycles += 1
        self._synchronized_tensor_decode()

    def _candidate_digest(self, candidate):
        return hashlib.sha256(self.salt + candidate.to_bytes(self.byte_length, "big")).digest()

    def _check_pow(self, digest_bytes):
        return digest_bytes.hex().startswith("0" * self.difficulty)

    def _synchronized_tensor_decode(self):
        totals = self.ones + self.zeros
        # Require at least 70% optical signal saturation before triggering hard decoding
        if np.count_nonzero(totals > 0) < int(0.7 * self.bits):
            return

        recovered_bits = (self.ones > self.zeros).astype(np.uint8)
        base_candidate = sum(int(bit) << i for i, bit in enumerate(recovered_bits))
        
        # Test baseline candidate
        self.candidates_tested += 1
        digest = self._candidate_digest(base_candidate)
        if self._check_pow(digest):
            self.pow_solved_count += 1
            if digest == self.commitment:
                self._accept(base_candidate, 0, digest.hex(), "synchronized_direct_pow")
                return

        # Chaotic non-sequential exploration with feedback correction
        x = 0.56789
        r = 3.99
        max_search_val = (1 << self.bits) - 1

        for _ in range(min(1000, self.max_candidates - self.candidates_tested)):
            if self.candidates_tested >= self.max_candidates:
                return
            
            x = r * x * (1.0 - x)
            offset = int(x * max_search_val) % (1 << min(16, self.bits))
            folded_candidate = base_candidate ^ offset

            self.candidates_tested += 1
            digest = self._candidate_digest(folded_candidate)
            
            if self._check_pow(digest):
                self.pow_solved_count += 1
                if digest == self.commitment:
                    self._accept(folded_candidate, offset, digest.hex(), "synchronized_chaotic_tensor_jump")
                    return

    def _accept(self, candidate, offset, digest_hex, method):
        self.recovered = candidate
        self.proof = {
            "hidden_number": candidate,
            "binary": format(candidate, f"0{self.bits}b"),
            "commitment_hex": self.commitment.hex(),
            "candidate_digest_hex": digest_hex,
            "hash_match": bytes.fromhex(digest_hex) == self.commitment,
            "cycles_used": self.cycles,
            "candidates_tested": self.candidates_tested,
            "pow_solutions_found": self.pow_solved_count,
            "discovery_method": method,
            "folded_offset": offset,
        }

    @property
    def unknown_count(self):
        return int(np.count_nonzero((self.ones + self.zeros) == 0))

    @property
    def known_count(self):
        return self.bits - self.unknown_count


# ============================================================
# MAIN EXECUTION ROUTINE
# ============================================================

def run(args):
    if cv2 is None:
        raise RuntimeError("OpenCV is required. Install: pip install opencv-python")

    bits = max(8, ((args.secret_bits + 7) // 8) * 8)
    rows = args.rows
    cols = math.ceil(bits / rows) if args.cols is None else args.cols
    total_cells = rows * cols

    oracle = HiddenNumberOracle(
        target_number=args.n,
        bits=total_cells,
        custom_data=args.custom_data
    )

    recogniser = SynchronizedTensorRecogniser(
        bits=total_cells,
        salt=oracle.public_parameters()["salt"],
        commitment=oracle.public_parameters()["commitment"],
        difficulty=args.difficulty,
        max_candidates=args.max_candidates
    )

    source = SyntheticSource()

    print("\n========== SYNCHRONIZED TENSOR POW RECOVERY PIPELINE ==========")
    print(f"Target N             : {oracle.hidden_number}")
    print(f"Number width         : {bits} bits")
    print(f"Tensor Grid (2D)     : {rows} x {cols}")
    print(f"Custom Input Data    : {oracle.data_input}")
    print(f"Generated SHA256     : {oracle.digest_hex}")
    print(f"PoW Difficulty (0s)  : {args.difficulty}")
    print(f"Commitment           : {oracle.public_parameters()['commitment'].hex()}")

    oracle_bits = oracle.bit_vector()
    grid_image = create_folded_tensor_grid(oracle_bits, rows, cols, cell_size=args.cell_size)

    progress = tqdm(range(args.cycles), desc="Synchronizing tensor frames & mining PoW", unit="frame")
    for _ in progress:
        frame = source.read(grid_image)

        observed_bits, valid, _ = parallel_folded_tensor_pool(
            frame, rows, cols, args.threshold
        )
        
        # Apply controlled simulation noise and reveal masks
        reveal_mask = np.random.random(total_cells) < args.reveal
        noise_mask = np.random.random(total_cells) < args.noise
        observed_bits = observed_bits ^ noise_mask.astype(np.uint8)
        valid = valid & reveal_mask

        recogniser.observe(observed_bits, valid)
        progress.set_postfix(
            known=recogniser.known_count,
            unknown=recogniser.unknown_count,
            tested=recogniser.candidates_tested,
            pow_solved=recogniser.pow_solved_count
        )

        if recogniser.recovered is not None:
            break

    source.close()

    print("\n========== RECOGNISER RESULT ==========")
    if recogniser.proof:
        proof = recogniser.proof
        print("RECOVERY SUCCESSFUL (SYNCHRONIZED)")
        print(f"Recovered Nonce      : {proof['hidden_number']}")
        print(f"Discovery Method     : {proof['discovery_method']}")
        print(f"Candidates Tested    : {proof['candidates_tested']}")
        print(f"PoW Solutions Found  : {proof['pow_solutions_found']}")
        print(f"Cycles Used          : {proof['cycles_used']}")
        print(f"Verified PoW Hash    : {proof['candidate_digest_hex']}")
        
        revealed = oracle.reveal_if_proven(recogniser.recovered)
        if revealed:
            print(f"Prime factors        : {revealed['prime_factors']}")
            print("MATCH: Tensor synchronization and Proof-of-Work validation completed successfully.")
    else:
        print("FAILED: Recovery limit reached without synchronization. Try increasing --cycles or lowering --noise.")


def main():
    parser = argparse.ArgumentParser(description="Synchronized folded-space tensor recovery with adaptive thresholding")
    parser.add_argument("--n", type=int, default=None)
    parser.add_argument("--secret-bits", type=int, default=64)
    parser.add_argument("--custom-data", type=str, default="hello world")
    parser.add_argument("--difficulty", type=int, default=2, help="Required leading zero hex characters")
    parser.add_argument("--cycles", type=int, default=1200)
    parser.add_argument("--reveal", type=float, default=0.60)
    parser.add_argument("--noise", type=float, default=0.01)
    parser.add_argument("--max-candidates", type=int, default=500000)
    parser.add_argument("--rows", type=int, default=8)
    parser.add_argument("--cols", type=int, default=None)
    parser.add_argument("--cell-size", type=int, default=24)
    parser.add_argument("--threshold", type=float, default=127.0)
    run(parser.parse_args())


if __name__ == "__main__":
    main()
