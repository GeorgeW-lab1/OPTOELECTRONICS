import csv
import hashlib
import json
import time
from typing import Optional

import numpy as np


class PhotonicCameraRecovery:
    """
    Camera-based photonic recovery of the unknown input to a SHA-256 target:

        target = SHA256(known_data || frame_bytes)

    The unknown input is the spatial pattern of lit pixels in a (rows x cols)
    sensor frame. Source is AND-gated (pixel i lights only if K_i = 1, with
    probability p per exposure). Recovery is O(n): accumulate lit pixels and
    hash only when a new pixel appears.

    run() records EVERYTHING about the process and returns it as a dict:
      config, target, per-event log, per-chunk stats, detection/noise stats,
      recovered frame, ground-truth comparison, theory vs. observed, timing.
    """

    def __init__(self, pattern: np.ndarray, known_data: bytes, p: float = 0.01,
                 noise_sigma: float = 0.08, seed: Optional[int] = None):
        self.secret = (np.asarray(pattern) > 0).astype(np.uint8)
        self.shape = self.secret.shape
        self.n = self.secret.size
        self.k = int(self.secret.sum())
        self.p = p
        self.noise_sigma = noise_sigma
        self.known_data = known_data
        self.seed = seed
        self.rng = np.random.default_rng(seed)
        self.target = self._digest(self.secret)

    def _digest(self, frame: np.ndarray) -> str:
        return hashlib.sha256(self.known_data + frame.astype(np.uint8).tobytes()).hexdigest()

    def expose(self, count: int) -> np.ndarray:
        R = self.rng.random((count, self.n)) < self.p
        X = R & self.secret.reshape(1, -1).astype(bool)
        S = X.astype(np.float32) + self.rng.normal(0, self.noise_sigma, X.shape).astype(np.float32)
        return S > 0.5

    def show(self, frame: np.ndarray) -> str:
        return "\n".join("".join("#" if v else "." for v in row) for row in frame)

    def run(self, max_frames: int = 5_000_000, chunk: int = 4096, verbose: bool = True) -> dict:
        t_start = time.time()
        lit = np.zeros(self.n, dtype=np.uint8)
        secret_flat = self.secret.reshape(-1).astype(bool)

        events, chunks = [], []
        per_pixel_clicks = np.zeros(self.n, dtype=np.int64)   # total detections per pixel
        false_pos = 0                                         # clicks on pixels where K_i = 0
        total_clicks = 0
        frames_done = 0
        hashes = 0
        recovered = False
        recovered_frame = None
        recovered_at = None

        while frames_done < max_frames and not recovered:
            c = min(chunk, max_frames - frames_done)
            D = self.expose(c)

            clicks_per_pixel = D.sum(axis=0)
            per_pixel_clicks += clicks_per_pixel
            chunk_clicks = int(clicks_per_pixel.sum())
            chunk_fp = int(clicks_per_pixel[~secret_flat].sum())
            total_clicks += chunk_clicks
            false_pos += chunk_fp

            first_hit = np.where(D.any(axis=0), D.argmax(axis=0), -1)
            new_pixels = sorted((i for i in range(self.n) if first_hit[i] >= 0 and not lit[i]),
                                key=lambda i: first_hit[i])

            for i in new_pixels:
                lit[i] = 1
                m = frames_done + int(first_hit[i]) + 1
                hashes += 1
                digest = self._digest(lit.reshape(self.shape))
                ok = digest == self.target
                ev = {
                    "frame": m,
                    "pixel": int(i),
                    "row": int(i // self.shape[1]),
                    "col": int(i % self.shape[1]),
                    "lit_count": int(lit.sum()),
                    "hash_count": hashes,
                    "digest": digest,
                    "matches_target": bool(ok),
                    "true_pixel": bool(secret_flat[i]),
                    "elapsed_s": round(time.time() - t_start, 6),
                }
                events.append(ev)
                if verbose:
                    print(f"frame m={m:8d} | lit={ev['lit_count']:2d}/{self.n} | "
                          f"pixel {i:2d} (r{ev['row']},c{ev['col']}) | hashes={hashes} | match={ok}")
                if ok:
                    recovered, recovered_at = True, m
                    recovered_frame = lit.reshape(self.shape).copy()
                    break

            chunks.append({
                "frames_start": frames_done + 1,
                "frames_end": frames_done + c,
                "clicks": chunk_clicks,
                "false_positive_clicks": chunk_fp,
                "new_pixels": len(new_pixels),
                "lit_after_chunk": int(lit.sum()),
            })
            frames_done += c

        frames_used = recovered_at if recovered else frames_done
        harmonic = sum(1.0 / j for j in range(1, self.k + 1))
        elapsed = time.time() - t_start

        result = {
            "config": {
                "shape": list(self.shape), "n_pixels": self.n, "k_lit_true": self.k,
                "p": self.p, "noise_sigma": self.noise_sigma, "seed": self.seed,
                "known_data": self.known_data.decode("utf-8", "replace"),
                "max_frames": max_frames, "chunk": chunk,
            },
            "target_hash": self.target,
            "recovered": recovered,
            "recovered_at_frame": recovered_at,
            "hashes_computed": hashes,
            "frames_exposed": frames_done,
            "frames_used": frames_used,
            "recovered_frame": recovered_frame.tolist() if recovered else None,
            "recovered_frame_ascii": self.show(recovered_frame) if recovered else None,
            "recovered_digest": self._digest(recovered_frame) if recovered else None,
            "ground_truth_match": bool(recovered and np.array_equal(recovered_frame, self.secret)),
            "ground_truth_ascii": self.show(self.secret),
            "detection_stats": {
                "total_clicks": total_clicks,
                "false_positive_clicks": false_pos,
                "clicks_per_pixel": per_pixel_clicks.reshape(self.shape).tolist(),
                "observed_rate_per_true_pixel": (
                    float(per_pixel_clicks[secret_flat].sum() / (frames_done * self.k))
                    if frames_done and self.k else None),
            },
            "theory": {
                "expected_exposures_Hk_over_p": harmonic / self.p if self.p else None,
                "observed_over_expected": (frames_used / (harmonic / self.p)) if self.p else None,
                "max_hashes_bound_n": self.n,
            },
            "timing_s": round(elapsed, 4),
            "events": events,
            "chunk_stats": chunks,
        }

        if verbose:
            print()
            print("RECOVERED" if recovered else "NOT RECOVERED",
                  f"| frame={frames_used} | hashes={hashes} | time={elapsed:.2f}s")
            if recovered:
                print(result["recovered_frame_ascii"])
                print("Digest :", result["recovered_digest"])
                print("Target :", self.target)
                print("Ground-truth match:", result["ground_truth_match"])
            print(f"Expected ~H_k/p = {result['theory']['expected_exposures_Hk_over_p']:.0f} frames; "
                  f"clicks={total_clicks}, false positives={false_pos}")
        return result


def export(result: dict, prefix: str = "photonic_run") -> None:
    with open(f"{prefix}.json", "w") as f:
        json.dump(result, f, indent=2)
    if result["events"]:
        with open(f"{prefix}_events.csv", "w", newline="") as f:
            w = csv.DictWriter(f, fieldnames=list(result["events"][0].keys()))
            w.writeheader()
            w.writerows(result["events"])
    with open(f"{prefix}_chunks.csv", "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(result["chunk_stats"][0].keys()))
        w.writeheader()
        w.writerows(result["chunk_stats"])
    print(f"Saved {prefix}.json, {prefix}_events.csv, {prefix}_chunks.csv")


if __name__ == "__main__":
    # 4x8 = 32-pixel spatial pattern (edit freely)
    PATTERN = np.array([[int(c) for c in row] for row in (
        
        "1",
    )])

    sim = PhotonicCameraRecovery(PATTERN, known_data=b"George Wagenknecht - 2026",
                                 p=0.00006, seed=42)
    result = sim.run(max_frames=5_000_000)
    export(result)
