def candidate(R0,R1,R2,R3):
    outputs=[]
    steps=0
    if steps==0: pass
    score=(sum(outputs)+R0*7)%100 if outputs else R3%100
    return score, outputs, steps