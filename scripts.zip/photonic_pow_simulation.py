import hashlib
import string
import time
from typing import Optional, Sequence, Union

import numpy as np


class PhotonicCameraRecovery:
    """
    Recovery pipeline:

    1. Simulate AND-gated photon leakage.
    2. Recover the 1/0 frame from the SHA-256 target.
    3. Recover a clipped KNOWN_DATA prefix by enumerating its unknown
       bytes directly with a manual odometer.

    No itertools and no hardcoded clip lists.
    """

    def __init__(
        self,
        pattern,
        known_data: bytes,
        p: float = 0.001,
        noise_sigma: float = 0.08,
        visible: Optional[Sequence[int]] = None,
        seed=None,
    ):
        self.secret = (np.asarray(pattern) > 0).astype(np.uint8)
        self.shape = self.secret.shape
        self.n = self.secret.size

        self.p = p
        self.sigma = noise_sigma
        self.known = known_data
        self.rng = np.random.default_rng(seed)

        visible = np.arange(self.n) if visible is None else np.asarray(visible)
        self.mask = np.zeros(self.n, dtype=bool)
        self.mask[visible] = True

        self.hidden = np.flatnonzero(~self.mask)
        self.target = self.digest(self.known, self.secret.ravel())

    @staticmethod
    def _to_bytes(value: Union[bytes, np.ndarray]) -> bytes:
        if isinstance(value, bytes):
            return value
        return np.asarray(value, dtype=np.uint8).tobytes()

    def digest(self, known: bytes, frame) -> str:
        return hashlib.sha256(
            self._to_bytes(known) + self._to_bytes(frame)
        ).hexdigest()

    def _try_hidden(self, lit: np.ndarray) -> Optional[np.ndarray]:
        """Brute-force hidden frame pixels with a manual binary counter."""
        base = lit.copy()
        hidden_count = len(self.hidden)

        if hidden_count == 0:
            if self.digest(self.known, base) == self.target:
                return base.copy()
            return None

        bits = [0] * hidden_count

        while True:
            base[self.hidden] = bits

            if self.digest(self.known, base) == self.target:
                return base.copy()

            index = 0
            while index < hidden_count and bits[index] == 1:
                bits[index] = 0
                index += 1

            if index == hidden_count:
                break

            bits[index] = 1

        return None

    def _check(self, lit: np.ndarray) -> Optional[np.ndarray]:
        """Try exact visible estimate, then tolerate one false visible click."""
        recovered = self._try_hidden(lit)
        if recovered is not None:
            return recovered

        for i in np.flatnonzero(lit & self.mask):
            trial = lit.copy()
            trial[i] = 0

            recovered = self._try_hidden(trial)
            if recovered is not None:
                return recovered

        return None

    def recover_frame(
        self,
        max_frames: int = 5_000_000,
        chunk: int = 4096,
        min_hits: int = 1,
    ):
        """Recover the binary frame from accumulated photon-click evidence."""
        illuminated_visible = (
            self.secret.ravel().astype(bool) & self.mask
        ).astype(float)

        hits = np.zeros(self.n, dtype=np.int64)
        previous_lit = None

        for done in range(0, max_frames, chunk):
            count = min(chunk, max_frames - done)

            clicks = (
                self.rng.random((count, self.n)) < self.p
            ).astype(float)

            # AND gate: illumination AND visibility.
            signal = clicks * illuminated_visible
            signal += self.rng.normal(0, self.sigma, size=(count, self.n))

            hits += (signal > 0.5).sum(axis=0)
            lit = (hits >= min_hits).astype(np.uint8)

            if previous_lit is None or (lit != previous_lit).any():
                recovered = self._check(lit)

                if recovered is not None:
                    return recovered.reshape(self.shape), done + count

            previous_lit = lit

        return None, max_frames

    def recover_known_data_bytes(
        self,
        frame,
        length: int,
        charset: bytes,
        max_candidates: Optional[int] = None,
    ):
        """
        Recover KNOWN_DATA as exactly `length` bytes drawn from `charset`.

        This applies the hidden-byte idea directly to KNOWN_DATA:
        enumerate byte values position by position using a manual odometer.

        Example:
            length = 3
            charset = printable letters/digits/space/hyphen
            candidate = b"GW6"
        """
        frame_bytes = self._to_bytes(frame)
        charset = bytes(sorted(set(charset)))
        base = len(charset)

        total = base ** length
        if max_candidates is not None and total > max_candidates:
            raise RuntimeError(
                f"Search space {total} exceeds limit {max_candidates}."
            )

        indices = [0] * length
        candidates_tested = 0

        while True:
            candidate = bytes(charset[i] for i in indices)
            candidates_tested += 1

            if self.digest(candidate, frame_bytes) == self.target:
                return candidate, candidates_tested

            # Manual odometer increment: rightmost byte changes first.
            position = length - 1

            while position >= 0:
                indices[position] += 1

                if indices[position] < base:
                    break

                indices[position] = 0
                position -= 1

            if position < 0:
                break

        return None, candidates_tested


if __name__ == "__main__":
    SECRET_PATTERN = np.array(
        [
            [1, 0, 1, 1, 0, 0, 1, 0],
            [0, 1, 0, 0, 1, 1, 0, 1],
            [1, 1, 1, 0, 0, 0, 0, 1],
            [0, 0, 0, 1, 1, 1, 1, 0],
        ],
        dtype=np.uint8,
    )

    # Short clipped KNOWN_DATA used to demonstrate byte-level recovery.
    KNOWN_DATA = b"George Wagenkencht - 2026"

    recovery = PhotonicCameraRecovery(
        pattern=SECRET_PATTERN,
        known_data=KNOWN_DATA,
        p=0.001,
        noise_sigma=0.08,
        visible=np.arange(24),
        seed=42,
    )

    print("SHA-256 target:")
    print(recovery.target)

    # Step 1: recover the 1/0 frame.
    start = time.time()
    recovered_frame, frames_used = recovery.recover_frame()
    elapsed = time.time() - start

    print("\nFrame recovery")
    print("  recovered:", recovered_frame is not None)
    print("  frames needed:", frames_used)
    print(f"  elapsed: {elapsed:.3f}s")
    print(recovered_frame)

    # Step 2: recover KNOWN_DATA by enumerating its bytes directly.
    charset = (
        string.ascii_letters
        + string.digits
        + " -"
    ).encode()

    start = time.time()
    recovered_known_data, candidates_tested = (
        recovery.recover_known_data_bytes(
            frame=recovered_frame,
            length=3,
            charset=charset,
        )
    )
    elapsed = time.time() - start

    print("\nKNOWN_DATA recovery")
    print("  recovered:", recovered_known_data)
    print("  candidates tested:", candidates_tested)
    print(f"  elapsed: {elapsed:.3f}s")
    print("  matches original:", recovered_known_data == KNOWN_DATA)
