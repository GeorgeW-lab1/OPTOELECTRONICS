#!/usr/bin/env python3
"""
linesort.py - sort line-per-line text datasets (one integer / one string per line).

  ints     : one integer per line   -> int64 array -> parallel sample-sort (fastsort.py)
             (integers beyond int64 fall back to Python big-int sort)
  strings  : one string per line    -> bytewise (UTF-8 / memcmp) order, like `LC_ALL=C sort`

Add --optical to route the data through the paper's pipeline (optical_sort.py) first:
  ints    : each int64 is a 8x8 grid record, recovered + verified against SHA-256 commitments.
  strings : each string is cut into 8-byte words, every word is a verified 8x8 record, strings
            are reassembled. Lengths are treated as public side-information (like the grid size).
            Any string with an unverified word is excluded and reported.

Options: --desc, --unique, --ignore-case (strings).
Raw conversion for ints:  to-raw (text -> int64 raw)   from-raw (int64 raw -> text).

  python linesort.py gen ints    ints.txt --n 1_000_000
  python linesort.py gen strings words.txt --n 200_000
  python linesort.py ints    ints.txt  sorted.txt [--desc] [--unique] [--optical]
  python linesort.py strings words.txt sorted.txt [--ignore-case] [--optical]
  python linesort.py bench ints|strings --n 100_000 [--optical]
"""
import argparse, os, sys, time
import numpy as np
from fastsort import save_raw, load_raw, parallel_sort
import optical_sort as ops


# ------------------------------------------------------------------ ints
def load_ints(path):
    """One integer per line. Returns int64 ndarray, or a Python list if values overflow int64."""
    raw = open(path, "rb").read()
    if not raw.strip():
        return np.empty(0, np.int64)
    try:
        arr = np.fromstring(raw.decode("ascii"), dtype=np.int64, sep="\n")
        info = np.iinfo(np.int64)
        saturated = arr.size and (arr.max() == info.max or arr.min() == info.min)
        quick = raw.count(b"\n") + (0 if raw.endswith(b"\n") else 1)
        if not saturated:                           # NumPy clamps overflowing values to the limits
            if arr.size == quick:                   # no blank lines, nothing truncated
                return arr
            toks = raw.split()
            if arr.size == len(toks):
                return arr
        toks = raw.split()
    except (ValueError, UnicodeDecodeError, DeprecationWarning):
        toks = raw.split()
    vals = [int(t) for t in toks]                   # raises on genuinely bad lines
    try:
        return np.array(vals, dtype=np.int64)
    except OverflowError:
        return vals


def save_ints(path, arr):
    seq = arr.tolist() if isinstance(arr, np.ndarray) else arr
    with open(path, "w") as f:
        f.write("\n".join(map(str, seq)))
        if len(seq):
            f.write("\n")


def sort_ints(arr, desc=False, unique=False, optical=False, chan=None, threads=None):
    if isinstance(arr, list):                       # big ints: no vector path, no optical
        if optical:
            print("note: values exceed int64, optical stage skipped", file=sys.stderr)
        out = sorted(set(arr) if unique else arr, reverse=desc)
        return out
    if optical:
        out, done, _ = ops.run_arrays(arr, threads=threads, **(chan or {}))
    else:
        out = parallel_sort(arr, threads)
    if unique and out.size:
        out = out[np.concatenate(([True], out[1:] != out[:-1]))]
    return out[::-1].copy() if desc else out


# ------------------------------------------------------------------ strings
def load_lines(path):
    """Returns (list of bytes lines, crlf flag)."""
    raw = open(path, "rb").read()
    lines = raw.split(b"\n")
    if lines and lines[-1] == b"":
        lines.pop()
    crlf = bool(lines) and all(l.endswith(b"\r") for l in lines)
    if crlf:
        lines = [l[:-1] for l in lines]
    return lines, crlf, b"\x00" in raw


def save_lines(path, lines, crlf=False):
    nl = b"\r\n" if crlf else b"\n"
    with open(path, "wb") as f:
        if lines:
            f.write(nl.join(lines)); f.write(nl)


def _bytewise_sort(lines, has_nul, threads):
    """Fast bytewise sort. NumPy 'S' arrays use memcmp order (needs no NUL bytes);
    chunked sample-sort across threads, else Python's list sort."""
    n = len(lines)
    if n >= 200_000 and not has_nul:
        w = max(map(len, lines))
        if 0 < w <= 128 and w * n <= 1_500_000_000:
            return parallel_sort(np.array(lines, dtype=f"S{w}"), threads).tolist()
    lines = list(lines)
    lines.sort()
    return lines


def _optical_roundtrip(lines, chan, threads):
    """Strings -> 8-byte words -> optical recovery (verified) -> strings. Returns (lines, n_lost)."""
    n = len(lines)
    lens = np.fromiter(map(len, lines), np.int64, n)
    nw = (lens + 7) // 8
    total = int(lens.sum())
    pad = np.zeros(int(nw.sum()) * 8, np.uint8)
    if total:
        src = np.frombuffer(b"".join(lines), np.uint8)
        dst_start = np.cumsum(nw * 8) - nw * 8
        src_start = np.cumsum(lens) - lens
        dest = np.repeat(dst_start - src_start, lens) + np.arange(total)
        pad[dest] = src
    words = pad.view(">u8").astype(np.uint64)
    if not words.size:
        return lines, 0
    rec, done, _ = ops.run_arrays(words, sort=False, threads=threads, **(chan or {}))
    sid = np.repeat(np.arange(n), nw)
    bad = np.bincount(sid[~done], minlength=n) > 0
    buf = rec.astype(">u8").view(np.uint8)
    out_b = buf[dest].tobytes() if total else b""
    offs = np.cumsum(lens) - lens
    out = [out_b[o:o + l] for o, l, b in zip(offs.tolist(), lens.tolist(), bad.tolist()) if not b]
    return out, int(bad.sum())


def sort_strings(lines, has_nul=False, desc=False, unique=False, ignore_case=False,
                 optical=False, chan=None, threads=None):
    lost = 0
    if optical:
        lines, lost = _optical_roundtrip(lines, chan, threads)
        if lost:
            print(f"WARNING: {lost:,} strings excluded (unverified words)", file=sys.stderr)
    if ignore_case:
        out = sorted(lines, key=bytes.lower)
    else:
        out = _bytewise_sort(lines, has_nul, threads)
    if unique:
        key = bytes.lower if ignore_case else (lambda x: x)
        res, prev = [], None
        for l in out:
            k = key(l)
            if k != prev:
                res.append(l); prev = k
        out = res
    if desc:
        out.reverse()
    return out


# ------------------------------------------------------------------ generators
def gen_ints(n, seed=0):
    return np.random.default_rng(seed).integers(-10**12, 10**12, n, dtype=np.int64)


def gen_strings(n, seed=0):
    rng = np.random.default_rng(seed)
    lens = rng.integers(3, 21, n)
    chars = rng.integers(97, 123, (n, 20), dtype=np.uint8)
    return [chars[i, :lens[i]].tobytes() for i in range(n)]


# ------------------------------------------------------------------ CLI
def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawTextHelpFormatter)
    sp = ap.add_subparsers(dest="cmd", required=True)
    num = lambda s: int(s.replace("_", ""))

    def common(p, strings):
        p.add_argument("--desc", action="store_true"); p.add_argument("--unique", action="store_true")
        if strings:
            p.add_argument("--ignore-case", action="store_true")
        p.add_argument("--optical", action="store_true", help="recover via optical pooling pipeline first")
        p.add_argument("--mode", choices=["bit", "pixel"], default="bit")
        p.add_argument("--r", type=float, default=0.45); p.add_argument("--eps", type=float, default=0.02)
        p.add_argument("--sigma", type=float, default=40.0); p.add_argument("--block", type=int, default=16)
        p.add_argument("--tmax", type=int, default=800)
        p.add_argument("--chase-L", type=int, default=12); p.add_argument("--chase-t", type=int, default=2)
        p.add_argument("--qmax", type=int, default=20_000); p.add_argument("--seed", type=int, default=0)
        p.add_argument("--threads", type=int)

    g = sp.add_parser("gen"); g.add_argument("kind", choices=["ints", "strings"]); g.add_argument("path"); g.add_argument("--n", type=num, default=100_000); g.add_argument("--seed", type=int, default=0)
    pi = sp.add_parser("ints"); pi.add_argument("src"); pi.add_argument("dst"); common(pi, False)
    ps = sp.add_parser("strings"); ps.add_argument("src"); ps.add_argument("dst"); common(ps, True)
    b = sp.add_parser("bench"); b.add_argument("kind", choices=["ints", "strings"]); b.add_argument("--n", type=num, default=100_000); common(b, True)
    tr = sp.add_parser("to-raw"); tr.add_argument("src"); tr.add_argument("dst")
    fr = sp.add_parser("from-raw"); fr.add_argument("src"); fr.add_argument("dst"); fr.add_argument("--dtype", default="int64")
    a = ap.parse_args()

    chan = lambda: dict(mode=a.mode, r=a.r, eps=a.eps, sigma=a.sigma, block=a.block,
                        T_max=a.tmax, L=a.chase_L, t=a.chase_t, qmax=a.qmax, seed=a.seed)

    if a.cmd == "gen":
        if a.kind == "ints":
            save_ints(a.path, gen_ints(a.n, a.seed))
        else:
            save_lines(a.path, gen_strings(a.n, a.seed))
        print(f"wrote {a.n:,} {a.kind} -> {a.path}")
    elif a.cmd == "to-raw":
        arr = load_ints(a.src)
        save_raw(np.asarray(arr, dtype=np.int64), a.dst); print(f"{len(arr):,} ints -> {a.dst} (int64 raw)")
    elif a.cmd == "from-raw":
        arr = load_raw(a.src, a.dtype); save_ints(a.dst, arr); print(f"{len(arr):,} ints -> {a.dst}")
    elif a.cmd == "ints":
        arr = load_ints(a.src); t = time.perf_counter()
        out = sort_ints(arr, a.desc, a.unique, a.optical, chan(), a.threads)
        dt = time.perf_counter() - t
        save_ints(a.dst, out); print(f"sorted {len(out):,} ints in {dt:.3f}s -> {a.dst}")
    elif a.cmd == "strings":
        lines, crlf, nul = load_lines(a.src); t = time.perf_counter()
        out = sort_strings(lines, nul, a.desc, a.unique, a.ignore_case, a.optical, chan(), a.threads)
        dt = time.perf_counter() - t
        save_lines(a.dst, out, crlf); print(f"sorted {len(out):,} strings in {dt:.3f}s -> {a.dst}")
    else:                                            # bench: text round trip through temp files
        import tempfile
        with tempfile.TemporaryDirectory() as d:
            src, dst = os.path.join(d, "in.txt"), os.path.join(d, "out.txt")
            if a.kind == "ints":
                save_ints(src, gen_ints(a.n, a.seed))
                arr = load_ints(src); ref = sorted(arr.tolist())
                t = time.perf_counter(); out = sort_ints(arr, a.desc, a.unique, a.optical, chan(), a.threads); dt = time.perf_counter() - t
                save_ints(dst, out); got = load_ints(dst).tolist()
                ref = sorted(set(ref)) if a.unique else ref
                ref = ref[::-1] if a.desc else ref
            else:
                save_lines(src, gen_strings(a.n, a.seed))
                lines, crlf, nul = load_lines(src)
                key = bytes.lower if a.ignore_case else None
                ref = sorted(lines, key=key)
                t = time.perf_counter(); out = sort_strings(lines, nul, a.desc, a.unique, a.ignore_case, a.optical, chan(), a.threads); dt = time.perf_counter() - t
                save_lines(dst, out, crlf); got = load_lines(dst)[0]
                if a.unique:
                    seen, r2 = None, []
                    for l in ref:
                        k = l.lower() if a.ignore_case else l
                        if k != seen: r2.append(l); seen = k
                    ref = r2
                ref = ref[::-1] if a.desc else ref
            ok = (got == ref) if not a.ignore_case else ([x.lower() for x in got] == [x.lower() for x in ref])
            print(f"{a.kind}: n={a.n:,} sort {dt:.3f}s | text round-trip verified vs Python: {'OK' if ok else 'MISMATCH'}")


if __name__ == "__main__":
    main()
