import hashlib
import heapq
import json
import math
import threading
import time
import queue
import tkinter as tk
from tkinter import messagebox
from collections import deque

import numpy as np

try:
    import pyautogui
    HAS_PYAUTOGUI = True
    pyautogui.FAILSAFE = True
    pyautogui.PAUSE = 0.02
except ImportError:
    HAS_PYAUTOGUI = False


# ============================================================================
# KEYBOARD OUTPUT
# ============================================================================

ENABLE_KEYBOARD = True

KEY_HIGH = ("shift", "w")
KEY_LOW = ("shift", "s")

KEYBOARD_ONLY_AFTER_ARM = True
KEYBOARD_REQUIRE_CONFIDENCE = True
KEYBOARD_MIN_DELTA = 0.01
KEYBOARD_COOLDOWN = 0.0

_last_keyboard_action = 0.0


# ============================================================================
# CONFIGURATION
# ============================================================================

LAMBDA = 10000.0
SIGMA_C = 0.005

N_SLOTS = 32
FIELD_BITS = 16
PRICE_DELTA_SCALE = 100.0

REVEAL_DELAY = 2.8

N_WINDOWS = 2000
N_PERMS = 100
REPORT_EVERY = 25

LEADS = (0, 1, 2, 3, 4)

N_SIGMA = 5.0
MIN_CYCLES = 40
ROLL_CYCLES = 400

Z_MIN = 4.0
JOINT_CONF_MIN = 0.999

DELTA_BUF_LEN = 64
MIN_BUF = 64
ENTROPY_MAX_BITS = 0.25
STREAK = 5
MIN_ABS_DELTA = 2.0


# ============================================================================
# HELPERS
# ============================================================================

def format_clock_time(timestamp_ns):
    seconds = timestamp_ns / 1e9
    clock = time.strftime("%H:%M:%S", time.localtime(seconds))
    ms = int((timestamp_ns % 1_000_000_000) // 1_000_000)
    return f"{clock}.{ms:03d}"


def noise_stats(lambd, sigma_c):
    shared = sigma_c ** 2 * lambd
    var_z = 1.0 + shared
    return var_z, math.sqrt(var_z), shared / var_z


def phi(z):
    return 0.5 * (1.0 + math.erf(z / math.sqrt(2.0)))


def sign_entropy(values):
    n = len(values)

    if not n:
        return 0.0, (0, 0, 0)

    counts = (
        sum(x > 0 for x in values),
        sum(x < 0 for x in values),
        sum(x == 0 for x in values),
    )

    h = 0.0

    for c in counts:
        if c:
            p = c / n
            h -= p * math.log2(p)

    return h, counts


# ============================================================================
# 32-BIT PAYLOAD
# ============================================================================

def timestamp_to_code(timestamp_ns):
    ms = (int(timestamp_ns) // 1_000_000) % 60000
    return ms & 0xFFFF


def price_delta_to_code(price_delta):
    cents = int(round(float(price_delta) * PRICE_DELTA_SCALE))
    cents = max(-32768, min(32767, cents))
    return cents & 0xFFFF


def code_to_signed_price_delta(code):
    value = int(code) & 0xFFFF

    if value >= 0x8000:
        value -= 0x10000

    return value / PRICE_DELTA_SCALE


def encode_payload_bits(timestamp_ns, price_delta):
    time_code = timestamp_to_code(timestamp_ns)
    delta_code = price_delta_to_code(price_delta)

    time_bits = [
        (time_code >> (15 - k)) & 1
        for k in range(16)
    ]

    delta_bits = [
        (delta_code >> (15 - k)) & 1
        for k in range(16)
    ]

    return np.array(time_bits + delta_bits, dtype=int)


def bits_to_code(bits):
    code = 0

    for bit in bits:
        code = (code << 1) | (int(bit) & 1)

    return code


def decode_payload_bits(bits):
    bits = np.asarray(bits, dtype=int).flatten()

    if len(bits) != N_SLOTS:
        raise ValueError("Invalid payload length")

    timestamp_code = bits_to_code(bits[:16])
    delta_code = bits_to_code(bits[16:])

    return (
        timestamp_code,
        code_to_signed_price_delta(delta_code)
    )


def decode_timestamp_from_code(code, reference_ns):
    minute_start = (
        int(reference_ns) // 60_000_000_000
    ) * 60_000_000_000

    decoded_ns = minute_start + (int(code) & 0xFFFF) * 1_000_000

    return decoded_ns, format_clock_time(decoded_ns)


def make_payload_tilt(bits, eps_abs):
    bits = np.asarray(bits, dtype=float)
    strength = max(float(eps_abs), 0.25)

    return 2.0 * strength * (bits - 0.5)


# ============================================================================
# OPTICAL CHANNEL
# ============================================================================

class OptoelectronicViewport:

    def __init__(self, lambd=LAMBDA, sigma_c=SIGMA_C):
        self.lambd = lambd
        self.sigma_c = sigma_c

        print("[OPTICAL] Synthetic photon-counting channel initialized")

    def generate_window_block(self, n_windows, n_slots, tilt=None):

        shared_noise = np.random.normal(
            0.0,
            self.sigma_c,
            size=(n_windows, 1)
        )

        lam = self.lambd * (1.0 + shared_noise)

        counts = np.random.poisson(
            np.clip(lam, 1.0, None),
            size=(n_windows, n_slots)
        )

        Z = (
            counts - self.lambd
        ) / np.sqrt(self.lambd)

        if tilt is not None:
            Z += tilt

        return Z


# ============================================================================
# ASYNCHRONOUS INPUT QUEUE
# ============================================================================

class TextInputSource:

    def __init__(self):
        self.values = queue.SimpleQueue()

    def submit(self, value):
        self.values.put({
            "price": float(value),
            "received_ns": time.time_ns()
        })

    def get(self, timeout=0.1):
        try:
            return self.values.get(timeout=timeout)
        except queue.Empty:
            return None



# ============================================================================
# ASYNCHRONOUS FORCED REVEAL SCHEDULER
# ============================================================================

class AsyncRevealScheduler(threading.Thread):

    def __init__(self, output_queue):

        super().__init__(daemon=True)

        self.output_queue = output_queue
        self.condition = threading.Condition()
        self.pending = []

        self.sequence = 0
        self.running = True

    def schedule(self, delay_seconds, callback):

        due_perf_ns = (
            time.perf_counter_ns()
            + int(delay_seconds * 1e9)
        )

        due_wall_ns = (
            time.time_ns()
            + int(delay_seconds * 1e9)
        )

        with self.condition:

            self.sequence += 1

            heapq.heappush(
                self.pending,
                (
                    due_perf_ns,
                    self.sequence,
                    due_wall_ns,
                    callback
                )
            )

            self.condition.notify()

        return due_wall_ns

    def run(self):

        while self.running:

            with self.condition:

                while self.running and not self.pending:
                    self.condition.wait()

                if not self.running:
                    break

                due_ns = self.pending[0][0]
                remaining = (
                    due_ns - time.perf_counter_ns()
                ) / 1e9

                if remaining > 0:
                    self.condition.wait(timeout=remaining)
                    continue

                item = heapq.heappop(self.pending)

            due_perf_ns, sequence, due_wall_ns, callback = item

            actual_perf_ns = time.perf_counter_ns()
            actual_wall_ns = time.time_ns()

            try:

                result = callback(
                    due_wall_ns,
                    actual_wall_ns
                )

                result["scheduled_reveal_ns"] = due_wall_ns
                result["actual_reveal_ns"] = actual_wall_ns
                result["actual_reveal_perf_ns"] = actual_perf_ns

                self.output_queue.put(result)

            except Exception as e:
                print(f"[REVEAL] Callback error: {e}")

    def stop(self):

        with self.condition:
            self.running = False
            self.condition.notify_all()


# ============================================================================
# LEAD-LAG RECORDS
# ============================================================================

class ArmRecord:

    def __init__(self, maxlen=ROLL_CYCLES):
        self.M = deque(maxlen=maxlen)
        self.Y = deque(maxlen=maxlen)

    def add(self, col_means, y_bits):
        self.M.append(np.asarray(col_means, dtype=float))
        self.Y.append(np.asarray(y_bits, dtype=float))

    def __len__(self):
        return len(self.M)


def lead_stats(arm, leads, n_slots, n_perms):

    C = len(arm)

    M = np.array(arm.M)
    Y = np.array(arm.Y)

    Mc = M - M.mean(axis=0)
    Yc = Y - Y.mean(axis=0)

    obs = {}
    den = {}

    for L in leads:

        x = Mc[:, :n_slots - L]
        y = Yc[:, L:]

        d = math.sqrt(
            float((x * x).sum() * (y * y).sum())
        )

        den[L] = d

        obs[L] = (
            float((x * y).sum() / d)
            if d >
