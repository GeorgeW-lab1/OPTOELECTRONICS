#!/usr/bin/env python3
"""RP NewTech Proof-of-Work — scientific PoW demo using the RP-SCIENCE v2 stack.

Combines:
- RP-SCIENCE v2 entropy/frame pipeline (synthetic or USB camera).
- SHA-256 proof-of-work mining with leading-zero-bit difficulty.
- Independent verification of every accepted solution.
- Scientific analysis: hash-count distribution, timing, hashrate, luck,
  confidence intervals, autocorrelation, and JSON/CSV artefacts.

No Tkinter.

Examples:
  python rp_newtech_pow.py --synthetic --difficulty 16 --rounds 10
  python rp_newtech_pow.py --device 0 --difficulty 18 --rounds 5
  python rp_newtech_pow.py --synthetic --difficulty 20 --rounds 3 --json newtech.json
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import secrets
import statistics
import sys
import time
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Iterator

import numpy as np

try:
    import cv2
except ImportError:
    cv2 = None

W, H = 128, 96
PROTOCOL = "RP-NEWTECH-POW-v1"


# ---------------------------------------------------------------------------
# Statistical utilities
# ---------------------------------------------------------------------------

def wilson_interval(successes: int, n: int, alpha: float = 0.05) -> tuple[float, float]:
    if n <= 0:
        return (0.0, 1.0)
    z = 1.959963984540054 if abs(alpha - 0.05) < 1e-12 else _normal_quantile(1 - alpha / 2)
    p = successes / n
    denom = 1 + z * z / n
    centre = (p + z * z / (2 * n)) / denom
    half = z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / denom
    return max(0.0, centre - half), min(1.0, centre + half)


def _normal_quantile(p: float) -> float:
    if not 0 < p < 1:
        raise ValueError("p must be between 0 and 1")
    return math.sqrt(2) * _inverse_erf(2 * p - 1)


def _inverse_erf(x: float) -> float:
    if x <= -1:
        return -math.inf
    if x >= 1:
        return math.inf
    a = 0.147
    ln = math.log(1 - x * x)
    first = 2 / (math.pi * a) + ln / 2
    return math.copysign(math.sqrt(math.sqrt(first * first - ln / a) - first), x)


def lag_autocorrelation(values: list[float], lag: int = 1) -> float:
    if len(values) <= lag:
        return 0.0
    a = np.asarray(values[:-lag], dtype=float)
    b = np.asarray(values[lag:], dtype=float)
    if np.std(a) == 0 or np.std(b) == 0:
        return 0.0
    return float(np.corrcoef(a, b)[0, 1])


def geometric_confidence_interval(successes: int, alpha: float = 0.05) -> tuple[float, float]:
    """Confidence interval for the geometric mean of hashes per success."""
    if successes <= 0:
        return (float("inf"), float("inf"))
    z = 1.959963984540054 if abs(alpha - 0.05) < 1e-12 else _normal_quantile(1 - alpha / 2)
    lower = successes / (successes + z * math.sqrt(successes))
    upper = successes / (successes - z * math.sqrt(successes))
    return lower, upper


# ---------------------------------------------------------------------------
# Entropy sources
# ---------------------------------------------------------------------------

class SyntheticEntropy:
    """Deterministic synthetic photon frames, suitable for repeatable demonstrations."""

    def __init__(self, seed: int = 20261110, level: float = 120.0):
        self.rng = np.random.default_rng(seed)
        self.level = level
        self.index = 0

    def next_frame(self) -> bytes:
        gray = np.clip(self.rng.poisson(self.level, size=(H, W)), 0, 255).astype(np.uint8)
        payload = gray.tobytes() + self.index.to_bytes(8, "big")
        self.index += 1
        return payload

    def close(self) -> None:
        pass


class CameraEntropy(SyntheticEntropy):
    """Live camera entropy. Camera frames seed the challenge; they are not trusted randomness."""

    def __init__(self, device: int = 0, warmup: int = 8):
        if cv2 is None:
            raise RuntimeError("Install OpenCV for camera entropy: pip install opencv-python")
        backend = cv2.CAP_DSHOW if sys.platform == "win32" else cv2.CAP_ANY
        self.cap = cv2.VideoCapture(device, backend)
        if not self.cap.isOpened():
            raise RuntimeError(f"Cannot open camera device {device}")
        for _ in range(warmup):
            self.cap.read()
        self.device = device

    def next_frame(self) -> bytes:
        ok, frame = self.cap.read()
        if not ok or frame is None:
            raise RuntimeError("Camera stopped delivering frames")
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        gray = cv2.resize(gray, (W, H), interpolation=cv2.INTER_AREA)
        payload = gray.tobytes() + self.index.to_bytes(8, "big")
        self.index += 1
        return payload

    def close(self) -> None:
        if self.cap is not None and self.cap.isOpened():
            self.cap.release()


# ---------------------------------------------------------------------------
# Proof of work
# ---------------------------------------------------------------------------

@dataclass
class PowRound:
    round_index: int
    entropy_sha256: str
    challenge: str
    difficulty_bits: int
    nonce: int | None
    digest: str | None
    hashes_tried: int
    elapsed_seconds: float
    hashes_per_second: float
    expected_hashes: float
    luck_ratio: float | None
    verified: bool
    nonce_commitment: str


class NewTechPow:
    def __init__(self, source: SyntheticEntropy, difficulty: int, max_hashes: int):
        if not 1 <= difficulty <= 32:
            raise ValueError("difficulty must be between 1 and 32 leading zero bits")
        if max_hashes < 1:
            raise ValueError("max-hashes must be positive")
        self.source = source
        self.difficulty = difficulty
        self.max_hashes = max_hashes

    @staticmethod
    def leading_zero_bits(digest: bytes) -> int:
        bits = 0
        for byte in digest:
            if byte:
                bits += (byte ^ (byte - 1)).bit_length() - 1
                return bits
            bits += 8
        return bits

    @staticmethod
    def meets_target(digest: bytes, difficulty: int) -> bool:
        if difficulty <= 0:
            return True
        full, remainder = divmod(difficulty, 8)
        if any(digest[:full]):
            return False
        if remainder:
            return digest[full] >> (8 - remainder) == 0
        return True

    def mine(self, round_index: int) -> PowRound:
        entropy = self.source.next_frame()
        entropy_digest = hashlib.sha256(entropy).digest()
        challenge = hashlib.sha256(b"RP-NEWTECH-POW|" + entropy_digest).digest()
        commitment = hashlib.sha256(challenge + secrets.token_bytes(16)).hexdigest()

        started = time.perf_counter()
        nonce = None
        digest = None
        hashes = 0

        for candidate in range(self.max_hashes):
            candidate_digest = hashlib.sha256(
                challenge + candidate.to_bytes(8, "big")
            ).digest()
            hashes += 1
            if self.meets_target(candidate_digest, self.difficulty):
                nonce = candidate
                digest = candidate_digest
                break

        elapsed = time.perf_counter() - started
        verified = False
        if nonce is not None:
            check = hashlib.sha256(challenge + nonce.to_bytes(8, "big")).digest()
            verified = check == digest and self.meets_target(check, self.difficulty)

        expected = float(2 ** self.difficulty)
        return PowRound(
            round_index=round_index,
            entropy_sha256=entropy_digest.hex(),
            challenge=challenge.hex(),
            difficulty_bits=self.difficulty,
            nonce=nonce,
            digest=digest.hex() if digest else None,
            hashes_tried=hashes,
            elapsed_seconds=elapsed,
            hashes_per_second=hashes / elapsed if elapsed > 0 else 0.0,
            expected_hashes=expected,
            luck_ratio=expected / hashes if hashes else None,
            verified=verified,
            nonce_commitment=commitment,
        )


# ---------------------------------------------------------------------------
# Analysis
# ---------------------------------------------------------------------------

def analyse(results: list[PowRound], alpha: float) -> dict:
    solved = [r for r in results if r.nonce is not None]
    hashes = [float(r.hashes_tried) for r in results]
    times = [r.elapsed_seconds for r in results]
    rates = [r.hashes_per_second for r in results]
    difficulty = results[0].difficulty_bits if results else 0
    expected = float(2 ** difficulty) if difficulty else 0.0

    successes = len(solved)
    solve_rate = successes / len(results) if results else 0.0
    ci = wilson_interval(successes, len(results), alpha)

    if solved:
        observed_geometric_mean = math.exp(
            sum(math.log(r.hashes_tried) for r in solved) / successes
        )
        ci_geo = geometric_confidence_interval(successes, alpha)
    else:
        observed_geometric_mean = None
        ci_geo = (float("inf"), float("inf"))

    return {
        "rounds": len(results),
        "solved_rounds": successes,
        "unsolved_rounds": len(results) - successes,
        "solve_rate": solve_rate,
        "solve_rate_wilson_ci": ci,
        "difficulty_bits": difficulty,
        "theoretical_expected_hashes": expected,
        "observed_geometric_mean_hashes": observed_geometric_mean,
        "geometric_mean_confidence_factor": ci_geo,
        "total_hashes": int(sum(hashes)),
        "total_time_seconds": sum(times),
        "mean_hashes_per_round": statistics.mean(hashes) if hashes else 0.0,
        "median_hashes_per_round": statistics.median(hashes) if hashes else 0.0,
        "mean_hashrate": statistics.mean(rates) if rates else 0.0,
        "median_hashrate": statistics.median(rates) if rates else 0.0,
        "mean_luck_ratio": statistics.mean(r.luck_ratio for r in solved) if solved else None,
        "lag1_autocorrelation_hashes": lag_autocorrelation(hashes, 1),
        "lag1_autocorrelation_time": lag_autocorrelation(times, 1),
        "all_solutions_verified": all(r.verified for r in solved),
        "verification_failures": sum(not r.verified for r in solved),
    }


# ---------------------------------------------------------------------------
# Output
# ---------------------------------------------------------------------------

def save_csv(results: list[PowRound], path: Path) -> None:
    if not results:
        return
    fields = list(asdict(results[0]).keys())
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(asdict(result) for result in results)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="RP NewTech scientific proof-of-work demo")
    source = parser.add_mutually_exclusive_group(required=True)
    source.add_argument("--synthetic", action="store_true", help="reproducible synthetic entropy")
    source.add_argument("--device", type=int, help="OpenCV camera index")
    parser.add_argument("--difficulty", type=int, default=16, help="leading zero bits required")
    parser.add_argument("--rounds", type=int, default=5, help="number of mining rounds")
    parser.add_argument("--max-hashes", type=int, default=2_000_000, help="per-round nonce limit")
    parser.add_argument("--seed", type=int, default=20261110, help="synthetic entropy seed")
    parser.add_argument("--alpha", type=float, default=0.05, help="confidence level")
    parser.add_argument("--json", default="rp_newtech_pow.json", help="JSON output path")
    parser.add_argument("--csv", default="rp_newtech_pow.csv", help="CSV output path")
    return parser


def main() -> int:
    args = build_parser().parse_args()
    if args.rounds < 1:
        raise SystemExit("--rounds must be positive")
    if not 0 < args.alpha < 1:
        raise SystemExit("--alpha must be between 0 and 1")

    source = SyntheticEntropy(seed=args.seed) if args.synthetic else CameraEntropy(args.device)
    miner = NewTechPow(source, args.difficulty, args.max_hashes)

    print(f"{PROTOCOL}")
    print(f"Difficulty: {args.difficulty} leading zero bits")
    print(f"Expected hashes per solve: {2 ** args.difficulty:,}")
    print(f"Per-round limit: {args.max_hashes:,} hashes")

    results: list[PowRound] = []
    try:
        for index in range(args.rounds):
            result = miner.mine(index)
            results.append(result)
            state = "SOLVED" if result.nonce is not None else "LIMIT REACHED"
            print(
                f"round {index + 1}/{args.rounds}: {state} | "
                f"{result.hashes_tried:,} hashes | {result.elapsed_seconds:.3f} s | "
                f"{result.hashes_per_second:,.0f} H/s | verified={result.verified}"
            )
    except KeyboardInterrupt:
        print("\nStopped by user.")
    finally:
        source.close()

    if not results:
        return 1

    json_path = Path(args.json)
    csv_path = Path(args.csv)
    json_path.parent.mkdir(parents=True, exist_ok=True)
    csv_path.parent.mkdir(parents=True, exist_ok=True)
    save_csv(results, csv_path)

    analysis = analyse(results, args.alpha)
    document = {
        "protocol": PROTOCOL,
        "created_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "entropy_source": "synthetic" if args.synthetic else f"camera:{args.device}",
        "parameters": {
            "difficulty_bits": args.difficulty,
            "rounds": args.rounds,
            "max_hashes_per_round": args.max_hashes,
            "synthetic_seed": args.seed if args.synthetic else None,
            "alpha": args.alpha,
        },
        "analysis": analysis,
        "rounds": [asdict(result) for result in results],
        "output_csv": str(csv_path),
    }

    json_path.write_text(json.dumps(document, indent=2), encoding="utf-8")

    print("\nScientific summary")
    for key, value in analysis.items():
        if isinstance(value, float):
            print(f"{key}: {value:,.6f}")
        else:
            print(f"{key}: {value}")
    print(f"Saved JSON: {json_path}")
    print(f"Saved CSV: {csv_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
