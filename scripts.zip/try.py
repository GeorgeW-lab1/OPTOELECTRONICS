#!/usr/bin/env python3
"""
RP-GHOST Asynchronous Commit-Reveal Decoder & Live Webcam Photonic Pipeline
Framework: Beam-Phase Correlation Theory Implementation
"""

import hashlib
import heapq
import json
import math
import threading
import time
import queue
from collections import deque

import numpy as np

try:
    import cv2
    HAS_CV2 = True
except ImportError:
    HAS_CV2 = False

try:
    import pyautogui
    HAS_PYAUTOGUI = True
    pyautogui.FAILSAFE = True
    pyautogui.PAUSE = 0.02
except ImportError:
    HAS_PYAUTOGUI = False

try:
    import orjson
    _loads = orjson.loads
except ImportError:
    _loads = json.loads

try:
    import websocket
    HAS_WS = True
except ImportError:
    HAS_WS = False


# ============================================================================
# KEYBOARD OUTPUT MODALITY (Conditional Execution)
# ============================================================================

ENABLE_KEYBOARD = True

KEY_HIGH = ("shift", "w")
KEY_LOW = ("shift", "s")

KEYBOARD_ONLY_AFTER_ARM = True
KEYBOARD_REQUIRE_CONFIDENCE = True
KEYBOARD_MIN_DELTA = 0.01
KEYBOARD_COOLDOWN = 0.0

_last_keyboard_action = 0.0

# ============================================================================
# CONFIGURATION & THEORY PARAMETERS
# ============================================================================

LAMBDA = 10000.0          # Base coherent amplitude (Axiom 1)
SIGMA_C = 0.005           # Phase-coherent noise coupling parameter

N_SLOTS = 32              # Output mode dimensions
FIELD_BITS = 16
PRICE_DELTA_SCALE = 100.0

REVEAL_DELAY = 2.8
SAMPLE_INTERVAL = 1.0

N_WINDOWS = 2000
N_PERMS = 100
REPORT_EVERY = 25

LEADS = (0, 1, 2, 3, 4)

N_SIGMA = 5.0
MIN_CYCLES = 40
ROLL_CYCLES = 400

Z_MIN = 4.0
JOINT_CONF_MIN = 0.999

DELTA_BUF_LEN = 64
MIN_BUF = 64
ENTROPY_MAX_BITS = 0.25
STREAK = 5
MIN_ABS_DELTA = 2.0

EXCHANGE = "binance"
WEBCAM_INDEX = 0


# ============================================================================
# MATHEMATICAL & THEORY HELPERS
# ============================================================================

def format_clock_time(timestamp_ns):
    seconds = timestamp_ns / 1e9
    clock = time.strftime("%H:%M:%S", time.localtime(seconds))
    ms = int((timestamp_ns % 1_000_000_000) // 1_000_000)
    return f"{clock}.{ms:03d}"


def noise_stats(lambd, sigma_c):
    shared = sigma_c ** 2 * lambd
    var_z = 1.0 + shared
    return var_z, math.sqrt(var_z), shared / var_z


def phi(z):
    return 0.5 * (1.0 + math.erf(z / math.sqrt(2.0)))


def sign_entropy(values):
    n = len(values)

    if not n:
        return 0.0, (0, 0, 0)

    counts = (
        sum(x > 0 for x in values),
        sum(x < 0 for x in values),
        sum(x == 0 for x in values),
    )

    h = 0.0

    for c in counts:
        if c:
            p = c / n
            h -= p * math.log2(p)

    return h, counts


# ============================================================================
# 32-BIT NON-SEPARABLE PAYLOAD ENCODING
# ============================================================================

def timestamp_to_code(timestamp_ns):
    ms = (int(timestamp_ns) // 1_000_000) % 60000
    return ms & 0xFFFF


def price_delta_to_code(price_delta):
    cents = int(round(float(price_delta) * 100.0))
    cents = max(-32768, min(32767, cents))
    return cents & 0xFFFF


def code_to_signed_price_delta(code):
    value = int(code) & 0xFFFF

    if value >= 0x8000:
        value -= 0x10000

    return value / 100.0


def encode_payload_bits(timestamp_ns, price_delta):
    """Encodes state information into a unified global amplitude configuration."""
    time_code = timestamp_to_code(timestamp_ns)
    delta_code = price_delta_to_code(price_delta)

    time_bits = [
        (time_code >> (15 - k)) & 1
        for k in range(16)
    ]

    delta_bits = [
        (delta_code >> (15 - k)) & 1
        for k in range(16)
    ]

    return np.array(time_bits + delta_bits, dtype=int)


def bits_to_code(bits):
    code = 0
    for bit in bits:
        code = (code << 1) | (int(bit) & 1)
    return code


def decode_payload_bits(bits):
    bits = np.asarray(bits, dtype=int).flatten()

    if len(bits) != N_SLOTS:
        raise ValueError("Invalid payload length")

    timestamp_code = bits_to_code(bits[:16])
    delta_code = bits_to_code(bits[16:])

    return (
        timestamp_code,
        code_to_signed_price_delta(delta_code)
    )


def decode_timestamp_from_code(code, reference_ns):
    minute_start = (
        int(reference_ns) // 60_000_000_000
    ) * 60_000_000_000

    decoded_ns = minute_start + (int(code) & 0xFFFF) * 1_000_000

    return decoded_ns, format_clock_time(decoded_ns)


def make_payload_tilt(bits, eps_abs):
    """Applies Axiom 2 & 3: Unitary beam-phase mapping across output modes."""
    bits = np.asarray(bits, dtype=float)
    strength = max(float(eps_abs), 0.25)
    return 2.0 * strength * (bits - 0.5)


# ============================================================================
# LIVE WEBCAM PHOTONIC ACQUISITION THREAD (Phase-Coherent Source)
# ============================================================================

class WebcamPhotonicFeed(threading.Thread):
    def __init__(self, frame_queue):
        super().__init__(daemon=True)
        self.frame_queue = frame_queue
        self.running = True

    def run(self):
        if not HAS_CV2:
            print("[WARNING] 'opencv-python' (cv2) not available. Running in simulated photonic noise mode.")
            self._run_mock_feed()
            return

        cap = cv2.VideoCapture(WEBCAM_INDEX)
        if not cap.isOpened():
            print(f"[WARNING] Could not open webcam index {WEBCAM_INDEX}. Falling back to simulated feed.")
            self._run_mock_feed()
            return

        ret, prev_frame = cap.read()
        if not ret:
            cap.release()
            self._run_mock_feed()
            return

        prev_gray = cv2.cvtColor(prev_frame, cv2.COLOR_BGR2GRAY)

        while self.running:
            ret, frame = cap.read()
            if not ret:
                time.sleep(0.05)
                continue

            gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
            diff = cv2.absdiff(gray, prev_gray)
            mean_intensity = float(np.mean(gray))
            mean_motion = float(np.mean(diff))

            prev_gray = gray

            frame_data = {
                "mean_intensity": mean_intensity,
                "motion_energy": mean_motion,
                "timestamp": time.time_ns()
            }

            try:
                self.frame_queue.put_nowait(frame_data)
            except queue.Full:
                try:
                    self.frame_queue.get_nowait()
                except queue.Empty:
                    pass
                self.frame_queue.put_nowait(frame_data)

            time.sleep(0.033)

        cap.release()

    def _run_mock_feed(self):
        while self.running:
            mock_motion = float(np.random.exponential(2.5))
            frame_data = {
                "mean_intensity": 128.0,
                "motion_energy": mock_motion,
                "timestamp": time.time_ns()
            }
            try:
                self.frame_queue.put_nowait(frame_data)
            except queue.Full:
                pass
            time.sleep(0.033)

    def stop(self):
        self.running = False


# ============================================================================
# OPTOELECTRONIC VIEWPORT (Beam-Phase Mapping Engine)
# ============================================================================

class OptoelectronicViewport:
    """
    Implements Axioms 1-3: Transforms a single coherent amplitude input into 
    superimposed output modes via unitary phase-mapping.
    """

    def __init__(self, lambd=LAMBDA, sigma_c=SIGMA_C):
        self.lambd = lambd
        self.sigma_c = sigma_c
        print("[OPTICAL] Unitary Beam-Phase Mapping Engine Initialized (Phase-Coherent Whole)")

    def generate_window_block(self, n_windows, n_slots, tilt=None, motion_energy=0.0):
        motion_scale = 1.0 + min(max(motion_energy / 20.0, 0.0), 10.0)
        effective_sigma = self.sigma_c * motion_scale

        shared_noise = np.random.normal(
            0.0,
            effective_sigma,
            size=(n_windows, 1)
        )

        lam = self.lambd * (1.0 + shared_noise)

        counts = np.random.poisson(
            np.clip(lam, 1.0, None),
            size=(n_windows, n_slots)
        )

        # Unitary redistribution of quantum possibility
        Z = (
            counts - self.lambd
        ) / np.sqrt(self.lambd)

        if tilt is not None:
            Z += tilt * (1.0 + 0.02 * motion_energy)

        return Z


# ============================================================================
# ASYNCHRONOUS LIVE PRICE FETCHER
# ============================================================================

def parse_binance(d):
    if d.get("s") != "BTCUSDT":
        return None

    bid = d.get("b")
    ask = d.get("a")

    if bid is None or ask is None:
        return None

    bid = float(bid)
    ask = float(ask)

    if bid <= 0 or ask <= 0:
        return None

    return (bid + ask) / 2.0


class AsyncPriceFetcher(threading.Thread):
    def __init__(self, exchange="binance"):
        super().__init__(daemon=True)
        if exchange != "binance":
            raise ValueError("This version uses Binance BTCUSDT")

        self.url = "wss://stream.binance.com:443/ws/btcusdt@bookTicker"
        self.ticks = queue.Queue(maxsize=1)
        self.running = True
        self.ws = None
        self.received = 0
        self.last_message_ns = 0

    def _on_open(self, ws):
        print("[FETCH] Binance WebSocket connected")

    def _on_message(self, ws, message):
        try:
            data = _loads(message)
            price = parse_binance(data)

            if price is None:
                return

            received_ns = time.time_ns()
            received_perf_ns = time.perf_counter_ns()

            tick = {
                "price": price,
                "received_ns": received_ns,
                "received_perf_ns": received_perf_ns,
            }

            try:
                self.ticks.put_nowait(tick)
            except queue.Full:
                try:
                    self.ticks.get_nowait()
                except queue.Empty:
                    pass
                self.ticks.put_nowait(tick)

            self.received += 1
            self.last_message_ns = received_ns

        except Exception as e:
            print(f"[FETCH] Parse error: {e}")

    def _on_error(self, ws, error):
        print(f"[FETCH] WebSocket error: {error}")

    def _on_close(self, ws, code, message):
        print(f"[FETCH] WebSocket closed: {code} {message}")

    def run(self):
        if not HAS_WS:
            print("[FETCH] Install websocket-client")
            return

        while self.running:
            try:
                self.ws = websocket.WebSocketApp(
                    self.url,
                    on_open=self._on_open,
                    on_message=self._on_message,
                    on_error=self._on_error,
                    on_close=self._on_close
                )
                self.ws.run_forever(ping_interval=20, ping_timeout=10)
            except Exception as e:
                print(f"[FETCH] Connection exception: {e}")

            if self.running:
                time.sleep(3)

    def stop(self):
        self.running = False
        if self.ws:
            self.ws.close()


# ============================================================================
# ASYNCHRONOUS FORCED REVEAL SCHEDULER
# ============================================================================

class AsyncRevealScheduler(threading.Thread):
    def __init__(self, output_queue):
        super().__init__(daemon=True)
        self.output_queue = output_queue
        self.condition = threading.Condition()
        self.pending = []
        self.sequence = 0
        self.running = True

    def schedule(self, delay_seconds, callback):
        due_perf_ns = time.perf_counter_ns() + int(delay_seconds * 1e9)
        due_wall_ns = time.time_ns() + int(delay_seconds * 1e9)

        with self.condition:
            self.sequence += 1
            heapq.heappush(
                self.pending,
                (due_perf_ns, self.sequence, due_wall_ns, callback)
            )
            self.condition.notify()

        return due_wall_ns

    def run(self):
        while self.running:
            item = None
            with self.condition:
                while self.running and not self.pending:
                    self.condition.wait()

                if not self.running:
                    break

                due_ns = self.pending[0][0]
                remaining = (due_ns - time.perf_counter_ns()) / 1e9

                if remaining > 0:
                    self.condition.wait(timeout=remaining)
                    continue

                item = heapq.heappop(self.pending)

            if item is None:
                continue

            due_perf_ns, sequence, due_wall_ns, callback = item
            actual_perf_ns = time.perf_counter_ns()
            actual_wall_ns = time.time_ns()

            try:
                result = callback(due_wall_ns, actual_wall_ns)
                result["scheduled_reveal_ns"] = due_wall_ns
                result["actual_reveal_ns"] = actual_wall_ns
                result["actual_reveal_perf_ns"] = actual_perf_ns
                self.output_queue.put(result)
            except Exception as e:
                print(f"[REVEAL] Callback error: {e}")

    def stop(self):
        with self.condition:
            self.running = False
            self.condition.notify_all()


# ============================================================================
# LEAD-LAG RECORDS (Joint-State Analysis)
# ============================================================================

class ArmRecord:
    def __init__(self, maxlen=ROLL_CYCLES):
        self.M = deque(maxlen=maxlen)
        self.Y = deque(maxlen=maxlen)

    def add(self, col_means, y_bits):
        self.M.append(np.asarray(col_means, dtype=float))
        self.Y.append(np.asarray(y_bits, dtype=float))

    def __len__(self):
        return len(self.M)


def lead_stats(arm, leads, n_slots, n_perms):
    C = len(arm)
    M = np.array(arm.M)
    Y = np.array(arm.Y)

    Mc = M - M.mean(axis=0)
    Yc = Y - Y.mean(axis=0)

    obs = {}
    den = {}

    for L in leads:
        x = Mc[:, :n_slots - L]
        y = Yc[:, L:]
        d = math.sqrt(float((x * x).sum() * (y * y).sum()))
        den[L] = d
        obs[L] = float((x * y).sum() / d) if d > 0 else 0.0

    perm_vals = {L: [] for L in leads}
    done = 0

    while done < n_perms:
        P = min(250, n_perms - done)
        idx = np.argsort(np.random.random((P, C)), axis=1)
        Yp = Yc[idx]

        for L in leads:
            if den[L] > 0:
                s = np.einsum("ck,pck->p", Mc[:, :n_slots - L], Yp[:, :, L:])
                perm_vals[L].append(s / den[L])
        done += P

    out = {}
    for L in leads:
        if den[L] > 0 and perm_vals[L]:
            arr = np.concatenate(perm_vals[L])
            sd = arr.std()
            z = (obs[L] - arr.mean()) / sd if sd > 0 else 0.0
        else:
            z = 0.0
        out[L] = (obs[L], z)

    return out


# ============================================================================
# COMMITMENT CREATION (Axiom 4: Joint-State Primacy)
# ============================================================================

def make_commitment(arm, timestamp_ns, price, price_delta):
    if arm == "BEFORE":
        bits = encode_payload_bits(timestamp_ns, price_delta)
        material = (
            bits.tobytes()
            + str(timestamp_ns).encode()
            + repr(price).encode()
            + repr(price_delta).encode()
        )
        commitment = hashlib.sha256(material).hexdigest()
        return commitment, bits

    noise = np.random.normal(0.0, 1.0, size=(256, N_SLOTS))
    commitment = hashlib.sha256(noise.tobytes()).hexdigest()
    return commitment, None


# ============================================================================
# CONDITIONAL COLLAPSE & DECODER (Axiom 5)
# ============================================================================

def inject_decoded_direction(arm, decoded_delta, min_z, joint_conf):
    global _last_keyboard_action

    keys = KEY_HIGH if decoded_delta > 0 else KEY_LOW
    direction = "HIGH" if decoded_delta > 0 else "LOW"

    try:
        pyautogui.hotkey(*keys)
        _last_keyboard_action = now
        return f"INJECTED {direction}: {'+'.join(keys).upper()}"
    except Exception as e:
        return f"KEYBOARD ERROR: {e}"


def process_reveal(
    event,
    viewport,
    frame_queue,
    before,
    after,
    delta_buf,
    analysis,
    counters
):
    arm = event["arm"]
    fetch_ns = event["fetch_ns"]
    fetch_price = event["price"]
    price_delta = event["price_delta"]

    scheduled_ns = event["scheduled_reveal_ns"]
    actual_ns = event["actual_reveal_ns"]

    current_motion = 0.0
    while not frame_queue.empty():
        try:
            frame_data = frame_queue.get_nowait()
            current_motion = frame_data["motion_energy"]
        except queue.Empty:
            break

    if arm == "BEFORE":
        Y = event["committed_bits"].copy()
        payload_timestamp_ns = scheduled_ns
    else:
        payload_timestamp_ns = actual_ns
        Y = encode_payload_bits(payload_timestamp_ns, price_delta)

    _, sigma_z, _ = noise_stats(LAMBDA, SIGMA_C)
    eps_abs = 0.02 * sigma_z
    tilt = make_payload_tilt(Y, eps_abs)

    # Measurement conditioning / conditional collapse across the modes
    Z = viewport.generate_window_block(
        N_WINDOWS,
        N_SLOTS,
        tilt,
        motion_energy=current_motion
    )

    m = Z.mean(axis=0)
    col_z = m / (Z.std(axis=0, ddof=1) / math.sqrt(N_WINDOWS))
    bit_z = col_z.copy()

    decoded_bits = (bit_z > 0).astype(int)
    decoded_code, decoded_delta = decode_payload_bits(decoded_bits)

    actual_code = timestamp_to_code(payload_timestamp_ns)
    decoded_ns, decoded_time = decode_timestamp_from_code(decoded_code, actual_ns)

    time_error_ms = ((decoded_code - actual_code + 30000) % 60000) - 30000
    exact_bits = int(np.sum(decoded_bits == Y))

    if arm == "BEFORE":
        before.add(m, Y)
    else:
        after.add(m, Y)

    counters["revealed"] += 1
    if time_error_ms == 0:
        counters["timestamp_hits"] += 1
    if abs(time_error_ms) <= 1:
        counters["within_1ms"] += 1
    if abs(time_error_ms) <= 10:
        counters["within_10ms"] += 1
    counters["timestamp_total"] += 1

    delta_error = decoded_delta - price_delta
    counters["delta_abs_error"] += abs(delta_error)
    counters["delta_total"] += 1
    if abs(delta_error) < 0.0051:
        counters["delta_exact"] += 1

    min_z = float(np.abs(bit_z).min())
    joint_conf = float(np.prod([phi(z) for z in np.abs(bit_z)]))

    certain = (min_z >= Z_MIN and joint_conf >= JOINT_CONF_MIN)
    keyboard_status = inject_decoded_direction(
        arm=arm,
        decoded_delta=decoded_delta,
        min_z=min_z,
        joint_conf=joint_conf
    )

    delta_buf.append(time_error_ms)
    entropy, counts = sign_entropy(delta_buf)
    n_pos, n_neg, n_zero = counts

    low_entropy = (len(delta_buf) >= MIN_BUF and entropy <= ENTROPY_MAX_BITS)
    dominant = 1 if n_pos > n_neg else -1 if n_neg > n_pos else 0
    agrees = (time_error_ms != 0 and dominant != 0 and (time_error_ms > 0) == (dominant > 0))
    recent = list(delta_buf)[-STREAK:]
    streak_ok = (len(recent) == STREAK and (all(x > 0 for x in recent) or all(x < 0 for x in recent)))
    big_enough = abs(time_error_ms) >= MIN_ABS_DELTA

    gates = {
        "positive control recovered": analysis["pipeline_ok"],
        "after-arm channel signal": analysis["channel_decode_ok"],
        "certain": certain,
        "low entropy": low_entropy,
        "agrees": agrees,
        "streak": streak_ok,
        "big enough": big_enough
    }

    failed = [name for name, passed in gates.items() if not passed]
    elapsed_ms = (event["actual_reveal_perf_ns"] - event["commit_perf_ns"]) / 1e6

    print()
    print("=" * 78)
    print(f"[{counters['revealed']}] {arm} ARM | CONDITIONAL STATE REVEAL (PHASE-COHERENT)")
    print("=" * 78)
    print(f"  Commitment:       {event['commitment'][:24]}...")
    print(f"  Elapsed delay:    {elapsed_ms:.2f} ms | Motion Energy: {current_motion:.2f}")
    print(f"  BTC price:        ${fetch_price:,.2f} | Actual Delta: {price_delta:+.2f} USD")
    print(f"  Decoded Time:     {decoded_time} | Error: {time_error_ms:+d} ms")
    print(f"  Decoded Delta:    {decoded_delta:+.2f} USD | Bit Recovery: {exact_bits}/{N_SLOTS}")
    print(f"  Keyboard Modality:{keyboard_status}")
    print("-" * 78)
    print(f"  Minimum |z|:      {min_z:.2f} | Joint Confidence: {joint_conf:.8f}")
    if failed:
        print(f"  [GATE] WITHHELD: {', '.join(failed)}")
    else:
        print("  [GATE] All phase-coherence gates passed.")
    print("=" * 78)

    return time_error_ms


# ============================================================================
# STATISTICAL ANALYSIS (Bell-Type Visibility & Correlation Verification)
# ============================================================================

def run_analysis(before, after, analysis, counters):
    if len(before) < MIN_CYCLES or len(after) < MIN_CYCLES:
        print(f"[ANALYSIS] Waiting for convergence: BEFORE={len(before)}, AFTER={len(after)}")
        return

    sb = lead_stats(before, LEADS, N_SLOTS, N_PERMS)
    sa = lead_stats(after, LEADS, N_SLOTS, N_PERMS)

    pc_rho, pc_z = sb[0]
    analysis["pipeline_ok"] = pc_z >= N_SIGMA

    best_L = max(LEADS, key=lambda L: sa[L][1])
    analysis["channel_decode_ok"] = (sa[best_L][1] >= N_SIGMA)

    print()
    print("[ANALYSIS - BEAM-PHASE CORRELATION VERIFICATION] " + "-" * 35)
    print(f"BEFORE control: rho={pc_rho:+.4f} z={pc_z:+.2f}")
    for L in LEADS:
        print(f"AFTER lead +{L}: rho={sa[L][0]:+.4f} z={sa[L][1]:+.2f}")
    print(f"Positive Control State: {'RECOVERED' if analysis['pipeline_ok'] else 'NOT RECOVERED'}")
    print(f"Non-Separable Channel:  {'RECOVERED' if analysis['channel_decode_ok'] else 'NOT RECOVERED'}")
    print("-" * 65)
    print()


# ============================================================================
# MAIN PIPELINE EXECUTION
# ============================================================================

def run_full_predictor_pipeline(
    exchange=EXCHANGE,
    delay_seconds=REVEAL_DELAY,
    max_cycles=None
):
    np.random.seed(2026)

    var_z, sigma_z, slot_corr = noise_stats(LAMBDA, SIGMA_C)

    prereg = {
        "exchange": exchange,
        "delay_seconds": delay_seconds,
        "lambda": LAMBDA,
        "sigma_c": SIGMA_C,
        "slots": N_SLOTS,
        "windows": N_WINDOWS,
        "leads": list(LEADS),
        "arms": ["BEFORE", "AFTER"],
        "framework": "Beam-Phase Correlation Theory"
    }

    prereg_hash = hashlib.sha256(json.dumps(prereg, sort_keys=True).encode()).hexdigest()

    print("=" * 78)
    print(" RP-GHOST: BEAM-PHASE CORRELATION PIPELINE")
    print("=" * 78)
    print(f"[PREREG HASH] {prereg_hash}")
    print(f"[EXCHANGE]    {exchange} | Delay: {delay_seconds:.3f}s")
    print(f"[OPTICAL]     Lambda={LAMBDA} | Sigma(z)={sigma_z:.3f} | Slot Corr={slot_corr:.4f}")
    print()

    if not HAS_WS:
        print("[ERROR] Install websocket-client: pip install websocket-client")
        return

    viewport = OptoelectronicViewport()
    fetcher = AsyncPriceFetcher(exchange)
    frame_queue = queue.Queue(maxsize=10)
    webcam_feed = WebcamPhotonicFeed(frame_queue)
    reveal_queue = queue.Queue()
    scheduler = AsyncRevealScheduler(reveal_queue)

    before = ArmRecord()
    after = ArmRecord()
    delta_buf = deque(maxlen=DELTA_BUF_LEN)

    analysis = {"pipeline_ok": False, "channel_decode_ok": False}
    counters = {
        "scheduled": 0, "revealed": 0, "timestamp_hits": 0,
        "within_1ms": 0, "within_10ms": 0, "timestamp_total": 0,
        "delta_exact": 0, "delta_total": 0, "delta_abs_error": 0.0
    }

    previous_price = None
    last_sample_perf_ns = 0

    webcam_feed.start()
    fetcher.start()
    scheduler.start()

    print("[START] Active sampling of phase-coherent stream...")

    try:
        while (
            max_cycles is None
            or counters["scheduled"] < max_cycles
            or counters["revealed"] < counters["scheduled"]
        ):
            try:
                tick = fetcher.ticks.get(timeout=0.02)
            except queue.Empty:
                tick = None

            if tick is not None:
                now_perf = time.perf_counter_ns()
                if (
                    now_perf - last_sample_perf_ns >= int(SAMPLE_INTERVAL * 1e9)
                    and (max_cycles is None or counters["scheduled"] < max_cycles)
                ):
                    last_sample_perf_ns = now_perf
                    price = tick["price"]
                    fetch_ns = tick["received_ns"]

                    price_delta = 0.0 if previous_price is None else price - previous_price
                    previous_price = price

                    arm = "BEFORE" if np.random.random() < 0.5 else "AFTER"
                    commit_ns = time.time_ns()
                    commit_perf_ns = time.perf_counter_ns()

                    scheduled_payload_ns = fetch_ns + int(delay_seconds * 1e9)
                    commitment, committed_bits = make_commitment(arm, scheduled_payload_ns, price, price_delta)

                    captured = {
                        "arm": arm,
                        "price": price,
                        "price_delta": price_delta,
                        "fetch_ns": fetch_ns,
                        "commit_ns": commit_ns,
                        "commit_perf_ns": commit_perf_ns,
                        "commitment": commitment,
                        "committed_bits": committed_bits.copy() if committed_bits is not None else None
                    }

                    def reveal_callback(scheduled_ns, actual_ns, data=captured):
                        return {**data, "scheduled_reveal_ns": scheduled_ns, "actual_reveal_ns": actual_ns}

                    scheduler.schedule(delay_seconds, reveal_callback)
                    counters["scheduled"] += 1

            while True:
                try:
                    event = reveal_queue.get_nowait()
                except queue.Empty:
                    break

                process_reveal(event, viewport, frame_queue, before, after, delta_buf, analysis, counters)

                if counters["revealed"] > 0 and counters["revealed"] % REPORT_EVERY == 0:
                    if not hasattr(run_full_predictor_pipeline, "_last_report") or run_full_predictor_pipeline._last_report != counters["revealed"]:
                        run_full_predictor_pipeline._last_report = counters["revealed"]
                        run_analysis(before, after, analysis, counters)

    except KeyboardInterrupt:
        print("\n[STOP] Pipeline halted by user.")
    finally:
        print("[SHUTDOWN] Terminating threads...")
        scheduler.stop()
        webcam_feed.stop()
        fetcher.stop()
        scheduler.join(timeout=2.0)
        webcam_feed.join(timeout=2.0)
        fetcher.join(timeout=2.0)
        print("[DONE] RP-GHOST pipeline terminated successfully.")


if __name__ == "__main__":
    run_full_predictor_pipeline(
        exchange="binance",
        delay_seconds=REVEAL_DELAY,
        max_cycles=None
    )
