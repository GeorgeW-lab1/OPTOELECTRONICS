import math
import time
import threading
import socket
import json
from collections import deque
import numpy as np

try:
    import orjson  # pip install orjson (optional, faster parsing)
    _loads = orjson.loads
except ImportError:
    _loads = json.loads

try:
    import websocket  # pip install websocket-client
    HAS_WS = True
except ImportError:
    HAS_WS = False

try:
    import cv2
    HAS_CV2 = True
except ImportError:
    HAS_CV2 = False

try:
    import pyautogui
    HAS_PYAUTOGUI = True
    pyautogui.FAILSAFE = True
    pyautogui.PAUSE = 0  # remove the default 0.1 s delay after every call
except ImportError:
    HAS_PYAUTOGUI = False


# ----------------------------------------------------------------------------
# Gate settings
# ----------------------------------------------------------------------------
# Certainty gate (per-cycle decode confidence)
Z_MIN = 3.0            # every price bit must have |z| >= this
JOINT_CONF_MIN = 0.99  # joint probability that all price bits are correct
N_PRICE_BITS = 16

# Entropy gate (rolling buffer of deltas)
DELTA_BUF_LEN = 32       # rolling window of recent deltas
MIN_BUF = 16             # don't decide until at least this many are buffered
ENTROPY_MAX_BITS = 0.6   # max sign entropy allowed (0 = all one direction, 1.585 = fully mixed)


def _phi(z):
    """Standard normal CDF: probability a bit's sign is correct given its z-score."""
    return 0.5 * (1.0 + math.erf(z / math.sqrt(2.0)))


def sign_entropy(deltas):
    """Shannon entropy (bits) of the +/-/0 sign distribution, plus the counts."""
    n = len(deltas)
    counts = (sum(d > 0 for d in deltas), sum(d < 0 for d in deltas), sum(d == 0 for d in deltas))
    h = 0.0
    for c in counts:
        if c:
            p = c / n
            h -= p * math.log2(p)
    return h, counts


# ----------------------------------------------------------------------------
# Optoelectronic viewport
# ----------------------------------------------------------------------------
class OptoelectronicViewport:
    """Acquires standardized photon/pixel noise samples z_k from a webcam or calibrated synthetic source."""

    def __init__(self, camera_index=0, lambd=10000.0, sigma_c=0.005, use_webcam=False):
        self.camera_index = camera_index
        self.lambd = lambd
        self.sigma_c = sigma_c
        self.cap = None
        self.live_mode = False

        if use_webcam and HAS_CV2:
            print(f"[INIT] Attempting to open webcam index {camera_index}...")
            cap = cv2.VideoCapture(self.camera_index)
            if cap is not None and cap.isOpened():
                ret, frame = cap.read()
                if ret and frame is not None:
                    self.cap = cap
                    self.live_mode = True
                    print("[INIT] Live webcam successfully initialized.")
                else:
                    cap.release()
        if not self.live_mode:
            print("[INIT] Using calibrated synthetic optical viewport (Safe Mode).")

    def generate_ensemble_matrix(self, n_ensemble, n_slots, secret_Y, epsilon, lead_L):
        delta_shared = np.random.normal(0.0, self.sigma_c, size=(n_ensemble, 1))
        lambda_matrix = self.lambd * (1.0 + delta_shared)
        counts = np.random.poisson(np.clip(lambda_matrix, 1.0, None), size=(n_ensemble, n_slots))
        Z_ens = (counts - self.lambd) / np.sqrt(self.lambd)

        if secret_Y is not None and epsilon != 0.0:
            # wrap-around, matching the decoder's modular mapping:
            # column j carries the bias of bit (j + lead_L) % n_slots
            Z_ens += 2.0 * epsilon * (np.roll(secret_Y, -lead_L) - 0.5)

        return Z_ens

    def release(self):
        if self.cap is not None:
            self.cap.release()


# ----------------------------------------------------------------------------
# FIFO queue
# ----------------------------------------------------------------------------
class FifoTargetQueue:
    """Maintains a First-In, First-Out sliding history with explicit index pop capabilities."""

    def __init__(self, max_capacity=100):
        self.buffer = deque(maxlen=max_capacity)

    def push(self, timestamp, price, encoded_bits):
        self.buffer.append({
            "timestamp": timestamp,
            "price": price,
            "encoded_bits": encoded_bits,
        })

    def pop_at(self, index=2):
        temp_list = list(self.buffer)
        if 0 <= index < len(temp_list):
            popped_item = temp_list.pop(index)
            self.buffer = deque(temp_list, maxlen=self.buffer.maxlen)
            return popped_item
        return None

    def __len__(self):
        return len(self.buffer)


# ----------------------------------------------------------------------------
# Payload encoding
# ----------------------------------------------------------------------------
class TimeCodeLatch:
    """Implements 32-slot bit pooling for combined price + timestamp encoding/decoding."""

    @staticmethod
    def encode_payload(price_val, timestamp_val, n_slots=32):
        encoded_price = int(price_val / 10) & 0xFFFF
        encoded_time = int(timestamp_val) & 0xFFFF
        combined = (encoded_price << 16) | encoded_time
        return np.array([(combined >> (n_slots - 1 - k)) & 1 for k in range(n_slots)], dtype=int)

    @staticmethod
    def decode_payload(bits, reference_price=0.0):
        combined = 0
        for bit in bits:
            combined = (combined << 1) | int(bit)
        reconstructed_price_code = (combined >> 16) & 0xFFFF
        reconstructed_timestamp = combined & 0xFFFF

        if reference_price > 0.0:
            raw_predicted = float(reconstructed_price_code * 10)
            if abs(raw_predicted - reference_price) > 1000.0:
                reconstructed_price_code = int(reference_price / 10) & 0xFFFF

        return reconstructed_price_code, reconstructed_timestamp


# ----------------------------------------------------------------------------
# Exchange feeds (push-based WebSocket, top-of-book mid price)
# ----------------------------------------------------------------------------
def _parse_deribit(d):
    p = d.get("params")
    if p and p.get("channel", "").startswith("quote."):
        q = p["data"]
        return (float(q["best_bid_price"]) + float(q["best_ask_price"])) / 2.0


def _parse_bitmex(d):
    if d.get("table") == "quote" and d.get("data"):
        q = d["data"][-1]
        if q.get("bidPrice") and q.get("askPrice"):
            return (float(q["bidPrice"]) + float(q["askPrice"])) / 2.0


def _parse_coinbase(d):
    if d.get("type") == "ticker" and d.get("best_bid") and d.get("best_ask"):
        return (float(d["best_bid"]) + float(d["best_ask"])) / 2.0


def _parse_kraken(d):
    if d.get("channel") == "ticker" and d.get("data"):
        t = d["data"][0]
        return (float(t["bid"]) + float(t["ask"])) / 2.0


def _parse_okx(d):
    if d.get("data") and "bidPx" in d["data"][0]:
        t = d["data"][0]
        return (float(t["bidPx"]) + float(t["askPx"])) / 2.0


EXCHANGES = {
    "deribit": {
        "url": "wss://www.deribit.com/ws/api/v2",
        "sub": {"jsonrpc": "2.0", "id": 1, "method": "public/subscribe",
                "params": {"channels": ["quote.BTC-PERPETUAL"]}},
        "parse": _parse_deribit,
    },
    "bitmex": {
        "url": "wss://ws.bitmex.com/realtime",
        "sub": {"op": "subscribe", "args": ["quote:XBTUSD"]},
        "parse": _parse_bitmex,
    },
    "coinbase": {
        "url": "wss://ws-feed.exchange.coinbase.com",
        "sub": {"type": "subscribe", "product_ids": ["BTC-USD"], "channels": ["ticker"]},
        "parse": _parse_coinbase,
    },
    "kraken": {
        "url": "wss://ws.kraken.com/v2",
        "sub": {"method": "subscribe", "params": {"channel": "ticker", "symbol": ["BTC/USD"]}},
        "parse": _parse_kraken,
    },
    "okx": {
        "url": "wss://ws.okx.com:8443/ws/v5/public",
        "sub": {"op": "subscribe", "args": [{"channel": "tickers", "instId": "BTC-USDT"}]},
        "parse": _parse_okx,
    },
}


class AsyncPriceFetcher(threading.Thread):
    """Push-based BTC mid-price stream from a selectable exchange, with optional throttle."""

    def __init__(self, exchange="deribit", delay_seconds=0.0):
        super().__init__(daemon=True)
        cfg = EXCHANGES[exchange]
        self.url, self.sub, self.parse = cfg["url"], cfg["sub"], cfg["parse"]
        self.exchange = exchange
        self.delay_seconds = delay_seconds
        self._last_publish = 0.0
        self.latest_price = 0.0
        self.update_event = threading.Event()
        self.last_recv_ns = 0
        self.running = True
        self.ws = None

    def _on_open(self, ws):
        ws.send(json.dumps(self.sub))

    def _on_message(self, ws, message):
        try:
            price = self.parse(_loads(message))
        except Exception:
            return
        if not price:
            return
        now = time.perf_counter()
        if now - self._last_publish < self.delay_seconds:
            return  # inside the delay window, drop this tick
        self._last_publish = now
        self.latest_price = price
        self.last_recv_ns = time.perf_counter_ns()
        self.update_event.set()

    def run(self):
        if not HAS_WS:
            print("[FETCH] Missing dependency: pip install websocket-client")
            return
        while self.running:
            try:
                self.ws = websocket.WebSocketApp(
                    self.url, on_open=self._on_open, on_message=self._on_message)
                self.ws.run_forever(
                    ping_interval=20, ping_timeout=10,
                    sockopt=((socket.IPPROTO_TCP, socket.TCP_NODELAY, 1),),
                )
            except Exception:
                pass
            if self.running:
                time.sleep(0.2)  # brief backoff, then reconnect

    def get_price(self):
        return self.latest_price

    def stop(self):
        self.running = False
        if self.ws:
            self.ws.close()


# ----------------------------------------------------------------------------
# Keystroke injection: key depends ONLY on the sign of the prediction delta
# ----------------------------------------------------------------------------
def execute_keystroke_injection(price_delta):
    """Shift+W if predicted > actual, Shift+S if predicted < actual, nothing on zero."""
    if price_delta > 0:
        key = 'w'
    elif price_delta < 0:
        key = 's'
    else:
        print(f"[HW-INJECT] Delta {price_delta:+.2f} -> no sign, keystroke skipped")
        return

    print(f"[HW-INJECT] Delta {price_delta:+,.2f} -> Shift + {key.upper()}")

    if HAS_PYAUTOGUI:
        try:
            pyautogui.keyDown('shift')
            pyautogui.press(key)
            pyautogui.keyUp('shift')
        except Exception as e:
            print(f"[HW-INJECT] PyAutoGUI execution error: {e}")
    else:
        print("[HW-INJECT] PyAutoGUI not installed. Simulation mode only.")


# ----------------------------------------------------------------------------
# Main pipeline
# ----------------------------------------------------------------------------
def run_full_predictor_pipeline(exchange="deribit", delay_seconds=0.1,
                                epsilon=0.05, n_ensemble=20000):
    np.random.seed(2026)
    print("==========================================================================")
    print("  RP-GHOST OPTOELECTRONIC L-ANTICIPATION: ENTROPY-GATED KEYSTROKES        ")
    print("==========================================================================")

    viewport = OptoelectronicViewport(use_webcam=False)
    fifo_queue = FifoTargetQueue(max_capacity=50)
    delta_buf = deque(maxlen=DELTA_BUF_LEN)
    price_fetcher = AsyncPriceFetcher(exchange=exchange, delay_seconds=delay_seconds)
    price_fetcher.start()
    print(f"[FETCH] Streaming from {exchange}")

    n_slots = 32
    lead_L = 2

    # Expected per-bit z for reference (noise std on a column mean ~ 1.118 / sqrt(N))
    expected_z = epsilon / (1.118 / math.sqrt(n_ensemble))
    print(f"[GATE] epsilon={epsilon}, N={n_ensemble:,} -> expected per-bit z ~ {expected_z:.2f} "
          f"(need >= {Z_MIN})")
    if expected_z < Z_MIN:
        print("[GATE] WARNING: expected z is below Z_MIN, the certainty gate will rarely or never pass. "
              "Raise epsilon or n_ensemble.")

    try:
        iteration = 0
        while True:
            # Block until a fresh tick arrives instead of spinning on stale data
            if not price_fetcher.update_event.wait(timeout=1.0):
                continue
            price_fetcher.update_event.clear()

            live_btc_price = price_fetcher.get_price()
            if live_btc_price <= 0.0:
                continue
            iteration += 1
            current_timestamp = time.time()

            # 1. Encode target payload (price + timestamp)
            Y_hidden = TimeCodeLatch.encode_payload(live_btc_price, current_timestamp, n_slots=n_slots)
            fifo_queue.push(current_timestamp, live_btc_price, Y_hidden)

            # 2. Manage queue (pop at index 2 once depth allows)
            if len(fifo_queue) >= 3:
                fifo_queue.pop_at(index=2)

            # 3. Generate ensemble noise matrix
            Z_ens = viewport.generate_ensemble_matrix(n_ensemble, n_slots, Y_hidden, epsilon, lead_L=lead_L)

            # 4. Recover bits AND measure uncertainty per bit
            col_means = Z_ens.mean(axis=0)
            col_se = Z_ens.std(axis=0, ddof=1) / np.sqrt(n_ensemble)
            col_z = col_means / col_se                      # signal-to-noise per column

            noise_idx = (np.arange(n_slots) - lead_L) % n_slots
            bit_z = col_z[noise_idx]                        # z-score of each recovered bit
            recovered_bits = (bit_z > 0.0).astype(int)

            rec_price_code, rec_timestamp = TimeCodeLatch.decode_payload(
                recovered_bits, reference_price=live_btc_price)

            predicted_btc_price = float(rec_price_code * 10)
            price_delta = predicted_btc_price - live_btc_price

            # Certainty is judged on the price bits only, since they alone set the keystroke sign
            raw_price_code = int("".join(map(str, recovered_bits[:N_PRICE_BITS])), 2)
            clamped = (raw_price_code != rec_price_code)    # decoder overwrote the raw bits
            price_z = np.abs(bit_z[:N_PRICE_BITS])
            min_z = float(price_z.min())
            joint_conf = float(np.prod([_phi(z) for z in price_z]))
            certain = (min_z >= Z_MIN) and (joint_conf >= JOINT_CONF_MIN) and not clamped

            latency_ms = (time.perf_counter_ns() - price_fetcher.last_recv_ns) / 1e6
            print(f"[{iteration}] Actual ${live_btc_price:,.2f} | Predicted ${predicted_btc_price:,.2f} "
                  f"| Δ {price_delta:+,.2f} | min|z| {min_z:.2f} | joint {joint_conf:.4f} "
                  f"| clamped {clamped} | {latency_ms:.1f} ms")

            # 5. Buffer the delta, measure entropy, then decide
            delta_buf.append(price_delta)
            h, (n_pos, n_neg, n_zero) = sign_entropy(delta_buf)
            low_entropy = len(delta_buf) >= MIN_BUF and h <= ENTROPY_MAX_BITS

            dominant = 1 if n_pos > n_neg else (-1 if n_neg > n_pos else 0)
            agrees = price_delta != 0 and dominant != 0 and (price_delta > 0) == (dominant > 0)

            print(f"    entropy {h:.3f} bits | buf {len(delta_buf)} (+{n_pos} / -{n_neg} / 0:{n_zero}) "
                  f"| certain {certain} | low-entropy {low_entropy} | agrees {agrees}")

            if certain and low_entropy and agrees:
                execute_keystroke_injection(price_delta)
            else:
                print("[GATE] Withheld (uncertain, high entropy, or against the buffered direction)")

    except KeyboardInterrupt:
        pass
    finally:
        price_fetcher.stop()
        viewport.release()
        print("\n[DONE] Predictor pipeline terminated safely.")


if __name__ == "__main__":
    # Exchange options: "deribit", "bitmex", "coinbase", "kraken", "okx"
    run_full_predictor_pipeline(
        exchange="deribit",
        delay_seconds=0.1,
        epsilon=0.05,
        n_ensemble=20000,
    )
