import argparse
import hashlib
import itertools
import math
import time
from typing import List, Optional, Tuple

import numpy as np


def leading_zero_bits(digest: bytes) -> int:
    value = int.from_bytes(digest, "big")
    return len(digest) * 8 - value.bit_length()


class PoWPuzzle:
    """Find nonce with SHA256(known_data || nonce) having >= `difficulty` leading zero bits."""

    def __init__(self, known_data: bytes, difficulty: int, nonce_bits: int, double_sha: bool = False):
        self.data = known_data
        self.difficulty = difficulty
        self.nonce_bits = nonce_bits
        self.nonce_len = (nonce_bits + 7) // 8
        self.double_sha = double_sha
        self.hashes = 0  # global hash counter: every attempt is counted here

    def hash(self, nonce: int) -> bytes:
        self.hashes += 1
        h = hashlib.sha256(self.data + nonce.to_bytes(self.nonce_len, "big")).digest()
        return hashlib.sha256(h).digest() if self.double_sha else h

    def verify(self, nonce: int) -> bool:
        return leading_zero_bits(self.hash(nonce)) >= self.difficulty


def int_to_bits(value: int, n: int) -> List[int]:
    return [(value >> (n - 1 - i)) & 1 for i in range(n)]


class PhotonicPoWSolver:
    """
    The nonce is NOT given to the solver. Two ways to find it:

    1. No hint (default): the solver searches the nonce space itself, stage by stage.
       The photonic channel is not used, so all work is real hashing.

    2. Capped photonic hint (--hint-ones N): a photonic source whose key is a
       pre-existing valid nonce emits X = K AND R. Observation STOPS as soon as
       N distinct '1' bits have been revealed, so the solver only ever learns a
       few bits and must still search the rest. Zeros are never revealed (a
       missing '1' could be K_i=0 or just an unseen '1').
    """

    def __init__(self, puzzle: PoWPuzzle, p: float = 0.3, seed: Optional[int] = None):
        self.puzzle = puzzle
        self.n = puzzle.nonce_bits
        self.p = p
        self.rng = np.random.default_rng(seed)

    # ---- Mode 1: pure search, staged ----
    def search(self, stage_size: int = 1 << 16, max_stages: int = 1 << 20, start: Optional[int] = None):
        space = 1 << self.n
        start = int(self.rng.integers(space)) if start is None else start
        for stage in range(1, max_stages + 1):
            for i in range(stage_size):
                nonce = (start + (stage - 1) * stage_size + i) % space
                if self.puzzle.verify(nonce):
                    return nonce, stage
            if (stage - 1) * stage_size + stage_size >= space:
                break
        return None, stage

    # ---- Mode 2: capped photonic hint + search over the unrevealed positions ----
    def collect_hint(self, secret_bits: np.ndarray, max_ones: int, max_obs: int = 10_000) -> Tuple[np.ndarray, int]:
        seen = np.zeros(self.n, dtype=int)
        for m in range(1, max_obs + 1):
            R = (self.rng.random(self.n) < self.p).astype(int)
            new = seen | (secret_bits & R)
            if int(new.sum()) > max_ones:
                break  # would reveal more than allowed; stop before leaking it
            seen = new
            if int(seen.sum()) == max_ones:
                break
        return seen, m

    def search_with_hint(self, seen: np.ndarray):
        unseen = [i for i in range(self.n) if seen[i] == 0]
        base = int("".join(map(str, seen)), 2)
        weights = [1 << (self.n - 1 - i) for i in unseen]
        u = len(unseen)
        for k in range(u + 1):  # fewest extra ones first
            for combo in itertools.combinations(weights, k):
                nonce = base + sum(combo)
                if self.puzzle.verify(nonce):
                    return nonce
        return None


def mine_reference_nonce(puzzle: PoWPuzzle, start: int) -> int:
    """Creates the photonic source's key. Hashes spent here are NOT counted as solver work."""
    saved = puzzle.hashes
    for nonce in range(start, 1 << puzzle.nonce_bits):
        if puzzle.verify(nonce):
            puzzle.hashes = saved
            return nonce
    raise RuntimeError("no valid nonce; lower difficulty")


def report(puzzle: PoWPuzzle, nonce: Optional[int], t0: float, label: str):
    dt = time.time() - t0
    if nonce is None:
        print(f"[-] {label}: no solution found ({puzzle.hashes} hashes, {dt:.2f}s)")
        return
    d = puzzle.hash(nonce)
    puzzle.hashes -= 1  # the report hash is not search work
    print(f"[+] {label}: SOLVED")
    print(f"    nonce  : {nonce} (0x{nonce:0{puzzle.nonce_len * 2}x})")
    print(f"    hash   : {d.hex()}")
    print(f"    zeros  : {leading_zero_bits(d)} (needed {puzzle.difficulty})")
    print(f"    hashes : {puzzle.hashes}   expected ~{2 ** puzzle.difficulty} for a blind search")
    print(f"    time   : {dt:.2f}s")


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--bits", type=int, default=24, help="nonce size in bits")
    ap.add_argument("--difficulty", type=int, default=24, help="required leading zero bits")
    ap.add_argument("--hint-ones", type=int, default=4, help="max nonce 1-bits the photonic channel may reveal (0 = no hint)")
    ap.add_argument("--p", type=float, default=0.7)
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--data", default="block_header_demo|prev=00000abc|merkle=deadbeef|ts=1789000000")
    a = ap.parse_args()

    puzzle = PoWPuzzle(a.data.encode(), a.difficulty, a.bits)
    solver = PhotonicPoWSolver(puzzle, p=a.p, seed=a.seed)
    print(f"[*] n={a.bits} bit nonce, difficulty={a.difficulty}, hint cap={a.hint_ones} ones")

    t0 = time.time()
    if a.hint_ones <= 0:
        nonce, stages = solver.search()
        report(puzzle, nonce, t0, f"pure search ({stages} stages)")
    else:
        ref = mine_reference_nonce(puzzle, start=int(solver.rng.integers(1 << a.bits)) % (1 << a.bits))
        secret = np.array(int_to_bits(ref, a.bits), dtype=int)
        seen, m = solver.collect_hint(secret, a.hint_ones)
        print(f"[*] photonic hint after m={m} observations: {int(seen.sum())}/{a.bits} bits revealed "
              f"(source key weight {int(secret.sum())})")
        print(f"[*] hint pattern: {''.join(map(str, seen))}")
        t0 = time.time()
        nonce = solver.search_with_hint(seen)
        report(puzzle, nonce, t0, "hinted search")
