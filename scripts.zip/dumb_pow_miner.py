#!/usr/bin/env python3
"""
Dumb PoW miner host for the non-blocking Arduino SHA-256 miner sketch.

The Arduino does all the hashing. This script only drives it with the sketch's own commands:

    PC  -> Arduino   JOB:<64-hex challenge>:<difficulty>
    Arduino -> PC    MINING_STARTED
    Arduino -> PC    MINED:<challenge>:<difficulty>:<16-hex nonce>:<64-hex hash>
    PC  -> Arduino   ACCEPTED   (proof checked OK)   -> Arduino answers DISARMED
                     REJECTED   (proof is bad)       -> Arduino answers REJECTED_ACK
    PC  -> Arduino   STOP       (Ctrl-C / timeout)   -> Arduino answers STOPPED

Proof rule (same as the sketch): SHA256(challenge_bytes + nonce_bytes) must start with
<difficulty> zero bits. Nonce is 8 bytes, counted up from 0.

NOTE: ACCEPTED makes the sketch drive its relay pin (pin 8) HIGH. Use --no-accept to verify the
proof and then STOP instead, leaving the relay alone.

Usage:
    python dumb_pow_miner.py COM3 --difficulty 12
    python dumb_pow_miner.py /dev/ttyACM0 -d 16 --challenge <64 hex>
    python dumb_pow_miner.py LOOPBACK -d 16        # built-in virtual Arduino, no hardware

Real ports need:  pip install pyserial
"""

import argparse
import hashlib
import queue
import secrets
import sys
import threading
import time

CHALLENGE_BYTES = 32
NONCE_BYTES = 8
MIN_DIFFICULTY = 1
MAX_DIFFICULTY = 32          # the sketch rejects anything outside 1..32


# ==============================================================================
# PROOF CHECK (host side, independent of the Arduino)
# ==============================================================================
def leading_zero_bits(digest: bytes) -> int:
    n = int.from_bytes(digest, "big")
    return len(digest) * 8 - n.bit_length()


def verify_proof(challenge_hex, difficulty, nonce_hex, hash_hex, expect_challenge, expect_difficulty):
    """Returns (ok, reason). Recomputes the hash itself; never trusts the Arduino's claim."""
    if challenge_hex.upper() != expect_challenge.upper():
        return False, "challenge does not match the job that was sent"
    if difficulty != expect_difficulty:
        return False, f"difficulty {difficulty} != job difficulty {expect_difficulty}"
    try:
        challenge = bytes.fromhex(challenge_hex)
        nonce = bytes.fromhex(nonce_hex)
        claimed = bytes.fromhex(hash_hex)
    except ValueError:
        return False, "non-hex field"
    if len(nonce) != NONCE_BYTES:
        return False, "nonce is not 8 bytes"
    real = hashlib.sha256(challenge + nonce).digest()
    if real != claimed:
        return False, f"hash mismatch (real {real.hex().upper()})"
    bits = leading_zero_bits(real)
    if bits < difficulty:
        return False, f"only {bits} leading zero bits, need {difficulty}"
    return True, f"{bits} leading zero bits (need {difficulty})"


# ==============================================================================
# VIRTUAL ARDUINO  (same protocol as the sketch, brute force in Python)
# ==============================================================================
class VirtualArduino:
    """File-like object (write/readline/close) that behaves like the sketch over serial."""

    def __init__(self):
        self._out = queue.Queue()
        self._buf = b""
        self._lock = threading.Lock()
        self._gen = 0                 # bumped on every JOB/STOP so old mining threads quit
        self.state = "IDLE"           # IDLE | MINING | AWAITING
        self.disarmed = False
        self._say("MINER_READY")

    def _say(self, text):
        self._out.put((text + "\r\n").encode("ascii"))

    # ---- serial-like interface -------------------------------------------
    def write(self, data: bytes):
        self._buf += data
        while b"\n" in self._buf:
            line, self._buf = self._buf.split(b"\n", 1)
            line = line.replace(b"\r", b"").decode("ascii", "replace").upper()
            if line:
                self._handle(line)
        return len(data)

    def readline(self) -> bytes:
        try:
            return self._out.get(timeout=0.1)
        except queue.Empty:
            return b""

    def close(self):
        with self._lock:
            self._gen += 1

    # ---- commands ----------------------------------------------------------
    def _handle(self, line):
        if line.startswith("JOB:"):
            self._job(line[4:])
        elif line == "ACCEPTED":
            if self.state != "AWAITING":
                self._say("IGNORED:NO_PROOF_PENDING")
            else:
                self.state, self.disarmed = "IDLE", True
                self._say("DISARMED")
        elif line == "REJECTED":
            self.state = "IDLE"
            self._say("REJECTED_ACK")
        elif line == "STOP":
            if self.state == "IDLE":
                self._say("IDLE")
            else:
                with self._lock:
                    self._gen += 1
                self.state = "IDLE"
                self._say("STOPPED")
        else:
            self._say("ERR:UNKNOWN_COMMAND")

    def _job(self, payload):
        if ":" not in payload:
            self._say("ERR:BAD_JOB:FORMAT")
            return
        chal_hex, diff_txt = payload.split(":", 1)
        if len(chal_hex) != CHALLENGE_BYTES * 2:
            self._say("ERR:BAD_JOB:CHALLENGE_LENGTH")
            return
        try:
            challenge = bytes.fromhex(chal_hex)
        except ValueError:
            self._say("ERR:BAD_JOB:CHALLENGE_HEX")
            return
        digits = "".join(ch for ch in diff_txt if ch.isdigit())
        diff = int(digits) if digits else 0
        if not MIN_DIFFICULTY <= diff <= MAX_DIFFICULTY:
            self._say("ERR:BAD_JOB:DIFFICULTY_RANGE")
            return
        with self._lock:
            self._gen += 1
            gen = self._gen
        self.state = "MINING"
        self._say("MINING_STARTED")
        threading.Thread(target=self._mine, args=(gen, challenge, diff), daemon=True).start()

    def _mine(self, gen, challenge, diff):
        nonce = 0
        while True:
            if gen != self._gen:
                return
            nb = nonce.to_bytes(NONCE_BYTES, "big")
            digest = hashlib.sha256(challenge + nb).digest()
            if leading_zero_bits(digest) >= diff:
                self.state = "AWAITING"
                self._say(f"MINED:{challenge.hex().upper()}:{diff}:{nb.hex().upper()}:{digest.hex().upper()}")
                return
            nonce += 1


# ==============================================================================
# THE DUMB MINER (host)
# ==============================================================================
def open_port(name, baud):
    if name.upper() == "LOOPBACK":
        return VirtualArduino()
    try:
        import serial
    except ImportError:
        sys.exit("pyserial is not installed. Run: pip install pyserial")
    return serial.Serial(name, baud, timeout=0.1, write_timeout=1.0)


def send(port, line):
    port.write((line + "\n").encode("ascii"))
    print(f"TX  {line}")


def read_line(port):
    raw = port.readline()
    return raw.decode("ascii", "replace").strip() if raw else ""


def mine(port, challenge_hex, difficulty, timeout, accept):
    """Returns 0 on a verified proof, non-zero otherwise."""
    challenge_hex = challenge_hex.upper()

    # Opening a real port resets most Arduinos; give the banner a moment, but don't require it.
    t_end = time.time() + 2.5
    while time.time() < t_end:
        line = read_line(port)
        if line:
            print(f"RX  {line}")
            if line == "MINER_READY":
                break

    send(port, f"JOB:{challenge_hex}:{difficulty}")
    t0 = time.time()
    deadline = t0 + timeout if timeout else None

    try:
        while True:
            if deadline and time.time() > deadline:
                print(f"timeout after {timeout:g}s, stopping")
                send(port, "STOP")
                _drain(port, 1.0)
                return 2

            line = read_line(port)
            if not line:
                continue
            print(f"RX  {line}")

            if line.startswith("ERR:"):
                return 3
            elif line.startswith("MINED:"):
                parts = line.split(":")
                if len(parts) != 5 or not parts[2].isdigit():
                    print("malformed MINED line")
                    send(port, "REJECTED")
                    _drain(port, 1.0)
                    return 4
                _, chal, diff, nonce, digest = parts
                ok, why = verify_proof(chal, int(diff), nonce, digest, challenge_hex, difficulty)
                elapsed = time.time() - t0
                print(f"{'VALID' if ok else 'INVALID'}: {why}")
                if ok:
                    print(f"nonce  {nonce}  ({int(nonce, 16)} hashes)")
                    print(f"hash   {digest}")
                    print(f"time   {elapsed:.2f}s")
                    send(port, "ACCEPTED" if accept else "STOP")
                else:
                    send(port, "REJECTED")
                _drain(port, 1.0)
                return 0 if ok else 4
    except KeyboardInterrupt:
        print("\ninterrupted, stopping")
        send(port, "STOP")
        _drain(port, 1.0)
        return 130


def _drain(port, seconds):
    """Print whatever the Arduino says right after our reply (DISARMED, STOPPED, ...)."""
    end = time.time() + seconds
    while time.time() < end:
        line = read_line(port)
        if line:
            print(f"RX  {line}")
            if line in ("DISARMED", "STOPPED", "REJECTED_ACK", "IDLE", "IGNORED:NO_PROOF_PENDING"):
                return


def main():
    ap = argparse.ArgumentParser(description="Dumb PoW miner host for the Arduino JOB/MINED protocol")
    ap.add_argument("port", help="serial port (COM3, /dev/ttyACM0, ...) or LOOPBACK for the virtual Arduino")
    ap.add_argument("-d", "--difficulty", type=int, default=12,
                    help=f"leading zero bits, {MIN_DIFFICULTY}..{MAX_DIFFICULTY} (default 12)")
    ap.add_argument("-c", "--challenge", help="64 hex chars (default: random)")
    ap.add_argument("-b", "--baud", type=int, default=115200)
    ap.add_argument("-t", "--timeout", type=float, default=0, help="seconds before sending STOP (0 = wait forever)")
    ap.add_argument("--no-accept", action="store_true",
                    help="verify the proof but send STOP instead of ACCEPTED (leaves the relay alone)")
    args = ap.parse_args()

    if not MIN_DIFFICULTY <= args.difficulty <= MAX_DIFFICULTY:
        ap.error(f"difficulty must be {MIN_DIFFICULTY}..{MAX_DIFFICULTY}")
    challenge = args.challenge or secrets.token_hex(CHALLENGE_BYTES)
    if len(challenge) != CHALLENGE_BYTES * 2:
        ap.error("challenge must be exactly 64 hex characters")
    try:
        bytes.fromhex(challenge)
    except ValueError:
        ap.error("challenge is not valid hex")

    port = open_port(args.port, args.baud)
    try:
        sys.exit(mine(port, challenge, args.difficulty, args.timeout, not args.no_accept))
    finally:
        port.close()


if __name__ == "__main__":
    main()
