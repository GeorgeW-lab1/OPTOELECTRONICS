import hashlib
import numpy as np
from itertools import combinations

def packbits(b_vector):
    """Packs a binary vector into bytes for SHA-256 commitment."""
    # Ensure input is uint8 and pad to multiple of 8 if necessary
    b_arr = np.asarray(b_vector, dtype=np.uint8)
    padded_len = ((len(b_arr) + 7) // 8) * 8
    padded = np.zeros(padded_len, dtype=np.uint8)
    padded[:len(b_arr)] = b_arr
    return np.packbits(padded)

def run_transparent_bench(rows=8, cols=7, max_cycles=49, sigma=40.0, epsilon=0.02, r=0.45, seed=42):
    """
    Simulates the Optical-Channel Subset Sum Recovery and Chase List Decoding pipeline.
    """
    np.random.seed(seed)
    m = rows * cols
    print(f"[*] Initializing Subset Sum Instance: m = {m} variables ({rows}x{cols} grid)")

    # ---------------------------------------------------------
    # Step 1: Oracle Setup
    # ---------------------------------------------------------
    weights = np.random.randint(10**11, 10**12, size=m, dtype=np.int64)
    secret_b = np.random.randint(0, 2, size=m, dtype=np.uint8)
    if np.sum(secret_b) == 0:
        secret_b[0] = 1  # enforce at least one non-zero bit

    target_sum = np.dot(weights, secret_b.astype(np.int64))
    salt = os_urandom_mock(16)
    
    # Commitment: SHA-256(s || packbits(b))
    packed_secret = packbits(secret_b)
    commit_hasher = hashlib.sha256()
    commit_hasher.update(salt + packed_secret.tobytes())
    commitment = commit_hasher.digest()

    print(f"[*] Oracle Target Sum S = {target_sum}")
    print(f"[*] Commitment generated successfully.")

    # ---------------------------------------------------------
    # Step 2: Optical Channel & Recognizer State Initialization
    # ---------------------------------------------------------
    ones_counts = np.zeros(m, dtype=np.int32)
    zeros_counts = np.zeros(m, dtype=np.int32)
    seen_mask = np.zeros(m, dtype=bool)

    # Pre-reshape grid representation for optical rendering
    b_grid = secret_b.reshape((rows, cols))

    success = False
    solved_cycle = -1

    for cycle in range(1, max_cycles + 1):
        # 2A-2B: Render binary grid scaled by 255.0 and upsample via np.repeat (16x16 pixels per cell)
        # Equivalent to Kronecker spatial pooling preparation
        pixel_grid = np.repeat(np.repeat(b_grid.astype(float) * 255.0, 16, axis=0), 16, axis=1)

        # Add Gaussian sensor noise N(0, sigma^2)
        noise = np.random.normal(0, sigma, size=pixel_grid.shape)
        noisy_pixels = pixel_grid + noise

        # 2C: Kronecker Spatial Pooling (Reshape and average 16x16 blocks -> R x C cells)
        pooled_cells = noisy_pixels.reshape(rows, 16, cols, 16).mean(axis=(1, 3))
        pooled_flat = pooled_cells.flatten()

        # 2D: Synthetic bit-flip mask and erasure reveal mask
        # Reveal mask: Bernoulli(r)
        revealed = np.random.rand(m) < r
        # Bit-flip mask: Bernoulli(epsilon) on revealed bits
        flips = np.random.rand(m) < epsilon

        # Update sufficient statistics for newly revealed cells
        for i in range(m):
            if revealed[i]:
                observed_bit = secret_b[i]
                if flips[i]:
                    observed_bit = 1 - observed_bit  # apply BSC error

                if observed_bit == 1:
                    ones_counts[i] += 1
                else:
                    zeros_counts[i] += 1
                seen_mask[i] = True

        valid_count = np.sum(seen_mask)
        
        # Check if all bits have been observed at least once (Coupon-Collector Cover Time)
        if valid_count == m:
            # 2E: Maximum-likelihood majority estimate
            b_hat = (ones_counts > zeros_counts).astype(np.uint8)

            # 2F: Dual Verifier Check
            current_sum = int(np.dot(weights, b_hat.astype(np.int64)))
            packed_b_hat = packbits(b_hat)
            
            hash_hasher = hashlib.sha256()
            hash_hasher.update(salt + packed_b_hat.tobytes())
            current_commit = hash_hasher.digest()

            if current_sum == target_sum and current_commit == commitment:
                success = True
                solved_cycle = cycle
                print(f"[+] Success! Exact recovery achieved at cycle {cycle}.")
                break
            
            # If verification fails, apply Chase List Decoding (L=16, t=4)
            if cycle >= 23:  # Typical cover time threshold for larger configurations
                margins = np.abs(ones_counts - zeros_counts)
                l_indices = np.argsort(margins)[:16]  # Select L=16 least confident bits

                # Generate flip patterns of weight k <= 4
                chase_success = False
                for k in range(1, 5):
                    for combo in combinations(l_indices, k):
                        cand = b_hat.copy()
                        for idx in combo:
                            cand[idx] = 1 - cand[idx]  # flip bit

                        # Incremental / candidate verification
                        cand_sum = int(np.dot(weights, cand.astype(np.int64)))
                        if cand_sum == target_sum:
                            cand_packed = packbits(cand)
                            cand_hasher = hashlib.sha256()
                            cand_hasher.update(salt + cand_packed.tobytes())
                            if cand_hasher.digest() == commitment:
                                success = True
                                solved_cycle = cycle
                                b_hat = cand
                                chase_success = True
                                break
                    if chase_success:
                        break
                if chase_success:
                    print(f"[+] Chase List Decoding Success at cycle {cycle}!")
                    break

        if cycle % 10 == 0 or cycle == max_cycles:
            print(f"[*] Cycle {cycle}/{max_cycles} completed. Valid coverage: {valid_count}/{m}")

    if not success:
        print("[-] Pipeline reached max cycles without successful verification.")
    
    return success, solved_cycle, b_hat if success else None

def os_urandom_mock(n):
    """Mock for os.urandom to generate reproducible cryptographic salt."""
    import os
    return os.urandom(n)

if __name__ == "__main__":
    # Run with legacy 56-bit configuration for quick verification demonstration
    # (Set rows=800, cols=700 for the full 560,000-bit scaled simulation)
    run_transparent_bench(rows=8, cols=7, max_cycles=49)
