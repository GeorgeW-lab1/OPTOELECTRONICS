#!/usr/bin/env python3
"""
rp_synthetic_camera_math_solver.py

SYNTHETIC OPTICAL CAMERA & MATHEMATICAL TENSOR FOLDING PIPELINE
SIMULTANEOUS NONCE AND SHA-256 PROOF-OF-WORK RECOVERY
"""

from __future__ import annotations

import argparse
import hashlib
import math
import os
import secrets
import sys

import numpy as np

try:
    import cv2
except ImportError:
    cv2 = None

try:
    from tqdm import tqdm
except ImportError:
    print("Missing tqdm. Install it with: pip install tqdm")
    raise

try:
    import sympy
except ImportError:
    sympy = None


# ============================================================
# MATHEMATICAL TENSOR & ORACLE CORE
# ============================================================

def custom_data_to_tensor_number(data_str: str = "hello world", bits: int = 64):
    if not data_str:
        raise ValueError("custom-data must not be empty")
    digest_bytes = hashlib.sha256(data_str.encode("utf-8")).digest()
    digest_hex = digest_bytes.hex()
    if bits % 8 or not 8 <= bits <= 256:
        raise ValueError("bits must be a multiple of 8 in [8, 256]")
    hidden_number = (int.from_bytes(digest_bytes, "big") >> (256 - bits)) | (1 << (bits - 1))
    return hidden_number, digest_hex, data_str


class TensorMathematicalOracle:
    def __init__(self, target_number=None, bits=64, custom_data="hello world"):
        self.digest_hex = None
        self.data_input = None

        if target_number is None:
            target_number, digest_hex, data_input = custom_data_to_tensor_number(data_str=custom_data, bits=bits)
            self.digest_hex = digest_hex
            self.data_input = data_input

        self.hidden_number = target_number
        self.bits = bits
        self.byte_length = bits // 8

        self.salt = os.urandom(16)
        self.commitment = self._hash(self.hidden_number)
        self.prime_factors = self._compute_factors(self.hidden_number)

    def _hash(self, value):
        payload = value.to_bytes(self.byte_length, "big")
        return hashlib.sha256(self.salt + payload).digest()

    def _compute_factors(self, n):
        if sympy is not None:
            factors = []
            for prime, exp in sympy.factorint(n).items():
                factors.extend([int(prime)] * int(exp))
            return sorted(factors)
        factors = []
        rem, div = n, 2
        while div * div <= rem:
            while rem % div == 0:
                factors.append(div)
                rem //= div
            div = 3 if div == 2 else div + 2
        if rem > 1:
            factors.append(rem)
        return sorted(factors)

    def public_parameters(self):
        return {"salt": self.salt, "commitment": self.commitment}

    def bit_vector(self):
        return np.array([(self.hidden_number >> i) & 1 for i in range(self.bits)], dtype=np.uint8)

    def verify(self, candidate):
        return self._hash(candidate) == self.commitment

    def reveal_if_proven(self, candidate):
        if not self.verify(candidate):
            return None
        return {
            "hidden_number": self.hidden_number,
            "prime_factors": self.prime_factors,
            "commitment": self.commitment.hex(),
        }


# ============================================================
# SYNTHETIC CAMERA & MATHEMATICAL SPATIAL POOLING
# ============================================================

def create_mathematical_bit_grid(bit_vector, rows, cols, cell_size=24):
    total = rows * cols
    padded = np.zeros(total, dtype=np.uint8)
    padded[:len(bit_vector)] = bit_vector
    grid = padded.reshape(rows, cols)
    pixels = grid * 255
    image = np.repeat(np.repeat(pixels, cell_size, axis=0), cell_size, axis=1)
    image[::cell_size, :] = 90
    image[:, ::cell_size] = 90
    if cv2 is not None:
        return cv2.cvtColor(image.astype(np.uint8), cv2.COLOR_GRAY2BGR)
    return image


class SyntheticCameraSource:
    """Simulates physical optical camera frames mixed with mathematical sensor noise."""
    def __init__(self, optical_noise=0.01):
        self.optical_noise = optical_noise

    def read_frame(self, grid_image):
        if cv2 is None:
            return grid_image.copy()
        # Apply synthetic optical distortions and Poisson/Gaussian lighting variance
        noise = np.random.normal(0, self.optical_noise * 255, grid_image.shape)
        distorted = np.clip(grid_image.astype(np.float32) + noise, 0, 255).astype(np.uint8)
        return distorted

    def close(self):
        pass


def mathematical_spatial_pooling(frame, rows, cols, threshold=127.0):
    """Mathematical spatial integral transform over optical camera frame cells."""
    if cv2 is None:
        raise RuntimeError("OpenCV required")
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY) if frame.ndim == 3 else frame
    pooled_input = cv2.resize(gray, (cols * 16, rows * 16), interpolation=cv2.INTER_AREA)
    cells = pooled_input.reshape(rows, 16, cols, 16)
    
    # Mathematical integration across cell tensor space
    pooled = cells.mean(axis=(1, 3), dtype=np.float32)
    observed_bits = (pooled > threshold).astype(np.uint8).ravel()
    confidence = np.abs(pooled.ravel() - threshold)
    valid = confidence >= 20.0
    return observed_bits, valid


# ============================================================
# TENSOR FOLDED RECOGNISER (NONCE + POW)
# ============================================================

class TensorFoldedPowRecogniser:
    def __init__(self, bits, salt, commitment, difficulty=2, max_candidates=200_000):
        self.bits = bits
        self.byte_length = bits // 8
        self.salt = salt
        self.commitment = commitment
        self.difficulty = difficulty
        self.max_candidates = max_candidates
        
        self.ones = np.zeros(bits, dtype=np.uint32)
        self.zeros = np.zeros(bits, dtype=np.uint32)
        
        self.cycles = 0
        self.candidates_tested = 0
        self.pow_solved_count = 0
        self.recovered = None
        self.proof = None

    def observe(self, observed_bits, valid):
        self.ones += (observed_bits * valid).astype(np.uint32)
        self.zeros += ((1 - observed_bits) * valid).astype(np.uint32)
        self.cycles += 1
        self._tensor_mathematical_decode()

    def _candidate_digest(self, candidate):
        return hashlib.sha256(self.salt + candidate.to_bytes(self.byte_length, "big")).digest()

    def _tensor_mathematical_decode(self):
        if not np.all((self.ones + self.zeros) > 0):
            return

        recovered_bits = (self.ones > self.zeros).astype(np.uint8)
        base_candidate = sum(int(bit) << i for i, bit in enumerate(recovered_bits))
        
        # Chaotic mathematical map parameters (Logistic attractor sequence)
        x = 0.314159
        r = 3.99
        max_val = (1 << self.bits) - 1

        for _ in range(min(400, self.max_candidates - self.candidates_tested)):
            if self.candidates_tested >= self.max_candidates:
                return
            
            x = r * x * (1.0 - x)
            offset = int(x * max_val) % (1 << min(16, self.bits))
            candidate = base_candidate ^ offset

            self.candidates_tested += 1
            digest = self._candidate_digest(candidate)
            
            # Simultaneous PoW difficulty & cryptographic commitment check
            if digest.hex().startswith("0" * self.difficulty):
                self.pow_solved_count += 1
                if digest == self.commitment:
                    self.recovered = candidate
                    self.proof = {
                        "hidden_number": candidate,
                        "candidates_tested": self.candidates_tested,
                        "pow_solved": self.pow_solved_count,
                        "digest_hex": digest.hex()
                    }
                    return

    @property
    def known_count(self):
        return int(np.count_nonzero((self.ones + self.zeros) > 0))


# ============================================================
# EXECUTION ROUTINE
# ============================================================

def run(args):
    bits = max(8, ((args.secret_bits + 7) // 8) * 8)
    rows, cols = args.rows, math.ceil(bits / args.rows)
    total_cells = rows * cols

    oracle = TensorMathematicalOracle(target_number=args.n, bits=total_cells, custom_data=args.custom_data)
    recogniser = TensorFoldedPowRecogniser(
        bits=total_cells,
        salt=oracle.public_parameters()["salt"],
        commitment=oracle.public_parameters()["commitment"],
        difficulty=args.difficulty,
        max_candidates=args.max_candidates
    )

    camera = SyntheticCameraSource(optical_noise=args.noise)
    oracle_bits = oracle.bit_vector()
    grid_image = create_mathematical_bit_grid(oracle_bits, rows, cols)

    print("\n========== SYNTHETIC CAMERA & MATH TENSOR RECOVERY ==========")
    print(f"Target Number N      : {oracle.hidden_number}")
    print(f"Tensor Width         : {bits} bits")
    print(f"Spatial Grid         : {rows} x {cols}")
    print(f"Custom Input Data    : {oracle.data_input}")
    print(f"PoW Difficulty (0s)  : {args.difficulty}")

    progress = tqdm(range(args.cycles), desc="Synthetic camera optical frames", unit="frame")
    for _ in progress:
        frame = camera.read_frame(grid_image)
        observed_bits, valid = mathematical_spatial_pooling(frame, rows, cols, args.threshold)
        
        recogniser.observe(observed_bits, valid)
        progress.set_postfix(tested=recogniser.candidates_tested, pow_solved=recogniser.pow_solved_count)

        if recogniser.recovered is not None:
            break

    camera.close()

    print("\n========== RESULTS & PROOF ==========")
    if recogniser.proof:
        p = recogniser.proof
        print("SUCCESS: Unified Tensor Nonce & PoW Hash Synchronized!")
        print(f"Recovered Nonce      : {p['hidden_number']}")
        print(f"Candidates Tested    : {p['candidates_tested']}")
        print(f"Valid PoW Solutions  : {p['pow_solved']}")
        print(f"SHA-256 PoW Hash     : {p['digest_hex']}")
        
        revealed = oracle.reveal_if_proven(recogniser.recovered)
        if revealed:
            print(f"Prime Factors        : {revealed['prime_factors']}")
    else:
        print("FAILED: Recovery limit reached without synchronization.")


def main():
    parser = argparse.ArgumentParser(description="Synthetic camera & math tensor nonce/PoW solver")
    parser.add_argument("--n", type=int, default=None)
    parser.add_argument("--secret-bits", type=int, default=64)
    parser.add_argument("--custom-data", type=str, default="hello world")
    parser.add_argument("--difficulty", type=int, default=2)
    parser.add_argument("--cycles", type=int, default=500)
    parser.add_argument("--noise", type=float, default=0.01)
    parser.add_argument("--max-candidates", type=int, default=200000)
    parser.add_argument("--rows", type=int, default=8)
    parser.add_argument("--threshold", type=float, default=127.0)
    run(parser.parse_args())


if __name__ == "__main__":
    main()