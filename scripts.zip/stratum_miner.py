"""
Stratum V1 client + pure-Python SHA-256d miner lanes for the RP circuit.

Protocol: mining.subscribe -> mining.authorize -> mining.set_difficulty / mining.notify,
shares go back with mining.submit. Plain TCP (stratum+tcp), no TLS.

Share check: double-SHA256 of the 80-byte header, read as a little-endian integer,
must be <= diff1_target / pool_difficulty  (diff1_target = 0xffff * 2^208).
"""
import hashlib
import json
import secrets
import socket
import threading
import time

DIFF1 = 0xFFFF << 208
sha256 = hashlib.sha256


def dsha(b: bytes) -> bytes:
    return sha256(sha256(b).digest()).digest()


def swap_words(prevhash_hex: str) -> bytes:
    """Stratum sends prevhash as 8 words, each byte-reversed relative to the header."""
    raw = bytes.fromhex(prevhash_hex)
    return b"".join(raw[i:i + 4][::-1] for i in range(0, 32, 4))


def merkle_root(coinbase: bytes, branch) -> bytes:
    root = dsha(coinbase)
    for h in branch:
        root = dsha(root + h)
    return root


def build_header76(job, en1: bytes, en2: bytes) -> bytes:
    coinbase = job["c1"] + en1 + en2 + job["c2"]
    return (job["version"] + job["prev"] + merkle_root(coinbase, job["branch"])
            + job["ntime"] + job["nbits"])


def share_value(header76: bytes, nonce: int) -> int:
    return int.from_bytes(dsha(header76 + nonce.to_bytes(4, "little")), "little")


class StratumMiner:
    def __init__(self, host, port, user, password="x", lanes=2, log=print):
        self.host, self.port, self.user, self.password = host, int(port), user, password
        self.lanes, self.log = max(1, int(lanes)), log
        self.stop_ev = threading.Event()
        self.connected = False
        self.sock = None
        self.send_lock = threading.Lock()
        self.job = None                    # newest mining.notify, swapped as one pointer
        self.en1 = b""
        self.en2_size = 4
        self.diff = 1.0
        self.pending = {}                  # request id -> (job id, difficulty)
        self._id = 10
        self.hashes = 0
        self.accepted = self.rejected = self.submitted = 0
        self.best = 0.0                    # best share difficulty seen (even if below pool diff)
        self.last_reject = ""
        self.hps = 0.0
        self.threads = []

    # ------------------------------------------------------------ lifecycle
    def start(self):
        t = threading.Thread(target=self._conn_loop, daemon=True, name="stratum")
        t.start()
        self.threads = [t]
        for i in range(self.lanes):
            w = threading.Thread(target=self._lane, args=(i,), daemon=True, name=f"sha256d-{i}")
            w.start()
            self.threads.append(w)

    def stop(self):
        self.stop_ev.set()
        try:
            if self.sock:
                self.sock.close()
        except OSError:
            pass

    def snapshot(self):
        return dict(host=f"{self.host}:{self.port}", connected=self.connected, diff=self.diff,
                    hashes=self.hashes, hps=self.hps, submitted=self.submitted,
                    accepted=self.accepted, rejected=self.rejected, best=self.best,
                    last_reject=self.last_reject, job=self.job["id"] if self.job else None)

    # ------------------------------------------------------------ network
    def _send(self, obj):
        data = (json.dumps(obj) + "\n").encode()
        with self.send_lock:
            self.sock.sendall(data)

    def _conn_loop(self):
        backoff = 2
        while not self.stop_ev.is_set():
            try:
                self.sock = socket.create_connection((self.host, self.port), timeout=30)
                self.sock.settimeout(120)
                self.log(f"# pool: connected to {self.host}:{self.port}")
                self._send({"id": 1, "method": "mining.subscribe", "params": ["rp-circuit/1.0"]})
                self._send({"id": 2, "method": "mining.authorize", "params": [self.user, self.password]})
                backoff = 2
                for line in self.sock.makefile("r", encoding="utf-8", errors="replace"):
                    if self.stop_ev.is_set():
                        break
                    line = line.strip()
                    if line:
                        self._handle(json.loads(line))
            except (OSError, ValueError) as e:
                self.log(f"# pool: connection problem: {e}")
            self.connected = False
            self.job = None
            if self.stop_ev.is_set():
                return
            self.log(f"# pool: reconnecting in {backoff} s")
            self.stop_ev.wait(backoff)
            backoff = min(backoff * 2, 60)

    def _handle(self, m):
        mid, method = m.get("id"), m.get("method")
        if method == "mining.notify":
            p = m["params"]
            self.job = dict(id=p[0], prev=swap_words(p[1]), c1=bytes.fromhex(p[2]),
                            c2=bytes.fromhex(p[3]), branch=[bytes.fromhex(h) for h in p[4]],
                            version=bytes.fromhex(p[5])[::-1], nbits=bytes.fromhex(p[6])[::-1],
                            ntime=bytes.fromhex(p[7])[::-1], ntime_hex=p[7], clean=p[8])
        elif method == "mining.set_difficulty":
            self.diff = float(m["params"][0])
            self.log(f"# pool: difficulty set to {self.diff:g}")
        elif method == "client.reconnect":
            raise OSError("pool asked to reconnect")
        elif mid == 1 and m.get("result"):
            self.en1 = bytes.fromhex(m["result"][1])
            self.en2_size = int(m["result"][2])
            self.log(f"# pool: subscribed (extranonce1 {self.en1.hex()}, en2 size {self.en2_size})")
        elif mid == 2:
            self.connected = bool(m.get("result"))
            self.log("# pool: authorised" if self.connected else f"# pool: AUTH FAILED {m.get('error')}")
        elif mid in self.pending:
            job_id, d = self.pending.pop(mid)
            if m.get("result"):
                self.accepted += 1
                self.log(f"POOL SHARE ACCEPTED (job {job_id}, diff {d:g}) "
                         f"{self.accepted}/{self.submitted}")
            else:
                self.rejected += 1
                self.last_reject = str(m.get("error"))
                self.log(f"POOL SHARE REJECTED (job {job_id}): {self.last_reject}")

    def _submit(self, job, en2: bytes, nonce: int, d: float):
        self._id += 1
        self.pending[self._id] = (job["id"], d)
        self.submitted += 1
        try:
            self._send({"id": self._id, "method": "mining.submit",
                        "params": [self.user, job["id"], en2.hex(), job["ntime_hex"], f"{nonce:08x}"]})
        except OSError as e:
            self.log(f"# pool: submit failed: {e}")

    # ------------------------------------------------------------ miner lane
    def _lane(self, lane):
        while not self.stop_ev.is_set():
            job, diff = self.job, self.diff
            if job is None or not self.connected:
                self.hps = 0.0
                time.sleep(0.2)
                continue
            en2 = secrets.token_bytes(self.en2_size)          # own random extranonce2 per pass
            h76 = build_header76(job, self.en1, en2)
            mid = sha256(h76[:64])
            tail = h76[64:76]
            target = int(DIFF1 / diff)
            quick = diff >= 1.0                               # target < 2^224: top 4 bytes must be 0
            t0 = time.perf_counter()
            done = 0
            for nonce in range(1 << 32):
                h = mid.copy()
                h.update(tail + nonce.to_bytes(4, "little"))
                d = sha256(h.digest()).digest()
                if quick and d[28:] != b"\0\0\0\0":
                    pass
                else:
                    v = int.from_bytes(d, "little")
                    if v:
                        self.best = max(self.best, DIFF1 / v)
                    if v <= target:
                        self._submit(job, en2, nonce, diff)
                done += 1
                if done == 8192:
                    self.hashes += done
                    self.hps = done / max(time.perf_counter() - t0, 1e-9) if lane == 0 else self.hps
                    done, t0 = 0, time.perf_counter()
                    if self.job is not job or self.diff != diff or self.stop_ev.is_set():
                        break
            self.hashes += done
