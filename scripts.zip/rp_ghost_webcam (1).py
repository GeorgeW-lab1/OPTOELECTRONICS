#!/usr/bin/env python3
"""
RP-GHOST Webcam Oracle — Local Research Implementation
Author: George Wagenknecht

ARCHITECTURE
    Webcam / simulated entropy source
        |
        v
    Temporal image differences
        |
        v
    LSB extraction + Von Neumann debiasing
        |
        v
    64-bit oracle candidate
        |
        v
    ORACLE ZERO-PREFIX FILTER: SHA-256(candidate) must start with
    N zero bits (hashcash-style filter on the oracle, ~2^N samples)
        |
        v
    SHA-256-derived extranonce2
        |
        v
    Local 80-byte header construction
        |
        v
    LEFT-SIDE MINER: sequential nonce search
        |
        v
    INDEPENDENT SHA-256d recomputation

RP DECISION CIRCUIT
    Driver A: parity of extracted noise bits
    Driver B: motion energy exceeds calibrated threshold
    Gate:     A AND B
    Latch:    simulated clock-edge sampling
    Trials:   accept if ANY trial latches HIGH

IMPORTANT
    This is a local research implementation.
    It does NOT connect to Bitcoin Stratum pools.
    It does NOT submit Bitcoin shares.
    It does NOT establish that webcam data is cryptographically secure.

    The oracle selects candidates. It does not bypass proof-of-work.
    The oracle zero-prefix filter is separate from the header target:
    it costs ~2^N oracle samples and gives the header search no head start.
    A candidate is valid only if its independently recomputed hash
    satisfies the configured target.

INSTALL
    pip install numpy opencv-python

EXAMPLES
    python rp_ghost_webcam.py --camera 0
    python rp_ghost_webcam.py --simulate
    python rp_ghost_webcam.py --simulate --oracle-zeros 12
    python rp_ghost_webcam.py --simulate --oracle-zeros 0      (filter off)
    python rp_ghost_webcam.py --benchmark --simulate
    python rp_ghost_webcam.py --benchmark-nonce --simulate
    python rp_ghost_webcam.py --benchmark-nonce --nonce-bits 16 --bits 12
    python rp_ghost_webcam.py --midstate --simulate
"""

import argparse
import hashlib
import os
import statistics
import struct
import time

import numpy as np

try:
    import cv2
except ImportError:
    cv2 = None


# ============================================================
# CONFIGURATION / VALIDATION
# ============================================================
def reconstruct_oracle_sha256(seed):
    """Reconstruct the deterministic SHA-256 output from the 64-bit oracle value."""
    if not 0 <= seed <= 0xFFFFFFFFFFFFFFFF:
        raise ValueError("Oracle seed must be 64 bits.")

    oracle_input = seed.to_bytes(8, "big")
    oracle_sha256 = hashlib.sha256(oracle_input).digest()

    return {
        "oracle_input": oracle_input,
        "oracle_sha256": oracle_sha256,
        "extranonce2": oracle_sha256[:4],
    }


def verify_oracle_reconstruction(seed, expected_digest):
    return reconstruct_oracle_sha256(seed)["oracle_sha256"] == expected_digest


def validate_bits(bits):
    if not 1 <= bits <= 255:
        raise ValueError("Difficulty bits must be between 1 and 255.")


def validate_nonce_bits(bits):
    if not 1 <= bits <= 32:
        raise ValueError("Nonce width must be between 1 and 32.")


def target_from_bits(bits):
    validate_bits(bits)
    return 1 << (256 - bits)


def hash_meets_target(digest, target):
    """
    Bitcoin-style interpretation of the double-SHA-256 digest.
    The displayed digest is conventionally byte-reversed.
    """
    return int.from_bytes(digest[::-1], "big") < target


def leading_zero_bits(digest):
    """Number of leading zero bits in a digest, in natural byte order."""
    return 256 - int.from_bytes(digest, "big").bit_length()


# ============================================================
# HASHING
# ============================================================
def sha256d(data):
    """Double SHA-256."""
    return hashlib.sha256(hashlib.sha256(data).digest()).digest()


def hash_header(prefix, nonce):
    """Hash an 80-byte header."""
    if len(prefix) != 76:
        raise ValueError("Header prefix must be exactly 76 bytes.")
    if not 0 <= nonce <= 0xFFFFFFFF:
        raise ValueError("Nonce must fit into 32 bits.")

    header = prefix + struct.pack("<I", nonce)
    if len(header) != 80:
        raise ValueError("Constructed header is not 80 bytes.")

    return sha256d(header)


# ============================================================
# ENTROPY EXTRACTION
# ============================================================
def von_neumann(bits):
    """
    Von Neumann debiasing: 01 -> 0, 10 -> 1, 00/11 -> discard.

    Reduces first-order bias under suitable assumptions.
    It does NOT establish cryptographic entropy or independence.
    """
    n = (len(bits) // 2) * 2
    if n == 0:
        return np.array([], dtype=np.uint8)

    a = bits[:n:2]
    b = bits[1:n:2]
    return a[a != b]


class WebcamOracle:

    def __init__(self, index=0, simulate=False, warmup=10, max_entropy_frames=10000):
        self.simulate = bool(simulate or cv2 is None)
        self.cap = None
        self.prev = None
        self.max_entropy_frames = max_entropy_frames

        if self.simulate:
            print("[oracle] simulation mode enabled")
            print("[oracle] simulated frames generated using os.urandom")
            return

        self.cap = cv2.VideoCapture(index)
        if not self.cap.isOpened():
            raise RuntimeError(f"Unable to open camera index {index}")

        for _ in range(warmup):
            self.cap.read()

        print(f"[oracle] camera {index} opened")

    def _frame(self):
        if self.simulate:
            raw = os.urandom(64 * 64)
            return np.frombuffer(raw, dtype=np.uint8).reshape(64, 64)

        ok, frame = self.cap.read()
        if not ok:
            raise RuntimeError("Camera frame acquisition failed.")

        return cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

    def sample(self):
        """
        Returns (noise_bits, motion_energy).
        The extracted bits are experimental sensor-derived values.
        Their entropy has not been independently established.
        """
        cur = self._frame()

        if self.prev is None:
            self.prev = cur
            cur = self._frame()

        if self.simulate:
            diff = np.bitwise_xor(cur, self.prev)
        else:
            diff = cv2.absdiff(cur, self.prev)

        self.prev = cur

        temporal_bits = (diff & 1).flatten().astype(np.uint8)
        raw_bits = (cur & 1).flatten().astype(np.uint8)

        # Mix temporal difference and raw-frame LSB measurements.
        bits = temporal_bits ^ raw_bits
        energy = float(np.mean(diff))

        return bits, energy

    def oracle_64(self):
        """
        Collect 64 debiased bits. A frame limit prevents an endless loop
        if the source produces too few unequal bit pairs.
        """
        collected = []
        total = 0
        count = 0

        while total < 64:
            if count >= self.max_entropy_frames:
                raise RuntimeError(
                    "Unable to collect 64 debiased bits. Check the entropy source."
                )

            bits, _ = self.sample()
            filtered = von_neumann(bits)

            if len(filtered):
                collected.append(filtered)
                total += len(filtered)

            count += 1

        pool = np.concatenate(collected)[:64]

        result = 0
        for bit in pool:
            result = (result << 1) | int(bit)

        return result

    def close(self):
        if self.cap is not None:
            self.cap.release()


# ============================================================
# ORACLE ZERO-PREFIX FILTER
# ============================================================
def acquire_oracle_with_zeros(oracle, zero_bits, max_attempts=1_000_000):
    """
    Keep sampling the oracle until SHA-256(seed) starts with `zero_bits`
    zero bits. The digest is checked in natural byte order, so the printed
    hex visibly starts with zeros (e.g. 00 2d f5 ...).

    This is a hashcash-style filter on the ORACLE output. It is separate
    from the header proof-of-work and costs ~2^zero_bits samples.

    Returns (seed, digest, attempts, elapsed_seconds).
    """
    if not 0 <= zero_bits <= 64:
        raise ValueError("oracle zero bits must be between 0 and 64.")
    if max_attempts < 1:
        raise ValueError("max_attempts must be at least 1.")

    start = time.perf_counter()

    for attempt in range(1, max_attempts + 1):
        seed = oracle.oracle_64()
        digest = hashlib.sha256(seed.to_bytes(8, "big")).digest()

        if leading_zero_bits(digest) >= zero_bits:
            return seed, digest, attempt, time.perf_counter() - start

    raise RuntimeError(
        f"No oracle candidate with {zero_bits} leading zero bits "
        f"in {max_attempts:,} attempts."
    )


# ============================================================
# RP DECISION CIRCUIT
# ============================================================
def calibrate_driver_b(oracle, calibration_samples=20, mad_multiplier=3.0):
    """
    Calibrate Driver B using a separate baseline acquisition.
    The current trial is NOT included in its own threshold calculation.

    Threshold: median + max(1.0, MAD * 1.4826 * multiplier)
    """
    energies = []

    print("\n[rp] calibrating Driver B")

    for _ in range(calibration_samples):
        _, energy = oracle.sample()
        energies.append(energy)

    median_energy = float(np.median(energies))
    mad = float(np.median(np.abs(np.array(energies) - median_energy)))
    robust_sigma = 1.4826 * mad

    threshold = median_energy + max(1.0, robust_sigma * mad_multiplier)

    print(f"[rp] baseline median : {median_energy:.4f}")
    print(f"[rp] baseline MAD    : {mad:.4f}")
    print(f"[rp] Driver B limit  : {threshold:.4f}")

    return threshold


def rp_decision(oracle, k=8, clock_hz=10.0, calibration_samples=20, mad_multiplier=3.0):
    """
    Software model of the RP decision circuit.

    Driver A: parity of the acquired noise-bit frame.
    Driver B: motion energy exceeds the independently calibrated threshold.
    Gate:     A AND B.
    Latch:    software delay approximating a clock-edge sample.
    Repeat:   accept if ANY trial latches HIGH.
    """
    if k < 1:
        raise ValueError("k must be at least 1.")
    if clock_hz <= 0:
        raise ValueError("clock_hz must be positive.")

    threshold = calibrate_driver_b(oracle, calibration_samples, mad_multiplier)

    print("\n[rp] decision trials")

    for trial in range(k):
        bits, energy = oracle.sample()

        A = int(np.sum(bits, dtype=np.uint64) & 1)   # Driver A: parity
        B = int(energy > threshold)                  # Driver B: calibrated threshold
        Q = A & B                                    # gate

        if not oracle.simulate:
            time.sleep(1.0 / clock_hz)               # simulated clock edge

        print(
            f"  trial {trial + 1}/{k} A={A} B={B} "
            f"energy={energy:.4f} threshold={threshold:.4f} Q={Q}"
        )

        if Q:
            print("[rp] SELECT = HIGH")
            return True

    print("[rp] SELECT = LOW")
    return False


# ============================================================
# LOCAL HEADER CONSTRUCTION
# ============================================================
def make_header_prefix(extranonce2):
    """
    Construct a LOCAL TEST header prefix (not a real Bitcoin mining job).

    Dummy fields: all-zero previous hash, local coinbase string,
    locally generated merkle root, fixed nBits. A real Stratum
    implementation must use the actual pool job and network parameters.
    """
    if not isinstance(extranonce2, bytes):
        raise TypeError("extranonce2 must be bytes.")

    version = struct.pack("<I", 0x20000000)
    prevhash = bytes(32)
    merkle = sha256d(b"RP-GHOST-local-test" + extranonce2)
    ntime = struct.pack("<I", int(time.time()))
    nbits = struct.pack("<I", 0x1D00FFFF)

    prefix = version + prevhash + merkle + ntime + nbits

    if len(prefix) != 76:
        raise ValueError(f"Invalid header prefix length: {len(prefix)}")

    return prefix


def oracle_to_extranonce2(seed):
    """Convert a 64-bit oracle input into a 4-byte seed."""
    return reconstruct_oracle_sha256(seed)["extranonce2"]


# ============================================================
# SEQUENTIAL NONCE MINER
# ============================================================
def search_nonce(prefix, bits, max_nonce=2**32):
    """Sequential nonce search. Returns (nonce, digest, hashes_tried, elapsed)."""
    target = target_from_bits(bits)

    if not 1 <= max_nonce <= 2**32:
        raise ValueError("max_nonce must be between 1 and 2^32.")

    start = time.perf_counter()

    for nonce in range(max_nonce):
        digest = hash_header(prefix, nonce)

        if hash_meets_target(digest, target):
            return nonce, digest, nonce + 1, time.perf_counter() - start

    return None, None, max_nonce, time.perf_counter() - start


# ============================================================
# MIDSTATE SEARCH
# ============================================================
def search_nonce_midstate(prefix, bits, max_nonce=2**32):
    """
    SHA-256 midstate optimization: the first 64 header bytes are processed
    once; each nonce then processes only the 16-byte tail plus the second
    SHA-256. Changes hashing efficiency, not proof-of-work probability.
    """
    target = target_from_bits(bits)

    if len(prefix) != 76:
        raise ValueError("Prefix must be 76 bytes.")
    if not 1 <= max_nonce <= 2**32:
        raise ValueError("max_nonce must be between 1 and 2^32.")

    base = hashlib.sha256(prefix[:64])
    tail = prefix[64:]

    start = time.perf_counter()

    for nonce in range(max_nonce):
        first = base.copy()
        first.update(tail + struct.pack("<I", nonce))
        digest = hashlib.sha256(first.digest()).digest()

        if hash_meets_target(digest, target):
            return nonce, digest, nonce + 1, time.perf_counter() - start

    return None, None, max_nonce, time.perf_counter() - start


# ============================================================
# INDEPENDENT VERIFICATION
# ============================================================
def verify(prefix, nonce, bits):
    """
    Independently recompute SHA-256d for the supplied candidate.
    Verifies the local header and local target only; not pool acceptance.
    """
    if len(prefix) != 76:
        return False
    if not 0 <= nonce <= 0xFFFFFFFF:
        return False

    header = prefix + struct.pack("<I", nonce)
    if len(header) != 80:
        return False

    first_hash = hashlib.sha256(header).digest()
    second_hash = hashlib.sha256(first_hash).digest()

    return hash_meets_target(second_hash, target_from_bits(bits))


# ============================================================
# DISPLAY HELPERS
# ============================================================
def fmt_time(seconds):
    if seconds < 60:
        return f"{seconds:.3f} s"
    if seconds < 3600:
        return f"{seconds / 60:.2f} min"
    if seconds < 86400:
        return f"{seconds / 3600:.2f} hours"
    if seconds < 86400 * 365:
        return f"{seconds / 86400:.2f} days"
    return f"{seconds / (86400 * 365):.2f} years"


def print_result(nonce, digest, tried, elapsed, bits):
    rate = tried / elapsed if elapsed > 0 else 0

    print("\n[miner] SEARCH RESULT")

    if nonce is None:
        print("[miner] No valid nonce found.")
        print(f"[miner] Hashes tried: {tried:,}")
        print(f"[miner] Elapsed: {elapsed:.3f}s")
        print(f"[miner] Hash rate: {rate:,.0f} H/s")
        return

    print(f"[miner] nonce       : {nonce} (0x{nonce:08x})")
    print(f"[miner] hashes tried: {tried:,}")
    print(f"[miner] elapsed     : {elapsed:.3f}s")
    print(f"[miner] hash rate   : {rate:,.0f} H/s")
    print(f"[miner] digest      : {digest[::-1].hex()}")
    print(f"[miner] target bits : {bits}")


# ============================================================
# BENCHMARK 1 — SEARCH STRATEGIES
# ============================================================
def benchmark(oracle, bits, trials, oracle_zeros=0, oracle_max_attempts=1_000_000):
    """
    Compare candidate-seeding strategies on the same local header and target.
    The oracle does not reduce the expected number of hashes; this measures
    observed search variation and throughput.
    """
    if trials < 1:
        raise ValueError("trials must be at least 1.")

    target = target_from_bits(bits)

    def oracle_seed(_):
        seed, _, _, _ = acquire_oracle_with_zeros(oracle, oracle_zeros, oracle_max_attempts)
        return oracle_to_extranonce2(seed)

    styles = [
        ("oracle-seeded", oracle_seed, search_nonce),
        ("random-seeded", lambda i: os.urandom(4), search_nonce),
        ("sequential-seeded", lambda i: struct.pack("<I", i), search_nonce),
        ("midstate-search", lambda i: os.urandom(4), search_nonce_midstate),
    ]

    print("\n" + "=" * 76)
    print("RP-GHOST SEARCH STRATEGY BENCHMARK")
    print("=" * 76)
    print(f"Difficulty: {bits} bits")
    print(f"Expected hashes per successful search: {2**bits:,}")
    print(f"Trials per strategy: {trials}")
    print(f"Oracle zero-prefix filter: {oracle_zeros} bits")

    print("\n{:<18s} {:>14s} {:>12s} {:>14s}".format(
        "Strategy", "Mean hashes", "Mean time", "Hash rate"))

    best_rate = 0.0

    for name, seed_function, search_function in styles:
        hash_counts = []
        durations = []
        successes = 0

        for i in range(trials):
            prefix = make_header_prefix(seed_function(i))
            nonce, _, tried, elapsed = search_function(prefix, bits)

            hash_counts.append(tried)
            durations.append(elapsed)

            if nonce is not None:
                successes += 1
                if not verify(prefix, nonce, bits):
                    raise RuntimeError("Independent verification failed.")

        total_time = sum(durations)
        rate = sum(hash_counts) / total_time if total_time > 0 else 0
        best_rate = max(best_rate, rate)

        print(
            f"{name:<18s} {statistics.mean(hash_counts):>14,.0f} "
            f"{statistics.mean(durations):>11.3f}s {rate:>14,.0f}"
        )
        print(f"  successful searches: {successes}/{trials}")

    print("\n[benchmark] Interpretation")
    print("Different seeds change the header and therefore the individual search outcome.")
    print("They do not change the probability of an individual hash meeting the target.")
    print(f"Expected work remains approximately {2**bits:,} hashes.")

    if best_rate > 0:
        print("\nProjected search times at measured best rate:")
        for b in (12, 20, 28, 32, 40, 48):
            print(f"  {b:>2d} bits : {2**b:>18,d} hashes : {fmt_time(2**b / best_rate)}")

    print("\n[benchmark] Target value:")
    print(f"  {target:064x}")


# ============================================================
# BENCHMARK 2 — ORACLE NONCE VS SEQUENTIAL REACH
# ============================================================
def benchmark_nonce(oracle, nonce_bits, bits, trials, oracle_zeros=0, oracle_max_attempts=1_000_000):
    """
    Compare two ways of evaluating the SAME oracle-selected nonce.

    TEST A — SEQUENTIAL REACH: hash nonce 0, 1, 2, ... until the
             predetermined oracle nonce is reached.
    TEST B — DIRECT ORACLE EVALUATION: hash only the oracle nonce.

    Both use the exact same header prefix and target. This is a
    time-to-reach benchmark, not a mining-success benchmark.
    """
    validate_nonce_bits(nonce_bits)
    validate_bits(bits)

    if trials < 1:
        raise ValueError("trials must be at least 1.")

    mask = (1 << nonce_bits) - 1
    target = target_from_bits(bits)

    sequential_times = []
    direct_times = []
    sequential_hash_counts = []
    oracle_attempts = []
    successful_candidates = 0

    print("\n" + "=" * 90)
    print("RP-GHOST ORACLE NONCE VS SEQUENTIAL REACH")
    print("=" * 90)
    print(f"Nonce width: 2^{nonce_bits}")
    print(f"Test target: {bits} bits")
    print(f"Oracle zero-prefix filter: {oracle_zeros} bits")
    print(f"Trials: {trials}")

    print(
        f"\n{'Trial':>5s} {'Oracle nonce':>14s} {'Oracle samples':>15s} "
        f"{'Sequential hashes':>19s} {'Reach time':>12s} "
        f"{'Direct time':>12s} {'Valid':>8s}"
    )

    for trial in range(trials):

        # Oracle produces one predetermined candidate (zero-prefix filtered).
        oracle_value, _, attempts, _ = acquire_oracle_with_zeros(
            oracle, oracle_zeros, oracle_max_attempts
        )
        oracle_attempts.append(attempts)

        nonce = oracle_value & mask
        prefix = make_header_prefix(oracle_to_extranonce2(oracle_value))

        # TEST A: sequentially reach the predetermined nonce
        t0 = time.perf_counter()
        sequential_digest = None
        for current_nonce in range(nonce + 1):
            sequential_digest = hash_header(prefix, current_nonce)
        sequential_elapsed = time.perf_counter() - t0
        sequential_count = nonce + 1

        # TEST B: directly evaluate the oracle nonce
        t0 = time.perf_counter()
        direct_digest = hash_header(prefix, nonce)
        direct_elapsed = time.perf_counter() - t0

        if sequential_digest != direct_digest:
            raise RuntimeError("Sequential and direct hashes do not match.")

        valid = hash_meets_target(direct_digest, target)
        if valid:
            successful_candidates += 1

        sequential_times.append(sequential_elapsed)
        direct_times.append(direct_elapsed)
        sequential_hash_counts.append(sequential_count)

        print(
            f"{trial + 1:>5d} {nonce:>14,d} {attempts:>15,d} "
            f"{sequential_count:>19,d} {sequential_elapsed:>11.4f}s "
            f"{direct_elapsed * 1e6:>10.2f}us {'YES' if valid else 'NO':>8s}"
        )

    total_time = sum(sequential_times)
    sequential_rate = sum(sequential_hash_counts) / total_time if total_time > 0 else 0

    print("\n" + "-" * 90)
    print("[results] Oracle zero-prefix filter")
    print(f"Mean oracle samples per candidate: {statistics.mean(oracle_attempts):,.1f} "
          f"(expected ~{2**oracle_zeros:,})")

    print("\n[results] Sequential reach")
    print(f"Mean hashes to reach oracle nonce: {statistics.mean(sequential_hash_counts):,.0f}")
    print(f"Mean reach time: {statistics.mean(sequential_times):.6f}s")
    print(f"Measured sequential throughput: {sequential_rate:,.0f} H/s")

    print("\n[results] Direct oracle evaluation")
    print(f"Mean direct evaluation time: {statistics.mean(direct_times) * 1e6:.2f} microseconds")
    print("Direct evaluations per trial: 1")

    print("\n[results] Proof-of-work validity")
    print(f"Oracle candidates meeting target: {successful_candidates}/{trials}")
    print(f"Expected success probability: approximately 1 in {2**bits:,}")

    print("\n[interpretation]")
    print("The direct evaluation reaches the predetermined candidate without "
          "hashing the preceding nonce values.")
    print("It does not establish that the candidate is a valid proof of work.")
    print("The candidate has the same validity regardless of whether it was "
          "reached sequentially or selected directly.")
    print(f"Expected work to discover a valid candidate remains approximately "
          f"2^{bits} = {2**bits:,} independent hashes.")
    print("\nThis benchmark measures candidate reachability, not a reduction "
          "in expected proof-of-work.")


# ============================================================
# MAIN
# ============================================================
def main():
    parser = argparse.ArgumentParser(
        description="RP-GHOST webcam oracle and local proof-of-work research benchmark"
    )

    parser.add_argument("--camera", type=int, default=0)
    parser.add_argument("--simulate", action="store_true")
    parser.add_argument("--bits", type=int, default=12,
                        help="Local proof-of-work difficulty in bits")
    parser.add_argument("--rounds", type=int, default=1)
    parser.add_argument("--k", type=int, default=8, help="Number of RP decision trials")
    parser.add_argument("--clock-hz", type=float, default=10.0)
    parser.add_argument("--calibration-samples", type=int, default=20)
    parser.add_argument("--mad-multiplier", type=float, default=3.0)
    parser.add_argument("--require-rp-select", action="store_true",
                        help="Only mine when the RP decision circuit selects HIGH")
    parser.add_argument("--midstate", action="store_true")
    parser.add_argument("--benchmark", action="store_true")
    parser.add_argument("--bench-bits", type=int, default=32)
    parser.add_argument("--trials", type=int, default=10)
    parser.add_argument("--benchmark-nonce", action="store_true")
    parser.add_argument("--nonce-bits", type=int, default=32)
    parser.add_argument("--oracle-zeros", type=int, default=32,
                        help="Leading zero bits required in the oracle SHA-256 "
                             "(0 disables the filter)")
    parser.add_argument("--oracle-max-attempts", type=int, default=1_000_000)

    args = parser.parse_args()

    validate_bits(args.bits)
    validate_bits(args.bench_bits)
    validate_nonce_bits(args.nonce_bits)

    if not 0 <= args.oracle_zeros <= 64:
        parser.error("--oracle-zeros must be between 0 and 64.")
    if args.oracle_max_attempts < 1:
        parser.error("--oracle-max-attempts must be at least 1.")
    if args.rounds < 1:
        parser.error("--rounds must be at least 1.")
    if args.trials < 1:
        parser.error("--trials must be at least 1.")
    if args.k < 1:
        parser.error("--k must be at least 1.")
    if args.calibration_samples < 1:
        parser.error("--calibration-samples must be at least 1.")

    print("=" * 72)
    print("RP-GHOST — LOCAL RESEARCH IMPLEMENTATION")
    print("=" * 72)
    print(f"TEST_BITS: {args.bits}")
    print(f"Expected hashes: {2**args.bits:,}")
    print(f"Oracle zero-prefix bits: {args.oracle_zeros} "
          f"(~{2**args.oracle_zeros:,} oracle samples)")
    print(f"Simulation: {args.simulate}")
    print("Pool connection: DISABLED")
    print("Share submission: DISABLED")

    oracle = WebcamOracle(index=args.camera, simulate=args.simulate)

    try:

        if args.benchmark_nonce:
            benchmark_nonce(oracle, args.nonce_bits, args.bits, args.trials,
                            args.oracle_zeros, args.oracle_max_attempts)
            return

        if args.benchmark:
            benchmark(oracle, args.bench_bits, args.trials,
                      args.oracle_zeros, args.oracle_max_attempts)
            return

        search_function = search_nonce_midstate if args.midstate else search_nonce

        for round_number in range(args.rounds):

            print("\n" + "=" * 72)
            print(f"ROUND {round_number + 1}/{args.rounds}")
            print("=" * 72)

            # --- RP decision circuit ---
            print("\n[rp] running decision circuit")

            selected = rp_decision(
                oracle,
                k=args.k,
                clock_hz=args.clock_hz,
                calibration_samples=args.calibration_samples,
                mad_multiplier=args.mad_multiplier,
            )

            if args.require_rp_select and not selected:
                print("[system] RP decision rejected candidate generation.")
                continue

            # --- Oracle generation with zero-prefix filter ---
            print("\n[oracle] acquiring 64-bit input")

            seed, _, attempts, oracle_elapsed = acquire_oracle_with_zeros(
                oracle, args.oracle_zeros, args.oracle_max_attempts
            )

            print(f"[oracle] 64-bit input: {seed:016x}")
            print(f"[oracle] zero-prefix filter: {args.oracle_zeros} bits, "
                  f"{attempts:,} samples, {oracle_elapsed:.3f}s")

            reconstruction = reconstruct_oracle_sha256(seed)
            oracle_input = reconstruction["oracle_input"]
            oracle_digest = reconstruction["oracle_sha256"]
            extranonce2 = reconstruction["extranonce2"]

            print(f"[oracle] input bytes : {oracle_input.hex()}")
            print(f"[oracle] SHA-256     : {oracle_digest.hex()}")
            print(f"[oracle] extranonce2 : {extranonce2.hex()}")

            if hashlib.sha256(oracle_input).digest() != oracle_digest:
                raise RuntimeError("[oracle] SHA-256 reconstruction failed")
            print("[oracle] SHA-256 reconstruction: PASS")

            zeros = leading_zero_bits(oracle_digest)
            print(f"[oracle] leading zero bits: {zeros} (required {args.oracle_zeros})")
            if zeros < args.oracle_zeros:
                raise RuntimeError("[oracle] zero-prefix requirement not met")

            # --- Header construction ---
            prefix = make_header_prefix(extranonce2)
            print(f"[miner] header prefix: {prefix.hex()} {len(prefix)} bytes")
            print("[miner] local test header constructed")

            # --- Left-side miner ---
            print("\n[miner] starting nonce search")

            nonce, digest, tried, elapsed = search_function(prefix, args.bits)
            print_result(nonce, digest, tried, elapsed, args.bits)

            if nonce is None:
                print("[miner] no valid nonce found in 32-bit space")
                continue

            # --- Independent verification ---
            print("\n[verify] independently recomputing candidate")

            valid = verify(prefix, nonce, args.bits)
            print(f"[verify] result: {'PASS' if valid else 'FAIL'}")

            if not valid:
                print("[verify] candidate rejected")
                continue

            print("\n[RESULT] LOCAL TEST PROOF-OF-WORK VALID")
            print(f"Nonce: 0x{nonce:08x}")
            print(f"Hash: {digest[::-1].hex()}")
            print(f"Difficulty: {args.bits} leading-zero-bit target")
            print("[RESULT] Oracle generated the candidate seed.")
            print("[RESULT] Left-side miner established target validity.")
            print("[RESULT] Independent verification passed.")
            print("[NOTE] This is not a Bitcoin pool share.")

    finally:
        oracle.close()
        print("\n[system] oracle closed")


if __name__ == "__main__":
    main()
