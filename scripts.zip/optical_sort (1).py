#!/usr/bin/env python3
"""
optical_sort.py - the Wagenknecht optical bit-pooling pipeline, applied to datasets.

Pipeline (paper section in brackets), run for ALL records in parallel as tensor ops:
  oracle   : holds the dataset; publishes only salt s and per-record c_k = SHA256(s || x_k)   [1]
  channel  : each record is a rows x cols grid of black/white cells observed every cycle
             - mode "bit"   : reveal ~ Bernoulli(r), flip ~ Bernoulli(eps)                    [2.5, 3]
             - mode "pixel" : 255/0 cells + Gaussian pixel noise, BxB block mean pooling
                              (reshape + mean over axes (2,4)), confidence gate |p-tau|>=c0   [2.1-2.3]
  recogniser: sees only frames + commitments. Accumulates ones/zeros votes (majority = ML) [4.1],
              waits for cover, hashes the majority word, and for failures runs a Chase-type
              search over the L least-reliable bits (<= t flips, per-record budget qmax)     [5]
  output   : verified records only are sorted (parallel sample-sort) and saved raw.

Raw format: headerless little-endian binary. Commitment file: 16-byte salt + K*32-byte digests.

Supported dtypes: uint/int/float with itemsize 1,2,4,8 (order-preserving key mapping).
NOT a factoriser and not a compression/sorting breakthrough: it is a noisy-channel recovery
demo whose verifier is a hash. See paper sections 6-7 and 9.

CLI:
  python optical_sort.py gen   data.raw --n 100000 --dtype uint32
  python optical_sort.py run   data.raw sorted.raw --dtype uint32 [--mode pixel --sigma 40]
  python optical_sort.py bench --n 50000 --dtype uint32
"""
import argparse, hashlib, itertools, math, os, time
import numpy as np
from fastsort import save_raw, load_raw, parallel_sort, _gen

GRID = {8: (2, 4), 16: (4, 4), 32: (4, 8), 64: (8, 8)}   # m bits -> (rows, cols)
EULER = 0.5772156649015329


# ------------------------------------------------ order-preserving keys
def to_key(a):
    a = np.ascontiguousarray(a)
    bits = a.dtype.itemsize * 8
    U = np.dtype(f"<u{a.dtype.itemsize}")
    u = a.view(U)
    sign = U.type(1) << U.type(bits - 1)
    if a.dtype.kind == "u":
        return u
    if a.dtype.kind == "i":
        return u ^ sign
    if a.dtype.kind == "f":
        neg = (u >> U.type(bits - 1)).astype(bool)
        return np.where(neg, ~u, u ^ sign)
    raise TypeError("unsupported dtype")


def from_key(k, dtype):
    dt = np.dtype(dtype).newbyteorder("<")
    bits = dt.itemsize * 8
    U = k.dtype
    sign = U.type(1) << U.type(bits - 1)
    if dt.kind == "u":
        return k.view(dt)
    if dt.kind == "i":
        return (k ^ sign).view(dt)
    top = (k >> U.type(bits - 1)).astype(bool)
    return np.where(top, k ^ sign, ~k).view(dt)


# ------------------------------------------------ hashing helpers
def be_bytes(words, nb):
    """uint64 words -> concatenated big-endian fixed-length byte strings (nb bytes each)."""
    return np.ascontiguousarray(
        words.astype(">u8").view(np.uint8).reshape(-1, 8)[:, 8 - nb:]).tobytes()


def sha_rows(salt, raw, nb):
    cp = hashlib.sha256(salt).copy
    d = []
    for i in range(0, len(raw), nb):
        h = cp(); h.update(raw[i:i + nb]); d.append(h.digest())
    return np.frombuffer(b"".join(d), np.uint8).reshape(-1, 32)


def save_commit(path, salt, commits):
    with open(path, "wb") as f:
        f.write(salt); f.write(np.ascontiguousarray(commits).tobytes())


def load_commit(path):
    raw = open(path, "rb").read()
    return raw[:16], np.frombuffer(raw[16:], np.uint8).reshape(-1, 32)


# ------------------------------------------------ channels
def make_observer(words, m, mode, rng, r, eps, sigma, block, tau, c0):
    shifts = np.arange(m, dtype=np.uint64)
    rows, cols = GRID[m]

    def truth(idx):
        return ((words[idx][:, None] >> shifts) & np.uint64(1)).astype(bool)

    if mode == "bit":
        def observe(idx):
            b = truth(idx)
            reveal = rng.random(b.shape, dtype=np.float32) < r
            return reveal, b ^ (rng.random(b.shape, dtype=np.float32) < eps)
        return observe

    step = max(1, int(8e6 // (m * block * block)))      # records per pooling batch (memory cap)

    def observe(idx):
        rv, ob = [], []
        for s in range(0, len(idx), step):
            b = truth(idx[s:s + step])
            K = b.shape[0]
            lv = b.reshape(K, rows, 1, cols, 1).astype(np.float32) * 255
            frame = lv + rng.standard_normal((K, rows, block, cols, block), dtype=np.float32) * sigma
            p = frame.mean(axis=(2, 4)).reshape(K, -1)               # <- the spatial pooling
            valid = np.abs(p - tau) >= c0                            # confidence gate
            rv.append((rng.random(p.shape, dtype=np.float32) < r) & valid)
            ob.append(p > tau)
        return np.concatenate(rv), np.concatenate(ob)
    return observe


def _Q(x):
    return 0.5 * math.erfc(x / math.sqrt(2))


def effective_channel(r, sigma, block, tau, c0):
    """Section 2.3: worst-case (eps_eff, r_eff) over black/white cells."""
    s = sigma / block
    eps = rho = 0.0
    for d in (255 - tau, tau):
        eps = max(eps, _Q((d + c0) / s))
        rho = max(rho, _Q((d - c0) / s) - _Q((d + c0) / s))
    return eps, r * (1 - rho)


def theory(m, r, eps):
    Z = 2 * math.sqrt(eps * (1 - eps))
    base = 1 - r * (1 - Z)
    lam = -math.log(1 - r) if r < 1 else float("inf")
    H = 0.0 if eps in (0, 1) else -eps * math.log2(eps) - (1 - eps) * math.log2(1 - eps)
    cap = r * (1 - H)
    return dict(Z=Z, base=base, exponent=-math.log(base) if base > 0 else float("inf"),
                cover_mean=(math.log(m) + EULER) / lam, cover_sd=math.pi / (math.sqrt(6) * lam),
                capacity=cap, shannon_T=1 / cap if cap > 0 else float("inf"),
                T_union=lambda delta: math.log(m / delta) / -math.log(base))


# ------------------------------------------------ recogniser
def recognise(commits, salt, nb, observe, T_max, L, t, qmax, rng):
    K, m = len(commits), nb * 8
    ones = np.zeros((K, m), np.int16); zeros = np.zeros((K, m), np.int16)
    weights = np.uint64(1) << np.arange(m, dtype=np.uint64)
    out = np.zeros(K, np.uint64)
    done = np.zeros(K, bool)
    done_cycle = np.zeros(K, np.int32); cover_cycle = np.zeros(K, np.int32)
    tested = np.zeros(K, np.int64)
    L = min(L, m); t = min(t, L)
    combos = [np.array(list(itertools.combinations(range(L), k)), dtype=np.intp)
              for k in range(1, t + 1)]
    active = np.arange(K)
    hashes = 0
    cycle = 0
    while active.size and cycle < T_max:
        cycle += 1
        rev, obs = observe(active)
        ones[active] += (rev & obs); zeros[active] += (rev & ~obs)
        o, z = ones[active], zeros[active]
        seen = ((o + z) > 0).all(1)
        new = seen & (cover_cycle[active] == 0)
        cover_cycle[active[new]] = cycle
        idx = np.nonzero(seen)[0]
        if not idx.size:
            continue
        ai = active[idx]
        o, z = o[idx], z[idx]
        packed = ((o > z).astype(np.uint64) * weights).sum(1, dtype=np.uint64)
        ok = (sha_rows(salt, be_bytes(packed, nb), nb) == commits[ai]).all(1)
        hashes += len(ai); tested[ai] += 1
        out[ai[ok]] = packed[ok]; done[ai[ok]] = True; done_cycle[ai[ok]] = cycle
        fail = np.nonzero(~ok)[0]
        if t and fail.size:
            marg = np.abs(o[fail].astype(np.int32) - z[fail]).astype(np.float32)
            marg += rng.random(marg.shape, dtype=np.float32) * 0.5   # random tie-break (paper s.9.5)
            pos = np.argpartition(marg, L - 1, axis=1)[:, :L]         # L least-reliable bits
            for j, f in enumerate(fail):
                k = ai[f]
                room = qmax - tested[k]
                if room <= 0:
                    continue
                w = weights[pos[j]]
                masks = np.concatenate([w[c].sum(1, dtype=np.uint64) for c in combos])[:room]
                cand = packed[f] ^ masks
                hit = (sha_rows(salt, be_bytes(cand, nb), nb) == commits[k]).all(1)
                tested[k] += len(cand); hashes += len(cand)
                if hit.any():
                    out[k] = cand[np.argmax(hit)]; done[k] = True; done_cycle[k] = cycle
        active = active[~done[active]]
    return out, done, dict(cycles=cycle, hashes=hashes, done_cycle=done_cycle,
                           cover_cycle=cover_cycle)


# ------------------------------------------------ end to end
def run_arrays(data, mode="bit", r=0.45, eps=0.02, sigma=40.0, block=16, tau=127, c0=25,
               T_max=800, L=12, t=2, qmax=20_000, seed=0, commit_out=None, threads=None,
               verbose=True, sort=True):
    data = np.ascontiguousarray(data)
    nb = data.dtype.itemsize; m = nb * 8
    if m not in GRID:
        raise ValueError("itemsize must be 1, 2, 4 or 8 bytes")
    rng = np.random.default_rng(seed)
    keys = to_key(data)
    words = keys.astype(np.uint64)

    t0 = time.perf_counter()
    salt = rng.bytes(16)                                              # oracle
    commits = sha_rows(salt, be_bytes(words, nb), nb)
    if commit_out:
        save_commit(commit_out, salt, commits)
    t_commit = time.perf_counter() - t0

    if mode == "pixel":
        eps_e, r_e = effective_channel(r, sigma, block, tau, c0)
    else:
        eps_e, r_e = eps, r
    th = theory(m, r_e, eps_e)

    obs = make_observer(words, m, mode, rng, r, eps, sigma, block, tau, c0)
    t0 = time.perf_counter()
    rec, done, st = recognise(commits, salt, nb, obs, T_max, L, t, qmax, rng)
    t_rec = time.perf_counter() - t0

    t0 = time.perf_counter()
    if sort:
        result = from_key(parallel_sort(rec[done].astype(keys.dtype), threads), data.dtype)
    else:                                   # original order; unverified slots are zero (see `done`)
        result = from_key(rec.astype(keys.dtype), data.dtype)
    t_sort = time.perf_counter() - t0

    st.update(n=len(data), verified=int(done.sum()), t_commit=t_commit, t_recognise=t_rec,
              t_sort=t_sort, theory=th, eps_eff=eps_e, r_eff=r_e)
    if verbose:
        dc = st["done_cycle"][done]; cc = st["cover_cycle"][st["cover_cycle"] > 0]
        print(f"records {len(data):,} ({m}-bit, grid {GRID[m][0]}x{GRID[m][1]}, mode={mode})")
        print(f"channel: r_eff={r_e:.3f} eps_eff={eps_e:.4g}  Z={th['Z']:.3f}  "
              f"exponent={th['exponent']:.3f}/cycle  capacity={th['capacity']:.3f} bit/cell/frame")
        print(f"cover time  observed mean {cc.mean():.2f} (sd {cc.std():.2f}) | "
              f"theory {th['cover_mean']:.2f} (sd {th['cover_sd']:.2f})" if cc.size else "cover: none")
        if dc.size:
            print(f"verify cycle mean {dc.mean():.2f}, p99 {np.percentile(dc, 99):.0f}, max {dc.max()} | "
                  f"plain-majority bound T(1e-2)={th['T_union'](1e-2):.1f}  Shannon floor={th['shannon_T']:.2f}")
        print(f"verified {st['verified']:,}/{len(data):,}  hashes {st['hashes']:,}  "
              f"commit {t_commit:.2f}s recognise {t_rec:.2f}s sort {t_sort:.3f}s")
        if st["verified"] < len(data):
            print(f"WARNING: {len(data) - st['verified']:,} records unverified and excluded "
                  f"(raise --tmax / --chase-t / --qmax)")
    return result, done, st


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawTextHelpFormatter)
    sp = ap.add_subparsers(dest="cmd", required=True)
    num = lambda s: int(s.replace("_", ""))

    def chan(p):
        p.add_argument("--dtype", default="uint32")
        p.add_argument("--mode", choices=["bit", "pixel"], default="bit")
        p.add_argument("--r", type=float, default=0.45); p.add_argument("--eps", type=float, default=0.02)
        p.add_argument("--sigma", type=float, default=40.0); p.add_argument("--block", type=int, default=16)
        p.add_argument("--tau", type=int, default=127); p.add_argument("--c0", type=int, default=25)
        p.add_argument("--tmax", type=int, default=800)
        p.add_argument("--chase-L", type=int, default=12); p.add_argument("--chase-t", type=int, default=2)
        p.add_argument("--qmax", type=int, default=20_000); p.add_argument("--seed", type=int, default=0)
        p.add_argument("--threads", type=int)

    g = sp.add_parser("gen"); g.add_argument("path"); g.add_argument("--n", type=num, default=100_000); g.add_argument("--dtype", default="uint32")
    r_ = sp.add_parser("run"); r_.add_argument("src"); r_.add_argument("dst"); r_.add_argument("--commit-out"); r_.add_argument("--mmap", action="store_true"); chan(r_)
    b = sp.add_parser("bench"); b.add_argument("--n", type=num, default=50_000); chan(b)
    a = ap.parse_args()

    kw = lambda: dict(mode=a.mode, r=a.r, eps=a.eps, sigma=a.sigma, block=a.block, tau=a.tau, c0=a.c0,
                      T_max=a.tmax, L=a.chase_L, t=a.chase_t, qmax=a.qmax, seed=a.seed, threads=a.threads)
    if a.cmd == "gen":
        save_raw(_gen(a.n, a.dtype), a.path); print(f"wrote {a.n:,} x {a.dtype} -> {a.path}")
    elif a.cmd == "run":
        data = load_raw(a.src, a.dtype, mmap=a.mmap)
        res, done, st = run_arrays(data, commit_out=a.commit_out, **kw())
        save_raw(res, a.dst); print(f"saved {len(res):,} sorted records -> {a.dst}")
    else:
        data = _gen(a.n, a.dtype, a.seed)
        res, done, st = run_arrays(data, **kw())
        ref = np.sort(data)
        print("EXACT MATCH with np.sort" if np.array_equal(res, ref) else
              f"differs from np.sort ({len(res)} vs {len(ref)} records)")


if __name__ == "__main__":
    main()
