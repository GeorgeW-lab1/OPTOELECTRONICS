"""
Monte Carlo test of the two-level recognition model (Wagenknecht, v1.0).

Uses the paper's DUAL convention (Remark 5.3):
    X_i(t) = 1            if K_i = 0     (true zeros never produce a zero)
    X_i(t) = R_i(t)       if K_i = 1     (R ~ Bernoulli(p))
Level 1: U_m = {i : never saw a zero}.  Estimate K_hat = NOT B_m.
         Errors = true ones still stuck in U_m (count Q_m).
Level 2: flip k positions of U_m from 0 -> 1, k = 0,1,2,... and test
         SHA-256(salt || K) == C.

CAVEAT: the simulator reads K to generate samples (oracle access), so this
validates the *math*, not any physical effect (the paper's Limitation 2).
"""
import hashlib, itertools, math, os
import numpy as np

rng = np.random.default_rng(12345)


def commit(salt: bytes, K: np.ndarray) -> bytes:
    return hashlib.sha256(salt + np.packbits(K).tobytes()).digest()


def level1(K, p, m):
    """Return indicator B_m (True = never seen zero) after m cycles."""
    n = len(K)
    R = rng.random((m, n)) < p
    X = np.where(K[None, :] == 0, True, R)      # dual-convention Z-channel
    return X.all(axis=0)


def level2(B, salt, C, Bmax):
    """Hamming-ball search around K_hat = NOT B. Returns (K or None, hashes)."""
    U = np.flatnonzero(B)
    base = (~B).astype(np.uint8)                 # K_hat
    hashes = 0
    for k in range(len(U) + 1):
        if hashes + math.comb(len(U), k) > Bmax:  # budget rule, eq. (29)
            return None, hashes
        for F in itertools.combinations(U, k):
            cand = base.copy()
            cand[list(F)] = 1                    # flip 0 -> 1 on subset F
            hashes += 1
            if commit(salt, cand) == C:
                return cand, hashes
    return None, hashes


def check_statistics(n=64, p=0.5, ms=(2, 4, 6, 8, 10), trials=4000):
    print(f"--- Level-1 statistics  (n={n}, p={p}, {trials} trials) ---")
    print(f"{'m':>3} {'E[Q] theory':>12} {'E[Q] sim':>10} "
          f"{'P(Q=0) th':>10} {'P(Q=0) sim':>11} {'false neg':>10}")
    for m in ms:
        theta = p**m / 2
        Qs, fn = [], 0
        for _ in range(trials):
            K = rng.integers(0, 2, n, dtype=np.uint8)
            B = level1(K, p, m)
            # a "false negative" = true zero missing from U (must never happen)
            fn += int(np.sum((K == 0) & ~B))
            Qs.append(int(np.sum((K == 1) & B)))
        print(f"{m:>3} {n*theta:>12.4f} {np.mean(Qs):>10.4f} "
              f"{(1-theta)**n:>10.4f} {np.mean(np.array(Qs)==0):>11.4f} {fn:>10}")


def check_recovery(n=64, p=0.5, trials=200, Bmax=200_000, M=40):
    print(f"\n--- Sequential blind recovery (n={n}, p={p}, Bmax={Bmax}) ---")
    taus, Ts, ok = [], [], 0
    for _ in range(trials):
        K = rng.integers(0, 2, n, dtype=np.uint8)
        salt = os.urandom(16)
        C = commit(salt, K)
        R = rng.random((M, n)) < p
        X = np.where(K[None, :] == 0, True, R)
        total = 0
        for m in range(1, M + 1):
            B = X[:m].all(axis=0)                # decoder sees only X and C
            got, h = level2(B, salt, C, Bmax)
            total += h
            if got is not None:
                ok += int(np.array_equal(got, K))
                taus.append(m); Ts.append(total)
                break
    print(f"recovered {ok}/{trials}")
    print(f"mean stopping cycle tau = {np.mean(taus):.2f}   "
          f"(theory ~ log2(n) = {math.log2(n):.2f})")
    print(f"mean hash evaluations   = {np.mean(Ts):.1f}   "
          f"(brute force would need ~2^{n-1})")


def check_scaling(p=0.5, ns=(16, 32, 64, 128, 256), trials=60):
    print("\n--- Scaling in n (Experiment E analogue) ---")
    print(f"{'n':>5} {'mean tau':>9} {'mean hashes':>12}")
    for n in ns:
        taus, Ts = [], []
        for _ in range(trials):
            K = rng.integers(0, 2, n, dtype=np.uint8)
            salt = os.urandom(8); C = commit(salt, K)
            R = rng.random((60, n)) < p
            X = np.where(K[None, :] == 0, True, R)
            total = 0
            for m in range(1, 61):
                got, h = level2(X[:m].all(axis=0), salt, C, 50_000)
                total += h
                if got is not None:
                    taus.append(m); Ts.append(total); break
        print(f"{n:>5} {np.mean(taus):>9.2f} {np.mean(Ts):>12.1f}")


def check_dark_counts(n=64, p=0.5, pdark=0.01, m=20):
    """Limitation 1: with two-sided noise the hard rule loses true zeros."""
    K = rng.integers(0, 2, (2000, n), dtype=np.uint8)
    lost = 0
    for k in K:
        # true zero registers a zero (miss) with prob 1-(1-... ) -> here 1-pdark... 
        # model: a true zero gives X=1 w.p. 1-pdark (detector glitch to 0)
        X = np.where(k[None, :] == 0, rng.random((m, n)) > pdark,
                     rng.random((m, n)) < p)
        B = X.all(axis=0)
        lost += np.sum((k == 0) & ~B)
    print(f"\n--- Two-sided noise (glitch prob {pdark}, m={m}) ---")
    print(f"true zeros wrongly eliminated per trial: {lost/2000:.2f} "
          f"(theory {n/2*(1-(1-pdark)**m):.2f}) -> hard rule breaks; "
          "needs soft threshold")


def check_fano(n=64, p=0.5):
    # Numerically maximise I(X;Y) for the Z-channel used by the model
    # (input 1 -> output 1 w.p. p; input 0 -> output 0 always, up to relabel).
    def mi(q):                                   # q = P(input=1)
        py1 = q * p
        h = lambda x: 0 if x in (0, 1) else -x*math.log2(x)-(1-x)*math.log2(1-x)
        return h(py1) - q * h(p)
    C_num = max(mi(q) for q in np.linspace(0, 1, 10001))
    C_paper = math.log2(1 + (1 - p) * p ** (p / (1 - p)))
    print("\n--- Capacity / Fano check ---")
    print(f"numeric Z-channel capacity     : {C_num:.4f} bits/use")
    print(f"paper's formula (eq. 38)       : {C_paper:.4f} bits/use")
    print(f"min cycles m (Pe=0.01, numeric): "
          f"{(n*(1-0.01)-1)/(n*C_num):.2f}")


if __name__ == "__main__":
    check_statistics()
    check_recovery()
    check_scaling()
    check_dark_counts()
    check_fano()
