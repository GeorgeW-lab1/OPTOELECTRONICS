"""
Bit-Pooling Higher-Lower Search & Circuit Camera Lab 
(Tkinter / OpenCV Framework with Visual Bit Registers & Auto-Revealing Oracle)
Adapted from the RP-style optoelectronic decision circuit framework.
"""

import asyncio
import collections
import hashlib
import hmac
import multiprocessing
import os
import queue
import sys
import threading
import time
import tkinter as tk
from tkinter import ttk, messagebox, filedialog

import numpy as np

try:
    import cv2
except ImportError:
    cv2 = None


# ==============================================================================
# SHA-256 CRYPTOGRAPHIC PRIMITIVES
# ==============================================================================
class Sha256Pool:
    """
    Entropy pool. Every input (camera sensor noise, timing jitter, OS entropy) is
    folded into a 256-bit state with SHA-256. Extraction uses HMAC-SHA256 keyed
    with the state AND fresh os.urandom bytes, then ratchets the state forward
    (forward secrecy: a later state compromise doesn't reveal earlier outputs).

    Security note: the guarantee comes from os.urandom (the OS CSPRNG). Camera
    noise is *additional* entropy; it can never reduce security, because a hash
    of (secret || anything) is no easier to guess than the secret.
    """
    def __init__(self):
        self._lock = threading.Lock()
        self._state = hashlib.sha256(b"pool-init-v1" + os.urandom(32)).digest()
        self._n = 0
        self._prev_frame = None
        self.frames_mixed = 0
        self.camera_ok = False

    def add(self, data: bytes):
        with self._lock:
            self._n += 1
            self._state = hashlib.sha256(
                self._state + self._n.to_bytes(8, "big") + data
            ).digest()

    def add_frame(self, gray: np.ndarray):
        """
        Harvest sensor noise: LSBs of the frame-to-frame difference. A frozen or
        stuck camera (all zeros / all ones) fails the health test and is ignored.
        """
        if self._prev_frame is None or self._prev_frame.shape != gray.shape:
            self._prev_frame = gray.copy()
            return
        lsb = np.bitwise_xor(gray, self._prev_frame) & 1
        self._prev_frame = gray.copy()

        ones = float(lsb.mean())
        self.camera_ok = 0.05 < ones < 0.95        # crude stuck-source monitor
        if not self.camera_ok:
            return
        self.add(np.packbits(lsb.ravel()).tobytes()
                 + time.perf_counter_ns().to_bytes(8, "big"))
        self.frames_mixed += 1

    def extract(self, label: bytes) -> bytes:
        with self._lock:
            out = hmac.new(self._state, b"extract|" + label + os.urandom(32),
                           hashlib.sha256).digest()
            self._state = hashlib.sha256(self._state + b"ratchet").digest()
        return out


class HashStream:
    """Deterministic SHA-256 counter-mode stream: block_i = SHA256(key || i)."""
    def __init__(self, key: bytes):
        self._key = key
        self._ctr = 0
        self._buf = b""

    def read(self, n: int) -> bytes:
        while len(self._buf) < n:
            self._buf += hashlib.sha256(self._key + self._ctr.to_bytes(8, "big")).digest()
            self._ctr += 1
        out, self._buf = self._buf[:n], self._buf[n:]
        return out

    def randbelow(self, n: int) -> int:
        """Uniform integer in [0, n) using rejection sampling (no modulo bias)."""
        if n <= 1:
            return 0
        k = (n - 1).bit_length()
        nbytes = (k + 7) // 8
        mask = (1 << k) - 1
        while True:
            r = int.from_bytes(self.read(nbytes), "big") & mask
            if r < n:
                return r


def make_stream(mode: str, seed: str, pool: Sha256Pool) -> HashStream:
    if mode == "DETERMINISTIC":
        # Reproducible: same seed -> same target. Secret only if the seed is secret.
        key = hashlib.sha256(b"oracle-det-v1|" + seed.encode("utf-8")).digest()
    else:
        # Non-deterministic: OS entropy + camera noise pooled through SHA-256.
        key = pool.extract(b"oracle-nondet-v1")
    return HashStream(key)


def commit(target: int, salt: bytes) -> bytes:
    return hashlib.sha256(b"commit-v1|" + salt + target.to_bytes(8, "big")).digest()


def pow_ok(digest: bytes, bits: int) -> bool:
    """True if digest has at least `bits` leading zero bits."""
    return bits <= 0 or (int.from_bytes(digest, "big") >> (256 - bits)) == 0


def mine(header: bytes, bits: int, start: int = 0, alive=None):
    """
    Hashcash-style proof of work: find nonce with SHA256(header||nonce) < 2^(256-bits).
    Every 1024 tries it calls alive(n) (progress + cancel check; False aborts and returns
    None) and yields the GIL so this CPU-bound loop can't starve other threads.
    """
    nonce = start
    sha = hashlib.sha256
    n = 0
    while True:
        digest = sha(header + nonce.to_bytes(8, "big")).digest()
        if pow_ok(digest, bits):
            return nonce, digest, n + 1
        nonce = (nonce + 1) & 0xFFFFFFFFFFFFFFFF
        n += 1
        if (n & 0x3FF) == 0:
            if alive is not None and not alive(n):
                return None
            time.sleep(0)


class _WorkerDied(RuntimeError):
    pass


def _lower_priority():
    """Make the hashing process yield to the GUI/camera if CPU is scarce."""
    try:
        if os.name == "nt":
            import ctypes
            k32 = ctypes.windll.kernel32
            k32.SetPriorityClass(k32.GetCurrentProcess(), 0x00004000)   # BELOW_NORMAL
        else:
            os.nice(10)
    except Exception:
        pass


def _mine_worker(conn):
    """
    Runs in a SEPARATE PROCESS (own interpreter, own GIL) so proof of work can never
    steal time from the GUI, camera or oracle threads. Protocol over a Pipe:
      parent -> ("mine", jid, header, bits, start, duty) | ("cancel", jid) | ("quit",)
                (duty 0.05..1.0 = max share of one core the worker may use)
      child  -> ("ready", pid) | ("prog", jid, tries) | ("done", jid, nonce, digest, tries)
                | ("cancelled", jid)
    """
    _lower_priority()
    sha = hashlib.sha256
    conn.send(("ready", os.getpid()))
    while True:
        try:
            msg = conn.recv()
        except (EOFError, OSError):
            return
        if msg[0] == "quit":
            return
        if msg[0] != "mine":              # e.g. a stale cancel for a job that already finished
            continue
        _, jid, header, bits, start, duty = msg
        duty = min(max(float(duty), 0.05), 1.0)
        nonce, n = start, 0
        t_batch = time.perf_counter()
        while True:
            digest = sha(header + nonce.to_bytes(8, "big")).digest()
            if pow_ok(digest, bits):
                conn.send(("done", jid, nonce, digest, n + 1))
                break
            nonce = (nonce + 1) & 0xFFFFFFFFFFFFFFFF
            n += 1
            if (n & 0x7FFF) == 0:
                if conn.poll():
                    m = conn.recv()
                    if m[0] == "quit":
                        return
                    if m[0] == "cancel" and m[1] == jid:
                        conn.send(("cancelled", jid))
                        break
                conn.send(("prog", jid, n))
                if duty < 1.0:                # throttle: sleep so work/(work+sleep) == duty
                    busy = time.perf_counter() - t_batch
                    time.sleep(busy * (1.0 - duty) / duty)
                t_batch = time.perf_counter()


def _block_header(prev: bytes, step: int, trial: int, bit: int) -> bytes:
    return prev + step.to_bytes(2, "big") + trial.to_bytes(8, "big") + bytes([bit])


# ==============================================================================
# BIT-POOLING HIGHER-LOWER ORACLE CLASS
# ==============================================================================
class BitPoolingOracle:
    """
    Holds the secret target and answers higher/lower queries one bit at a time
    (MSB-first). The target is bound to a salted SHA-256 commitment published up
    front, so the reveal can be verified after the search.
    """
    def __init__(self, bit_depth, target, salt, pool_op="POPCOUNT", kernel_size=4):
        assert 1 <= bit_depth <= 64, "bit_depth must be 1..64"
        self.bit_depth = bit_depth
        self.max_val = (1 << bit_depth) - 1
        self._target = max(0, min(int(target), self.max_val))
        self._salt = salt
        self.commitment = commit(self._target, salt)   # public

        self.kernel_size = kernel_size
        self.stride = 2
        self.pool_op = pool_op
        self.schmitt_trigger = 0.5

        self.pooled_bits = 0
        self.is_done = False

    def reveal(self, force=False):
        return self._target if (self.is_done or force) else 0

    def verify(self) -> bool:
        """True iff the revealed target matches the commitment made at the start."""
        if not self.is_done:
            return False
        return hmac.compare_digest(commit(self._target, self._salt), self.commitment)

    def query_bit(self, trial_val):
        """Is the secret target >= trial_val?  Returns 1 or 0."""
        if self.is_done:
            return 0
        return 1 if self._target >= trial_val else 0

    def pool_step(self, val):
        """Applies hardware-style bit pooling (kernel, stride, operator) to a value."""
        bits = [(val >> i) & 1 for i in range(self.bit_depth)]

        pooled_out = []
        for i in range(0, len(bits), self.stride):
            block = bits[i : i + self.kernel_size]
            if not block:
                break

            if self.pool_op == "POPCOUNT":
                res = sum(block) / len(block)
                res_bit = 1 if res >= self.schmitt_trigger else 0
            elif self.pool_op == "AND":
                res_bit = 1 if all(b == 1 for b in block) else 0
            elif self.pool_op == "OR":
                res_bit = 1 if any(b == 1 for b in block) else 0
            elif self.pool_op == "XOR":
                res_bit = sum(block) % 2
            elif self.pool_op == "MAJORITY":
                res_bit = 1 if sum(block) > (len(block) / 2.0) else 0
            else:
                res_bit = block[0]

            pooled_out.append(res_bit)

        out_val = 0
        for idx, b in enumerate(pooled_out):
            out_val |= (b << idx)
        return out_val

    @property
    def target(self):
        """Raises PermissionError if accessed before search completion."""
        if not self.is_done:
            raise PermissionError("SECURITY VIOLATION: Oracle target is classified until fully pooled!")
        return self._target


# ==============================================================================
# BIT-POOLING SEARCH ENGINE  (oracle thread  ->  job queue  ->  mining thread)
# ==============================================================================
class BitPoolingSearchEngine:
    """
    Two worker threads, so neither ever waits on the other (or on the GUI/camera):

      ORACLE thread  - woken by a trigger (camera motion / Step button). Answers one
                       higher/lower query in microseconds, updates the GUI-visible
                       GUESS register, and drops a job {step, trial, bit} on the
                       pending queue.
      MINER thread   - takes jobs in order and seals each answer into the SHA-256
                       hash chain with proof of work. It can lag far behind the oracle.

    The target stays masked until BOTH are finished: all bits answered AND all
    blocks sealed, the chain verified, and the commitment checked.
    """
    MODES = ("NONDETERMINISTIC", "DETERMINISTIC")

    def __init__(self, bit_depth=10):
        self.bit_depth = bit_depth
        self.max_val = (1 << bit_depth) - 1
        self.lock = threading.RLock()
        self._cv = threading.Condition(self.lock)     # wakes the miner

        self.mode = "NONDETERMINISTIC"
        self.seed = "lab-seed"
        self.pool = Sha256Pool()

        self.kernel_size = 4
        self.pool_op = "POPCOUNT"

        # Proof-of-work settings / state
        self.pow_bits = 32            # leading-zero bits per answer; each +1 doubles the work
        self._gen = 0                 # bumped on reset so stale work is dropped
        self._paused = False          # Stop Lab pauses the miner (current block is abandoned)
        self._shutdown = False
        self._mining = False
        self._live_tries = 0
        self._mine_t0 = 0.0
        self.total_hashes = 0
        self.hashrate = 0.0

        # Proof of work runs in a separate process (falls back to a thread if that fails)
        self.pow_cpu = 0.5 if (os.cpu_count() or 1) <= 1 else 1.0   # max share of one core
        self._use_process = True
        self._proc = None
        self._conn = None
        self._jid = 0
        self._worker_failures = 0
        self.pow_backend = "starting..."

        self._pending = collections.deque()           # oracle -> miner jobs
        self._triggers = queue.Queue()                # anything -> oracle thread

        self.oracle = None
        self.reset()

        self._oracle_thread = threading.Thread(target=self._oracle_loop, name="oracle", daemon=True)
        self._miner_thread = threading.Thread(target=self._miner_loop, name="miner", daemon=True)
        self._oracle_thread.start()
        self._miner_thread.start()

    # ---- lifecycle -----------------------------------------------------------
    def reset(self, new_target=None):
        with self.lock:
            stream = make_stream(self.mode, self.seed, self.pool)
            target = new_target if new_target is not None else stream.randbelow(self.max_val + 1)
            salt = stream.read(32)
            self.oracle = BitPoolingOracle(self.bit_depth, target, salt,
                                           self.pool_op, self.kernel_size)
            self._gen += 1
            self._pending.clear()
            while True:                               # drop stale triggers
                try:
                    self._triggers.get_nowait()
                except queue.Empty:
                    break
            self._paused = False
            self._mining = False
            self._live_tries = 0
            self.chain = []
            self.genesis = hashlib.sha256(b"genesis-v1|" + self.oracle.commitment).digest()
            self.chain_tip = self.genesis
            self.total_hashes = 0
            self.hashrate = 0.0
            self.current_guess = 0
            self.step_count = 0                       # oracle answers given
            self.history = [0]
            self.oracle_done = False
            self.converged = False                    # oracle done AND chain sealed AND verified
            self._final_status = None
            self._update_registers()
            self._cv.notify_all()

    def shutdown(self):
        with self._cv:
            self._shutdown = True
            self._use_process = False
            self._cv.notify_all()
        self._kill_worker()

    def pause_mining(self):
        with self.lock:
            self._paused = True

    def resume_mining(self):
        with self._cv:
            self._paused = False
            self._cv.notify_all()

    def set_pool_op(self, op):
        with self.lock:
            self.pool_op = op
            self.oracle.pool_op = op

    def set_kernel(self, k):
        with self.lock:
            self.kernel_size = k
            self.oracle.kernel_size = k

    # ---- oracle thread -------------------------------------------------------
    def request_step(self):
        """Non-blocking: ask the oracle thread for the next bit. Coalesces duplicate requests."""
        with self.lock:
            if self.oracle_done or not self._triggers.empty():
                return False
            self._triggers.put(self._gen)
            return True

    def _oracle_loop(self):
        while not self._shutdown:
            try:
                gen = self._triggers.get(timeout=0.2)
            except queue.Empty:
                continue
            self._oracle_step(gen)

    def _oracle_step(self, gen):
        with self.lock:
            if gen != self._gen or self.oracle_done:
                return
            step_no = self.step_count + 1
            shift = self.bit_depth - step_no
            trial_val = self.oracle.pooled_bits | (1 << shift)
            bit = self.oracle.query_bit(trial_val)

            self.oracle.pooled_bits |= (bit << shift)
            self.current_guess = self.oracle.pooled_bits
            self.history.append(self.current_guess)
            self.step_count = step_no
            self._pending.append(dict(step=step_no, trial=trial_val, bit=bit))
            if step_no >= self.bit_depth:
                self.oracle_done = True
            self._update_registers()
            self._cv.notify_all()

    # ---- mining thread -------------------------------------------------------
    def _start_worker(self):
        ctx = multiprocessing.get_context("spawn")     # safe with Tk/OpenCV threads (no fork)
        parent, child = ctx.Pipe()
        proc = ctx.Process(target=_mine_worker, args=(child,), name="pow-worker", daemon=True)
        proc.start()
        child.close()
        if not parent.poll(30):
            proc.terminate()
            raise _WorkerDied("worker did not start")
        if parent.recv()[0] != "ready":
            proc.terminate()
            raise _WorkerDied("bad handshake")
        self._proc, self._conn = proc, parent
        self.pow_backend = "separate process (low priority)"

    def _kill_worker(self):
        proc, conn = self._proc, self._conn
        self._proc = self._conn = None
        try:
            if conn is not None:
                conn.send(("quit",))
                conn.close()
        except Exception:
            pass
        try:
            if proc is not None:
                proc.terminate()
                proc.join(1.0)
        except Exception:
            pass

    def _worker_ok(self):
        if not self._use_process:
            return False
        if self._proc is not None and self._proc.is_alive():
            return True
        try:
            self._start_worker()
            return True
        except Exception:
            self._worker_failed()
            return False

    def _worker_failed(self):
        self._kill_worker()
        self._worker_failures += 1
        if self._worker_failures >= 2:
            self._use_process = False
            self.pow_backend = "thread (process unavailable)"
        else:
            self.pow_backend = "restarting worker..."

    def _pow_via_process(self, gen, header, bits, start):
        conn = self._conn
        self._jid += 1
        jid = self._jid
        conn.send(("mine", jid, header, bits, start, self.pow_cpu))
        cancelling, t_cancel = False, 0.0
        while True:
            if conn.poll(0.05):
                msg = conn.recv()                      # EOFError if the worker died
                if msg[1] != jid:
                    continue
                if msg[0] == "prog":
                    self._live_tries = msg[2]
                elif msg[0] == "done":
                    return None if cancelling else (msg[2], msg[3], msg[4])
                elif msg[0] == "cancelled":
                    return None
            elif self._proc is None or not self._proc.is_alive():
                raise _WorkerDied("worker exited")
            if not cancelling and not self._mining_alive(gen, self._live_tries):
                conn.send(("cancel", jid))
                cancelling, t_cancel = True, time.time()
            elif cancelling and time.time() - t_cancel > 5:
                raise _WorkerDied("no cancel ack")

    def _run_pow(self, gen, header, bits, start):
        if self._worker_ok():
            try:
                return self._pow_via_process(gen, header, bits, start)
            except Exception:
                self._worker_failed()
                self._live_tries = 0
        # fallback: in-process thread (yields the GIL; slower for the rest of the app)
        if not self._use_process:
            self.pow_backend = "thread (process unavailable)"
        return mine(header, bits, start, alive=lambda n: self._mining_alive(gen, n))

    def _mining_alive(self, gen, n):
        self._live_tries = n
        return gen == self._gen and not self._paused and not self._shutdown

    def _miner_loop(self):
        self._worker_ok()                       # warm up the PoW process before the first job
        while True:
            with self._cv:
                while not self._shutdown and (self._paused or not self._pending):
                    self._cv.wait(0.2)
                if self._shutdown:
                    return
                gen = self._gen
                job = self._pending[0]                # peek: only removed once sealed
                header = _block_header(self.chain_tip, job["step"], job["trial"], job["bit"])
                bits = self.pow_bits
                start = 0 if self.mode == "DETERMINISTIC" else int.from_bytes(os.urandom(6), "big")
                self._mining = True
                self._live_tries = 0
                t0 = self._mine_t0 = time.perf_counter()

            # heavy part: no lock held, oracle/GUI/camera all keep running
            result = self._run_pow(gen, header, bits, start)
            dt = max(time.perf_counter() - t0, 1e-6)

            with self.lock:
                self._mining = False
                if (result is None or gen != self._gen
                        or not self._pending or self._pending[0] is not job):
                    continue                          # paused / reset: drop this attempt
                nonce, digest, tries = result
                self._pending.popleft()
                self.chain.append(dict(step=job["step"], trial=job["trial"], bit=job["bit"],
                                       bits=bits, nonce=nonce, hash=digest.hex()))
                self.chain_tip = digest
                self.total_hashes += tries
                self.hashrate = tries / dt
                if self.oracle_done and len(self.chain) >= self.bit_depth:
                    self._finalize()

    def _finalize(self):
        """Called with the lock held once every answer has been sealed."""
        if self.current_guess == self.oracle._target:
            self.oracle.is_done = True                # unlocks the target
            self.converged = True
            c = "COMMIT OK" if self.oracle.verify() else "COMMIT FAIL"
            p = "CHAIN OK" if self.verify_chain() else "CHAIN FAIL"
            self._final_status = f"LOCKED AT {self.current_guess} [{c}, {p}]"
        else:
            self._final_status = "POOL MISMATCH"
        self._update_registers()

    def verify_chain(self) -> bool:
        """Recompute every block: linkage, hash, and its own difficulty."""
        with self.lock:
            tip = self.genesis
            for blk in self.chain:
                header = _block_header(tip, blk["step"], blk["trial"], blk["bit"])
                d = hashlib.sha256(header + blk["nonce"].to_bytes(8, "big")).digest()
                if d.hex() != blk["hash"] or not pow_ok(d, blk["bits"]):
                    return False
                tip = d
            return tip == self.chain_tip

    # ---- state for the UI ----------------------------------------------------
    def _update_registers(self):
        self.guess_reg = self.current_guess
        try:
            self.target_reg = self.oracle.target
        except PermissionError:
            self.target_reg = 0
        self.pooled_register = self.oracle.pool_step(self.current_guess)

    def results_text(self) -> str:
        """Plain-text final report for copy/paste. Reveals nothing until the search is locked."""
        with self.lock:
            bd = self.bit_depth
            if not self.converged:
                return ("FINAL RESULTS PENDING\n"
                        f"status: {self._status_text()}\n"
                        f"(the report appears here once all {bd} answers are sealed and verified)")
            o = self.oracle
            hexw = (bd + 3) // 4

            def bits(v):
                b = format(v, f"0{bd}b")
                return " ".join(b[i:i + 8] for i in range(0, bd, 8))

            seed = f" (seed: {self.seed!r})" if self.mode == "DETERMINISTIC" else ""
            L = [
                "=== BIT-POOLING ORACLE: FINAL RESULTS ===",
                f"status      : {self._final_status}",
                f"mode        : {self.mode}{seed}",
                f"bit depth   : {bd}",
                f"pooling     : {self.pool_op}, kernel {self.kernel_size}, stride {o.stride}",
                "",
                f"TARGET (bin): {bits(o._target)}",
                f"TARGET (hex): 0x{o._target:0{hexw}X}",
                f"TARGET (dec): {o._target}",
                f"GUESS  (bin): {bits(self.current_guess)}",
                f"GUESS  (hex): 0x{self.current_guess:0{hexw}X}",
                f"GUESS  (dec): {self.current_guess}",
                f"POOLED (bin): {bits(self.pooled_register)}",
                f"POOLED (hex): 0x{self.pooled_register:0{hexw}X}",
                f"match       : {self.current_guess == o._target}",
                "",
                "--- commitment ---",
                f"salt (hex)  : {o._salt.hex()}",
                f"commit      : {o.commitment.hex()}",
                f"check       : commit == SHA256(b'commit-v1|' + salt + target.to_bytes(8,'big'))",
                "",
                "--- proof of work (SHA-256 hash chain) ---",
                f"blocks      : {len(self.chain)}   total hashes: {self.total_hashes:,}",
                f"genesis     : {self.genesis.hex()}",
                f"chain tip   : {self.chain_tip.hex()}",
                f"check       : hash_i = SHA256(prev || step(2B) || trial(8B) || bit(1B) || nonce(8B));"
                " prev_0 = SHA256(b'genesis-v1|' + commit); hash_i needs `bits` leading zero bits",
                "",
                "step  trial               bit  bits  nonce            hash",
            ]
            for b in self.chain:
                L.append(f"{b['step']:>4}  0x{b['trial']:016X}  {b['bit']}    {b['bits']:>4}  "
                         f"{b['nonce']:<15}  {b['hash']}")
            L.append("")
            L.append("answers (MSB first): " + "".join(str(b["bit"]) for b in self.chain))
            return "\n".join(L)

    def _status_text(self):
        if self._final_status:
            return self._final_status
        if self.step_count == 0 and not self.chain:
            return "READY"
        s = f"ORACLE {self.step_count}/{self.bit_depth} | SEALED {len(self.chain)}/{self.bit_depth}"
        if self._pending:
            s += " | MINING PAUSED" if self._paused else " | MINING"
        return s

    def snapshot(self, force_reveal=False):
        """Consistent view of engine state for the UI (target masked until allowed)."""
        with self.lock:
            return dict(
                target=self.oracle.reveal(force_reveal),
                guess=self.current_guess,
                pooled=self.pooled_register,
                status=self._status_text(),
                steps=self.step_count,
                sealed=len(self.chain),
                backlog=len(self._pending),
                history=list(self.history),
                converged=self.converged,
                oracle_done=self.oracle_done,
                commit=self.oracle.commitment.hex(),
                mode=self.mode,
                pool_frames=self.pool.frames_mixed,
                camera_ok=self.pool.camera_ok,
                chain_tip=self.chain_tip.hex(),
                chain_len=len(self.chain),
                pow_bits=self.pow_bits,
                total_hashes=self.total_hashes,
                hashrate=self.hashrate,
                mining=self._mining,
                pow_backend=self.pow_backend,
                live_tries=self._live_tries,
                live_rate=(self._live_tries / max(time.perf_counter() - self._mine_t0, 1e-6))
                          if self._mining else 0.0,
            )


# ==============================================================================
# CAMERA SOURCE HANDLING
# ==============================================================================
class Source:
    def __init__(self, index: int):
        if cv2 is None:
            raise RuntimeError("OpenCV is not installed. Run: pip install opencv-python")
        backend = cv2.CAP_DSHOW if sys.platform == "win32" else cv2.CAP_ANY
        cap = cv2.VideoCapture(index, backend)
        cap.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
        cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)
        if not (cap.isOpened() and cap.read()[0]):
            cap.release()
            raise RuntimeError(f"Cannot open camera {index}.")
        self.cap = cap
        self.rgb = None

    def read(self):
        ok, bgr = self.cap.read()
        if not ok:
            return None
        self.rgb = cv2.cvtColor(bgr, cv2.COLOR_BGR2RGB)
        return cv2.cvtColor(bgr, cv2.COLOR_BGR2GRAY)

    def close(self):
        self.cap.release()


def ppm_photo(rgb: np.ndarray) -> tk.PhotoImage:
    h, w, _ = rgb.shape
    data = b"P6 %d %d 255\n" % (w, h) + np.ascontiguousarray(rgb, np.uint8).tobytes()
    return tk.PhotoImage(data=data, format="PPM")


# ==============================================================================
# BACKGROUND SIMULATION THREAD
# ==============================================================================
class SimThread(threading.Thread):
    def __init__(self, cam_index, ctl, out, engine):
        super().__init__(daemon=True)
        self.cam_index = cam_index
        self.ctl = ctl
        self.out = out
        self.engine = engine

    def run(self):
        asyncio.run(self._run())

    async def _run(self):
        ctl, out, engine = self.ctl, self.out, self.engine
        try:
            src = Source(self.cam_index)
        except RuntimeError as e:
            out.put(("error", str(e)))
            out.put(("done", None))
            return
        out.put(("info", f"USB camera {self.cam_index} opened"))

        t_prev = time.perf_counter()
        idx = 0
        prev_even = False
        try:
            while not ctl["stop"]:
                gray = await asyncio.to_thread(src.read)
                if gray is None:
                    out.put(("info", "camera stopped delivering frames"))
                    break
                now = time.perf_counter()
                dt = min(max(now - t_prev, 1e-3), 0.25)
                t_prev = now

                # Optoelectronic entropy: raw sensor noise -> SHA-256 pool
                engine.pool.add_frame(gray)

                small = cv2.resize(gray, (128, 96), interpolation=cv2.INTER_AREA)
                motion_detected = idx > 5 and np.std(small) > 5.0
                x = int(np.std(small) * 10) if motion_detected else 0

                # Two sequential even motion triggers advance the bit-pooling step
                even_now = x > 0 and x % 2 == 0
                even_state = even_now and prev_even
                prev_even = even_now

                if even_state and ctl.get("auto_step", True):
                    engine.request_step()          # non-blocking: the oracle thread answers

                rgb = src.rgb if src.rgb is not None else np.stack([gray] * 3, axis=-1)
                pw, ph = 320, 240
                h_img, w_img = rgb.shape[:2]
                preview = rgb[np.arange(ph) * h_img // ph][:, np.arange(pw) * w_img // pw].copy()
                
                if ctl.get("ir_heatmap", False):
                    preview[:, :, 0] = np.clip(preview[:, :, 0].astype(int) + 80, 0, 255)
                    preview[:, :, 2] = np.clip(preview[:, :, 2].astype(int) - 50, 0, 255)

                snap = engine.snapshot(ctl.get("force_reveal", False))
                snap.update(preview=preview, idx=idx, dt=dt)
                out.put(("frame", snap))
                idx += 1
                await asyncio.sleep(0.03)
        finally:
            src.close()
            out.put(("done", None))


# ==============================================================================
# MAIN GUI APPLICATION
# ==============================================================================
class App:
    def __init__(self, window):
        self.window = window
        self.window.title("Bit-Pooling Oracle Search Lab — Auto-Revealing Registers")
        self.q = queue.Queue()
        self.ctl = dict(stop=False, ir_heatmap=False, auto_step=True, force_reveal=False)
        self.engine = BitPoolingSearchEngine(bit_depth=64)
        self.thread = None

        self._build_ui()
        self.window.protocol("WM_DELETE_WINDOW", self._close)
        self.window.after(15, self._poll)

    def _build_ui(self):
        main_frame = ttk.Frame(self.window, padding=10)
        main_frame.pack(fill="both", expand=True)

        # Controls Top Frame
        ctrl_frame = ttk.LabelFrame(main_frame, text="Laboratory Controls")
        ctrl_frame.pack(fill="x", padx=5, pady=5)

        ttk.Button(ctrl_frame, text="Start Lab", command=self.start_lab).pack(side="left", padx=5, pady=5)
        ttk.Button(ctrl_frame, text="Stop Lab", command=self.stop_lab).pack(side="left", padx=5, pady=5)
        ttk.Button(ctrl_frame, text="Step Bit Pool", command=self.step_search).pack(side="left", padx=5, pady=5)
        ttk.Button(ctrl_frame, text="Reset Pool", command=self.reset_search).pack(side="left", padx=5, pady=5)

        self.v_ir = tk.BooleanVar(value=False)
        ttk.Checkbutton(ctrl_frame, text="IR Thermal Heatmap", variable=self.v_ir,
                        command=lambda: self.ctl.update(ir_heatmap=self.v_ir.get())).pack(side="left", padx=10)

        # Target Management Frame
        target_frame = ttk.LabelFrame(main_frame, text="Hidden Target Management (Auto-Revealing Oracle)")
        target_frame.pack(fill="x", padx=5, pady=5)

        ttk.Label(target_frame, text=f"Target (0 - {self.engine.max_val}, or 0x hex):").pack(side="left", padx=5, pady=5)
        self.v_custom_target = tk.StringVar(value="[SECURE]")
        self.e_custom_target = ttk.Entry(target_frame, width=24, textvariable=self.v_custom_target)
        self.e_custom_target.pack(side="left", padx=5, pady=5)

        ttk.Button(target_frame, text="Set Custom", command=self.set_custom_target).pack(side="left", padx=2, pady=5)
        ttk.Button(target_frame, text="Randomize Target", command=self.randomize_target).pack(side="left", padx=5, pady=5)

        self.v_reveal = tk.BooleanVar(value=False)
        self.chk_reveal = ttk.Checkbutton(target_frame, text="Force Reveal Target", variable=self.v_reveal,
                                          command=lambda: self.ctl.update(force_reveal=self.v_reveal.get()))
        self.chk_reveal.pack(side="left", padx=15, pady=5)

        # Final results (selectable text + Copy / Save)
        res_frame = ttk.LabelFrame(main_frame, text="Final Results (select text, or use Copy)")
        res_frame.pack(side="bottom", fill="both", expand=False, padx=5, pady=5)
        btn_row = ttk.Frame(res_frame)
        btn_row.pack(fill="x", padx=5, pady=(5, 0))
        ttk.Button(btn_row, text="Copy Results", command=self.copy_results).pack(side="left", padx=2)
        ttk.Button(btn_row, text="Save Results...", command=self.save_results).pack(side="left", padx=2)
        self.lbl_copy = ttk.Label(btn_row, text="", foreground="#2e7d32")
        self.lbl_copy.pack(side="left", padx=10)
        txt_wrap = ttk.Frame(res_frame)
        txt_wrap.pack(fill="both", expand=True, padx=5, pady=5)
        self.txt_results = tk.Text(txt_wrap, height=12, width=120, wrap="none", font=("Consolas", 9))
        ys = ttk.Scrollbar(txt_wrap, orient="vertical", command=self.txt_results.yview)
        xs = ttk.Scrollbar(txt_wrap, orient="horizontal", command=self.txt_results.xview)
        self.txt_results.configure(yscrollcommand=ys.set, xscrollcommand=xs.set)
        ys.pack(side="right", fill="y")
        xs.pack(side="bottom", fill="x")
        self.txt_results.pack(side="left", fill="both", expand=True)
        # read-only, but still selectable / Ctrl+C-able; Ctrl+A selects everything
        self.txt_results.bind("<Control-a>", lambda e: (self.txt_results.tag_add("sel", "1.0", "end"), "break")[1])
        self._results_key = None
        self._set_results(self.engine.results_text())

        # Viewport and Registers Frame
        display_frame = ttk.Frame(main_frame)
        display_frame.pack(fill="both", expand=True, padx=5, pady=5)

        # Left: Circuit Camera Viewport
        cam_frame = ttk.LabelFrame(display_frame, text="Optoelectronic Circuit Camera Viewport")
        cam_frame.pack(side="left", padx=5, pady=5)
        self.cam_canvas = tk.Canvas(cam_frame, width=320, height=240, bg="black")
        self.cam_canvas.pack(padx=5, pady=5)
        self.cam_img_id = self.cam_canvas.create_image(0, 0, anchor="nw")

        # Right: Register & Hardware Status Panel
        right_panel = ttk.Frame(display_frame)
        right_panel.pack(side="right", fill="both", expand=True, padx=5, pady=5)

        reg_frame = ttk.LabelFrame(right_panel, text="Bit-Pooling Hardware Registers")
        reg_frame.pack(fill="x", padx=5, pady=5)

        self.reg_canvas = tk.Canvas(reg_frame, width=560, height=190, bg="#121414", highlightthickness=0)
        self.reg_canvas.pack(padx=5, pady=5)

        self.lbl_status = ttk.Label(reg_frame, text="Status: IDLE", font=("Consolas", 11), foreground="#00e5ff")
        self.lbl_status.pack(anchor="w", padx=10, pady=5)

        # Settings Configuration Panel
        set_frame = ttk.LabelFrame(right_panel, text="Pooling & Algorithm Settings")
        set_frame.pack(fill="both", expand=True, padx=5, pady=5)

        ttk.Label(set_frame, text="Pooling Operator:").grid(row=0, column=0, sticky="w", padx=5, pady=5)
        self.op_combo = ttk.Combobox(set_frame, values=["POPCOUNT", "AND", "OR", "XOR", "MAJORITY"], state="readonly")
        self.op_combo.set("POPCOUNT")
        self.op_combo.grid(row=0, column=1, padx=5, pady=5)
        self.op_combo.bind("<<ComboboxSelected>>", self._update_pool_op)

        ttk.Label(set_frame, text="Kernel Size:").grid(row=1, column=0, sticky="w", padx=5, pady=5)
        self.kernel_spin = ttk.Spinbox(set_frame, from_=2, to=8, increment=2, width=5, command=self._update_kernel)
        self.kernel_spin.set(4)
        self.kernel_spin.grid(row=1, column=1, sticky="w", padx=5, pady=5)

        ttk.Label(set_frame, text="Oracle Mode:").grid(row=2, column=0, sticky="w", padx=5, pady=5)
        self.mode_combo = ttk.Combobox(set_frame, values=list(BitPoolingSearchEngine.MODES), state="readonly")
        self.mode_combo.set(self.engine.mode)
        self.mode_combo.grid(row=2, column=1, padx=5, pady=5)
        self.mode_combo.bind("<<ComboboxSelected>>", self._update_mode)

        ttk.Label(set_frame, text="Seed (deterministic):").grid(row=3, column=0, sticky="w", padx=5, pady=5)
        self.v_seed = tk.StringVar(value=self.engine.seed)
        ttk.Entry(set_frame, width=16, textvariable=self.v_seed).grid(row=3, column=1, sticky="w", padx=5, pady=5)
        ttk.Button(set_frame, text="Apply Seed", command=self._apply_seed).grid(row=3, column=2, padx=5, pady=5)

        self.lbl_commit = ttk.Label(set_frame, text="SHA-256 commit: -", font=("Consolas", 9))
        self.lbl_commit.grid(row=4, column=0, columnspan=3, sticky="w", padx=5, pady=5)
        self.lbl_pool = ttk.Label(set_frame, text="Entropy pool: OS only", font=("Consolas", 9))
        self.lbl_pool.grid(row=5, column=0, columnspan=3, sticky="w", padx=5, pady=2)

        ttk.Label(set_frame, text="PoW difficulty (bits):").grid(row=6, column=0, sticky="w", padx=5, pady=5)
        self.pow_spin = ttk.Spinbox(set_frame, from_=0, to=64, increment=1, width=5, command=self._update_pow)
        self.pow_spin.set(self.engine.pow_bits)
        self.pow_spin.grid(row=6, column=1, sticky="w", padx=5, pady=5)
        self.lbl_pow = ttk.Label(set_frame, text="PoW: no blocks yet", font=("Consolas", 9))
        self.lbl_pow.grid(row=7, column=0, columnspan=3, sticky="w", padx=5, pady=2)
        self.lbl_tip = ttk.Label(set_frame, text="Chain tip: -", font=("Consolas", 9))
        self.lbl_tip.grid(row=8, column=0, columnspan=3, sticky="w", padx=5, pady=2)
        ttk.Label(set_frame, text="PoW CPU limit (%):").grid(row=9, column=0, sticky="w", padx=5, pady=5)
        self.cpu_spin = ttk.Spinbox(set_frame, from_=5, to=100, increment=5, width=5, command=self._update_cpu)
        self.cpu_spin.set(int(self.engine.pow_cpu * 100))
        self.cpu_spin.grid(row=9, column=1, sticky="w", padx=5, pady=5)
        self._refresh_commit()

    def start_lab(self):
        self.ctl["stop"] = False
        self.engine.resume_mining()
        if self.thread is None or not self.thread.is_alive():
            self.thread = SimThread(0, self.ctl, self.q, self.engine)
            self.thread.start()

    def stop_lab(self):
        self.ctl["stop"] = True
        self.engine.pause_mining()      # abandons the block in progress; Start/Step resumes

    def step_search(self):
        # oracle answers on its own thread; mining continues on the miner thread
        self.engine.resume_mining()
        self.engine.request_step()

    def _update_pow(self):
        try:
            self.engine.pow_bits = max(0, min(64, int(self.pow_spin.get())))
        except ValueError:
            pass

    def _update_cpu(self):
        try:
            self.engine.pow_cpu = max(5, min(100, int(self.cpu_spin.get()))) / 100.0
        except ValueError:
            pass

    def reset_search(self):
        self.engine.reset()
        self.v_custom_target.set("[SECURE]")
        self._refresh_commit()

    def set_custom_target(self):
        try:
            val = int(self.v_custom_target.get().strip(), 0)
            if 0 <= val <= self.engine.max_val:
                self.engine.reset(val)
                self._refresh_commit()
                messagebox.showinfo("Target Set", "New custom target configured for bit pooling.")
            else:
                messagebox.showerror("Invalid Range", f"Target must be between 0 and {self.engine.max_val}.")
        except ValueError:
            messagebox.showerror("Invalid Input", "Enter a decimal integer or 0x-prefixed hex for the custom target.")

    def randomize_target(self):
        self.engine.reset()
        self.v_custom_target.set("[SECURE]")
        self._refresh_commit()

    def _update_pool_op(self, event):
        self.engine.set_pool_op(self.op_combo.get())

    def _update_kernel(self):
        try:
            self.engine.set_kernel(int(self.kernel_spin.get()))
        except ValueError:
            pass

    def _update_mode(self, event):
        self.engine.mode = self.mode_combo.get()
        self.engine.reset()
        self._refresh_commit()

    def _apply_seed(self):
        self.engine.seed = self.v_seed.get()
        self.engine.reset()
        self._refresh_commit()

    def _set_results(self, text):
        self.txt_results.config(state="normal")
        self.txt_results.delete("1.0", "end")
        self.txt_results.insert("1.0", text)
        self.txt_results.config(state="disabled")      # selectable, not editable

    def copy_results(self):
        text = self.engine.results_text()
        self.window.clipboard_clear()
        self.window.clipboard_append(text)
        self.window.update()                            # keep clipboard after the app exits
        self.lbl_copy.config(text="Copied to clipboard")
        self.window.after(2500, lambda: self.lbl_copy.config(text=""))

    def save_results(self):
        path = filedialog.asksaveasfilename(defaultextension=".txt", initialfile="bit_pooling_results.txt",
                                            filetypes=[("Text", "*.txt"), ("All files", "*.*")])
        if path:
            with open(path, "w", encoding="utf-8") as f:
                f.write(self.engine.results_text() + "\n")
            self.lbl_copy.config(text=f"Saved {path}")

    def _refresh_commit(self):
        c = self.engine.oracle.commitment.hex()
        self.lbl_commit.config(text=f"SHA-256 commit: {c}")

    def _draw_bit_rows(self, target_val, guess_val, pooled_val, revealed):
        self.reg_canvas.delete("all")
        bit_depth = self.engine.bit_depth
        per_row, cell = 32, 14
        n_rows = (bit_depth + per_row - 1) // per_row
        hex_w = (bit_depth + 3) // 4

        # Automatically unmask target when converged or explicitly forced
        is_exposed = revealed or self.engine.converged
        active_target = target_val if is_exposed else 0

        rows = [
            ("TARGET", active_target, "#00e676", not is_exposed),
            ("GUESS ", guess_val, "#ffb300", False),
            ("POOLED", pooled_val, "#b388ff", False)
        ]

        y_offset = 8
        for label, val, color, hidden in rows:
            self.reg_canvas.create_text(8, y_offset + 8, text=label, fill="#88a0c0", anchor="w", font=("Consolas", 9, "bold"))

            for pos in range(bit_depth):
                b = bit_depth - 1 - pos                      # MSB first
                r, c = divmod(pos, per_row)
                x0 = 70 + c * cell + (c // 8) * 4            # small gap every byte
                y0 = y_offset + r * (cell + 2)
                bit_state = (val >> b) & 1
                self.reg_canvas.create_rectangle(
                    x0, y0, x0 + cell - 1, y0 + cell,
                    fill=color if (bit_state and not hidden) else "#1e2430",
                    outline="#38445c"
                )
                txt_val = "?" if hidden else str(bit_state)
                txt_color = "#000000" if (bit_state and not hidden) else "#708090"
                self.reg_canvas.create_text(x0 + cell // 2, y0 + cell // 2 + 1, text=txt_val,
                                            fill=txt_color, font=("Consolas", 7, "bold"))

            ty = y_offset + n_rows * (cell + 2) + 6
            num_str = "[HIDDEN]" if hidden else f"0x{val:0{hex_w}X}  ({val})"
            self.reg_canvas.create_text(70, ty, text=num_str, fill="#d2e0f0", anchor="w", font=("Consolas", 9))
            y_offset += n_rows * (cell + 2) + 22

    def _poll(self):
        try:
            for _ in range(100):
                ev = self.q.get_nowait()
                if ev[0] == "frame":
                    d = ev[1]
                    self.photo = ppm_photo(d["preview"])
                    self.cam_canvas.itemconfig(self.cam_img_id, image=self.photo)
                    self._draw_bit_rows(d["target"], d["guess"], d["pooled"], self.v_reveal.get())
                    self.lbl_status.config(text=f"Status: {d['status']}")
                    self.lbl_commit.config(text=f"SHA-256 commit: {d['commit']}")
                    expected = 2 ** d["pow_bits"]
                    if d["mining"]:
                        rate = max(d["live_rate"], 1.0)
                        eta = max(expected - d["live_tries"], 0) / rate
                        self.lbl_pow.config(text=(
                            f"MINING: {d['live_tries']:,} / ~{expected:,} hashes "
                            f"@ {rate/1000:.0f} kH/s | ~{eta:,.0f}s left (avg)"))
                    else:
                        rate = max(d["hashrate"], 5e5)
                        self.lbl_pow.config(text=(
                            f"PoW: {d['chain_len']} sealed, {d['backlog']} queued | {d['total_hashes']:,} hashes | "
                            f"{d['hashrate']/1000:.0f} kH/s | diff {d['pow_bits']} bits "
                            f"(~{expected/rate:,.1f}s/block)"))
                    self.lbl_tip.config(text=f"Chain tip: {d['chain_tip']}")
                    cam = "OK" if d["camera_ok"] else "no signal"
                    self.lbl_pool.config(text=f"Entropy pool: OS + camera[{cam}] frames={d['pool_frames']} | PoW: {d['pow_backend']}")
                    key = (d["commit"], d["converged"])
                    if key != self._results_key:        # only on lock / reset, so selection survives
                        self._results_key = key
                        text = self.engine.results_text()
                        self._set_results(text)
                        if d["converged"]:
                            print(text, flush=True)     # also copyable from the terminal
                elif ev[0] == "error":
                    messagebox.showerror("Camera Error", ev[1])
        except queue.Empty:
            pass
        self.window.after(30, self._poll)

    def _close(self):
        self.ctl["stop"] = True
        self.engine.shutdown()
        self.window.destroy()


if __name__ == "__main__":
    multiprocessing.freeze_support()
    root = tk.Tk()
    app = App(root)
    root.geometry("1180x960")
    root.mainloop()
