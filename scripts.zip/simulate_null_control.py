"""
Null-control simulation: can a camera + noise-cancellation stage + two-level
decoder recover K when K is NOT encoded on the display?

Conditions
  null   : K has no physical effect on the camera (I(K;X)=0 by construction)
  weak   : K adds a small brightness offset (a side-channel leak)
  strong : K is a physical AND mask (opaque cells pass ~5% of light)

Camera model, cell i, cycle t:
  B_i(t) = gain_i * R_i(t) + offset_i + g_i * c(t) + noise
  c(t) = common-mode noise (e.g. supply/exposure flicker), g_i = per-cell coupling
  W(t) = c(t) + small noise   <- reference channel used by the cancellation filter
  The reference W is generated independently of K.

Two analyses
  A) Best-effort statistical attack: score cells by mean residual brightness,
     with and without regression-based noise cancellation, predict K by median
     split. Bit accuracy 0.5 = no information.
  B) The paper's decoder: hard never-seen rule + Hamming-ball + SHA-256 check.
"""
import hashlib, itertools, math
import numpy as np

rng = np.random.default_rng(2026)
N, M, P = 16, 12, 0.5
GAIN, NOISE, CM_SD = 100.0, 20.0, 30.0
BMAX, TRIALS = 2000, 200


def commit(salt, K):
    return hashlib.sha256(salt + np.packbits(K).tobytes()).digest()


def camera(K, condition):
    R = (rng.random((M, N)) < P).astype(float)
    gain = np.full(N, GAIN)
    offset = np.zeros(N)
    if condition == "weak":
        offset = 8.0 * K
    elif condition == "strong":
        gain = np.where(K == 1, GAIN, 0.05 * GAIN)
    c = rng.normal(0, CM_SD, M)
    g = rng.uniform(0.5, 1.5, N)
    B = gain * R + offset + np.outer(c, g) + rng.normal(0, NOISE, (M, N))
    W = c + rng.normal(0, 3.0, M)
    return R, B, W


def attack_accuracy(K, R, B, W, use_nc):
    resid = B - GAIN * R                        # remove known probe contribution
    if use_nc:                                  # per-cell regression on reference W
        Wc = W - W.mean()
        beta = (Wc @ (resid - resid.mean(0))) / (Wc @ Wc)
        resid = resid - np.outer(W, beta)
    score = resid.mean(0)
    pred = (score > np.median(score)).astype(int)
    return np.mean(pred == K)


def level2(U, base, salt, C):
    hashes = 0
    for k in range(len(U) + 1):
        if hashes + math.comb(len(U), k) > BMAX:
            return False, hashes
        for F in itertools.combinations(U, k):
            cand = base.copy()
            cand[list(F)] = 1
            hashes += 1
            if commit(salt, cand) == C:
                return True, hashes
    return False, hashes


def paper_decoder(K, B, salt, C):
    X = (B > GAIN / 2).astype(np.uint8)         # threshold camera to bits
    total = 0
    for m in range(1, M + 1):
        lit = X[:m].any(axis=0)
        ok, h = level2(np.flatnonzero(~lit), lit.astype(np.uint8), salt, C)
        total += h
        if ok:
            return True, total
    return False, total


def main():
    print(f"n={N}, cycles={M}, trials={TRIALS}, budget/stage={BMAX}")
    print(f"blind-guess success per hash = 2^-{N} = {2**-N:.2e}\n")
    print(f"{'condition':<8} {'bit-acc raw':>12} {'bit-acc +NC':>12} "
          f"{'decoder success':>16} {'mean hashes':>12} {'guess-equiv':>12}")
    for cond in ("null", "weak", "strong"):
        raw, nc, wins, hashes = [], [], 0, []
        for _ in range(TRIALS):
            K = rng.integers(0, 2, N).astype(np.uint8)
            salt = rng.bytes(8)
            C = commit(salt, K)
            R, B, W = camera(K, cond)
            raw.append(attack_accuracy(K, R, B, W, False))
            nc.append(attack_accuracy(K, R, B, W, True))
            ok, h = paper_decoder(K, B, salt, C)
            wins += ok
            hashes.append(h)
        guess = np.mean(hashes) * 2.0**-N
        print(f"{cond:<8} {np.mean(raw):>12.3f} {np.mean(nc):>12.3f} "
              f"{wins/TRIALS:>16.3f} {np.mean(hashes):>12.0f} {guess:>12.4f}")
    print("\nbit-acc 0.5 = no information about K. 'guess-equiv' is the success "
          "rate a blind guesser would get with the same number of hashes.")


if __name__ == "__main__":
    main()
