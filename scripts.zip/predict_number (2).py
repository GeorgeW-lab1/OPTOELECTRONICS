#!/usr/bin/env python3
"""
predict_number.py - infer the hidden "isolated number" from a camera.

Author: George Wagenknecht  (framing / clock-ambiguity fixes added in v2)

What it does
------------
The TimeCodeLatch holds an n-bit number and the 74HC74 flip-flop emits one bit
per clock edge (MSB first) on SELECT. If SELECT drives something the camera can
see - an LED, or a patch on an LCD screen - the number is not guessed, it is
*recovered* from the light:

  1. grab frames and reduce a region of interest (ROI) to one brightness value
  2. normalise it (removes auto-exposure drift and slow brightness changes)
  3. recover the clock frequency and phase from the brightness edges
  4. sample one bit in the middle of every clock slot
  5. find the frame boundary with a preamble (Barker-7 by default)
  6. majority-vote the repeated frames and pool the bits into hex

What changed in v2 (fixes for "clock found but preamble not found")
-------------------------------------------------------------------
  * Clock ambiguity: an edge-based clock search cannot tell f from 2f (and can
    confuse f with f/2). The decoder now tests the found clock, half of it and
    double it (and both half-clock phases) and keeps whichever gives a repeating
    frame that contains the preamble.
  * Preamble matching tolerates a single wrong preamble bit after voting
    (--max-pre-err, default 1). Exact matches are always preferred.
  * If nothing matches with --nbits, it scans other widths (1..32 bits) and
    reports the width the transmitter seems to use (disable with --no-scan).
  * On failure it prints the raw slot bits, the real repetition period, and the
    voted frame closest to the expected preamble, so you can see what is wrong.
  * The default --clock help text now agrees with the code (6 Hz).
  * Faster voting (vectorised), and a longer default capture (>= 10 frames).
  * Synthetic mode can simulate a mismatching transmitter (--tx-clock,
    --tx-nbits) so these failure modes can be tested without hardware.

LCD screens
-----------
Filming an LCD is harder than filming an LED: pixels respond slowly (and unequally
for rising and falling), the backlight and rolling shutter add banding, and the
camera's auto-exposure drifts. This version handles those by normalising against
a rolling envelope, finding edges without hard thresholds, and treating rising and
falling edges separately. Pair it with lcd_transmitter.py to put the signal on a screen.

Usage
-----
  python predict_number.py --synthetic --lcd --secret 0xA5 --nbits 8   # simulated LCD
  python predict_number.py --cam 0 --nbits 8 --clock 6                 # webcam, auto ROI
  python predict_number.py --cam 0 --nbits 8 --select                  # pick ROI with mouse
  python predict_number.py --cam recording.mp4 --nbits 8 --roi 400,220,120,120
  python predict_number.py --cam 0 --debug                             # print raw bits too

Camera mode needs:  pip install opencv-python numpy

Signal format expected (repeated continuously):
  [ preamble bits | nbits data bits, MSB first ]   one bit per clock period
"""
import argparse
import collections
import math
import sys
import time

import numpy as np

PREAMBLE = "1110010"  # Barker-7: sharp autocorrelation, easy to find in a stream


# --------------------------------------------------------------------------
# Transmitter side (used by the synthetic camera)
# --------------------------------------------------------------------------
class TimeCodeLatch:
    """Latch holding the isolated number; outputs one bit (MSB first) per clock"""

    def __init__(self, value, nbits):
        self.value, self.nbits = value, nbits

    def bit(self, slot):
        return (self.value >> (self.nbits - 1 - slot)) & 1


class DFlipFlop74HC74:
    """Rising-edge D flip-flop: Q <- D on CLK, Qbar is the complement"""

    def __init__(self):
        self.q = 0

    @property
    def qbar(self):
        return 1 - self.q

    def clock(self, d):
        self.q = d & 1
        return self.q


class SyntheticLED:
    """Simulates the optical SELECT output seen by a camera.

    Includes: unknown start phase, clock skew between device and camera,
    response time, ambient light, slow drift, sensor noise, dropped frames and
    optional random bit errors. With lcd=True it also adds typical LCD-capture
    problems: slow, asymmetric pixel response, refresh/banding ripple, and
    auto-exposure wander plus a sudden exposure step.
    """

    def __init__(self, secret, nbits, clock_hz, preamble, clock_skew, bit_error, seed, lcd=False):
        self.rng = np.random.default_rng(seed)
        self.latch = TimeCodeLatch(secret, nbits)
        self.ff = DFlipFlop74HC74()
        pre = [int(c) for c in preamble]
        self.stream = pre + [self.latch.bit(i) for i in range(nbits)]
        self.L = len(self.stream)
        self.period = 1.0 / (clock_hz * (1.0 + clock_skew))
        self.t0 = self.rng.uniform(0, self.period) + 0.35  # unknown phase
        self.bit_error, self.lcd = bit_error, lcd
        self.n_done = -1
        self.level, self.last_t, self.tau = 0.0, 0.0, 0.012
        self.ambient, self.gain, self.noise = 40.0, 110.0, 6.0

    def brightness(self, t):
        n = int(math.floor((t - self.t0) / self.period))
        while self.n_done < n:  # process every clock edge that has passed
            self.n_done += 1
            d = self.stream[self.n_done % self.L]
            if self.rng.random() < self.bit_error:
                d ^= 1
            self.ff.clock(d)
        dt = max(0.0, t - self.last_t)
        self.last_t = max(t, self.last_t)
        target = float(self.ff.q)
        tau = self.tau
        if self.lcd:
            tau = 0.030 if target > self.level else 0.018  # slow rise, quicker fall
        self.level += (target - self.level) * (1 - math.exp(-dt / tau))
        if self.lcd:
            g = 1 + 0.25 * math.sin(2 * math.pi * 0.11 * t) - (0.2 if t > 5 else 0.0)
            ripple = 0.05 * self.gain * math.sin(2 * math.pi * 29.7 * t)
            v = g * (self.ambient + self.gain * self.level) + ripple
            v += self.rng.normal(0, 1.5 * self.noise)
        else:
            drift = 8.0 * math.sin(2 * math.pi * 0.13 * t)
            v = self.ambient + self.gain * self.level + drift + self.rng.normal(0, self.noise)
        return float(np.clip(v, 0, 255))


# --------------------------------------------------------------------------
# Camera
# --------------------------------------------------------------------------
class Camera:
    """Yields (timestamp_seconds, ROI brightness) per frame.

    source    : camera index ("0"), or a video file path
    synthetic : if True, use SyntheticLED instead of hardware
    """

    def __init__(self, source, synthetic, sim=None, fps=30.0, roi=None, select=False,
                 manual_exposure=False, exposure=None, debug_roi="roi_debug.png"):
        self.synthetic, self.sim, self.fps, self.roi = synthetic, sim, fps, roi
        self.debug_roi = debug_roi
        if synthetic:
            return
        try:
            import cv2
        except ImportError:
            sys.exit("OpenCV is required for camera mode:  pip install opencv-python")
        self.cv2 = cv2
        self.is_file = not str(source).isdigit()
        self.cap = cv2.VideoCapture(source if self.is_file else int(source))
        if not self.cap.isOpened():
            sys.exit(f"Could not open camera/video source: {source}")
        if self.is_file:
            self.fps = self.cap.get(cv2.CAP_PROP_FPS) or fps
        else:
            self.cap.set(cv2.CAP_PROP_FPS, fps)
            self.fps = self.cap.get(cv2.CAP_PROP_FPS) or fps
            if manual_exposure or exposure is not None:
                # Best effort: 0.25 = manual on V4L2/most backends; ignored where unsupported.
                self.cap.set(cv2.CAP_PROP_AUTO_EXPOSURE, 0.25)
                if exposure is not None:
                    self.cap.set(cv2.CAP_PROP_EXPOSURE, exposure)
        if self.roi is None:
            self.roi = self._select_roi() if select else self._auto_roi()
        print(f"[camera] {self.fps:.1f} fps, ROI x,y,w,h = {self.roi}")

    def _select_roi(self):
        ok, frame = self.cap.read()
        if not ok:
            sys.exit("No frame received from camera.")
        r = self.cv2.selectROI("Select the LED / screen patch, then press ENTER", frame,
                               showCrosshair=True)
        self.cv2.destroyAllWindows()
        if r[2] == 0 or r[3] == 0:
            sys.exit("No ROI selected.")
        self._rewind()
        return tuple(int(x) for x in r)

    def _auto_roi(self, seconds=4.0):
        """Find the blinking region: highest temporal variance after removing global
        exposure changes, then take the whole connected blob (an LCD patch is big)."""
        cv2, small, last = self.cv2, [], None
        for _ in range(int(self.fps * seconds)):
            ok, frame = self.cap.read()
            if not ok:
                break
            last = frame
            g = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
            small.append(cv2.resize(g, (160, 120), interpolation=cv2.INTER_AREA).astype(np.float32))
        if len(small) < 10:
            sys.exit("Not enough frames to find the blinking region; use --roi or --select.")
        arr = np.stack(small)
        arr -= np.median(arr, axis=(1, 2), keepdims=True)  # remove global exposure wander
        std = cv2.GaussianBlur(np.std(arr, axis=0), (0, 0), 1.5)
        mask = (std > 0.55 * std.max()).astype(np.uint8)
        _, labels, stats, _ = cv2.connectedComponentsWithStats(mask)
        y, x = np.unravel_index(np.argmax(std), std.shape)
        bx, by, bw, bh = stats[labels[y, x]][:4]
        # shrink to the inner 70% so slow pixel edges and borders are excluded
        bx, by = bx + 0.15 * bw, by + 0.15 * bh
        bw, bh = max(2.0, 0.7 * bw), max(2.0, 0.7 * bh)
        sx, sy = last.shape[1] / 160.0, last.shape[0] / 120.0
        roi = (int(bx * sx), int(by * sy), int(max(8, bw * sx)), int(max(8, bh * sy)))
        if self.debug_roi:
            vis = last.copy()
            cv2.rectangle(vis, (roi[0], roi[1]), (roi[0] + roi[2], roi[1] + roi[3]), (0, 255, 0), 2)
            cv2.imwrite(self.debug_roi, vis)
            print(f"[camera] auto-ROI preview saved to {self.debug_roi} - check it is on the signal")
        self._rewind()
        return roi

    def _rewind(self):
        if self.is_file:
            self.cap.set(self.cv2.CAP_PROP_POS_FRAMES, 0)

    def frames(self, duration):
        if self.synthetic:
            rng, k = self.sim.rng, 0
            while True:
                t = k / self.fps + rng.normal(0, 0.002)
                k += 1
                if t > duration:
                    return
                if rng.random() < 0.02:  # dropped frame
                    continue
                yield t, self.sim.brightness(max(t, 0.0))
        else:
            cv2, idx, start = self.cv2, 0, time.perf_counter()
            x, y, w, h = self.roi
            while True:
                ok, frame = self.cap.read()
                if not ok:
                    return
                t = idx / self.fps if self.is_file else time.perf_counter() - start
                idx += 1
                if t > duration:
                    return
                g = cv2.cvtColor(frame[max(y, 0):y + h, max(x, 0):x + w], cv2.COLOR_BGR2GRAY)
                yield t, float(g.mean())

    def release(self):
        if not self.synthetic:
            self.cap.release()


# --------------------------------------------------------------------------
# Decoder
# --------------------------------------------------------------------------
def normalise(t, v, win_s=3.0):
    """Scale brightness to ~0..1 using a rolling 5th/95th-percentile envelope.
    Removes auto-exposure drift, gain steps and slow backlight changes."""
    n = len(v)
    fs = (n - 1) / (t[-1] - t[0])
    w = max(15, int(win_s * fs)) | 1
    gl, gh = np.percentile(v, [5, 95])
    lo, hi = np.empty(n), np.empty(n)
    for i in range(n):
        seg = v[max(0, i - w // 2): i + w // 2 + 1]
        lo[i], hi[i] = np.percentile(seg, [5, 95])
    k = max(3, int(0.5 * fs))
    ker = np.ones(k) / k
    smooth = lambda a: np.convolve(np.pad(a, (k // 2, k - 1 - k // 2), mode="edge"), ker, mode="valid")
    lo, hi = smooth(lo), smooth(hi)
    span = np.maximum(hi - lo, 0.35 * (gh - gl))
    return (v - lo) / span


def edge_events(t, x):
    """Soft edge detection: weights for rising and falling changes between frames,
    with the noise floor estimated robustly (no hard binary threshold)."""
    d = np.diff(x)
    tm = 0.5 * (t[1:] + t[:-1])
    sigma = 1.4826 * np.median(np.abs(d - np.median(d)))
    thr = float(np.clip(3 * sigma, 0.10, 0.30))
    return tm, np.clip(d - thr, 0, None), np.clip(-d - thr, 0, None)


def recover_clock(tm, wr, wf, f0, span, duration):
    """Find f, phase so that edges fall at (k + phase)/f. Rising and falling edges are
    scored separately because LCD pixels respond with different delays.
    Returns (f, phase, lock) or None.

    NOTE: an edge-comb score is equally high at f and at 2f (edges at k/f are also at
    multiples of 1/(2f)), so the result may be a harmonic. decode() handles that."""
    keep = (wr + wf) > 0
    if keep.sum() < 6:
        return None
    tm, wr, wf = tm[keep], wr[keep], wf[keep]
    tot = wr.sum() + wf.sum()

    def score(freqs):
        E = np.exp(2j * np.pi * np.outer(freqs, tm))
        zr, zf = E @ wr, E @ wf
        return (np.abs(zr) + np.abs(zf)) / tot, zr, zf

    step = 0.05 / duration  # keeps phase error under ~0.05 cycle across the capture
    freqs = np.arange(f0 * (1 - span), f0 * (1 + span) + step, step)
    s, _, _ = score(freqs)
    f = freqs[int(np.argmax(s))]
    fine = np.linspace(f - step, f + step, 41)
    s, zr, zf = score(fine)
    i = int(np.argmax(s))
    phase = (np.angle(zr[i] + zf[i]) / (2 * np.pi)) % 1.0
    return float(fine[i]), float(phase), float(s[i])


def phase_at(tm, w, f):
    """Phase (0..1) at which the weighted edges line up best for frequency f."""
    z = np.sum(w * np.exp(2j * np.pi * f * tm))
    return float((np.angle(z) / (2 * np.pi)) % 1.0)


def sample_slots(t, x, f, phase, thr=0.5, span=1.0):
    """One decision per clock slot, from the settled part (30%-85%) of the slot."""
    T = 1.0 / f
    kmin = int(math.ceil(t[0] * f - phase)) + 1
    kmax = int(math.floor(t[-1] * f - phase)) - 1
    bits, margins = [], []
    for k in range(kmin, kmax):
        b = (k + phase) * T
        i0, i1 = np.searchsorted(t, [b + 0.30 * T, b + 0.85 * T])
        if i1 <= i0:
            bits.append(-1)
            margins.append(0.0)
            continue
        m = x[i0:i1].mean()
        bits.append(int(m > thr))
        margins.append(min(1.0, abs(m - thr) / (span / 2)))
    return np.array(bits, dtype=int), np.array(margins, dtype=float)


def align_and_vote(bits, nbits, preamble, max_pre_err=0):
    """Find the frame start with the preamble and majority-vote the repeated frames.

    Returns candidates sorted by (preamble errors, -confidence). A candidate is any
    frame offset whose voted preamble differs from the expected one in at most
    `max_pre_err` bits."""
    pre = np.array([int(c) for c in preamble], dtype=int)
    P = len(pre)
    L = P + nbits
    n = len(bits)
    if n < L or nbits < 1:
        return []
    good = bits >= 0
    idx = np.arange(n)
    cands = []
    for off in range(L):
        pos = (idx + off) % L
        cnt = np.bincount(pos[good], minlength=L).astype(float)
        ones = np.bincount(pos[good], weights=bits[good].astype(float), minlength=L)
        m = np.where(cnt > 0, ones / np.maximum(cnt, 1.0), 0.5)
        maj = (m >= 0.5).astype(int)
        pre_err = int(np.sum(maj[:P] != pre)) if P else 0
        if pre_err > max_pre_err:
            continue
        cons = m[P:]
        agree = np.maximum(cons, 1 - cons)
        value = int("".join(map(str, maj[P:])), 2)
        cands.append({"value": value, "bit_conf": agree, "conf": float(agree.mean()),
                      "frames": int(n // L), "pre_err": pre_err, "offset": off})
    cands.sort(key=lambda c: (c["pre_err"], -c["conf"]))
    return cands


def diagnose(bits, nbits, preamble):
    """Human-readable view of what was actually received, used when decoding fails."""
    pre = np.array([int(c) for c in preamble], dtype=int)
    P, L = len(pre), len(pre) + nbits
    lines = ["[bits]    " + "".join("?" if b < 0 else str(b) for b in bits)]
    scores = []
    for Lp in range(max(3, 2), min(64, len(bits) // 2) + 1):
        a, b = bits[:-Lp], bits[Lp:]
        ok = (a >= 0) & (b >= 0)
        if ok.sum() < Lp:
            continue
        scores.append((Lp, float(np.mean(a[ok] == b[ok]))))
    if not scores:
        lines.append("[period]  capture too short to measure a repetition period")
        return lines
    top = max(s for _, s in scores)
    Lp = next(l for l, s in scores if s >= top - 0.02)  # smallest period with ~peak agreement
    lines.append(f"[period]  strongest repetition period = {Lp} slots "
                 f"(agreement {top:.2f}); you told me {L} = {P} preamble + {nbits} data")
    if Lp != L:
        lines.append(f"          -> transmitter frame looks like {Lp} bits: try --nbits {Lp - P} "
                     f"(with the same preamble length) or check the preamble length.")
    if Lp >= P and top > 0.6:
        pos = np.arange(len(bits)) % Lp
        good = bits >= 0
        cnt = np.bincount(pos[good], minlength=Lp)
        ones = np.bincount(pos[good], weights=bits[good].astype(float), minlength=Lp)
        maj = (ones / np.maximum(cnt, 1) >= 0.5).astype(int)
        best = None
        for inv in (0, 1):
            mm = 1 - maj if inv else maj
            for rot in range(Lp):
                rolled = np.roll(mm, -rot)
                d = int(np.sum(rolled[:P] != pre))
                if best is None or d < best[0]:
                    best = (d, inv, rolled)
        d, inv, rolled = best
        frame = "".join(map(str, rolled))
        lines.append(f"[frame]   voted frame closest to preamble {preamble}: "
                     f"{frame[:P]} | {frame[P:]}  ({d} preamble bit(s) differ"
                     f"{', inverted' if inv else ''})")
    return lines


def decode(t, v, clock, nbits, preamble, wide=False, max_pre_err=1, min_conf=0.80, scan=True):
    gl, gh = np.percentile(v, [5, 95])
    info = {"span": float(gh - gl)}
    if gh - gl < 8:
        info["error"] = (f"No visible modulation (brightness range {gh - gl:.1f}). "
                         "The ROI is probably not on the blinking region, or nothing is blinking.")
        return info
    x = normalise(t, v)
    tm, wr, wf = edge_events(t, x)
    D = t[-1] - t[0]
    fs = (len(t) - 1) / D
    info["events"] = int(((wr + wf) > 0).sum())
    res = None if wide else recover_clock(tm, wr, wf, clock, 0.04, D)
    # A narrow search can report a deceptively "ok" lock on noise, so also search wide
    # unless the narrow lock is clearly strong (a real clock scores ~0.85-0.95).
    if res is None or res[2] < 0.85:
        wide_res = recover_clock(tm, wr, wf, clock, 0.6, D)  # clock not near nominal? search 0.4x-1.6x
        if wide_res is not None and (res is None or wide_res[2] > res[2]):
            res = wide_res
    if res is None:
        info["error"] = (f"Too few brightness edges ({info['events']} usable) to recover the clock. "
                         "See the checklist below.")
        return info
    f, phase, lock = res
    info.update(clock=f, lock=lock, found_clock=f)

    # ---- clock hypotheses: found clock, half of it (2 phases), double it ----------
    w_all = wr + wf
    hyps = []
    for mult in (1.0, 0.5, 2.0):
        fh = f * mult
        if fh < 0.3 or fh > fs / 2.5:  # need >= ~2.5 frames per slot
            continue
        p0 = phase if mult == 1.0 else phase_at(tm, w_all, fh)
        for p in ([p0, (p0 + 0.5) % 1.0] if mult == 0.5 else [p0]):
            bits, margins = sample_slots(t, x, fh, p)
            hyps.append({"mult": mult, "f": fh, "phase": p, "bits": bits,
                         "margin": float(margins.mean()) if len(margins) else 0.0})
    primary = hyps[0]
    info.update(n_slots=int(len(primary["bits"])), slot_margin=primary["margin"])

    def polarity(bits, inv):
        return np.where(bits >= 0, 1 - bits, -1) if inv else bits

    # ---- try every hypothesis with the requested frame size ------------------------
    found = []
    for h in hyps:
        for inv in (False, True):
            for c in align_and_vote(polarity(h["bits"], inv), nbits, preamble, max_pre_err):
                c.update(mult=h["mult"], f=h["f"], phase=h["phase"], inverted=inv,
                         margin=h["margin"], n_slots=int(len(h["bits"])), nbits=nbits,
                         key=(h["mult"], h["phase"], inv))
                # prefer the straightforward reading unless an alternative is clearly better
                c["rank"] = c["conf"] - (0.0 if (h["mult"] == 1.0 and not inv) else 0.05)
                found.append(c)
    good = [c for c in found if c["conf"] >= min_conf]
    if good:
        good.sort(key=lambda c: (c["pre_err"] > 0, -c["rank"]))
        best = good[0]
        alts = [c for c in good[1:] if c["key"] == best["key"] and c["pre_err"] == 0
                and c["offset"] != best["offset"]]
        info.update(cands=[best] + alts, clock=best["f"], inverted=best["inverted"],
                    clock_mult=best["mult"], n_slots=best["n_slots"], slot_margin=best["margin"],
                    nbits_used=nbits)
        return info

    # ---- fallback: maybe the transmitter uses a different data width --------------
    if scan:
        scanned = []
        for nb in range(1, 33):
            if nb == nbits:
                continue
            for h in hyps:
                for inv in (False, True):
                    for c in align_and_vote(polarity(h["bits"], inv), nb, preamble, 0):
                        if c["conf"] >= 0.90 and c["frames"] >= 3:
                            c.update(mult=h["mult"], f=h["f"], phase=h["phase"], inverted=inv,
                                     margin=h["margin"], n_slots=int(len(h["bits"])), nbits=nb)
                            scanned.append(c)
        if scanned:
            top = max(c["conf"] for c in scanned)
            near = [c for c in scanned if c["conf"] >= top - 0.03]
            c = min(near, key=lambda c: (c["nbits"], c["mult"] != 1.0, -c["conf"]))
            info.update(cands=[c], clock=c["f"], inverted=c["inverted"], clock_mult=c["mult"],
                        n_slots=c["n_slots"], slot_margin=c["margin"], nbits_used=c["nbits"],
                        nbits_mismatch=True)
            return info

    info["diag"] = diagnose(primary["bits"], nbits, preamble)
    ratio = f / clock if clock else 0
    hint = ""
    if abs(ratio - 1) > 0.1:
        hint = (f" The found clock is {ratio:.2f}x the nominal {clock:g} Hz - pass the real "
                f"transmitter clock with --clock.")
    info["error"] = (f"Clock found ({f:.3f} Hz, lock {lock:.2f}) but no frame with the preamble "
                     f"{preamble} (+{nbits} data bits) repeats in the capture.{hint} "
                     "Capture longer, check --nbits/--preamble/--clock match the transmitter.")
    return info


def fmt_hex(value, nbits):
    return f"0x{value:0{(nbits + 3) // 4}X}"


CHECKLIST = """\
Checklist for filming an LCD screen:
  * The screen must actually be blinking a patch at the clock rate (run lcd_transmitter.py).
  * Make the patch large (a third of the screen or more) and fill the camera view with it.
  * Look at roi_debug.png: the green box must sit inside the blinking patch. Otherwise use
    --select or --roi x,y,w,h.
  * Keep the camera still and the room light steady; try --manual-exposure.
  * Camera fps must be at least 20; check the reported fps.
  * --clock, --nbits and --preamble must equal the transmitter's settings.
  * Use --save-trace trace.csv to inspect the brightness over time, and --debug for raw bits."""


# --------------------------------------------------------------------------
def parse_int(s):
    return int(s, 0)


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--cam", default="0", help="camera index or video file (default 0)")
    ap.add_argument("--synthetic", action="store_true", help="simulate the circuit, no hardware")
    ap.add_argument("--lcd", action="store_true", help="synthetic: add LCD-capture artefacts")
    ap.add_argument("--secret", type=parse_int, default=None, help="synthetic only: the hidden number")
    ap.add_argument("--nbits", type=int, default=8, help="width of the isolated number")
    ap.add_argument("--clock", type=float, default=6.0, help="nominal clock in Hz (default 6)")
    ap.add_argument("--preamble", default=PREAMBLE, help=f"frame preamble bits (default {PREAMBLE})")
    ap.add_argument("--duration", type=float, default=None, help="capture seconds (default: ~10 frames)")
    ap.add_argument("--fps", type=float, default=30.0, help="requested camera fps")
    ap.add_argument("--roi", default=None, help="x,y,w,h of the LED / screen patch")
    ap.add_argument("--select", action="store_true", help="choose the ROI with the mouse")
    ap.add_argument("--manual-exposure", action="store_true", help="try to disable auto-exposure")
    ap.add_argument("--exposure", type=float, default=None, help="manual exposure value (driver specific)")
    ap.add_argument("--wide", action="store_true", help="search the clock over 0.4x-1.6x nominal")
    ap.add_argument("--max-pre-err", type=int, default=1,
                    help="allowed wrong preamble bits after voting (default 1; exact matches win)")
    ap.add_argument("--min-conf", type=float, default=0.80,
                    help="minimum bit agreement across frames to accept a result (default 0.80)")
    ap.add_argument("--no-scan", action="store_true", help="do not try other --nbits values on failure")
    ap.add_argument("--debug", action="store_true", help="always print the raw slot bits / period")
    ap.add_argument("--seed", type=int, default=None)
    ap.add_argument("--clock-skew", type=float, default=0.007, help="synthetic: clock mismatch")
    ap.add_argument("--bit-error", type=float, default=0.02, help="synthetic: per-slot flip probability")
    ap.add_argument("--tx-clock", type=float, default=None,
                    help="synthetic: real transmitter clock if different from --clock (test mismatches)")
    ap.add_argument("--tx-nbits", type=int, default=None,
                    help="synthetic: real transmitter width if different from --nbits")
    ap.add_argument("--save-trace", default=None, help="write the brightness trace to CSV")
    args = ap.parse_args()

    L = len(args.preamble) + args.nbits
    duration = args.duration or max(12.0, 10 * L / args.clock)

    sim, secret = None, None
    if args.synthetic:
        tx_nbits = args.tx_nbits or args.nbits
        tx_clock = args.tx_clock or args.clock
        rng = np.random.default_rng(args.seed)
        secret = args.secret if args.secret is not None else int(rng.integers(0, 2 ** tx_nbits))
        if secret >> tx_nbits:
            sys.exit(f"--secret does not fit in {tx_nbits} bits")
        sim = SyntheticLED(secret, tx_nbits, tx_clock, args.preamble,
                           args.clock_skew, args.bit_error, args.seed, args.lcd)
    roi = tuple(int(x) for x in args.roi.split(",")) if args.roi else None

    cam = Camera(args.cam, args.synthetic, sim, args.fps, roi, args.select,
                 args.manual_exposure, args.exposure)
    traces = collections.defaultdict(lambda: collections.deque(maxlen=int(cam.fps * duration) + 64))

    print(f"[capture] {duration:.1f} s ({L} bits per frame, clock {args.clock} Hz)")
    for t, v in cam.frames(duration):
        traces["t"].append(t)
        traces["v"].append(v)
    cam.release()
    t, v = np.array(traces["t"]), np.array(traces["v"])
    print(f"[capture] {len(t)} frames")
    if len(t) < 30:
        sys.exit("Too few frames captured.")

    if args.save_trace:
        np.savetxt(args.save_trace, np.c_[t, v], delimiter=",", header="t_s,brightness", comments="")

    res = decode(t, v, args.clock, args.nbits, args.preamble, args.wide,
                 args.max_pre_err, args.min_conf, not args.no_scan)
    print(f"[signal]  brightness range {res['span']:.1f}, usable edge events {res.get('events', 0)}")
    if "clock" in res:
        print(f"[clock]   {res['clock']:.3f} Hz (nominal {args.clock}), lock quality {res.get('lock', 0):.2f}")
        print(f"[slots]   {res['n_slots']} decoded, mean decision margin {res['slot_margin']:.2f}")
    if args.debug or "error" in res:
        for line in res.get("diag", []):
            print(line)
    if "error" in res:
        print("RESULT:   FAILED -", res["error"])
        print(CHECKLIST)
        sys.exit(1)

    best = res["cands"][0]
    nb = res.get("nbits_used", args.nbits)
    if res.get("clock_mult", 1.0) != 1.0:
        print(f"[note]    the strongest edge clock was a {1 / res['clock_mult']:g}x harmonic; "
              f"decoded at {res['clock']:.3f} Hz instead")
    if res.get("inverted"):
        print("[note]    signal polarity was inverted (dark = 1); corrected automatically")
    if best["pre_err"]:
        print(f"[warn]    preamble matched with {best['pre_err']} wrong bit(s) - treat the result as "
              "less certain and capture longer")
    if res.get("nbits_mismatch"):
        print(f"[warn]    --nbits {args.nbits} found no frame; the transmitter appears to use "
              f"{nb} data bits. Result below is decoded as {nb} bits.")
    print()
    print(f"PREDICTED NUMBER : {best['value']}  ({fmt_hex(best['value'], nb)}, "
          f"{best['value']:0{nb}b})")
    print(f"CONFIDENCE       : {best['conf']:.1%} bit agreement over ~{best['frames']} frames")
    weak = [i for i, c in enumerate(best["bit_conf"]) if c < 0.8]
    if weak:
        print(f"WEAK BITS (slot, MSB=0): {weak}  - capture longer for more votes")
    if len(res["cands"]) > 1:
        print("AMBIGUOUS FRAMING: the preamble also matches at another offset. Alternatives:")
        for c in res["cands"][1:4]:
            print(f"   {c['value']} ({fmt_hex(c['value'], nb)})  conf {c['conf']:.1%}")
    if args.synthetic:
        ok = best["value"] == secret
        print(f"\n[synthetic ground truth] secret = {secret} ({fmt_hex(secret, nb)})  "
              f"-> {'MATCH' if ok else 'MISMATCH'}")
        sys.exit(0 if ok else 2)


if __name__ == "__main__":
    main()
