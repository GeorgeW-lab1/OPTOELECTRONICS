#!/usr/bin/env python3
"""Backward-compatible entry point; the code now lives in the turing_gen package."""
from turing_gen import *  # noqa: F401,F403
from turing_gen.cli import main

if __name__ == "__main__":
    raise SystemExit(main())
