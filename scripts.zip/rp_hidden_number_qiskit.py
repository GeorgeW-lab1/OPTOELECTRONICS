#!/usr/bin/env python3
"""
rp_hidden_number_qiskit.py
==========================

Commit-only hidden-number recovery with selectable Qiskit backends.

Backends:
  --backend aer      Qiskit AerSimulator
  --backend optical  Existing quantum_optical_bench OpticalBackend
  --backend both     Run both and merge their measured candidate counts

The oracle publishes only salt and SHA-256 commitment. The recogniser never
receives the hidden number. Camera-derived masks determine which positions
are observed. Qiskit prepares a superposition over unknown positions while
fixing currently observed positions, then measurements provide candidates.
Every candidate is checked with exact classical SHA-256.

Important:
  This is quantum-assisted candidate sampling, not a reversible SHA-256
  quantum oracle and not Grover search. A uniform superposition alone does
  not provide a speedup over random guessing. The commitment verifier is
  classical. OpticalBackend execution requires your existing
  quantum_optical_bench.py and compatible camera/ITO hardware.

Examples:
  python rp_hidden_number_qiskit.py --backend aer --bits 16
  python rp_hidden_number_qiskit.py --backend optical --camera 0 --port COM7
  python rp_hidden_number_qiskit.py --backend both --bits 16 --shots 4096
"""

from __future__ import annotations

import argparse
import hashlib
import math
import os
import platform
import secrets
import sys
from collections import Counter

import numpy as np

try:
    import cv2
except ImportError:
    cv2 = None

try:
    from qiskit import QuantumCircuit, transpile
except ImportError:
    QuantumCircuit = None
    transpile = None

try:
    from qiskit_aer import AerSimulator
except ImportError:
    AerSimulator = None


# ---------------------------------------------------------------------------
# Oracle: owns K; exposes only salt and commitment
# ---------------------------------------------------------------------------

class HiddenNumberOracle:
    def __init__(self, bits=16, reveal_probability=0.45, noise_probability=0.03):
        if bits < 8 or bits % 8:
            raise ValueError("bits must be a multiple of 8 and at least 8")
        if not 0 < reveal_probability <= 1:
            raise ValueError("reveal probability must be in (0, 1]")
        if not 0 <= noise_probability < 1:
            raise ValueError("noise probability must be in [0, 1)")
        self.bits = bits
        self.byte_length = bits // 8
        self.reveal_probability = reveal_probability
        self.noise_probability = noise_probability
        self.hidden_number = secrets.randbits(bits)
        self.salt = os.urandom(16)
        self.commitment = self.digest(self.hidden_number)

    def digest(self, value):
        return hashlib.sha256(
            self.salt + int(value).to_bytes(self.byte_length, "big")
        ).digest()

    def public_parameters(self):
        return {"salt": self.salt, "commitment": self.commitment}

    def observe_mask(self, reveal_mask):
        """Return noisy values only at positions selected by reveal_mask."""
        values = 0
        for i in range(self.bits):
            if (reveal_mask >> i) & 1:
                bit = (self.hidden_number >> i) & 1
                if secrets.randbelow(10_000) < int(self.noise_probability * 10_000):
                    bit ^= 1
                values |= bit << i
        return reveal_mask, values

    def verify(self, candidate):
        return self.digest(candidate) == self.commitment

    def reveal_if_proven(self, candidate):
        if not self.verify(candidate):
            return None
        return {
            "number": self.hidden_number,
            "binary": format(self.hidden_number, f"0{self.bits}b"),
            "commitment": self.commitment.hex(),
            "proof": True,
        }


# ---------------------------------------------------------------------------
# Camera observation source
# ---------------------------------------------------------------------------

def list_cameras(max_index=10):
    if cv2 is None:
        return []
    system = platform.system()
    names = (
        ["CAP_DSHOW", "CAP_MSMF", "CAP_ANY"] if system == "Windows"
        else ["CAP_AVFOUNDATION", "CAP_ANY"] if system == "Darwin"
        else ["CAP_V4L2", "CAP_ANY"]
    )
    backends = [(n, getattr(cv2, n)) for n in names if hasattr(cv2, n)]
    found = []
    for index in range(max_index):
        for name, backend in backends:
            cap = cv2.VideoCapture(index, backend)
            if cap.isOpened():
                w = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
                h = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
                found.append((index, name, w, h))
                cap.release()
                break
    return found


class CameraSource:
    def __init__(self, source, width=640, height=480, fps=30):
        if cv2 is None:
            raise RuntimeError("Install opencv-python for camera input")
        self.cap = cv2.VideoCapture(source)
        if not self.cap.isOpened():
            raise RuntimeError(f"Could not open camera {source}")
        self.cap.set(cv2.CAP_PROP_FRAME_WIDTH, width)
        self.cap.set(cv2.CAP_PROP_FRAME_HEIGHT, height)
        self.cap.set(cv2.CAP_PROP_FPS, fps)

    def read(self):
        ok, frame = self.cap.read()
        if not ok or frame is None:
            return None
        return cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

    def close(self):
        self.cap.release()


class SyntheticSource:
    def __init__(self, width=64, height=48, seed=2026):
        self.width = width
        self.height = height
        self.rng = np.random.default_rng(seed)
        yy, xx = np.mgrid[0:height, 0:width]
        self.base = 90 + 50 * (xx / max(width, 1))
        self.frame_number = 0

    def read(self):
        self.frame_number += 1
        drift = 20 * math.sin(self.frame_number / 25.0)
        lam = np.clip(self.base + drift, 1, 250)
        return np.clip(self.rng.poisson(lam), 0, 255).astype(np.uint8)

    def close(self):
        pass


def camera_reveal_mask(frame, bits, reveal_probability, cycle):
    """Camera pixel intensity controls which bit positions are observed."""
    flat = frame.reshape(-1)
    threshold = int(reveal_probability * 100)
    mask = 0
    for i in range(bits):
        pixel = int(flat[(i * 997 + cycle * 31) % flat.size])
        if pixel % 100 < threshold:
            mask |= 1 << i
    return mask


# ---------------------------------------------------------------------------
# Qiskit candidate circuit
# ---------------------------------------------------------------------------

def build_candidate_circuit(bits, known_mask, known_values):
    """
    Prepare |known bits> tensor |+> for unknown positions.

    Qiskit classical bitstring display is reversed relative to qubit indices;
    int(bitstring, 2) still reconstructs the integer represented by the
    measured register when qubit i is mapped to classical bit i.
    """
    qc = QuantumCircuit(bits, bits)
    for i in range(bits):
        if (known_mask >> i) & 1:
            if (known_values >> i) & 1:
                qc.x(i)
        else:
            qc.h(i)
    qc.measure(range(bits), range(bits))
    return qc


class CandidateQuantumBackend:
    def __init__(self, mode, bits, shots, port="COM7", seed=2026):
        if QuantumCircuit is None:
            raise RuntimeError("Install qiskit: pip install qiskit")
        self.mode = mode
        self.bits = bits
        self.shots = shots
        self.seed = seed
        self.aer = None
        self.optical_computer = None
        self.optical_camera = None
        self.ito = None

        if mode in ("aer", "both"):
            if AerSimulator is None:
                raise RuntimeError(
                    "Aer backend requested but qiskit-aer is missing. "
                    "Install with: pip install qiskit-aer"
                )
            self.aer = AerSimulator()

        if mode in ("optical", "both"):
            self._init_optical(port)

    def _init_optical(self, port):
        try:
            from quantum_optical_bench import (
                GeneralQuantumComputer,
                OpticalBackend,
                OpticalBench,
                OpticalCamera,
                ITOController,
            )
        except ImportError as exc:
            raise RuntimeError(
                "Optical backend requires your existing quantum_optical_bench.py"
            ) from exc

        # This is the same constructor pattern used by your existing optical
        # Qiskit application. The optical bench uses its own camera object;
        # the observation camera remains independently selectable.
        self.optical_camera = OpticalCamera(width=256, height=256)
        self.ito = ITOController(port=port)
        bench = OpticalBench(camera=self.optical_camera, rows=16, cols=16)
        optical_backend = OpticalBackend(
            bench=bench,
            ito=self.ito,
            num_qubits=self.bits,
            spatial_rows=16,
            spatial_cols=16,
            temporal_bins=2,
        )
        self.optical_computer = GeneralQuantumComputer(
            num_qubits=self.bits,
            optical_backend=optical_backend,
        )

    def sample(self, known_mask, known_values):
        qc = build_candidate_circuit(self.bits, known_mask, known_values)
        combined = Counter()

        if self.mode in ("aer", "both"):
            compiled = transpile(qc, self.aer, seed_transpiler=self.seed)
            result = self.aer.run(
                compiled,
                shots=self.shots,
                seed_simulator=self.seed,
            ).result()
            combined.update(result.get_counts())

        if self.mode in ("optical", "both"):
            result = self.optical_computer.run_optical(qc, shots=self.shots)
            combined.update(result.counts)

        return combined

    def close(self):
        for obj in (self.optical_camera, self.ito):
            if obj is not None:
                try:
                    obj.close()
                except Exception:
                    pass


# ---------------------------------------------------------------------------
# Commit-only recogniser
# ---------------------------------------------------------------------------

class CommitOnlyRecogniser:
    def __init__(self, bits, salt, commitment, backend, max_candidates=200_000):
        self.bits = bits
        self.byte_length = bits // 8
        self.salt = salt
        self.commitment = commitment
        self.backend = backend
        self.max_candidates = max_candidates

        self.ones = [0] * bits
        self.zeros = [0] * bits
        self.seen_mask = 0
        self.known_mask = 0
        self.known_values = 0
        self.cycles = 0
        self.candidates_tested = 0
        self.recovered = None
        self.proof = None

    def _digest(self, candidate):
        return hashlib.sha256(
            self.salt + candidate.to_bytes(self.byte_length, "big")
        ).digest()

    def observe(self, reveal_mask, observed_values):
        self.cycles += 1
        for i in range(self.bits):
            if (reveal_mask >> i) & 1:
                self.seen_mask |= 1 << i
                if (observed_values >> i) & 1:
                    self.ones[i] += 1
                else:
                    self.zeros[i] += 1

        # Use majority vote over repeated noisy observations. A bit becomes
        # fixed as soon as it has been observed; subsequent observations can
        # reverse the majority estimate.
        self.known_mask = self.seen_mask
        values = 0
        for i in range(self.bits):
            if self.ones[i] >= self.zeros[i]:
                values |= 1 << i
        self.known_values = values & self.known_mask

    def search(self):
        if self.recovered is not None:
            return
        counts = self.backend.sample(self.known_mask, self.known_values)
        ranked = sorted(counts.items(), key=lambda item: item[1], reverse=True)

        for bitstring, frequency in ranked:
            try:
                candidate = int(bitstring.replace(" ", ""), 2)
            except ValueError:
                continue

            candidate &= (1 << self.bits) - 1
            if self.candidates_tested >= self.max_candidates:
                return
            self.candidates_tested += 1

            # Reject any candidate inconsistent with the current majority
            # observation before spending a SHA-256 comparison.
            if ((candidate ^ self.known_values) & self.known_mask) != 0:
                continue

            digest = self._digest(candidate)
            if digest == self.commitment:
                self.recovered = candidate
                self.proof = {
                    "number": candidate,
                    "binary": format(candidate, f"0{self.bits}b"),
                    "cycles": self.cycles,
                    "candidates_tested": self.candidates_tested,
                    "known_bits": self.known_mask.bit_count(),
                    "unknown_bits": self.bits - self.known_mask.bit_count(),
                    "commitment": self.commitment.hex(),
                    "candidate_digest": digest.hex(),
                    "hash_match": True,
                    "independent_recheck": self._digest(candidate) == self.commitment,
                }
                return

    @property
    def unknown_count(self):
        return self.bits - self.known_mask.bit_count()


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def run(args):
    if args.backend in ("optical", "both") and args.bits > args.max_optical_qubits:
        raise ValueError(
            f"Optical mode is configured for at most {args.max_optical_qubits} "
            "qubits. Increase --max-optical-qubits only if your bench supports it."
        )

    if args.camera is None:
        source = SyntheticSource(seed=args.seed)
        source_name = "synthetic Poisson sensor"
    else:
        try:
            source = CameraSource(args.camera, args.width, args.height, args.fps)
            source_name = f"camera {args.camera}"
        except Exception as exc:
            print(f"[camera] {exc}; falling back to synthetic sensor", file=sys.stderr)
            source = SyntheticSource(seed=args.seed)
            source_name = "synthetic Poisson sensor"

    oracle = HiddenNumberOracle(args.bits, args.reveal, args.noise)
    public = oracle.public_parameters()

    print(f"[observation source] {source_name}")
    print(f"[backend] {args.backend}")
    print(f"[bits] {args.bits}")
    print(f"[salt] {public['salt'].hex()}")
    print(f"[commitment] {public['commitment'].hex()}")
    print("[recogniser] receives no hidden-number value")

    quantum_backend = None
    recogniser = None

    try:
        quantum_backend = CandidateQuantumBackend(
            args.backend, args.bits, args.shots, args.port, args.seed
        )
        recogniser = CommitOnlyRecogniser(
            args.bits,
            public["salt"],
            public["commitment"],
            quantum_backend,
            args.max_candidates,
        )

        for cycle in range(1, args.cycles + 1):
            frame = source.read()
            if frame is None:
                print("[camera] frame stream ended")
                break

            reveal_mask = camera_reveal_mask(
                frame, args.bits, args.reveal, cycle
            )
            observed_mask, observed_values = oracle.observe_mask(reveal_mask)
            recogniser.observe(observed_mask, observed_values)

            recogniser.search()

            if args.verbose:
                print(
                    f"[cycle {cycle:4d}] "
                    f"known={args.bits - recogniser.unknown_count:2d}/{args.bits} "
                    f"unknown={recogniser.unknown_count:2d} "
                    f"tested={recogniser.candidates_tested:8d} "
                    f"recovered={'yes' if recogniser.recovered is not None else 'no'}"
                )

            if args.preview and cv2 is not None:
                view = cv2.resize(
                    frame, (args.width * 2, args.height * 2),
                    interpolation=cv2.INTER_NEAREST,
                )
                cv2.putText(
                    view,
                    f"cycle {cycle} unknown {recogniser.unknown_count}",
                    (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.7, 255, 2,
                )
                cv2.imshow("Qiskit commit-only recogniser", view)
                if cv2.waitKey(1) & 0xFF == ord("q"):
                    break

            if recogniser.recovered is not None:
                break

    finally:
        source.close()
        if quantum_backend is not None:
            quantum_backend.close()
        if args.preview and cv2 is not None:
            try:
                cv2.destroyAllWindows()
            except cv2.error:
                pass

    print("\n========== RECOGNISER RESULT ==========")
    if recogniser is not None and recogniser.proof:
        p = recogniser.proof
        print(f"Recovered number       : {p['number']}")
        print(f"Recovered binary       : {p['binary']}")
        print(f"Cycles                 : {p['cycles']}")
        print(f"Candidates tested      : {p['candidates_tested']}")
        print(f"Known bits             : {p['known_bits']}")
        print(f"Unknown bits           : {p['unknown_bits']}")
        print(f"Commitment             : {p['commitment']}")
        print(f"Candidate digest       : {p['candidate_digest']}")
        print(f"Hash match             : {p['hash_match']}")
        print(f"Independent recheck    : {p['independent_recheck']}")
        print("PROOF: candidate digest equals the public commitment.")
    else:
        print("NOT RECOVERED")
        if recogniser is not None:
            print(f"Cycles                 : {recogniser.cycles}")
            print(f"Candidates tested      : {recogniser.candidates_tested}")
            print(f"Unknown positions      : {recogniser.unknown_count}")
        print("No measured candidate matched the commitment.")

    print("\n========== INDEPENDENT ORACLE CHECK ==========")
    if recogniser is not None and recogniser.recovered is not None:
        revealed = oracle.reveal_if_proven(recogniser.recovered)
        if revealed:
            print(f"Oracle number          : {revealed['number']}")
            print(f"Oracle binary          : {revealed['binary']}")
            print(f"Oracle proof           : {revealed['proof']}")
            print(
                "MATCH: recovered candidate equals oracle secret."
                if revealed["number"] == recogniser.recovered
                else "MISMATCH"
            )
        else:
            print("Oracle refused candidate.")
    else:
        print("Oracle did not reveal the secret.")


def main():
    parser = argparse.ArgumentParser(
        description="Commit-only hidden-number recovery using Qiskit/Aer/optical backends"
    )
    parser.add_argument("--backend", choices=("aer", "optical", "both"), default="aer")
    parser.add_argument("--bits", type=int, default=16)
    parser.add_argument("--cycles", type=int, default=80)
    parser.add_argument("--reveal", type=float, default=0.45)
    parser.add_argument("--noise", type=float, default=0.03)
    parser.add_argument("--shots", type=int, default=4096)
    parser.add_argument("--max-candidates", type=int, default=200_000)
    parser.add_argument("--camera", type=int, default=None)
    parser.add_argument("--width", type=int, default=640)
    parser.add_argument("--height", type=int, default=480)
    parser.add_argument("--fps", type=float, default=30)
    parser.add_argument("--port", default="COM7")
    parser.add_argument("--max-optical-qubits", type=int, default=16)
    parser.add_argument("--seed", type=int, default=2026)
    parser.add_argument("--preview", action="store_true")
    parser.add_argument("--verbose", action="store_true")
    args = parser.parse_args()

    if args.bits < 8 or args.bits % 8:
        parser.error("--bits must be a multiple of 8 and at least 8")
    if args.cycles < 1 or args.shots < 1:
        parser.error("--cycles and --shots must be positive")
    if not 0 < args.reveal <= 1:
        parser.error("--reveal must be in (0, 1]")
    if not 0 <= args.noise < 1:
        parser.error("--noise must be in [0, 1)")
    if args.max_candidates < 1:
        parser.error("--max-candidates must be positive")

    run(args)


if __name__ == "__main__":
    main()
