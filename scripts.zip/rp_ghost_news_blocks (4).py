#!/usr/bin/env python3
"""
RP-GHOST WEBCAM & PHASE-CORRELATION PIPELINE + BITCOIN BLOCK DATA CHANNEL
-------------------------------------------------------------------------
Watches the Bitcoin chain tip (mempool.space, no key needed). Each new block's
data (hash, height, timestamp, nonce, version, bits, size, weight, tx count,
merkle root, previous hash) is framed as [8-bit index | 24-bit data | 8-bit
CRC-8] or [32-bit value | CRC-8] (40 slots), sent through the simulated
optoelectronic phase channel, decoded, CRC-checked, retried on failure, and
printed. Falls back to a clearly-labelled simulated chain if the API is down.
"""

import hashlib
import json
import math
import os
import queue
import struct
import threading
import time
import urllib.request
from collections import deque
from datetime import datetime, timedelta, timezone

import numpy as np

try:
    import cv2
    HAS_OPENCV = True
except ImportError:
    HAS_OPENCV = False

try:
    import websocket
    HAS_WS = True
except ImportError:
    HAS_WS = False

# ============================================================================
# CONFIGURATION & CONSTANTS
# ============================================================================

LAMBDA_BASE = 10000.0
SIGMA_C = 0.005
N_SLOTS = 40
WEBCAM_INDEX = 0
WEBCAM_WIDTH = 640
WEBCAM_HEIGHT = 480
WEBCAM_FPS = 30

CHUNK_BYTES = 3                # data bytes per 40-bit frame
LARGE_DECODE_WINDOWS = 20000  # windows averaged per block-data frame
LARGE_DECODE_RETRIES = 8      # CRC re-sends per frame
BLOCK_API = "https://mempool.space/api"   # public Bitcoin block explorer API (no key needed)
BLOCK_POLL_SECONDS = 10       # how often to check for a new chain tip
TIP_REPRINT_CYCLES = 0        # full tip report: 0 = once per tip, N = reprint every N cycles
BLOCK_SIM_INTERVAL = 15       # simulated block interval if the API is unreachable

# ============================================================================
# HELPERS & CRC-8
# ============================================================================

def compute_crc8(data_bytes):
    crc = 0x00
    for byte in data_bytes:
        crc ^= byte
        for _ in range(8):
            crc = ((crc << 1) ^ 0x07) & 0xFF if crc & 0x80 else (crc << 1) & 0xFF
    return crc


def format_clock_time(timestamp_ns):
    seconds = timestamp_ns / 1e9
    clock = time.strftime("%H:%M:%S", time.localtime(seconds))
    ms = int((timestamp_ns % 1_000_000_000) // 1_000_000)
    return f"{clock}.{ms:03d}"


def timestamp_to_code(timestamp_ns):
    return ((int(timestamp_ns) // 1_000_000) % 60000) & 0xFFFF


def price_delta_to_code(price_delta):
    cents = max(-32768, min(32767, int(round(float(price_delta) * 100.0))))
    return cents & 0xFFFF


def code_to_signed_price_delta(code):
    value = int(code) & 0xFFFF
    if value >= 0x8000:
        value -= 0x10000
    return value / 100.0


def bits_to_code(bits):
    code = 0
    for bit in bits:
        code = (code << 1) | (int(bit) & 1)
    return code


def int_to_bits(value, width):
    return [(value >> (width - 1 - k)) & 1 for k in range(width)]


def encode_payload_bits(timestamp_ns, price_delta, frame_entropy_hash=0):
    time_code = timestamp_to_code(timestamp_ns) ^ (frame_entropy_hash & 0xFFFF)
    delta_code = price_delta_to_code(price_delta)
    payload = bytearray([(time_code >> 8) & 0xFF, time_code & 0xFF,
                         (delta_code >> 8) & 0xFF, delta_code & 0xFF])
    crc_val = compute_crc8(payload)
    return np.array(int_to_bits(time_code, 16) + int_to_bits(delta_code, 16)
                    + int_to_bits(crc_val, 8), dtype=int)


def decode_payload_bits(bits):
    bits = np.asarray(bits, dtype=int).flatten()
    if len(bits) != N_SLOTS:
        raise ValueError("Invalid payload length")
    timestamp_code = bits_to_code(bits[:16])
    delta_code = bits_to_code(bits[16:32])
    received_crc = bits_to_code(bits[32:])
    payload = bytearray([(timestamp_code >> 8) & 0xFF, timestamp_code & 0xFF,
                         (delta_code >> 8) & 0xFF, delta_code & 0xFF])
    return (timestamp_code, code_to_signed_price_delta(delta_code),
            received_crc == compute_crc8(payload))


def make_payload_tilt(bits, eps_abs):
    bits = np.asarray(bits, dtype=float)
    strength = max(float(eps_abs), 0.25)
    return 2.0 * strength * (bits - 0.5)


# ============================================================================
# TEXT FRAMING (byte chunks)
# ============================================================================

def encode_text_frame(index, chunk):
    """40 bits: 8-bit index | 24-bit data (3 bytes) | 8-bit CRC-8 over index+data."""
    chunk = bytes(chunk).ljust(CHUNK_BYTES, b"\x00")[:CHUNK_BYTES]
    body = bytes([index & 0xFF]) + chunk
    crc = compute_crc8(body)
    return np.array(int_to_bits(body[0], 8)
                    + [b for byte in chunk for b in int_to_bits(byte, 8)]
                    + int_to_bits(crc, 8), dtype=int)


def decode_text_frame(bits):
    bits = np.asarray(bits, dtype=int).flatten()
    index = bits_to_code(bits[:8])
    chunk = bytes(bits_to_code(bits[8 + 8 * i: 16 + 8 * i]) for i in range(CHUNK_BYTES))
    received_crc = bits_to_code(bits[32:40])
    ok = received_crc == compute_crc8(bytes([index]) + chunk)
    return index, chunk, ok


def format_age(age_sec):
    s = max(0, int(age_sec))
    d, rem = divmod(s, 86400)
    h, rem = divmod(rem, 3600)
    m, sec = divmod(rem, 60)
    if d:
        return f"{d}d {h}h"
    if h:
        return f"{h}h {m}m"
    if m:
        return f"{m}m {sec}s"
    return f"{sec}s"


# ============================================================================
# WEBCAM THREAD
# ============================================================================

class WebcamEntropySource(threading.Thread):
    def __init__(self, camera_index=WEBCAM_INDEX):
        super().__init__(daemon=True)
        self.camera_index = camera_index
        self.frame_queue = queue.Queue(maxsize=2)
        self.running = True
        self.latest_hash = 0
        self.frame_count = 0

    def run(self):
        if not HAS_OPENCV:
            print("[WEBCAM] OpenCV not available. Running in headless pseudo-entropy mode.")
            while self.running:
                time.sleep(1.0 / WEBCAM_FPS)
                dummy = np.random.randint(0, 255, (WEBCAM_HEIGHT, WEBCAM_WIDTH, 3), dtype=np.uint8)
                self.latest_hash = int(hashlib.sha256(dummy.tobytes()).hexdigest()[:4], 16)
                self.frame_count += 1
            return

        cap = cv2.VideoCapture(self.camera_index)
        cap.set(cv2.CAP_PROP_FRAME_WIDTH, WEBCAM_WIDTH)
        cap.set(cv2.CAP_PROP_FRAME_HEIGHT, WEBCAM_HEIGHT)
        cap.set(cv2.CAP_PROP_FPS, WEBCAM_FPS)
        if not cap.isOpened():
            print(f"[WEBCAM] Error: Could not open camera index {self.camera_index}")
            self.running = False
            return
        print(f"[WEBCAM] Opened camera #{self.camera_index} @ {WEBCAM_WIDTH}x{WEBCAM_HEIGHT}")

        while self.running:
            ret, frame = cap.read()
            if not ret:
                time.sleep(0.01)
                continue
            gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
            self.latest_hash = int.from_bytes(hashlib.sha256(gray.tobytes()).digest()[:2], "big")
            self.frame_count += 1
            try:
                self.frame_queue.put_nowait((gray, self.latest_hash))
            except queue.Full:
                try:
                    self.frame_queue.get_nowait()
                except queue.Empty:
                    pass
                self.frame_queue.put_nowait((gray, self.latest_hash))

        cap.release()
        print("[WEBCAM] Released camera stream.")

    def stop(self):
        self.running = False


# ============================================================================
# OPTICAL VIEWPORT
# ============================================================================

class OptoelectronicViewport:
    def __init__(self, lambd=LAMBDA_BASE, sigma_c=SIGMA_C):
        self.lambd = lambd
        self.sigma_c = sigma_c
        print("[OPTICAL] Phase-coherent optical viewport initialized")

    def generate_window_block(self, n_windows, n_slots, tilt=None):
        shared_noise = np.random.normal(0.0, self.sigma_c, size=(n_windows, 1))
        lam = self.lambd * (1.0 + shared_noise)
        counts = np.random.poisson(np.clip(lam, 1.0, None), size=(n_windows, n_slots))
        Z = (counts - self.lambd) / np.sqrt(self.lambd)
        if tilt is not None:
            Z += tilt
        return Z


# ============================================================================
# BINANCE PRICE FETCHER
# ============================================================================

class AsyncPriceFetcher(threading.Thread):
    def __init__(self):
        super().__init__(daemon=True)
        self.url = "wss://stream.binance.com:443/ws/btcusdt@bookTicker"
        self.ticks = queue.Queue(maxsize=1)
        self.running = True
        self.ws = None
        self.received = 0

    def _on_message(self, ws, message):
        try:
            data = json.loads(message)
            if data.get("s") != "BTCUSDT":
                return
            bid, ask = float(data.get("b", 0)), float(data.get("a", 0))
            if bid <= 0 or ask <= 0:
                return
            tick = {"price": (bid + ask) / 2.0, "received_ns": time.time_ns()}
            try:
                self.ticks.put_nowait(tick)
            except queue.Full:
                try:
                    self.ticks.get_nowait()
                except queue.Empty:
                    pass
                self.ticks.put_nowait(tick)
            self.received += 1
        except Exception:
            pass

    def run(self):
        if not HAS_WS:
            print("[FETCH] websocket-client missing. Running with synthetic price simulator.")
            p = 90000.0
            while self.running:
                time.sleep(1.0)
                p += np.random.normal(0, 10)
                try:
                    self.ticks.put_nowait({"price": p, "received_ns": time.time_ns()})
                except queue.Full:
                    pass
            return
        while self.running:
            try:
                self.ws = websocket.WebSocketApp(
                    self.url,
                    on_message=lambda ws, m: self._on_message(ws, m),
                    on_error=lambda ws, e: None,
                    on_close=lambda ws, c, m: None)
                self.ws.run_forever(ping_interval=20, ping_timeout=10)
            except Exception:
                pass
            if self.running:
                time.sleep(3)

    def stop(self):
        self.running = False
        if self.ws:
            self.ws.close()


# ============================================================================
# BLOCKCHAIN: NEXT-BLOCK HASH CHANNEL
# ============================================================================
# The next block hash cannot be known in advance (it is the output of proof of
# work), so the script watches the chain tip and, the moment a new block
# arrives, sends its hash / height / timestamp through the phase channel and
# decodes them back with CRC-8 checking.

def leading_zero_bits(hash_hex):
    n = 0
    for byte in bytes.fromhex(hash_hex):
        if byte == 0:
            n += 8
        else:
            return n + 8 - byte.bit_length()
    return n


def transmit_block_hash(viewport, hash_hex, windows=LARGE_DECODE_WINDOWS, max_retries=LARGE_DECODE_RETRIES):
    """32-byte hash -> 11 frames of [idx|3 bytes|CRC-8]. Returns (decoded_hex, retries, failed, margin)."""
    return transmit_bytes_hex(viewport, hash_hex, windows, max_retries)


def transmit_bytes_hex(viewport, hex_str, windows=LARGE_DECODE_WINDOWS, max_retries=LARGE_DECODE_RETRIES):
    """Any hex string (hash, merkle root, prev hash) -> frames of [idx|3 bytes|CRC-8]."""
    raw = bytes.fromhex(hex_str)
    chunks = [raw[i:i + CHUNK_BYTES] for i in range(0, len(raw), CHUNK_BYTES)]
    sigma_z = math.sqrt(1.0 + SIGMA_C ** 2 * LAMBDA_BASE)
    scale = sigma_z / math.sqrt(windows)
    received = bytearray()
    retries = failed = 0
    min_margin = float("inf")
    for i, chunk in enumerate(chunks):
        bits = encode_text_frame(i, chunk)
        tilt = make_payload_tilt(bits, 0.02 * sigma_z)
        good = None
        for _ in range(max_retries):
            Z = viewport.generate_window_block(windows, N_SLOTS, tilt=tilt)
            m = Z.mean(axis=0)
            idx, data, ok = decode_text_frame((m > 0).astype(int))
            if ok and idx == (i & 0xFF):
                good = data
                min_margin = min(min_margin, float(np.min(np.abs(m)) / scale))
                break
            retries += 1
        if good is None:
            failed += 1
            good = b"\xff" * CHUNK_BYTES
        received += good
    decoded = bytes(received)[:len(raw)].hex()
    return decoded, retries, failed, (0.0 if min_margin == float("inf") else min_margin)


def bits_to_target(bits):
    """Compact 'bits' (nBits) -> 256-bit target integer."""
    exp, mant = (bits >> 24) & 0xFF, bits & 0x007FFFFF
    return mant * (1 << (8 * (exp - 3))) if exp > 3 else mant >> (8 * (3 - exp))


def target_to_difficulty(target):
    return 0x00000000FFFF0000000000000000000000000000000000000000000000000000 / target if target else 0.0


def transmit_u32(viewport, value, windows=LARGE_DECODE_WINDOWS, max_retries=LARGE_DECODE_RETRIES):
    """40-bit frame: 32-bit unsigned value | CRC-8. Returns (decoded_value or None, retries, ok, margin)."""
    value &= 0xFFFFFFFF
    bits = np.array(int_to_bits(value, 32) + int_to_bits(compute_crc8(value.to_bytes(4, "big")), 8), dtype=int)
    sigma_z = math.sqrt(1.0 + SIGMA_C ** 2 * LAMBDA_BASE)
    tilt = make_payload_tilt(bits, 0.02 * sigma_z)
    scale = sigma_z / math.sqrt(windows)
    retries = 0
    for _ in range(max_retries):
        Z = viewport.generate_window_block(windows, N_SLOTS, tilt=tilt)
        m = Z.mean(axis=0)
        dbits = (m > 0).astype(int)
        got = bits_to_code(dbits[:32])
        if bits_to_code(dbits[32:40]) == compute_crc8(got.to_bytes(4, "big")):
            return got, retries, True, float(np.min(np.abs(m)) / scale)
        retries += 1
    return None, retries, False, 0.0


def decode_block(viewport, blk):
    """Send every block field through the phase channel; return decoded values + channel stats."""
    d = {"fields": {}}
    h, h_ret, h_fail, h_m = transmit_block_hash(viewport, blk["hash"])
    d["hash"], d["fields"]["hash"] = h, (h_fail == 0, h_ret, h_m, 11)
    for key in ("height", "timestamp", "nonce", "version", "bits", "size", "weight", "tx_count"):
        val, ret, ok, m = transmit_u32(viewport, int(blk.get(key) or 0))
        d[key] = val
        d["fields"][key] = (ok, ret, m, 1)
    for key in ("merkle_root", "prev_hash"):
        v, ret, fail, m = transmit_bytes_hex(viewport, blk[key])
        d[key] = v
        d["fields"][key] = (fail == 0, ret, m, 11)
    return d


def build_header(d):
    """Rebuild the 80-byte block header from the decoded fields (all little-endian on the wire)."""
    return (struct.pack("<I", d["version"] & 0xFFFFFFFF) + bytes.fromhex(d["prev_hash"])[::-1]
            + bytes.fromhex(d["merkle_root"])[::-1]
            + struct.pack("<III", d["timestamp"], d["bits"], d["nonce"]))


def print_block_report(blk, d, title="NEW BLOCK DETECTED"):
    """Print everything known about a block, computed from the DECODED values."""
    f = d["fields"]
    tag = " (SIMULATED)" if blk["simulated"] else ""
    ok_all = all(v[0] for v in f.values())
    if not ok_all:
        bad = [k for k, v in f.items() if not v[0]]
        print(f" [BLOCK] {title}{tag} - CRC FAILED on: {', '.join(bad)} (report skipped)")
        return
    hdr = build_header(d)
    rehash = hashlib.sha256(hashlib.sha256(hdr).digest()).digest()[::-1].hex()
    tgt = bits_to_target(d["bits"])
    hval = int(d["hash"], 16)
    diff = target_to_difficulty(tgt)
    height = d["height"]
    sub_sats = (50 * 100_000_000) >> (height // 210_000)
    next_halving = ((height // 210_000) + 1) * 210_000
    retarget_pos = height % 2016
    utc = datetime.fromtimestamp(d["timestamp"], timezone.utc)
    vsize = d["weight"] / 4.0
    ver = d["version"]
    checks = {k: (d[k] == (blk[k] if k != "tx_count" else int(blk[k] or 0)))
              for k in ("hash", "height", "timestamp", "nonce", "version", "bits",
                        "size", "weight", "tx_count", "merkle_root", "prev_hash")}
    frames = sum(v[3] for v in f.values())
    retries = sum(v[1] for v in f.values())
    margin = min(v[2] for v in f.values())

    print(f" [BLOCK] {title}{tag}  -  ALL FIELDS DECODED")
    print("   --- Identity ---")
    print(f"   Height:        {height:,}")
    print(f"   Hash:          {d['hash']}")
    print(f"   Hash (bytes):  {bytes.fromhex(d['hash'])[::-1].hex()}  (internal little-endian order)")
    print("   --- Header (80 bytes, rebuilt from decoded fields) ---")
    print(f"   Version:       0x{ver:08X}  ({ver:032b})"
          f"{'  [BIP9 version-bits signalling]' if (ver >> 29) == 0b001 else ''}")
    print(f"   Prev hash:     {d['prev_hash']}")
    print(f"   Merkle root:   {d['merkle_root']}")
    print(f"   Timestamp:     {d['timestamp']} = {utc:%Y-%m-%d %H:%M:%S} UTC | "
          f"{time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(d['timestamp']))} local "
          f"({format_age(time.time() - d['timestamp'])} ago)")
    print(f"   Bits:          0x{d['bits']:08X}")
    print(f"   Nonce:         {d['nonce']:,} (0x{d['nonce']:08X})")
    print(f"   Header hex:    {hdr.hex()}")
    print(f"   Header check:  double-SHA256(header) = {rehash}")
    print(f"                  {'MATCHES decoded hash - header is self-consistent' if rehash == d['hash'] else 'DOES NOT MATCH decoded hash' + (' (expected for simulated blocks)' if blk['simulated'] else '')}")
    print("   --- Proof of work ---")
    print(f"   Leading zeros: {leading_zero_bits(d['hash'])} bits ({len(d['hash']) - len(d['hash'].lstrip('0'))} hex digits)")
    print(f"   Target:        {tgt:064x}")
    print(f"   Difficulty:    {diff:,.2f}")
    print(f"   Hash <= target: {'YES' if hval <= tgt else 'NO'}"
          f"{f' | hash is {tgt / hval:,.2f}x below target' if hval and hval <= tgt else ''}")
    print(f"   Expected work: ~{diff * 2**32:.3e} hashes per block at this difficulty")
    print("   --- Size & transactions ---")
    print(f"   Size:          {d['size']:,} bytes ({d['size'] / 1e6:.3f} MB)")
    print(f"   Weight:        {d['weight']:,} WU ({d['weight'] / 4_000_000:.1%} of 4,000,000 limit) | vsize {vsize:,.0f} vB")
    print(f"   Tx count:      {d['tx_count']:,}" + (f" | avg {d['size'] / d['tx_count']:,.0f} bytes/tx" if d["tx_count"] else ""))
    print("   --- Chain position ---")
    print(f"   Subsidy:       {sub_sats / 1e8:.8f} BTC (halving epoch {height // 210_000})")
    print(f"   Next halving:  block {next_halving:,} (in {next_halving - height:,} blocks, ~{(next_halving - height) / 144:,.0f} days)")
    print(f"   Retarget:      block {retarget_pos}/2016 of difficulty period; "
          f"{2016 - retarget_pos:,} blocks to next adjustment")
    print("   --- Channel integrity ---")
    for k, v in f.items():
        print(f"   {k:<12}  CRC PASS | {v[3]:>2} frame(s) | retries {v[1]} | margin {v[2]:.1f} sigma"
              f" | {'matches chain data' if checks[k] else 'MISMATCH vs chain data'}")
    print(f"   Summary:       {sum(checks.values())}/{len(checks)} fields match chain data | "
          f"{frames} frames | {retries} CRC retries | min margin {margin:.1f} sigma")


class BlockFetcher(threading.Thread):
    """Watches the Bitcoin chain tip (mempool.space REST). Queues each NEW block.
    If the API is unreachable at startup it switches to a clearly-labelled simulation."""

    def __init__(self, base=BLOCK_API, poll_seconds=BLOCK_POLL_SECONDS):
        super().__init__(daemon=True)
        self.base = base
        self.poll_seconds = poll_seconds
        self.tip = None
        self.new_blocks = deque()
        self.lock = threading.Lock()
        self.simulated = False
        self.running = True

    def _get(self, path):
        req = urllib.request.Request(self.base + path, headers={"User-Agent": "rp-ghost/1.0"})
        with urllib.request.urlopen(req, timeout=10) as resp:
            return resp.read().decode("utf-8")

    def _poll(self):
        h = self._get("/blocks/tip/hash").strip()
        if len(h) != 64:
            raise RuntimeError("unexpected tip hash")
        with self.lock:
            if self.tip is not None and self.tip["hash"] == h:
                return
        data = json.loads(self._get(f"/block/{h}"))
        blk = {"hash": h, "height": 976118, "timestamp": int(data["timestamp"]),
               "nonce": int(data.get("nonce", 0)),
               "tx_count": data.get("tx_count"), "simulated": False,
               "version": int(data.get("version", 0)),
               "bits": int(data.get("bits", 0)),
               "size": int(data.get("size", 0)),
               "weight": int(data.get("weight", 0)),
               "difficulty": float(data.get("difficulty", 0.0)),
               "merkle_root": data.get("merkle_root") or "0" * 64,
               "prev_hash": data.get("previousblockhash") or "0" * 64}
        with self.lock:
            first = self.tip is None
            self.tip = blk
            if not first:
                self.new_blocks.append(blk)

    def _simulate(self):
        print("[BLOCK] Block API unreachable - running SIMULATED chain (not real blocks).")
        self.simulated = True
        height = 900000
        while self.running:
            digest = hashlib.sha256(hashlib.sha256(os.urandom(80)).digest()).hexdigest()
            blk = {"hash": ("0" * 18 + digest)[:64], "height": height, "timestamp": int(time.time()),
                   "nonce": int(np.random.randint(0, 2**32, dtype=np.uint64)),
                   "tx_count": int(np.random.randint(1500, 4000)), "simulated": True,
                   "version": 0x20000000, "bits": 0x17023CC1,
                   "size": int(np.random.randint(1_000_000, 1_800_000)),
                   "weight": int(np.random.randint(3_500_000, 4_000_000)),
                   "difficulty": 125807076547197.55,
                   "merkle_root": hashlib.sha256(os.urandom(32)).hexdigest(),
                   "prev_hash": (self.tip["hash"] if self.tip else "0" * 64)}
            with self.lock:
                first = self.tip is None
                self.tip = blk
                if not first:
                    self.new_blocks.append(blk)
            height += 1
            for _ in range(BLOCK_SIM_INTERVAL):
                if not self.running:
                    return
                time.sleep(1)

    def run(self):
        fails = 0
        while self.running:
            try:
                self._poll()
                fails = 0
            except Exception as e:
                fails += 1
                if fails == 1:
                    print(f"[BLOCK] Poll failed: {e}")
                if self.tip is None and fails >= 3:
                    self._simulate()
                    return
                time.sleep(1 if self.tip is None else self.poll_seconds)
                continue
            for _ in range(self.poll_seconds):
                if not self.running:
                    break
                time.sleep(1)

    def pop_new(self):
        with self.lock:
            return self.new_blocks.popleft() if self.new_blocks else None

    def get_tip(self):
        with self.lock:
            return self.tip

    def stop(self):
        self.running = False


# ============================================================================
# ORCHESTRATOR
# ============================================================================

def main():
    print("=" * 78)
    print(" RP-GHOST PIPELINE (CRC-8) + BITCOIN BLOCK DATA DECODER")
    print("=" * 78)

    webcam = WebcamEntropySource(WEBCAM_INDEX)
    webcam.start()
    fetcher = AsyncPriceFetcher()
    fetcher.start()
    blocks = BlockFetcher()
    blocks.start()
    viewport = OptoelectronicViewport()

    print("[START] Pipeline running. Press Ctrl+C to exit.\n")

    cycle = 0
    price_history = deque(maxlen=20)
    announced_tip = None
    tip_cache = {"hash": None, "decoded": None, "reports": 0}

    try:
        while True:
            cycle += 1
            start_ns = time.time_ns()
            current_time_str = format_clock_time(start_ns)

            try:
                tick = fetcher.ticks.get(timeout=5.0)
                price = tick["price"]
            except queue.Empty:
                price = 90000.0 + cycle * 5.0

            price_history.append(price)
            avg_price = sum(price_history) / len(price_history)
            price_delta = price - avg_price
            frame_hash = webcam.latest_hash

            scheduled_ns = start_ns + 1_000_000_000
            bits = encode_payload_bits(scheduled_ns, price_delta, frame_hash)

            sigma_z = math.sqrt(1.0 + SIGMA_C ** 2 * LAMBDA_BASE)
            tilt = make_payload_tilt(bits, 0.02 * sigma_z)
            Z = viewport.generate_window_block(2000, N_SLOTS, tilt=tilt)

            decoded_bits = (Z.mean(axis=0) > 0).astype(int)
            decoded_code, decoded_delta, crc_valid = decode_payload_bits(decoded_bits)

            minute_start = (int(start_ns) // 60_000_000_000) * 60_000_000_000
            decoded_ns = minute_start + (int(decoded_code) & 0xFFFF) * 1_000_000
            if decoded_ns - start_ns < -30_000_000_000:
                decoded_ns += 60_000_000_000
            elif decoded_ns - start_ns > 30_000_000_000:
                decoded_ns -= 60_000_000_000

            decoded_time = format_clock_time(decoded_ns)
            time_diff_sec = (decoded_ns - start_ns) / 1e9
            exact_bits = int(np.sum(decoded_bits == bits))

            print("-" * 78)
            print(f" [CYCLE #{cycle}] Webcam Entropy Hash: 0x{frame_hash:04X} | Frames: {webcam.frame_count}")
            print(f" BTC Price: ${price:,.2f} (Avg: ${avg_price:,.2f}) | Delta: {price_delta:+.2f}")
            print(f" Current Timestamp: {current_time_str} | Decoded Timestamp: {decoded_time}")
            print(f" Time Difference: {time_diff_sec:+.3f} s (Scheduled Offset: +1.000 s)")
            print(f" CRC-8 Integrity Check: {'PASS' if crc_valid else 'FAIL'}")
            print(f" Phase Bit Recovery: {exact_bits}/{N_SLOTS} verified via Optoelectronic Collapse")

            # ---- Blockchain: decode the NEXT block hash ----
            blk = blocks.pop_new()
            if blk:
                decoded = decode_block(viewport, blk)
                print_block_report(blk, decoded)
                tip_cache.update(hash=blk["hash"], decoded=decoded, reports=1)
                announced_tip = blk["hash"]
            else:
                tip = blocks.get_tip()
                if tip:
                    # Decode the current tip once (cached per tip hash) and print everything about it
                    if tip_cache["hash"] != tip["hash"]:
                        tip_cache.update(hash=tip["hash"], decoded=decode_block(viewport, tip), reports=0)
                    due = (tip_cache["reports"] == 0 or
                           (TIP_REPRINT_CYCLES and cycle % TIP_REPRINT_CYCLES == 0))
                    if due:
                        print_block_report(tip, tip_cache["decoded"], title="CURRENT CHAIN TIP")
                        tip_cache["reports"] += 1
                    print(f" [BLOCK] Waiting for next block... tip #{tip_cache['decoded']['height']} "
                          f"{tip_cache['decoded']['hash']} "
                          f"mined {format_age(time.time() - tip_cache['decoded']['timestamp'])} ago"
                          f"{' [SIMULATED]' if tip['simulated'] else ''}")
                else:
                    print(" [BLOCK] Connecting to chain...")
            print("-" * 78)
            time.sleep(1.0)

    except KeyboardInterrupt:
        print("\n[STOP] Shutting down...")
    finally:
        webcam.stop()
        fetcher.stop()
        blocks.stop()
        webcam.join(timeout=2.0)
        fetcher.join(timeout=2.0)
        blocks.join(timeout=2.0)
        print("[DONE] Pipeline successfully terminated.")


if __name__ == "__main__":
    main()
