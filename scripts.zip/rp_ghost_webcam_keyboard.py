#!/usr/bin/env python3
"""
RP-GHOST WEBCAM, BINANCE & KEYBOARD INJECTION PIPELINE
--------------------------------------------------------
Integrates live physical webcam entropy (OpenCV), asynchronous Binance BTCUSDT feeds,
unitary beam-phase correlation encoding, quantum conditional state collapse, 
and automated keystroke injection.
"""

import hashlib
import json
import math
import queue
import threading
import time
from collections import deque

import numpy as np

try:
    import cv2
    HAS_OPENCV = True
except ImportError:
    HAS_OPENCV = False

try:
    import websocket
    HAS_WS = True
except ImportError:
    HAS_WS = False

try:
    import pyautogui
    HAS_PYAUTOGUI = True
    pyautogui.FAILSAFE = True
    pyautogui.PAUSE = 0.02
except ImportError:
    HAS_PYAUTOGUI = False

# ============================================================================
# CONFIGURATION & CONSTANTS
# ============================================================================

LAMBDA_BASE = 10000.0
SIGMA_C = 0.005
N_SLOTS = 32

WEBCAM_INDEX = 0
WEBCAM_WIDTH = 640
WEBCAM_HEIGHT = 480
WEBCAM_FPS = 30

ENABLE_KEYBOARD = True
KEY_HIGH = ("shift", "w")
KEY_LOW = ("shift", "s")
KEYBOARD_MIN_DELTA = 0.01
KEYBOARD_COOLDOWN = 1.0
Z_MIN = 3.5
JOINT_CONF_MIN = 0.99

_last_keyboard_action = 0.0


# ============================================================================
# HELPERS & TIMESTAMP / FRAME BIT ENCODING
# ============================================================================

def format_clock_time(timestamp_ns):
    seconds = timestamp_ns / 1e9
    clock = time.strftime("%H:%M:%S", time.localtime(seconds))
    ms = int((timestamp_ns % 1_000_000_000) // 1_000_000)
    return f"{clock}.{ms:03d}"


def timestamp_to_code(timestamp_ns):
    ms = (int(timestamp_ns) // 1_000_000) % 60000
    return ms & 0xFFFF


def price_delta_to_code(price_delta):
    cents = int(round(float(price_delta) * 100.0))
    cents = max(-32768, min(32767, cents))
    return cents & 0xFFFF


def code_to_signed_price_delta(code):
    value = int(code) & 0xFFFF
    if value >= 0x8000:
        value -= 0x10000
    return value / 100.0


def encode_payload_bits(timestamp_ns, price_delta, frame_entropy_hash=0):
    time_code = timestamp_to_code(timestamp_ns) ^ (frame_entropy_hash & 0xFFFF)
    delta_code = price_delta_to_code(price_delta)

    time_bits = [(time_code >> (15 - k)) & 1 for k in range(16)]
    delta_bits = [(delta_code >> (15 - k)) & 1 for k in range(16)]
    return np.array(time_bits + delta_bits, dtype=int)


def bits_to_code(bits):
    code = 0
    for bit in bits:
        code = (code << 1) | (int(bit) & 1)
    return code


def decode_payload_bits(bits):
    bits = np.asarray(bits, dtype=int).flatten()
    if len(bits) != N_SLOTS:
        raise ValueError("Invalid payload length")
    timestamp_code = bits_to_code(bits[:16])
    delta_code = bits_to_code(bits[16:])
    return timestamp_code, code_to_signed_price_delta(delta_code)


def decode_timestamp_from_code(code, reference_ns):
    minute_start = (int(reference_ns) // 60_000_000_000) * 60_000_000_000
    decoded_ns = minute_start + (int(code) & 0xFFFF) * 1_000_000
    return decoded_ns, format_clock_time(decoded_ns)


def make_payload_tilt(bits, eps_abs):
    bits = np.asarray(bits, dtype=float)
    strength = max(float(eps_abs), 0.25)
    return 2.0 * strength * (bits - 0.5)


def phi(z):
    return 0.5 * (1.0 + math.erf(z / math.sqrt(2.0)))


# ============================================================================
# KEYBOARD INJECTION ENGINE
# ============================================================================

def inject_decoded_direction(decoded_delta, min_z, joint_conf):
    global _last_keyboard_action

    if not ENABLE_KEYBOARD:
        return "DISABLED"

    if not HAS_PYAUTOGUI:
        return "PYAUTOGUI NOT INSTALLED"

    if min_z < Z_MIN or joint_conf < JOINT_CONF_MIN:
        return "SKIPPED: LOW CONFIDENCE"

    if abs(decoded_delta) < KEYBOARD_MIN_DELTA:
        return "SKIPPED: ZERO DIRECTION"

    now = time.monotonic()
    if now - _last_keyboard_action < KEYBOARD_COOLDOWN:
        return "SKIPPED: COOLDOWN"

    keys = KEY_HIGH if decoded_delta > 0 else KEY_LOW
    direction = "HIGH" if decoded_delta > 0 else "LOW"

    try:
        pyautogui.hotkey(*keys)
        _last_keyboard_action = now
        return f"INJECTED {direction}: {'+'.join(keys).upper()}"
    except Exception as e:
        return f"KEYBOARD ERROR: {e}"


# ============================================================================
# WEBCAM FRAME CAPTURE THREAD
# ============================================================================

class WebcamEntropySource(threading.Thread):
    def __init__(self, camera_index=WEBCAM_INDEX):
        super().__init__(daemon=True)
        self.camera_index = camera_index
        self.frame_queue = queue.Queue(maxsize=2)
        self.running = True
        self.latest_hash = 0
        self.frame_count = 0

    def run(self):
        if not HAS_OPENCV:
            while self.running:
                time.sleep(1.0 / WEBCAM_FPS)
                dummy_frame = np.random.randint(0, 255, (WEBCAM_HEIGHT, WEBCAM_WIDTH, 3), dtype=np.uint8)
                self.latest_hash = int(hashlib.sha256(dummy_frame.tobytes()).hexdigest()[:4], 16)
                self.frame_count += 1
            return

        cap = cv2.VideoCapture(self.camera_index)
        cap.set(cv2.CAP_PROP_FRAME_WIDTH, WEBCAM_WIDTH)
        cap.set(cv2.CAP_PROP_FRAME_HEIGHT, WEBCAM_HEIGHT)
        cap.set(cv2.CAP_PROP_FPS, WEBCAM_FPS)

        if not cap.isOpened():
            self.running = False
            return

        while self.running:
            ret, frame = cap.read()
            if not ret:
                time.sleep(0.01)
                continue
            gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
            h_bytes = hashlib.sha256(gray.tobytes()).digest()
            self.latest_hash = int.from_bytes(h_bytes[:2], byteorder='big')
            self.frame_count += 1

            try:
                self.frame_queue.put_nowait(self.latest_hash)
            except queue.Full:
                try:
                    self.frame_queue.get_nowait()
                except queue.Empty:
                    pass
                self.frame_queue.put_nowait(self.latest_hash)

        cap.release()

    def stop(self):
        self.running = False


# ============================================================================
# OPTOELECTRONIC VIEWPORT & UNITARY MAPPING
# ============================================================================

class OptoelectronicViewport:
    def __init__(self, lambd=LAMBDA_BASE, sigma_c=SIGMA_C):
        self.lambd = lambd
        self.sigma_c = sigma_c

    def generate_window_block(self, n_windows, n_slots, tilt=None):
        shared_noise = np.random.normal(0.0, self.sigma_c, size=(n_windows, 1))
        lam = self.lambd * (1.0 + shared_noise)
        counts = np.random.poisson(np.clip(lam, 1.0, None), size=(n_windows, n_slots))
        Z = (counts - self.lambd) / np.sqrt(self.lambd)
        if tilt is not None:
            Z += tilt
        return Z


# ============================================================================
# BINANCE PRICE FETCHER THREAD
# ============================================================================

class AsyncPriceFetcher(threading.Thread):
    def __init__(self):
        super().__init__(daemon=True)
        self.url = "wss://stream.binance.com:443/ws/btcusdt@bookTicker"
        self.ticks = queue.Queue(maxsize=1)
        self.running = True
        self.ws = None

    def _on_message(self, ws, message):
        try:
            data = json.loads(message)
            if data.get("s") != "BTCUSDT":
                return
            bid, ask = float(data.get("b", 0)), float(data.get("a", 0))
            if bid <= 0 or ask <= 0:
                return
            price = (bid + ask) / 2.0
            tick = {"price": price, "received_ns": time.time_ns()}
            try:
                self.ticks.put_nowait(tick)
            except queue.Full:
                try:
                    self.ticks.get_nowait()
                except queue.Empty:
                    pass
                self.ticks.put_nowait(tick)
        except Exception:
            pass

    def run(self):
        if not HAS_WS:
            p = 90000.0
            while self.running:
                time.sleep(1.0)
                p += np.random.normal(0, 10)
                try:
                    self.ticks.put_nowait({"price": p, "received_ns": time.time_ns()})
                except queue.Full:
                    pass
            return

        while self.running:
            try:
                self.ws = websocket.WebSocketApp(
                    self.url,
                    on_message=lambda ws, m: self._on_message(ws, m),
                    on_error=lambda ws, e: None,
                    on_close=lambda ws, c, m: None
                )
                self.ws.run_forever(ping_interval=20, ping_timeout=10)
            except Exception:
                pass
            if self.running:
                time.sleep(3)

    def stop(self):
        self.running = False
        if self.ws:
            self.ws.close()


# ============================================================================
# MAIN PIPELINE ORCHESTRATOR
# ============================================================================

def main():
    print("=" * 78)
    print(" RP-GHOST WEBCAM, BINANCE & KEYBOARD INJECTION PIPELINE")
    print("=" * 78)

    webcam = WebcamEntropySource(WEBCAM_INDEX)
    webcam.start()

    fetcher = AsyncPriceFetcher()
    fetcher.start()

    viewport = OptoelectronicViewport()

    print("[START] Pipeline running with keystroke injection enabled. Press Ctrl+C to exit.\n")

    cycle = 0
    previous_price = None

    try:
        while True:
            cycle += 1
            start_ns = time.time_ns()

            try:
                tick = fetcher.ticks.get(timeout=2.0)
                price = tick["price"]
            except queue.Empty:
                price = 90000.0 + cycle * 5.0

            price_delta = 0.0 if previous_price is None else price - previous_price
            previous_price = price

            frame_hash = webcam.latest_hash
            scheduled_ns = start_ns + 1000_000_000
            bits = encode_payload_bits(scheduled_ns, price_delta, frame_hash)

            sigma_z = math.sqrt(1.0 + SIGMA_C**2 * LAMBDA_BASE)
            tilt = make_payload_tilt(bits, 0.02 * sigma_z)
            Z = viewport.generate_window_block(2000, N_SLOTS, tilt=tilt)

            m = Z.mean(axis=0)
            col_z = m / (Z.std(axis=0, ddof=1) / math.sqrt(2000))
            decoded_bits = (col_z > 0).astype(int)
            decoded_code, decoded_delta = decode_payload_bits(decoded_bits)
            _, decoded_time = decode_timestamp_from_code(decoded_code, start_ns)

            min_z = float(np.abs(col_z).min())
            joint_conf = float(np.prod([phi(z) for z in np.abs(col_z)]))

            keyboard_status = inject_decoded_direction(decoded_delta, min_z, joint_conf)
            exact_bits = int(np.sum(decoded_bits == bits))

            print("-" * 78)
            print(f" [CYCLE #{cycle}] Webcam Entropy Hash: 0x{frame_hash:04X} | Min |z|: {min_z:.2f} | Conf: {joint_conf:.4f}")
            print(f" BTC Price: ${price:,.2f} | Delta: {price_delta:+.2f}")
            print(f" Decoded Delta: {decoded_delta:+.2f} USD | Direction: {'HIGH' if decoded_delta > 0 else 'LOW'}")
            print(f" Keyboard Status: {keyboard_status}")
            print(f" Bit Recovery: {exact_bits}/{N_SLOTS} verified via Optoelectronic Collapse")
            print("-" * 78)

            time.sleep(1.0)

    except KeyboardInterrupt:
        print("\n[STOP] Shutting down...")
    finally:
        webcam.stop()
        fetcher.stop()
        webcam.join(timeout=1.0)
        fetcher.join(timeout=1.0)
        print("[DONE]")


if __name__ == "__main__":
    main()
