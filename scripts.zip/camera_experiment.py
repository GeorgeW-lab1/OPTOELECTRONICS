#!/usr/bin/env python3
"""
Real-camera test of the two-level recognition decoder.

PHYSICAL SETUP
  * A monitor shows a random probe pattern R(t): an ROWS x COLS grid of cells,
    each bright with probability p (fresh every cycle).
  * A physical mask K is taped over the monitor: transparent cell = 1,
    opaque cell (black card) = 0.  So physically  X_i = K_i AND R_i.
  * A webcam looks at the monitor (not your laptop's own screen).
  * The decoder gets only: the camera-derived bits X(t), the probe R(t),
    the salt and the commitment C = SHA256(salt || K).  It never sees K.

ORIGINAL (non-dual) CONVENTION
  X_i = 1  =>  K_i = 1 for sure.   U_m = cells never lit after m cycles.
  K_hat = lit cells;  Level 2 flips subsets of U_m from 0 -> 1.

WORKFLOW
  1. python camera_experiment.py commit --bits 0110...   (rows*cols bits)
       -> prints SALT and COMMIT.  Make the physical mask yourself to match.
  2. python camera_experiment.py run --salt SALT --commit C [--rows 8 --cols 8]
       -> select the monitor region, calibrates, runs cycles, decodes.
  Offline test with no hardware:
     python camera_experiment.py selftest

HONEST CAVEAT: with an all-white screen the camera sees the mask directly, so
"recovery" is not a cryptographic break.  This only measures how the Z-channel
model, hard never-seen rule and Hamming-ball decoder behave on REAL sensor
noise (flicker, light leakage, rolling shutter, latency).
"""
import argparse, hashlib, itertools, math, os, sys, time
import numpy as np

rng = np.random.default_rng()


# ---------------------------------------------------------------- crypto ----
def commit_fn(salt: bytes, K: np.ndarray) -> bytes:
    return hashlib.sha256(salt + np.packbits(K.astype(np.uint8)).tobytes()).digest()


# ---------------------------------------------------------------- decoder ---
def level2(U, base, salt, C, Bmax):
    """base = K_hat (lit cells). Flip k cells of U from 0->1, k=0,1,2,..."""
    hashes = 0
    for k in range(len(U) + 1):
        if hashes + math.comb(len(U), k) > Bmax:
            return None, hashes, k - 1
        for F in itertools.combinations(U, k):
            cand = base.copy()
            cand[list(F)] = 1
            hashes += 1
            if commit_fn(salt, cand) == C:
                return cand, hashes, k
    return None, hashes, len(U)


def decode(X, salt, C, Bmax=500_000):
    """X: (M, n) binary camera observations. Sequential decoding."""
    total = 0
    for m in range(1, X.shape[0] + 1):
        lit = X[:m].any(axis=0)                     # cells ever seen lit
        U = np.flatnonzero(~lit)                    # never-seen-lit set
        got, h, k = level2(U, lit.astype(np.uint8), salt, C, Bmax)
        total += h
        if got is not None:
            return got, m, total, len(U)
    return None, X.shape[0], total, len(U)


# ---------------------------------------------------------------- cameras ---
class SimCamera:
    """Fake camera+monitor+mask so the pipeline can be tested offline."""
    def __init__(self, K, p, leak=25.0, noise=8.0):
        self.K, self.leak, self.noise = K, leak, noise
    def measure(self, R):                           # returns per-cell brightness
        bright = np.where(self.K == 1, 200.0, self.leak) * R
        dark = np.where(self.K == 1, 20.0, 18.0) * (1 - R)
        return bright + dark + rng.normal(0, self.noise, R.shape)
    def calibrate(self):
        n = len(self.K)
        lo = np.median(self.measure(np.zeros(n)))
        hi = np.percentile(self.measure(np.ones(n)), 90)
        return lo, hi


class WebcamRig:
    def __init__(self, rows, cols, cam_index=0, hold_ms=250, settle=3, avg=4):
        import cv2
        self.cv2, self.rows, self.cols = cv2, rows, cols
        self.cap = cv2.VideoCapture(cam_index)
        if not self.cap.isOpened():
            sys.exit("Cannot open camera")
        self.hold_ms, self.settle, self.avg = hold_ms, settle, avg
        cv2.namedWindow("probe", cv2.WND_PROP_FULLSCREEN)
        cv2.setWindowProperty("probe", cv2.WND_PROP_FULLSCREEN, cv2.WINDOW_FULLSCREEN)
        self._select_roi()

    def _grab(self):
        ok, f = self.cap.read()
        if not ok:
            sys.exit("Camera read failed")
        return self.cv2.cvtColor(f, self.cv2.COLOR_BGR2GRAY).astype(float)

    def _select_roi(self):
        cv2 = self.cv2
        self._show(np.ones(self.rows * self.cols))   # all white for alignment
        for _ in range(20):
            self._grab(); cv2.waitKey(30)
        frame = self._grab().astype(np.uint8)
        print("Drag a box around the masked monitor area, press ENTER.")
        x, y, w, h = cv2.selectROI("select region", frame, False)
        cv2.destroyWindow("select region")
        self.roi = (int(x), int(y), int(w), int(h))

    def _show(self, R):
        cv2 = self.cv2
        img = np.kron(R.reshape(self.rows, self.cols), np.ones((80, 80))) * 255
        cv2.imshow("probe", img.astype(np.uint8))

    def _cells(self, f):
        x, y, w, h = self.roi
        crop = f[y:y + h, x:x + w]
        ch, cw = h // self.rows, w // self.cols
        out = np.empty(self.rows * self.cols)
        for r in range(self.rows):
            for c in range(self.cols):
                # centre of each cell only, to avoid edge bleed
                cell = crop[r*ch + ch//4: (r+1)*ch - ch//4,
                            c*cw + cw//4: (c+1)*cw - cw//4]
                out[r * self.cols + c] = cell.mean()
        return out

    def measure(self, R):
        self._show(R)
        self.cv2.waitKey(self.hold_ms)
        for _ in range(self.settle):                 # drop stale buffered frames
            self._grab()
        return np.mean([self._cells(self._grab()) for _ in range(self.avg)], axis=0)

    def calibrate(self):
        n = self.rows * self.cols
        lo = np.median(self.measure(np.zeros(n)))
        hi = np.percentile(self.measure(np.ones(n)), 90)
        return lo, hi

    def close(self):
        self.cap.release(); self.cv2.destroyAllWindows()


# ---------------------------------------------------------------- driver ----
def acquire(rig, n, p, M):
    lo, hi = rig.calibrate()
    thr = lo + 0.5 * (hi - lo)
    print(f"calibration: dark={lo:.1f}  bright(90th pct)={hi:.1f}  threshold={thr:.1f}")
    if hi - lo < 30:
        print("WARNING: contrast is low; check alignment/exposure/lighting.")
    Rs, Xs = [], []
    for t in range(M):
        R = (rng.random(n) < p).astype(float)
        Xs.append((rig.measure(R) > thr).astype(np.uint8))
        Rs.append(R.astype(np.uint8))
    return np.array(Rs), np.array(Xs)


def report(R, X, K=None):
    """Channel diagnostics from probe R and observed X."""
    on = R == 1
    p_hat = on.mean()
    p_x_given_r1 = (X & R).sum(0) / np.maximum(R.sum(0), 1)       # per cell
    ghost = ((X == 1) & (R == 0)).mean()                          # lit w/o probe
    print(f"empirical p = {p_hat:.3f}   ghost-light rate (X=1,R=0) = {ghost:.4f}")
    if K is not None:
        pk1 = p_x_given_r1[K == 1].mean()
        pk0 = p_x_given_r1[K == 0].mean()
        print(f"P(X=1|R=1,K=1) = {pk1:.3f}   P(X=1|R=1,K=0) = {pk0:.4f} "
              f"(Z-channel model requires ~1 and 0)")


def run(args, rig=None, K_truth=None):
    n = args.rows * args.cols
    salt, C = bytes.fromhex(args.salt), bytes.fromhex(args.commit)
    own = rig is None
    if own:
        rig = WebcamRig(args.rows, args.cols, args.cam, args.hold)
    t0 = time.time()
    R, X = acquire(rig, n, args.p, args.cycles)
    if own:
        rig.close()
    print(f"acquired {args.cycles} cycles in {time.time()-t0:.1f}s")
    got, m, T, u = decode(X, salt, C, args.bmax)
    if got is None:
        print(f"DECODE FAILED after {m} cycles ({T} hashes). "
              "Likely sensor noise broke the hard rule: try lower hold noise, "
              "more cycles, or tighter alignment.")
    else:
        print(f"RECOVERED at cycle {m}, {T} hashes, |U_m|={u}")
        print("K =", "".join(map(str, got)))
    # Post-hoc diagnostics only; K_truth is never given to the decoder.
    if K_truth is not None:
        report(R, X, K_truth)
        if got is not None:
            print("matches ground truth:", np.array_equal(got, K_truth))
    return got


def main():
    ap = argparse.ArgumentParser()
    sub = ap.add_subparsers(dest="cmd", required=True)
    c = sub.add_parser("commit"); c.add_argument("--bits", required=True)
    for name in ("run", "selftest"):
        r = sub.add_parser(name)
        r.add_argument("--rows", type=int, default=8)
        r.add_argument("--cols", type=int, default=8)
        r.add_argument("--p", type=float, default=0.5)
        r.add_argument("--cycles", type=int, default=24)
        r.add_argument("--bmax", type=int, default=500_000)
        r.add_argument("--cam", type=int, default=0)
        r.add_argument("--hold", type=int, default=250, help="ms per pattern")
        r.add_argument("--salt"); r.add_argument("--commit")
    a = ap.parse_args()

    if a.cmd == "commit":
        K = np.array([int(b) for b in a.bits], dtype=np.uint8)
        salt = os.urandom(16)
        print("SALT  :", salt.hex()); print("COMMIT:", commit_fn(salt, K).hex())
        print(f"n = {len(K)} bits -> use --rows/--cols with rows*cols = {len(K)}")
    elif a.cmd == "run":
        if not (a.salt and a.commit):
            sys.exit("need --salt and --commit")
        run(a)
    else:
        n = a.rows * a.cols
        K = rng.integers(0, 2, n).astype(np.uint8)
        salt = os.urandom(16); C = commit_fn(salt, K)
        a.salt, a.commit = salt.hex(), C.hex()
        print(f"[selftest] simulated camera, n={n}")
        run(a, rig=SimCamera(K, a.p), K_truth=K)


if __name__ == "__main__":
    main()
