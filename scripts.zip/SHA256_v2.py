
"""
RP-GHOST / ViaBTC Bitcoin Stratum V1 Miner
Actual Bitcoin pool jobs, SHA256d, share validation and submission.

Install:
    pip install numpy opencv-python

Configure:
    Set VIABTC_USER to your ViaBTC worker name.
    Set VIABTC_PASSWORD if required.

Run:
    python SHA256.py
"""

import hashlib
import json
import os
import queue
import select
import socket
import struct
import threading
import time
import tkinter as tk
from decimal import Decimal
from tkinter import ttk
import sys
import numpy as np

try:
    import cv2
except ImportError:
    cv2 = None


# ================================================================
# CONFIGURATION
# ================================================================

POOL_HOST = "btc.viabtc.io"
POOL_PORT = 3333

POOL_USER = os.getenv("VIABTC_USER", "lolcatz.001")
POOL_PASSWORD = os.getenv("VIABTC_PASSWORD", "x")

USER_AGENT = "RPGHOST-BitcoinMiner/1.0"

SW, SH = 128, 96
PW, PH = 320, 240

ORACLE_BITS = 32

DIFF1_TARGET = 0x00000000FFFF0000000000000000000000000000000000000000000000000000

MINER_LANES = 2
HASH_BATCH = 4096

DELIM = ":"


# ================================================================
# HASHING AND BITCOIN TARGETS
# ================================================================

def sha256d(data: bytes) -> bytes:
    return hashlib.sha256(
        hashlib.sha256(data).digest()
    ).digest()


def compact_to_target(nbits: str) -> int:
    compact = int(nbits, 16)

    exponent = compact >> 24
    mantissa = compact & 0x007fffff

    if compact & 0x00800000:
        raise ValueError("Negative Bitcoin target")

    if exponent <= 3:
        target = mantissa >> (8 * (3 - exponent))
    else:
        target = mantissa << (8 * (exponent - 3))

    if target <= 0 or target >= (1 << 256):
        raise ValueError("Invalid Bitcoin target")

    return target


def difficulty_to_target(difficulty: float) -> int:
    if difficulty <= 0:
        raise ValueError("Invalid pool difficulty")

    return int(
        Decimal(DIFF1_TARGET) / Decimal(str(difficulty))
    )


def swap_words(data: bytes) -> bytes:
    if len(data) % 4:
        raise ValueError("Data length must be divisible by four")

    return b"".join(
        data[i:i + 4][::-1]
        for i in range(0, len(data), 4)
    )


# ================================================================
# LATCH REGISTERS
# ================================================================

class Register:

    def __init__(self, value=None):
        self._lock = threading.Lock()
        self._v = value
        self.seq = 0

    def write(self, value):
        with self._lock:
            self._v = value
            self.seq += 1
            return self.seq

    def read(self):
        with self._lock:
            return self.seq, self._v


# ================================================================
# ORIGINAL ORACLE
# ================================================================

class GhostedOracleWorker(threading.Thread):

    def __init__(self, msg_reg, log_cb):
        super().__init__(daemon=True, name="ghosted-oracle")

        self.msg_reg = msg_reg
        self.log_cb = log_cb

        self.ticks = queue.Queue()
        self._halt = threading.Event()

        self.q_bits_buffer = 0
        self.q_bit_count = 0

        self.oracle_block_id = 0
        self.target_stream_bits = ORACLE_BITS

    def stop(self):
        self._halt.set()

    def tick(self, idx, q_out):
        self.ticks.put((idx, q_out))

    def run(self):

        while not self._halt.is_set():

            try:
                idx, q_out = self.ticks.get(timeout=0.1)
            except queue.Empty:
                continue

            if q_out not in (0, 1):
                continue

            self.q_bits_buffer = (
                (self.q_bits_buffer << 1) | q_out
            )

            self.q_bit_count += 1

            self.log_cb(
                f"[ORACLE] Frame {idx} | Q={q_out} | "
                f"{self.q_bit_count}/{ORACLE_BITS}"
            )

            if self.q_bit_count < self.target_stream_bits:
                continue

            self.oracle_block_id += 1

            stream_hex = format(
                self.q_bits_buffer,
                f"0{self.target_stream_bits // 4}x"
            )

            digest = hashlib.sha512(
                f"RECONSTRUCTED-ORACLE-BLOCK-{self.oracle_block_id}:{stream_hex}".encode("ascii")
            ).digest()

            msg_int = int.from_bytes(digest, "big")

            record = {
                "block_id": self.oracle_block_id,
                "stream_hex": stream_hex,
                "message": msg_int
            }

            if not verify_oracle_record(record):

                self.log_cb(
                    f"[ORACLE VERIFICATION FAILED] Block #{self.oracle_block_id}"
                )

            else:

                self.log_cb(
                    f"[ORACLE VERIFICATION PASSED] "
                    f"Block #{self.oracle_block_id} | "
                    f"SHA-512 independently confirmed"
                )

                self.log_cb(str(record))

                self.msg_reg.write({
                    **record,
                    "oracle_verified": True
                })

            self.q_bits_buffer = 0
            self.q_bit_count = 0


def independently_verify_oracle(
    block_id,
    stream_hex,
    message
):

    if not isinstance(block_id, int) or isinstance(block_id, bool) or block_id < 1:
        return False

    if not isinstance(stream_hex, str) or len(stream_hex) != 8:
        return False

    try:
        int(stream_hex, 16)
    except ValueError:
        return False

    if not isinstance(message, int) or isinstance(message, bool):
        return False

    if not 0 <= message < (1 << 512):
        return False

    expected = hashlib.sha512(
        f"RECONSTRUCTED-ORACLE-BLOCK-{block_id}:{stream_hex}".encode("ascii")
    ).digest()

    return int.from_bytes(expected, "big") == message


def verify_oracle_record(record):

    if not isinstance(record, dict):
        return False

    return independently_verify_oracle(
        record.get("block_id"),
        record.get("stream_hex"),
        record.get("message")
    )


# ================================================================
# STRATUM V1 CLIENT
# ================================================================

class StratumClient(threading.Thread):

    def __init__(self, job_reg, log_cb):

        super().__init__(daemon=True, name="viabtc-stratum")

        self.job_reg = job_reg
        self.log_cb = log_cb

        self.sock = None
        self.rx_buffer = b""

        self.send_lock = threading.Lock()
        self.id_lock = threading.Lock()

        self.request_id = 10
        self.pending_submits = {}

        self.extranonce1 = b""
        self.extranonce2_size = 0

        self.pending_difficulty = 1.0

        self._halt = threading.Event()

        self.connected = threading.Event()
        self.authorized = False

    def stop(self):
        self._halt.set()

        if self.sock:
            try:
                self.sock.shutdown(socket.SHUT_RDWR)
            except OSError:
                pass

            try:
                self.sock.close()
            except OSError:
                pass

    def send_message(self, message):

        data = (
            json.dumps(message, separators=(",", ":")) + "\n"
        ).encode("utf-8")

        with self.send_lock:
            self.sock.sendall(data)

    def send_request(self, method, params):

        with self.id_lock:
            self.request_id += 1
            rid = self.request_id

        self.send_message({
            "id": rid,
            "method": method,
            "params": params
        })

        return rid

    def read_message(self, timeout=None):

        deadline = None if timeout is None else time.monotonic() + timeout

        while not self._halt.is_set():

            newline = self.rx_buffer.find(b"\n")

            if newline >= 0:

                line = self.rx_buffer[:newline]
                self.rx_buffer = self.rx_buffer[newline + 1:]

                if not line.strip():
                    continue

                return json.loads(line.decode("utf-8"))

            if deadline is not None:
                remaining = deadline - time.monotonic()

                if remaining <= 0:
                    raise TimeoutError("Stratum response timeout")
            else:
                remaining = 1.0

            readable, _, _ = select.select(
                [self.sock],
                [],
                [],
                min(remaining, 1.0)
            )

            if not readable:
                if deadline is not None and time.monotonic() >= deadline:
                    raise TimeoutError("Stratum response timeout")
                continue

            chunk = self.sock.recv(65536)

            if not chunk:
                raise ConnectionError("Pool disconnected")

            self.rx_buffer += chunk

        raise ConnectionError("Stratum client stopped")

    def wait_response(self, request_id, timeout=30):

        while not self._halt.is_set():

            msg = self.read_message(timeout)

            if msg.get("id") == request_id:
                return msg

            self.dispatch(msg)

        raise ConnectionError("Stratum client stopped")

    def run(self):

        if not POOL_USER or POOL_USER.startswith("YOUR_"):
            self.log_cb(
                "[STRATUM ERROR] Configure VIABTC_USER before connecting."
            )
            return

        try:

            self.log_cb(
                f"[STRATUM] Connecting to {POOL_HOST}:{POOL_PORT}"
            )

            self.sock = socket.create_connection(
                (POOL_HOST, POOL_PORT),
                timeout=15
            )

            self.sock.setblocking(True)

            self.log_cb("[STRATUM] TCP connection established.")

            # ----------------------------------------------------
            # SUBSCRIBE
            # ----------------------------------------------------

            subscribe_id = self.send_request(
                "mining.subscribe",
                [USER_AGENT]
            )

            response = self.wait_response(subscribe_id)

            if response.get("error") or not response.get("result"):
                raise RuntimeError(
                    f"Subscription failed: {response}"
                )

            result = response["result"]

            self.extranonce1 = bytes.fromhex(result[1])
            self.extranonce2_size = int(result[2])

            if self.extranonce2_size < 1:
                raise RuntimeError("Invalid extranonce2 size")

            self.log_cb(
                f"[STRATUM] Subscribed | "
                f"Extranonce1={self.extranonce1.hex()} | "
                f"Extranonce2 size={self.extranonce2_size}"
            )

            # ----------------------------------------------------
            # AUTHORIZE
            # ----------------------------------------------------

            auth_id = self.send_request(
                "mining.authorize",
                [POOL_USER, POOL_PASSWORD]
            )

            response = self.wait_response(auth_id)

            if response.get("error") or response.get("result") is not True:
                raise RuntimeError(
                    f"Worker authorization failed: {response}"
                )

            self.authorized = True
            self.connected.set()

            self.log_cb(
                f"[STRATUM] Worker authorized: {POOL_USER}"
            )

            # ----------------------------------------------------
            # RECEIVE POOL JOBS AND SHARE RESPONSES
            # ----------------------------------------------------

            while not self._halt.is_set():

                try:
                    msg = self.read_message(timeout=1)

                except TimeoutError:
                    continue

                self.dispatch(msg)

        except Exception as e:

            if not self._halt.is_set():
                self.log_cb(f"[STRATUM ERROR] {e}")

        finally:

            self.connected.clear()
            self.authorized = False

            self.log_cb("[STRATUM] Connection closed.")

    def dispatch(self, msg):

        method = msg.get("method")

        if method == "mining.set_difficulty":

            self.pending_difficulty = float(
                msg["params"][0]
            )

            self.log_cb(
                f"[POOL] New share difficulty: {self.pending_difficulty}"
            )

        elif method == "mining.set_extranonce":

            self.extranonce1 = bytes.fromhex(
                msg["params"][0]
            )

            self.extranonce2_size = int(
                msg["params"][1]
            )

            self.log_cb(
                "[POOL] Extranonce parameters updated."
            )

        elif method == "mining.notify":

            p = msg["params"]

            if len(p) < 9:
                self.log_cb("[POOL ERROR] Invalid mining.notify")
                return

            job = {
                "job_id": p[0],
                "prevhash": p[1],
                "coinb1": p[2],
                "coinb2": p[3],
                "merkle_branch": p[4],
                "version": p[5],
                "nbits": p[6],
                "ntime": p[7],
                "clean_jobs": bool(p[8]),
                "difficulty": self.pending_difficulty,
                "extranonce1": self.extranonce1,
                "extranonce2_size": self.extranonce2_size
            }

            self.job_reg.write(job)

            self.log_cb(
                f"[POOL JOB] {job['job_id']} | "
                f"Difficulty={job['difficulty']} | "
                f"nBits={job['nbits']} | "
                f"Clean={job['clean_jobs']}"
            )

        elif method == "client.show_message":

            self.log_cb(
                f"[POOL MESSAGE] {msg.get('params')}"
            )

        elif method == "client.reconnect":

            self.log_cb(
                f"[POOL RECONNECT REQUEST] {msg.get('params')}"
            )

        elif "id" in msg and msg["id"] in self.pending_submits:

            info = self.pending_submits.pop(msg["id"])

            if msg.get("result") is True:

                self.log_cb(
                    f"[SHARE ACCEPTED] Job={info['job_id']} | "
                    f"Lane={info['lane']} | "
                    f"Nonce={info['nonce']}"
                )

            else:

                self.log_cb(
                    f"[SHARE REJECTED] Job={info['job_id']} | "
                    f"Lane={info['lane']} | "
                    f"Error={msg.get('error')}"
                )

    def submit_share(self, job, extranonce2, ntime, nonce, lane):

        if not self.authorized or not self.connected.is_set():
            self.log_cb("[SUBMIT ERROR] Not authorized; share was not sent.")
            return False

        # Register the request before writing it to the socket. This prevents
        # a fast pool response from arriving before pending_submits is ready.
        with self.id_lock:
            self.request_id += 1
            rid = self.request_id
            self.pending_submits[rid] = {
                "job_id": job["job_id"],
                "nonce": f"{nonce:08x}",
                "lane": lane
            }

        try:
            self.send_message({
                "id": rid,
                "method": "mining.submit",
                "params": [
                    POOL_USER,
                    job["job_id"],
                    extranonce2,
                    ntime,
                    f"{nonce:08x}"
                ]
            })
        except Exception:
            self.pending_submits.pop(rid, None)
            raise

        self.log_cb(
            f"[SHARE SUBMITTED] Request={rid} | Job={job['job_id']} | "
            f"Lane={lane} | Extranonce2={extranonce2} | "
            f"NTime={ntime} | Nonce={nonce:08x}"
        )
        return True


# ================================================================
# ORACLE-SEEDED EXTRANONCE2
# ================================================================

def oracle_extranonce2(message, lane, counter, size):

    if size < 1:
        raise ValueError("Invalid extranonce2 size")

    message_bytes = message.to_bytes(64, "big")

    seed = hashlib.sha256(
        message_bytes + struct.pack("<I", lane)
    ).digest()

    if size <= 32:

        base = int.from_bytes(seed[-size:], "big")

    else:

        output = bytearray()
        block = 0

        while len(output) < size:

            output.extend(
                hashlib.sha256(
                    seed + struct.pack("<I", block)
                ).digest()
            )

            block += 1

        base = int.from_bytes(bytes(output[:size]), "big")

    value = (
        base + counter
    ) % (1 << (8 * size))

    return value.to_bytes(size, "big").hex()


# ================================================================
# BITCOIN COINBASE AND MERKLE ROOT
# ================================================================

def build_merkle_root(job, extranonce2):

    coinbase = (
        bytes.fromhex(job["coinb1"])
        + job["extranonce1"]
        + bytes.fromhex(extranonce2)
        + bytes.fromhex(job["coinb2"])
    )

    merkle_root = sha256d(coinbase)

    for branch in job["merkle_branch"]:

        branch_bytes = bytes.fromhex(branch)

        merkle_root = sha256d(
            merkle_root + branch_bytes
        )

    return merkle_root


# ================================================================
# BITCOIN 80-BYTE BLOCK HEADER
# ================================================================

def build_header_prefix(job, extranonce2):

    version = bytes.fromhex(job["version"])[::-1]

    # Stratum V1 prevhash uses reversed 32-bit words.
    prevhash = swap_words(
        bytes.fromhex(job["prevhash"])
    )

    merkle_root = build_merkle_root(
        job,
        extranonce2
    )

    ntime = bytes.fromhex(job["ntime"])[::-1]

    nbits = bytes.fromhex(job["nbits"])[::-1]

    prefix = (
        version
        + prevhash
        + merkle_root
        + ntime
        + nbits
    )

    if len(prefix) != 76:
        raise ValueError(
            f"Invalid header prefix: {len(prefix)} bytes"
        )

    return prefix


def build_full_header(prefix, nonce):

    header = prefix + struct.pack("<I", nonce)

    if len(header) != 80:
        raise ValueError("Bitcoin header must be exactly 80 bytes")

    return header


# ================================================================
# BITCOIN MINER LANES
# ================================================================

class BitcoinMinerLane(threading.Thread):

    def __init__(
        self,
        lane,
        job_reg,
        msg_reg,
        stratum,
        log_cb
    ):

        super().__init__(
            daemon=True,
            name=f"bitcoin-miner-{lane}"
        )

        self.lane = lane

        self.job_reg = job_reg
        self.msg_reg = msg_reg

        self.stratum = stratum
        self.log_cb = log_cb

        self._halt = threading.Event()

        self.hashes = 0
        self.shares = 0

    def stop(self):
        self._halt.set()

    def run(self):

        last_key = None

        counter = 0
        nonce = 0

        last_report = time.perf_counter()
        last_hashes = 0

        active_oracle = None

        while not self._halt.is_set():

            job_seq, job = self.job_reg.read()
            msg_seq, latest_oracle = self.msg_reg.read()

            if (
                job is None
                or latest_oracle is None
                or not latest_oracle.get("oracle_verified")
                or not self.stratum.connected.is_set()
            ):

                time.sleep(0.05)
                continue

            # Latch one verified oracle seed for this pool job. New camera
            # oracle blocks must not restart the 32-bit nonce search.
            key = job_seq

            if key != last_key:

                last_key = key
                active_oracle = latest_oracle
                counter = 0
                nonce = 0

                self.log_cb(
                    f"[MINER {self.lane}] Starting Bitcoin job "
                    f"{job['job_id']} using latched oracle block "
                    f"{active_oracle['block_id']}"
                )

            oracle = active_oracle

            try:

                extranonce2 = oracle_extranonce2(
                    oracle["message"],
                    self.lane,
                    counter,
                    job["extranonce2_size"]
                )

                prefix = build_header_prefix(
                    job,
                    extranonce2
                )

                share_target = difficulty_to_target(
                    job["difficulty"]
                )

                block_target = compact_to_target(
                    job["nbits"]
                )

                # Pool shares use the pool-assigned share target.
                # The Bitcoin network target is only for identifying a
                # full block candidate; it must NOT gate share submission.
                target = share_target

            except Exception as e:

                self.log_cb(
                    f"[MINER {self.lane} ERROR] {e}"
                )

                time.sleep(1)
                continue

            # ----------------------------------------------------
            # SEARCH 32-BIT BITCOIN NONCE SPACE
            # ----------------------------------------------------

            for _ in range(HASH_BATCH):

                if self._halt.is_set():
                    break

                current_job_seq, _ = self.job_reg.read()

                if current_job_seq != job_seq:
                    break

                header = build_full_header(
                    prefix,
                    nonce
                )

                digest = sha256d(header)

                hash_value = int.from_bytes(
                    digest,
                    "little"
                )

                self.hashes += 1

                if hash_value <= block_target:
                    self.log_cb(
                        f"[BLOCK CANDIDATE] Lane={self.lane} | "
                        f"Hash={digest[::-1].hex()} | "
                        f"Nonce={nonce:08x}"
                    )

                if hash_value <= share_target:
                    self.shares += 1

                    self.log_cb(
                        f"[SHARE FOUND] Lane={self.lane} | "
                        f"Hash={digest[::-1].hex()} | "
                        f"Nonce={nonce:08x} | "
                        f"Pool difficulty={job['difficulty']}"
                    )

                    self.stratum.submit_share(
                        job,
                        extranonce2,
                        job["ntime"],
                        nonce,
                        self.lane
                    )

                nonce += 1

                if nonce > 0xffffffff:

                    nonce = 0
                    counter += 1

                    extranonce2 = oracle_extranonce2(
                        oracle["message"],
                        self.lane,
                        counter,
                        job["extranonce2_size"]
                    )

                    prefix = build_header_prefix(
                        job,
                        extranonce2
                    )

            now = time.perf_counter()

            if now - last_report >= 5:

                rate = (
                    self.hashes - last_hashes
                ) / (now - last_report)

                self.log_cb(
                    f"[HASHRATE] Lane={self.lane} | "
                    f"{rate:,.2f} H/s | "
                    f"Total={self.hashes:,} | "
                    f"Shares={self.shares} | "
                    f"PoolDiff={job['difficulty']} | "
                    f"Status={'SEARCHING - no qualifying share yet' if self.shares == 0 else 'SHARES FOUND'}"
                )

                last_report = now
                last_hashes = self.hashes


# ================================================================
# CAMERA SOURCE
# ================================================================

class Source:

    def __init__(self, index):

        if cv2 is None:
            raise RuntimeError(
                "Install OpenCV: pip install opencv-python"
            )

        backend = (
            cv2.CAP_DSHOW
            if sys.platform == "win32"
            else cv2.CAP_ANY
        )

        self.cap = cv2.VideoCapture(index, backend)

        self.cap.set(cv2.CAP_PROP_BUFFERSIZE, 1)
        self.cap.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
        self.cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)

        if not self.cap.isOpened():
            raise RuntimeError(
                f"Cannot open camera {index}"
            )

        self.rgb = None

    def read(self):

        if not self.cap.grab():
            return None

        ok, bgr = self.cap.retrieve()

        if not ok:
            return None

        self.rgb = cv2.cvtColor(
            bgr,
            cv2.COLOR_BGR2RGB
        )

        return cv2.cvtColor(
            bgr,
            cv2.COLOR_BGR2GRAY
        )

    def close(self):
        self.cap.release()


def downscale(gray):

    small = cv2.resize(
        gray,
        (SW, SH),
        interpolation=cv2.INTER_AREA
    )

    return cv2.GaussianBlur(
        small,
        (5, 5),
        0
    )


def ppm_photo(rgb):

    h, w, _ = rgb.shape

    data = b"P6 %d %d 255\n" % (w, h)

    data += np.ascontiguousarray(
        rgb,
        dtype=np.uint8
    ).tobytes()

    return tk.PhotoImage(
        data=data,
        format="PPM"
    )


# ================================================================
# MAIN APPLICATION
# ================================================================

class App:

    def __init__(self, window):

        self.window = window

        window.title(
            "RP-GHOST | Actual Bitcoin Pool Miner"
        )

        self.q = queue.Queue()

        self.ctl = {
            "stop": False,
            "thr": 18,
            "min_px": 30
        }

        self.msg_reg = Register()
        self.job_reg = Register()

        self.oracle = GhostedOracleWorker(
            self.msg_reg,
            self.log
        )

        self.stratum = StratumClient(
            self.job_reg,
            self.log
        )

        self.miners = [
            BitcoinMinerLane(
                i,
                self.job_reg,
                self.msg_reg,
                self.stratum,
                self.log
            )
            for i in range(MINER_LANES)
        ]

        self.oracle.start()

        for miner in self.miners:
            miner.start()

        self._build_ui()

        window.protocol(
            "WM_DELETE_WINDOW",
            self.close
        )

        window.after(30, self.poll)

    def log(self, message):
        self.q.put(("log", str(message)))

    def _build_ui(self):

        main = ttk.Frame(
            self.window,
            padding=10
        )

        main.pack(
            fill="both",
            expand=True
        )

        controls = ttk.LabelFrame(
            main,
            text="Bitcoin Pool Controls",
            padding=8
        )

        controls.pack(
            fill="x",
            pady=5
        )

        self.start_button = ttk.Button(
            controls,
            text="Connect / Start Mining",
            command=self.start
        )

        self.start_button.pack(
            side="left",
            padx=5
        )

        self.stop_button = ttk.Button(
            controls,
            text="Stop",
            command=self.stop,
            state="disabled"
        )

        self.stop_button.pack(
            side="left",
            padx=5
        )

        self.status = tk.StringVar(
            value="Disconnected"
        )

        ttk.Label(
            controls,
            textvariable=self.status,
            font=("Arial", 10, "bold")
        ).pack(
            side="left",
            padx=12
        )

        content = ttk.Frame(main)

        content.pack(
            fill="both",
            expand=True
        )

        self.canvas = tk.Canvas(
            content,
            width=PW,
            height=PH,
            bg="black"
        )

        self.canvas.pack(
            side="left",
            padx=5
        )

        self.image_id = self.canvas.create_image(
            0,
            0,
            anchor="nw"
        )

        log_frame = ttk.LabelFrame(
            content,
            text="Oracle / Stratum / Bitcoin PoW Log",
            padding=5
        )

        log_frame.pack(
            side="right",
            fill="both",
            expand=True
        )

        self.log_text = tk.Text(
            log_frame,
            width=75,
            height=22,
            font=("Consolas", 9),
            state="disabled"
        )

        self.log_text.pack(
            side="left",
            fill="both",
            expand=True
        )

        scroll = ttk.Scrollbar(
            log_frame,
            orient="vertical",
            command=self.log_text.yview
        )

        scroll.pack(
            side="right",
            fill="y"
        )

        self.log_text.configure(
            yscrollcommand=scroll.set
        )

    def start(self):

        self.ctl["stop"] = False

        self.start_button.config(
            state="disabled"
        )

        self.stop_button.config(
            state="normal"
        )

        self.status.set(
            "Connecting to ViaBTC..."
        )

        if not self.stratum.is_alive():
            self.stratum.start()

        self.sim_thread = threading.Thread(
            target=self.sim_loop,
            daemon=True
        )

        self.sim_thread.start()

    def stop(self):

        self.ctl["stop"] = True

        self.log("[SYSTEM] Camera stopped.")

        self.stop_button.config(
            state="disabled"
        )

        self.start_button.config(
            state="normal"
        )

    def close(self):

        self.ctl["stop"] = True

        self.oracle.stop()
        self.stratum.stop()

        for miner in self.miners:
            miner.stop()

        self.window.destroy()

    def sim_loop(self):

        try:
            src = Source(0)

        except RuntimeError as e:

            self.log(f"[CAMERA ERROR] {e}")
            self.q.put(("done",))

            return

        self.log("[CAMERA] USB camera connected.")

        prev = None
        idx = 0

        try:

            while not self.ctl["stop"]:

                gray = src.read()

                if gray is None:
                    break

                small = downscale(gray)

                if prev is None or idx < 5:

                    mask = np.zeros(
                        (SH, SW),
                        dtype=bool
                    )

                else:

                    diff = np.abs(
                        small.astype(np.int16)
                        - prev.astype(np.int16)
                    )

                    mask = diff > self.ctl["thr"]

                prev = small

                motion_px = int(mask.sum())

                motion = motion_px >= self.ctl["min_px"]

                x = motion_px if motion else 0

                driver_a = 0

                if motion and x > 4 and x % 2 == 1:

                    r = 2 + (x * 7) % (x - 3)

                    driver_a = int(
                        miller_rabin_witness(r, x)
                    )

                driver_b = int(
                    motion and x > 2 and x % 2 == 1
                )

                q_out = driver_a & driver_b

                self.oracle.tick(
                    idx,
                    q_out
                )

                if src.rgb is not None:

                    preview = cv2.resize(
                        src.rgb,
                        (PW, PH)
                    )

                    self.q.put(
                        ("frame", preview)
                    )

                idx += 1

                time.sleep(0.03)

        finally:

            src.close()

            self.q.put(("done",))

    def poll(self):

        try:

            while True:

                item = self.q.get_nowait()

                if item[0] == "log":

                    self.log_text.config(
                        state="normal"
                    )

                    self.log_text.insert(
                        "end",
                        item[1] + "\n"
                    )

                    lines = int(
                        self.log_text.index("end-1c").split(".")[0]
                    )

                    if lines > 500:

                        self.log_text.delete(
                            "1.0",
                            f"{lines - 400}.0"
                        )

                    self.log_text.see("end")

                    self.log_text.config(
                        state="disabled"
                    )

                elif item[0] == "frame":

                    photo = ppm_photo(item[1])

                    self.canvas.itemconfig(
                        self.image_id,
                        image=photo
                    )

                    self._photo = photo

                elif item[0] == "done":

                    self.log("[CAMERA] Capture ended.")

        except queue.Empty:
            pass

        if self.stratum.connected.is_set():

            self.status.set(
                "ViaBTC Connected / Authorized"
            )

        elif self.stratum.is_alive():

            self.status.set(
                "Connecting / Authenticating"
            )

        else:

            self.status.set(
                "Disconnected"
            )

        self.window.after(
            30,
            self.poll
        )


# ================================================================
# MILLER-RABIN CIRCUIT FUNCTION
# ================================================================

def miller_rabin_witness(a, n):

    if n < 2:
        return False

    d, s = n - 1, 0

    while d % 2 == 0:
        d //= 2
        s += 1

    y = pow(a, d, n)

    if y in (1, n - 1):
        return False

    for _ in range(s - 1):

        y = y * y % n

        if y == n - 1:
            return False

    return True


# ================================================================
# ENTRY POINT
# ================================================================

if __name__ == "__main__":

    root = tk.Tk()

    app = App(root)

    root.geometry("1150x600")

    root.mainloop()
