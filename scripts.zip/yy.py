
#!/usr/bin/env python3
"""
Webcam Optoelectronic AND Circuit — Extended Independent Probe

Topology:

                         +--> MAIN AND --> DELAY --> AND_dly --> DFF
Photon ROIs -> Drivers --|
                         +--> SECONDARY AND --> PROBE

The secondary probe:
    - Receives live, undelayed A/B driver outputs.
    - Is independent of the main AND and delay line.
    - Collects for duration * probe_duration_factor.
    - Continues collecting after the main circuit stops.

Example:
    python optoelectronic_sim_delay.py --leak --probe

    python optoelectronic_sim_delay.py --synthetic --probe \
        --duration 30 --probe-duration-factor 2

Install:
    pip install numpy opencv-python matplotlib
"""

import argparse
import hashlib
import secrets
import time
import csv
from collections import deque
from dataclasses import dataclass

import numpy as np

try:
    import cv2
except ImportError:
    cv2 = None

try:
    import matplotlib.pyplot as plt
except ImportError:
    plt = None


# ============================================================
# Configuration
# ============================================================

@dataclass
class Config:
    camera: int = 0
    synthetic: bool = False

    duration: float = 30.0
    sample_hz: float = 10.0

    delay_ms: float = 150.0
    delay_mode: str = "post"

    leak: bool = True

    probe: bool = False
    probe_err: float = 0.0
    probe_duration_factor: float = 2.0

    roi_threshold: float = 0.5
    driver_a_mode: str = "intensity"
    ema_alpha: float = 0.25

    rc_tau_ms: float = 50.0
    npn_threshold: float = 0.7

    schmitt_low: float = 0.42
    schmitt_high: float = 0.58

    seed: int = 42

    plot: bool = True
    show_camera: bool = True
    trace_file: str = ""


# ============================================================
# Helpers
# ============================================================

def clamp(value, low, high):
    return max(low, min(high, value))


def bit(value):
    return 1 if bool(value) else 0


def sha256_hex(data):
    return hashlib.sha256(data).hexdigest()


# ============================================================
# Photon source
# ============================================================

class PhotonSource:
    """
    Webcam:
        Left ROI  = detector B
        Right ROI = detector A

    Synthetic mode generates two noisy intensity signals.
    """

    def __init__(self, cfg):
        self.cfg = cfg
        self.cap = None
        self.rng = np.random.default_rng(cfg.seed)
        self.t = 0.0

        if not cfg.synthetic:
            if cv2 is None:
                raise RuntimeError(
                    "OpenCV required. Install with pip install opencv-python"
                )

            self.cap = cv2.VideoCapture(cfg.camera)

            if not self.cap.isOpened():
                raise RuntimeError(
                    f"Cannot open camera {cfg.camera}. "
                    "Try --synthetic."
                )

    def read(self, dt):
        if self.cfg.synthetic:
            return self.synthetic_read(dt)

        ok, frame = self.cap.read()

        if not ok or frame is None:
            raise RuntimeError("Could not read webcam frame.")

        height, width = frame.shape[:2]
        midpoint = width // 2

        roi_b = frame[:, :midpoint]
        roi_a = frame[:, midpoint:]

        gray_a = cv2.cvtColor(roi_a, cv2.COLOR_BGR2GRAY)
        gray_b = cv2.cvtColor(roi_b, cv2.COLOR_BGR2GRAY)

        intensity_a = float(np.mean(gray_a)) / 255.0
        intensity_b = float(np.mean(gray_b)) / 255.0

        return intensity_a, intensity_b, frame

    def synthetic_read(self, dt):
        self.t += dt

        wave_a = 0.5 + 0.35 * np.sin(
            2.0 * np.pi * 0.37 * self.t
        )

        wave_b = 0.5 + 0.35 * np.sin(
            2.0 * np.pi * 0.37 * self.t + 1.1
        )

        intensity_a = clamp(
            wave_a + self.rng.normal(0.0, 0.09),
            0.0,
            1.0,
        )

        intensity_b = clamp(
            wave_b + self.rng.normal(0.0, 0.09),
            0.0,
            1.0,
        )

        return intensity_a, intensity_b, None

    def close(self):
        if self.cap is not None:
            self.cap.release()


# ============================================================
# Driver A
# ============================================================

class DriverA:
    def __init__(self, cfg):
        self.cfg = cfg
        self.ema = 0.0

    def step(self, intensity):
        alpha = self.cfg.ema_alpha

        self.ema = (
            alpha * intensity
            + (1.0 - alpha) * self.ema
        )

        if self.cfg.driver_a_mode == "parity":
            quantised = int(
                clamp(self.ema, 0.0, 1.0) * 65535
            )

            digest = hashlib.sha256(
                str(quantised).encode("utf-8")
            ).digest()

            return bool(digest[0] & 1)

        return self.ema >= self.cfg.roi_threshold


# ============================================================
# Driver B — Schmitt trigger
# ============================================================

class DriverB:
    def __init__(self, cfg):
        self.cfg = cfg
        self.state = False

    def step(self, intensity):
        if intensity >= self.cfg.schmitt_high:
            self.state = True

        elif intensity <= self.cfg.schmitt_low:
            self.state = False

        return self.state


# ============================================================
# RC node
# ============================================================

class RCNode:
    def __init__(self, tau_ms):
        self.tau = max(0.000001, tau_ms / 1000.0)
        self.voltage = 0.0

    def step(self, input_value, dt):
        alpha = 1.0 - np.exp(-dt / self.tau)

        target = 1.0 if input_value else 0.0

        self.voltage += alpha * (
            target - self.voltage
        )

        return self.voltage


# ============================================================
# NPN threshold link
# ============================================================

class IfThenLink:
    def __init__(self, threshold=0.7):
        self.threshold = threshold

    def step(self, voltage):
        return voltage > self.threshold


# ============================================================
# Main delay line
# ============================================================

class DelayLine:
    """
    Discrete delay line.

    Delay resolution is limited by sample_hz.
    At 10 Hz, the time resolution is 100 ms.
    """

    def __init__(self, delay_ms, sample_hz):
        self.sample_hz = max(0.1, sample_hz)
        self.dt = 1.0 / self.sample_hz

        self.delay_ms = max(0.0, delay_ms)

        self.delay_samples = int(round(
            (self.delay_ms / 1000.0) / self.dt
        ))

        self.queue = deque(
            [False] * (self.delay_samples + 1)
        )

    def step(self, value):
        self.queue.append(bool(value))
        return self.queue.popleft()

    @property
    def effective_delay_ms(self):
        return (
            self.delay_samples
            * 1000.0
            / self.sample_hz
        )


# ============================================================
# Logic
# ============================================================

def and_gate(a, b):
    return bool(a and b)


def or_gate(a, b):
    return bool(a or b)


# ============================================================
# D flip-flop
# ============================================================

class DFlipFlop:
    def __init__(self):
        self.q = False

    def clock(self, d):
        self.q = bool(d)
        return self.q


# ============================================================
# Commitment
# ============================================================

class Commitment:
    def __init__(self):
        self.secret_text = format(
            secrets.randbits(64),
            "064b",
        )

        self.salt = secrets.token_bytes(16)

        self.digest = sha256_hex(
            self.salt + self.secret_text.encode("ascii")
        )

    def verify(self, candidate):
        candidate = str(candidate)

        if len(candidate) != len(self.secret_text):
            return False

        return sha256_hex(
            self.salt + candidate.encode("ascii")
        ) == self.digest


# ============================================================
# AND accumulator
# ============================================================

class AndAccumulator:
    def __init__(self):
        self.value = None
        self.count = 0

    def update(self, value):
        value = bit(value)

        if self.value is None:
            self.value = value
        else:
            self.value &= value

        self.count += 1
        return self.value


# ============================================================
# Independent secondary AND probe
# ============================================================

class SecondaryAndProbe:
    """
    This branch receives live A and B signals.

    It is completely independent of:
        - Main AND output
        - Main delay line
        - Delayed A
        - Delayed B
        - D flip-flop

    Probe measurement noise is applied after the secondary AND gate.
    """

    def __init__(self, error_probability=0.0, seed=1):
        self.error_probability = clamp(
            error_probability,
            0.0,
            1.0,
        )

        self.rng = np.random.default_rng(seed)

        self.truth_history = []
        self.measurement_history = []
        self.time_history = []

    def step(self, a, b, elapsed):
        # Independent secondary AND gate.
        truth = and_gate(a, b)

        # Simulated measurement noise.
        measured = truth

        if self.rng.random() < self.error_probability:
            measured = not measured

        self.truth_history.append(bit(truth))
        self.measurement_history.append(bit(measured))
        self.time_history.append(elapsed)

        return truth, measured

    def summary(self):
        if not self.truth_history:
            return {
                "samples": 0,
                "duration": 0.0,
                "error": None,
                "truth_duty": 0.0,
                "measurement_duty": 0.0,
            }

        truth = np.asarray(
            self.truth_history,
            dtype=np.int8,
        )

        measured = np.asarray(
            self.measurement_history,
            dtype=np.int8,
        )

        error = float(np.mean(truth != measured))

        duration = (
            self.time_history[-1]
            if self.time_history
            else 0.0
        )

        return {
            "samples": len(truth),
            "duration": duration,
            "error": error,
            "truth_duty": float(np.mean(truth)),
            "measurement_duty": float(np.mean(measured)),
        }


# ============================================================
# Main circuit meter
# ============================================================

class LeakMeter:
    def __init__(self):
        self.y_values = []
        self.and_values = []
        self.delayed_values = []

    def slot(self, y, and_value, and_delayed):
        self.y_values.append(bit(y))
        self.and_values.append(bit(and_value))
        self.delayed_values.append(bit(and_delayed))

    def summary(self):
        y = np.asarray(self.y_values, dtype=np.int8)

        and_values = np.asarray(
            self.and_values,
            dtype=np.int8,
        )

        delayed = np.asarray(
            self.delayed_values,
            dtype=np.int8,
        )

        zero_mask = y == 0

        if np.any(zero_mask):
            p_leak = float(np.mean(delayed[zero_mask]))
        else:
            p_leak = 0.0

        return {
            "samples": len(y),
            "p_leak": p_leak,
            "main_and_duty": (
                float(np.mean(and_values))
                if len(and_values) else 0.0
            ),
            "delayed_and_duty": (
                float(np.mean(delayed))
                if len(delayed) else 0.0
            ),
        }


# ============================================================
# Trace
# ============================================================

class Trace:
    def __init__(self):
        self.rows = []

    def add(self, **kwargs):
        self.rows.append(kwargs)

    def save_csv(self, filename):
        if not self.rows:
            return

        keys = list(dict.fromkeys(
            key
            for row in self.rows
            for key in row
        ))

        with open(
            filename,
            "w",
            newline="",
            encoding="utf-8",
        ) as f:
            writer = csv.DictWriter(
                f,
                fieldnames=keys,
            )

            writer.writeheader()
            writer.writerows(self.rows)


# ============================================================
# Main session
# ============================================================

def run_session(cfg):
    dt = 1.0 / cfg.sample_hz

    main_duration = cfg.duration

    if cfg.probe:
        probe_duration = (
            cfg.duration * cfg.probe_duration_factor
        )
    else:
        probe_duration = cfg.duration

    total_duration = max(
        main_duration,
        probe_duration,
    )

    total_samples = int(
        np.ceil(total_duration * cfg.sample_hz)
    )

    main_samples = int(
        np.ceil(main_duration * cfg.sample_hz)
    )

    source = PhotonSource(cfg)

    driver_a = DriverA(cfg)
    driver_b = DriverB(cfg)

    rc = RCNode(cfg.rc_tau_ms)
    npn = IfThenLink(cfg.npn_threshold)

    delay = DelayLine(
        cfg.delay_ms,
        cfg.sample_hz,
    )

    dff = DFlipFlop()

    accumulator = AndAccumulator()
    meter = LeakMeter()

    probe = SecondaryAndProbe(
        cfg.probe_err,
        cfg.seed + 100,
    )

    commitment = Commitment()
    trace = Trace()

    print("\n=== Webcam Optoelectronic AND Circuit ===")
    print(
        f"Input mode:       "
        f"{'synthetic' if cfg.synthetic else 'webcam'}"
    )
    print(f"Main delay mode:  {cfg.delay_mode}")
    print(f"Requested delay:  {cfg.delay_ms:.2f} ms")
    print(
        f"Effective delay:  "
        f"{delay.effective_delay_ms:.2f} ms"
    )
    print(f"Leak path:        {'enabled' if cfg.leak else 'disabled'}")
    print(f"Secondary probe:  {'enabled' if cfg.probe else 'disabled'}")
    print(f"Main duration:    {main_duration:.2f} seconds")

    if cfg.probe:
        print(
            f"Probe duration:   {probe_duration:.2f} seconds"
        )
        print(
            f"Probe multiplier: {cfg.probe_duration_factor:.2f}x"
        )

    print(f"Total duration:   {total_duration:.2f} seconds")
    print(f"Sample rate:      {cfg.sample_hz:.2f} Hz")
    print("----------------------------------------")
    print("Commitment:", commitment.digest)
    print("----------------------------------------")

    start = time.monotonic()
    next_sample = start

    try:
        for index in range(total_samples):
            elapsed = index * dt

            main_active = index < main_samples
            probe_active = cfg.probe and (
                elapsed < probe_duration
            )

            # ----------------------------------------------------
            # Read live photon-derived detector inputs.
            # These continue throughout the probe-only period.
            # ----------------------------------------------------

            intensity_a, intensity_b, frame = source.read(dt)

            # ----------------------------------------------------
            # Detector drivers
            # ----------------------------------------------------

            a = driver_a.step(intensity_a)

            b_driver = driver_b.step(intensity_b)

            # Driver B -> RC -> NPN threshold.
            rc_voltage = rc.step(b_driver, dt)
            b_out = npn.step(rc_voltage)

            # ----------------------------------------------------
            # Independent secondary probe
            #
            # This is evaluated from raw live a and b_out.
            # It is not affected by the main delay.
            # ----------------------------------------------------

            probe_truth = None
            probe_measurement = None

            if probe_active:
                probe_truth, probe_measurement = probe.step(
                    a,
                    b_out,
                    elapsed,
                )

            # ----------------------------------------------------
            # Main circuit runs only during main_duration.
            # ----------------------------------------------------

            if main_active:

                if cfg.delay_mode == "a":
                    main_a = delay.step(a)
                    main_b = b_out

                    main_and = and_gate(
                        main_a,
                        main_b,
                    )

                    and_delayed = main_and

                elif cfg.delay_mode == "b":
                    main_a = a
                    main_b = delay.step(b_out)

                    main_and = and_gate(
                        main_a,
                        main_b,
                    )

                    and_delayed = main_and

                else:
                    main_a = a
                    main_b = b_out

                    main_and = and_gate(
                        main_a,
                        main_b,
                    )

                    and_delayed = delay.step(main_and)

                y = or_gate(main_a, main_b)

                if cfg.leak:
                    d = or_gate(y, and_delayed)
                else:
                    d = y

                q = dff.clock(d)

                accumulator.update(and_delayed)

                meter.slot(
                    y,
                    main_and,
                    and_delayed,
                )

            else:
                # The main circuit has stopped.
                # Only the independent probe continues.
                main_a = np.nan
                main_b = np.nan
                main_and = np.nan
                and_delayed = np.nan
                y = np.nan
                d = np.nan
                q = np.nan

            # ----------------------------------------------------
            # Trace collection
            # ----------------------------------------------------

            trace.add(
                time=elapsed,
                phase=(
                    "main_and_probe"
                    if main_active
                    else "probe_only"
                ),
                intensity_a=intensity_a,
                intensity_b=intensity_b,
                driver_a=bit(a),
                driver_b=bit(b_driver),
                rc_voltage=rc_voltage,
                b_out=bit(b_out),
                main_a=main_a,
                main_b=main_b,
                main_and=main_and,
                and_delayed=and_delayed,
                y=y,
                d=d,
                q=q,
                probe_truth=(
                    bit(probe_truth)
                    if probe_truth is not None
                    else np.nan
                ),
                probe_measurement=(
                    bit(probe_measurement)
                    if probe_measurement is not None
                    else np.nan
                ),
            )

            # ----------------------------------------------------
            # Webcam display
            # ----------------------------------------------------

            if (
                frame is not None
                and cfg.show_camera
                and cv2 is not None
            ):
                height, width = frame.shape[:2]
                midpoint = width // 2

                cv2.line(
                    frame,
                    (midpoint, 0),
                    (midpoint, height),
                    (0, 255, 255),
                    2,
                )

                if main_active:
                    status = (
                        f"MAIN A={bit(a)} B={bit(b_out)} "
                        f"AND={bit(main_and)} "
                        f"DELAY={bit(and_delayed)} "
                        f"D={bit(d)} Q={bit(q)}"
                    )
                else:
                    status = "MAIN CIRCUIT STOPPED - PROBE ONLY"

                cv2.putText(
                    frame,
                    status,
                    (10, 25),
                    cv2.FONT_HERSHEY_SIMPLEX,
                    0.5,
                    (0, 255, 0),
                    2,
                )

                if cfg.probe:
                    probe_status = (
                        f"PROBE AND={bit(probe_truth)} "
                        f"MEASURED={bit(probe_measurement)}"
                    )

                    cv2.putText(
                        frame,
                        probe_status,
                        (10, 50),
                        cv2.FONT_HERSHEY_SIMPLEX,
                        0.5,
                        (255, 200, 0),
                        2,
                    )

                cv2.imshow(
                    "Optoelectronic AND Circuit",
                    frame,
                )

                key = cv2.waitKey(1) & 0xFF

                if key == ord("q") or key == 27:
                    break

            # ----------------------------------------------------
            # Console progress
            # ----------------------------------------------------

            if index % max(
                1,
                int(cfg.sample_hz),
            ) == 0:

                if main_active:
                    status = (
                        f"MAIN A={bit(a)} B={bit(b_out)} "
                        f"AND={bit(main_and)} "
                        f"AND_dly={bit(and_delayed)} "
                        f"D={bit(d)} Q={bit(q)}"
                    )
                else:
                    status = "MAIN STOPPED"

                if cfg.probe:
                    status += (
                        f" | PROBE={bit(probe_truth)}"
                        f" MEASURED={bit(probe_measurement)}"
                    )

                print(
                    f"\rElapsed {elapsed:7.2f}/"
                    f"{total_duration:.2f}s | {status}",
                    end="",
                    flush=True,
                )

            # ----------------------------------------------------
            # Fixed-rate sampling
            # ----------------------------------------------------

            next_sample += dt
            sleep_time = next_sample - time.monotonic()

            if sleep_time > 0:
                time.sleep(sleep_time)

    except KeyboardInterrupt:
        print("\nInterrupted by user.")

    finally:
        source.close()

        if cv2 is not None:
            cv2.destroyAllWindows()

    # ============================================================
    # Results
    # ============================================================

    main_result = meter.summary()
    probe_result = probe.summary()
    accumulator_result = {
        "value": accumulator.value,
        "count": accumulator.count,
    }

    print("\n\n=== Main Circuit Results ===")
    print(f"Main samples:          {main_result['samples']}")
    print(
        f"Main AND duty:         "
        f"{main_result['main_and_duty']:.4f}"
    )
    print(
        f"Delayed AND duty:      "
        f"{main_result['delayed_and_duty']:.4f}"
    )
    print(
        f"P(AND_dly=1 | Y=0):    "
        f"{main_result['p_leak']:.4f}"
    )
    print(
        f"AND accumulator:       "
        f"{accumulator_result['value']}"
    )

    if cfg.probe:
        print("\n=== Extended Secondary Probe Results ===")
        print(
            f"Probe samples:         "
            f"{probe_result['samples']}"
        )
        print(
            f"Probe collection time: "
            f"{probe_result['duration']:.2f} seconds"
        )
        print(
            f"Probe AND duty:        "
            f"{probe_result['truth_duty']:.4f}"
        )
        print(
            f"Probe measured duty:   "
            f"{probe_result['measurement_duty']:.4f}"
        )

        if probe_result["error"] is not None:
            print(
                f"Probe measurement error: "
                f"{probe_result['error']:.4f}"
            )

        print(
            "Probe topology:        "
            "independent parallel AND; no main delay"
        )

    print("\n=== Commitment ===")
    print("Commitment:", commitment.digest)
    print("Salt:", commitment.salt.hex())
    print("Secret length:", len(commitment.secret_text))
    print("Verification: no candidate supplied.")

    if cfg.trace_file:
        trace.save_csv(cfg.trace_file)
        print(f"\nTrace saved to: {cfg.trace_file}")

    if cfg.plot and plt is not None:
        plot_trace(trace, cfg)

    return {
        "main": main_result,
        "probe": probe_result,
        "accumulator": accumulator_result,
        "commitment": commitment.digest,
        "trace": trace,
    }


# ============================================================
# Plotting
# ============================================================

def plot_trace(trace, cfg):
    if plt is None:
        return

    rows = trace.rows

    if not rows:
        return

    def column(name):
        return [row.get(name, np.nan) for row in rows]

    t = column("time")

    fig, axes = plt.subplots(
        4,
        1,
        figsize=(13, 11),
        sharex=True,
    )

    axes[0].plot(
        t,
        column("intensity_a"),
        label="Detector A",
    )

    axes[0].plot(
        t,
        column("intensity_b"),
        label="Detector B",
    )

    axes[0].set_ylabel("Intensity")
    axes[0].legend()
    axes[0].grid(True, alpha=0.25)

    axes[1].step(
        t,
        column("driver_a"),
        where="post",
        label="Driver A",
    )

    axes[1].step(
        t,
        column("b_out"),
        where="post",
        label="B out",
    )

    axes[1].plot(
        t,
        column("rc_voltage"),
        label="RC voltage",
    )

    axes[1].set_ylabel("Drivers")
    axes[1].legend()
    axes[1].grid(True, alpha=0.25)

    axes[2].step(
        t,
        column("main_and"),
        where="post",
        label="Main AND",
    )

    axes[2].step(
        t,
        column("and_delayed"),
        where="post",
        label="Main delayed AND",
    )

    if cfg.probe:
        axes[2].step(
            t,
            column("probe_truth"),
            where="post",
            label="Secondary AND truth",
        )

        axes[2].step(
            t,
            column("probe_measurement"),
            where="post",
            label="Secondary probe measurement",
            alpha=0.7,
        )

    axes[2].set_ylabel("AND branches")
    axes[2].legend()
    axes[2].grid(True, alpha=0.25)

    axes[3].step(
        t,
        column("y"),
        where="post",
        label="Y",
    )

    axes[3].step(
        t,
        column("d"),
        where="post",
        label="D",
    )

    axes[3].step(
        t,
        column("q"),
        where="post",
        label="DFF Q",
    )

    axes[3].set_ylabel("Main output")
    axes[3].set_xlabel("Time (seconds)")
    axes[3].legend()
    axes[3].grid(True, alpha=0.25)

    if cfg.probe:
        for axis in axes:
            axis.axvline(
                cfg.duration,
                linestyle="--",
                label="Main circuit stops",
            )

    fig.suptitle(
        "Optoelectronic Circuit — Extended Independent Probe"
    )

    fig.tight_layout()
    plt.show()


# ============================================================
# CLI
# ============================================================

def parse_args():
    parser = argparse.ArgumentParser(
        description=(
            "Webcam optoelectronic AND circuit with "
            "an extended independent secondary probe."
        )
    )

    parser.add_argument("--camera", type=int, default=0)
    parser.add_argument("--synthetic", action="store_true")

    parser.add_argument("--duration", type=float, default=5.0)
    parser.add_argument("--sample-hz", type=float, default=100.0)

    parser.add_argument("--delay-ms", type=float, default=10.0)

    parser.add_argument(
        "--delay-mode",
        choices=("post", "a", "b"),
        default="post",
    )

    parser.add_argument(
        "--leak",
        action="store_true",
        default=True,
    )

    parser.add_argument(
        "--no-leak",
        action="store_false",
        dest="leak",
    )

    parser.add_argument("--probe", action="store_true")
    parser.add_argument("--probe-err", type=float, default=0.0)

    parser.add_argument(
        "--probe-duration-factor",
        type=float,
        default=2.0,
        help=(
            "Total probe duration as a multiple of --duration. "
            "Default: 2.0"
        ),
    )

    parser.add_argument(
        "--roi-threshold",
        type=float,
        default=0.5,
    )

    parser.add_argument(
        "--driver-a-mode",
        choices=("intensity", "parity"),
        default="intensity",
    )

    parser.add_argument("--ema-alpha", type=float, default=0.25)

    parser.add_argument("--rc-tau-ms", type=float, default=50.0)
    parser.add_argument("--npn-threshold", type=float, default=0.7)

    parser.add_argument("--schmitt-low", type=float, default=0.42)
    parser.add_argument("--schmitt-high", type=float, default=0.58)

    parser.add_argument("--seed", type=int, default=42)

    parser.add_argument(
        "--no-plot",
        action="store_false",
        dest="plot",
    )

    parser.add_argument(
        "--no-camera-window",
        action="store_false",
        dest="show_camera",
    )

    parser.add_argument("--trace-file", type=str, default="")

    return parser.parse_args()


def main():
    args = parse_args()

    if args.duration <= 0:
        raise SystemExit("--duration must be positive.")

    if args.sample_hz <= 0:
        raise SystemExit("--sample-hz must be positive.")

    if args.delay_ms < 0:
        raise SystemExit("--delay-ms cannot be negative.")

    if args.probe_duration_factor < 1.0:
        raise SystemExit(
            "--probe-duration-factor must be at least 1.0."
        )

    if not 0.0 <= args.probe_err <= 1.0:
        raise SystemExit("--probe-err must be between 0 and 1.")

    if not 0.0 <= args.ema_alpha <= 1.0:
        raise SystemExit("--ema-alpha must be between 0 and 1.")

    if args.schmitt_low >= args.schmitt_high:
        raise SystemExit(
            "--schmitt-low must be lower than --schmitt-high."
        )

    cfg = Config(
        camera=args.camera,
        synthetic=args.synthetic,
        duration=args.duration,
        sample_hz=args.sample_hz,
        delay_ms=args.delay_ms,
        delay_mode=args.delay_mode,
        leak=args.leak,
        probe=args.probe,
        probe_err=args.probe_err,
        probe_duration_factor=args.probe_duration_factor,
        roi_threshold=args.roi_threshold,
        driver_a_mode=args.driver_a_mode,
        ema_alpha=args.ema_alpha,
        rc_tau_ms=args.rc_tau_ms,
        npn_threshold=args.npn_threshold,
        schmitt_low=args.schmitt_low,
        schmitt_high=args.schmitt_high,
        seed=args.seed,
        plot=args.plot,
        show_camera=args.show_camera,
        trace_file=args.trace_file,
    )

    run_session(cfg)


if __name__ == "__main__":
    main()
