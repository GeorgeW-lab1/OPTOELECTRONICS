#!/usr/bin/env python3
"""
RP-GHOST Live Webcam Photonic Frame-Differencing & Phase-Mapping Pipeline
Beam-Phase Correlation Theory Architecture
"""

import hashlib
import json
import time
import threading
import queue
import sys

import numpy as np

try:
    import cv2
    HAS_CV2 = True
except ImportError:
    HAS_CV2 = False


# ============================================================================
# CONFIGURATION
# ============================================================================

LAMBDA = 10000.0
SIGMA_C = 0.005
N_SLOTS = 32
WEBCAM_INDEX = 0


# ============================================================================
# HELPERS & TIMESTAMP ENCODING
# ============================================================================

def format_clock_time(timestamp_ns):
    seconds = timestamp_ns / 1e9
    clock = time.strftime("%H:%M:%S", time.localtime(seconds))
    ms = int((timestamp_ns % 1_000_000_000) // 1_000_000)
    return f"{clock}.{ms:03d}"


def timestamp_to_code(timestamp_ns):
    ms = (int(timestamp_ns) // 1_000_000) % 60000
    return ms & 0xFFFF


def encode_timestamp_bits(timestamp_ns):
    time_code = timestamp_to_code(timestamp_ns)
    time_bits = [(time_code >> (15 - k)) & 1 for k in range(16)]
    padding_bits = [(time_code >> k) & 1 for k in range(16)]
    return np.array(time_bits + padding_bits, dtype=int)


def bits_to_code(bits):
    code = 0
    for bit in bits:
        code = (code << 1) | (int(bit) & 1)
    return code


def decode_timestamp_from_code(code, reference_ns):
    minute_start = (int(reference_ns) // 60_000_000_000) * 60_000_000_000
    decoded_ns = minute_start + (int(code) & 0xFFFF) * 1_000_000
    return decoded_ns, format_clock_time(decoded_ns)


# ============================================================================
# LIVE WEBCAM PHOTONIC ACQUISITION THREAD
# ============================================================================

class WebcamPhotonicFeed(threading.Thread):
    def __init__(self, frame_queue):
        super().__init__(daemon=True)
        self.frame_queue = frame_queue
        self.running = True

    def run(self):
        if not HAS_CV2:
            print("[WARNING] 'opencv-python' (cv2) not available. Running in simulated photonic noise mode.")
            self._run_mock_feed()
            return

        cap = cv2.VideoCapture(WEBCAM_INDEX)
        if not cap.isOpened():
            print(f"[WARNING] Could not open webcam index {WEBCAM_INDEX}. Falling back to simulated feed.")
            self._run_mock_feed()
            return

        ret, prev_frame = cap.read()
        if not ret:
            cap.release()
            self._run_mock_feed()
            return

        prev_gray = cv2.cvtColor(prev_frame, cv2.COLOR_BGR2GRAY)

        while self.running:
            ret, frame = cap.read()
            if not ret:
                time.sleep(0.05)
                continue

            gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
            # Compute optical frame-differencing (photonic intensity fluctuation proxy)
            diff = cv2.absdiff(gray, prev_gray)
            mean_intensity = float(np.mean(gray))
            mean_motion = float(np.mean(diff))

            prev_gray = gray

            self.frame_queue.put({
                "mean_intensity": mean_intensity,
                "motion_energy": mean_motion,
                "timestamp": time.time_ns()
            })
            time.sleep(0.033) # ~30 FPS capture rate

        cap.release()

    def _run_mock_feed(self):
        while self.running:
            mock_motion = float(np.random.exponential(2.5))
            self.frame_queue.put({
                "mean_intensity": 128.0,
                "motion_energy": mock_motion,
                "timestamp": time.time_ns()
            })
            time.sleep(0.033)

    def stop(self):
        self.running = False


# ============================================================================
# OPTOELECTRONIC VIEWPORT WITH PHOTONIC FRAME MODULATION
# ============================================================================

class OptoelectronicViewport:
    def __init__(self, lambd=LAMBDA, sigma_c=SIGMA_C):
        self.lambd = lambd
        self.sigma_c = sigma_c

    def generate_window_block(self, n_windows, n_slots, tilt=None, motion_energy=0.0):
        # Modulate effective quantum noise amplitude by real-time optical motion energy
        motion_scale = 1.0 + min(max(motion_energy / 20.0, 0.0), 10.0)
        effective_sigma = self.sigma_c * motion_scale

        shared_noise = np.random.normal(0.0, effective_sigma, size=(n_windows, 1))
        lam = self.lambd * (1.0 + shared_noise)
        counts = np.random.poisson(np.clip(lam, 1.0, None), size=(n_windows, n_slots))
        Z = (counts - self.lambd) / np.sqrt(self.lambd)
        
        if tilt is not None:
            # Apply unitary beam-phase mapping modulated by optical motion structure
            Z += tilt * (1.0 + 0.02 * motion_energy)
            
        return Z


# ============================================================================
# COMPUTATIONAL PIPELINE PROCESSOR
# ============================================================================

class GhostPipelineProcessor(threading.Thread):
    def __init__(self, output_queue, frame_queue):
        super().__init__(daemon=True)
        self.output_queue = output_queue
        self.frame_queue = frame_queue
        self.running = True

    def run(self):
        mock_height = 850000
        viewport = OptoelectronicViewport()
        current_frame_data = {"mean_intensity": 128.0, "motion_energy": 0.0}

        while self.running:
            # Drain latest webcam optical frame statistics
            while not self.frame_queue.empty():
                try:
                    current_frame_data = self.frame_queue.get_nowait()
                except queue.Empty:
                    break

            mock_height += 1
            start_ns = time.time_ns()

            # Proof-of-Work / Hash commitment search loop
            nonce = 0
            block_hash = ""
            target_prefix = "0000"
            
            while True:
                nonce += 1
                header_data = f"{mock_height}:{nonce}:{current_frame_data['motion_energy']}:{start_ns}"
                block_hash = hashlib.sha256(header_data.encode()).hexdigest()
                if block_hash.startswith(target_prefix) or nonce > 12000:
                    break

            completion_ns = time.time_ns()
            mining_duration_ms = (completion_ns - start_ns) / 1_000_000

            # Encode completion timestamp and apply optical motion-modulated unitary mapping
            bits = encode_timestamp_bits(completion_ns)
            tilt = 2.0 * 0.1 * (bits - 0.5)

            Z = viewport.generate_window_block(1000, N_SLOTS, tilt, motion_energy=current_frame_data["motion_energy"])
            m = Z.mean(axis=0)
            decoded_bits = (m > 0).astype(int)
            decoded_code = bits_to_code(decoded_bits[:16])
            _, decoded_time = decode_timestamp_from_code(decoded_code, completion_ns)

            result = {
                "height": mock_height,
                "hash": block_hash,
                "nonce": nonce,
                "mean_intensity": current_frame_data["mean_intensity"],
                "motion_energy": current_frame_data["motion_energy"],
                "start_time": format_clock_time(start_ns),
                "completion_ns": completion_ns,
                "completion_time": format_clock_time(completion_ns),
                "mining_duration_ms": mining_duration_ms,
                "decoded_time": decoded_time,
                "exact_bits": int(np.sum(decoded_bits[:16] == bits[:16]))
            }

            self.output_queue.put(result)
            time.sleep(0.5)

    def stop(self):
        self.running = False


# ============================================================================
# MAIN ENTRY POINT
# ============================================================================

def main():
    print("=" * 84)
    print(" RP-GHOST: LIVE WEBCAM PHOTONIC FRAME-DIFFERENCING & OPTOELECTRONIC PIPELINE")
    print("=" * 84)

    frame_queue = queue.Queue()
    output_queue = queue.Queue()

    webcam_feed = WebcamPhotonicFeed(frame_queue)
    processor = GhostPipelineProcessor(output_queue, frame_queue)

    webcam_feed.start()
    processor.start()

    try:
        while True:
            try:
                res = output_queue.get(timeout=0.1)
            except queue.Empty:
                continue

            print()
            print("-" * 84)
            print(f"  [BLOCK #{res['height']}] Nonce: {res['nonce']:,} | Hash: {res['hash'][:16]}...")
            print(f"  [PHOTONIC]    Intensity: {res['mean_intensity']:.1f} | Motion Energy: {res['motion_energy']:.2f}")
            print(f"  [WORKLOAD]    Started: {res['start_time']} | Duration: {res['mining_duration_ms']:.2f} ms")
            print(f"  [COMPLETION]  {res['completion_time']} ({res['completion_ns']} ns)")
            print(f"  [DECODED TS]  {res['decoded_time']} | Phase Verification: {res['exact_bits']}/16 bits")
            print("-" * 84)

    except KeyboardInterrupt:
        print("\n[STOP] Shutting down pipeline gracefully...")
    finally:
        processor.stop()
        webcam_feed.stop()
        processor.join(timeout=1.0)
        webcam_feed.join(timeout=1.0)
        print("[DONE] Pipeline terminated successfully.")


if __name__ == "__main__":
    main()
