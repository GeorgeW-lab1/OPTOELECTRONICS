"""
Actually trying to use the photon decoder (decode_v2) to do proof-of-work mining,
and showing what happens.

Run from the same directory as photon_suite.py, or adjust the sys.path line below.
"""
import hashlib, time
import numpy as np
import sys
sys.path.insert(0, '.')
from photon_suite import PhotonCircuit, PhotonStatistics, decode_v2, CLK


def leading_zero_bits(hexdigest):
    n = int(hexdigest, 16)
    total = len(hexdigest) * 4
    return total if n == 0 else total - n.bit_length()


def pow_verify(prefix, difficulty, nbits):
    def verify(nonce):
        h = hashlib.sha256(f"{prefix}:{nonce}".encode()).hexdigest()
        return leading_zero_bits(h) >= difficulty
    return verify


nbits = 24          # nonce space: 2^24 possible nonces
difficulty = 16     # need 16 leading zero bits -> expect ~65536 tries for honest search
prefix = "block123"
verify = pow_verify(prefix, difficulty, nbits)

print(f"PoW task: find nonce in [0, 2^{nbits}) such that sha256('{prefix}:nonce') "
      f"has >= {difficulty} leading zero bits")
print(f"expected honest search cost ~ 2^{difficulty} = {2**difficulty:,} hashes\n")

# ---- Attempt 1: run the actual photon decoder on this oracle, latch=0 (no known secret) ----
print("=== Attempt: photon-guided decode_v2 on the PoW oracle ===")
rng = np.random.default_rng(0)
circ = PhotonCircuit(0, nbits, rng)   # no secret exists to latch - there is no "right answer" yet
stats = PhotonStatistics(nbits)
budget = 200_000
max_words = 50
total_tries = 0
found = None
t0 = time.time()
for w in range(1, max_words + 1):
    stats.update(circ.word())
    cand, nU, tries = decode_v2(stats, verify, nbits, budget=budget - total_tries)
    total_tries += tries
    if cand is not None:
        found = cand
        break
    if total_tries >= budget:
        break
elapsed = time.time() - t0
print(f"words read={w}  |U| last ={nU}  candidate hashes tried={total_tries}  "
      f"found={found}  time={elapsed:.2f}s")
if found is not None:
    h = hashlib.sha256(f'{prefix}:{found}'.encode()).hexdigest()
    print(f"  -> hash={h}  leading_zeros={leading_zero_bits(h)}")
else:
    print("  -> FAILED: photon-guided search did not find a valid nonce within budget")

print()
# ---- Attempt 2: honest sequential search (what you'd actually do for real PoW) ----
print("=== Honest baseline: plain sequential nonce search ===")
t0 = time.time()
nonce = 0
tries = 0
while True:
    tries += 1
    h = hashlib.sha256(f"{prefix}:{nonce}".encode()).hexdigest()
    if leading_zero_bits(h) >= difficulty:
        break
    nonce += 1
    if tries >= budget:
        break
elapsed = time.time() - t0
if leading_zero_bits(h) >= difficulty:
    print(f"found nonce={nonce}  hash={h}  leading_zeros={leading_zero_bits(h)}  "
          f"hashes={tries}  time={elapsed:.3f}s")
else:
    print(f"not found within budget={budget}")
