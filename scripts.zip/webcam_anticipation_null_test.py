#!/usr/bin/env python3
"""
Webcam commit-reveal null test (RP-GHOST Steps 5-6, simplified).

This does NOT decode information from the future. It tests whether webcam
sensor noise correlates with a code that is created AFTER the noise was
recorded. Physics predicts it will not. The script is built so that a real
effect, if one existed, would be detectable, and so that a false positive
(a causal leak) cannot occur by construction.

Arms
  before : code is derived (chained PoW) BEFORE the noise window.
           Leak would be possible here, so it acts as a leak detector.
  after  : code is derived AFTER the noise window, from a seed that does
           not exist during capture. Any correlation here is the anomaly.
  control: 'after' arm plus a software-injected shift of eps*sigma.
           Must be recovered, otherwise the test has no power.

Usage
  python webcam_anticipation_null_test.py --simulate --trials 2000
  python webcam_anticipation_null_test.py --trials 300 --frames 20   # real webcam
Requires: numpy; opencv-python for the real webcam.
"""
import argparse
import hashlib
import os
import time

import numpy as np


# ---------- chained proof-of-work (c_{N+1} = H(c_N || x_N)) ----------
def chained_pow(seed: bytes, K: int, d: int) -> bytes:
    """K sequential searches, each needing d leading zero bits. Returns final hash."""
    c = seed
    for _ in range(K):
        x = 0
        while True:
            h = hashlib.sha256(c + x.to_bytes(8, "big")).digest()
            if int.from_bytes(h, "big") >> (256 - d) == 0:
                break
            x += 1
        c = h
    return c


def code_bit(K: int, d: int) -> int:
    return chained_pow(os.urandom(16), K, d)[0] & 1


# ---------- noise source ----------
class Noise:
    def __init__(self, simulate: bool, frames: int, rng):
        self.simulate, self.frames, self.rng = simulate, frames, rng
        self.cap = None
        if not simulate:
            import cv2  # noqa
            self.cv2 = cv2
            self.cap = cv2.VideoCapture(0)
            if not self.cap.isOpened():
                raise SystemExit("No webcam found. Use --simulate.")

    def window(self) -> float:
        """One scalar per trial: mean abs frame-to-frame residual (sensor noise level)."""
        if self.simulate:
            return float(self.rng.normal(0.0, 1.0))
        prev, acc = None, []
        for _ in range(self.frames):
            ok, f = self.cap.read()
            if not ok:
                raise SystemExit("Webcam read failed.")
            g = self.cv2.cvtColor(f, self.cv2.COLOR_BGR2GRAY).astype(np.float32)
            if prev is not None:
                acc.append(np.mean(np.abs(g - prev)))
            prev = g
        return float(np.mean(acc))

    def close(self):
        if self.cap is not None:
            self.cap.release()


# ---------- statistics ----------
def analyse(stats, bits):
    s = np.asarray(stats, float)
    b = np.asarray(bits, float)
    s = (s - s.mean()) / (s.std() + 1e-12)
    r = float(np.corrcoef(s, b)[0, 1])
    z = r * np.sqrt(len(s))  # ~N(0,1) under the null
    rng = np.random.default_rng(1)
    perm = np.array([np.corrcoef(s, rng.permutation(b))[0, 1] for _ in range(2000)])
    p = float((np.sum(np.abs(perm) >= abs(r)) + 1) / (len(perm) + 1))
    return r, z, p


def run_arm(name, n, noise, K, d, eps, rng, precommit):
    stats, bits = [], []
    for _ in range(n):
        pre = code_bit(K, d) if precommit else None
        s = noise.window()
        bit = pre if precommit else code_bit(K, d)  # 'after': code born after capture
        if eps:  # software-injected positive control, clearly labelled
            sigma = 1.0 if noise.simulate else 1.0
            s += eps * sigma * (2 * bit - 1)
        stats.append(s)
        bits.append(bit)
    if eps and not noise.simulate:
        pass  # injected shift is in z-units after standardisation below
    return stats, bits


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--trials", type=int, default=30)
    ap.add_argument("--frames", type=int, default=20)
    ap.add_argument("--K", type=int, default=3, help="chained PoW steps")
    ap.add_argument("--d", type=int, default=8, help="difficulty bits per step")
    ap.add_argument("--eps", type=float, default=0.2,
                    help="positive-control shift in sigma units")
    ap.add_argument("--simulate", action="store_true", help="use Gaussian noise, no webcam")
    ap.add_argument("--seed", type=int, default=0)
    a = ap.parse_args()

    rng = np.random.default_rng(a.seed)
    noise = Noise(a.simulate, a.frames, rng)
    t0 = time.time()
    try:
        arms = [("before (leak detector)", 0.0, True),
                ("after  (the anomaly)  ", 0.0, False),
                ("control (eps injected)", a.eps, False)]
        print(f"trials/arm={a.trials}  K={a.K}  d={a.d}  simulate={a.simulate}\n")
        for name, eps, pre in arms:
            st, bt = run_arm(name, a.trials, noise, a.K, a.d, eps, rng, pre)
            if eps:  # inject on standardised scale so it works for real sensors too
                s = np.asarray(st)
                s = (s - s.mean()) / (s.std() + 1e-12)
                st = list(s)
            r, z, p = analyse(st, bt)
            print(f"{name}  r={r:+.4f}  z={z:+.2f}  perm p={p:.3f}")
    finally:
        noise.close()
    print(f"\nelapsed {time.time() - t0:.1f}s")
    print("Expected: before and after ~ 0 (|z| < 3); control clearly non-zero.")
    print("If 'after' were significant, check for a causal leak first (shared clock,")
    print("seed reuse, thermal drift correlated with scheduling) before anything exotic.")


if __name__ == "__main__":
    main()
