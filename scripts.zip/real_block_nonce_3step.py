"""
Real Bitcoin genesis block, recast into the original script's 3-step shape:
  STEP 1 - Generate/derive input data (real tx -> real merkle root -> real target)
  STEP 2 - Work loop: brute-force nonce search, periodic status table
  STEP 3 - Output data & verification results, same report style as the original

This is real brute-force proof-of-work search on real public chain data.
There is no shortcut around it: that is what mining is.
"""
import hashlib, struct, time

def sha256d(b): return hashlib.sha256(hashlib.sha256(b).digest()).digest()

def run_transparent_bench():
    print("=" * 80)
    print(" 🚀 INITIALIZING REAL-BLOCK SHA-256D NONCE SEARCH PIPELINE")
    print("=" * 80)

    # ==========================================
    # 1. INPUT DATA GENERATION (REAL CHAIN DATA)
    # ==========================================
    print("\n[STEP 1] Deriving Input Data (Real Bitcoin Genesis Block Fields)...")

    VERSION, PREV_HASH, TIME_, BITS = 1, b"\x00" * 32, 1231006505, 0x1d00ffff
    KNOWN_NONCE = 2083236893   # public record; reported in STEP 3 only, never fed to the search

    coinbase_hex = (
        "01000000010000000000000000000000000000000000000000000000000000000000000000"
        "ffffffff4d04ffff001d0104455468652054696d65732030332f4a616e2f32303039204368616e"
        "63656c6c6f72206f6e206272696e6b206f66207365636f6e64206261696c6f757420666f722062"
        "616e6b73ffffffff0100f2052a01000000434104678afdb0fe5548271967f1a67130b7105cd6a8"
        "28e03909a67962e0ea1f61deb649f6bc3f4cef38c4f35504e51ec112de5c384df7ba0b8d578a4c"
        "702b6bf11d5fac00000000"
    )
    coinbase_tx = bytes.fromhex(coinbase_hex)
    merkle_root = sha256d(coinbase_tx)                 # computed from the real tx, not given
    header76 = struct.pack("<I", VERSION) + PREV_HASH + merkle_root + struct.pack("<II", TIME_, BITS)

    exponent, coeff = BITS >> 24, BITS & 0xffffff
    target = coeff * (1 << (8 * (exponent - 3)))
    nonce_space = 2**32
    expected_tries = 2**256 / target

    print(f"  • Real Coinbase Tx Length     : {len(coinbase_tx)} bytes")
    print(f"  • Computed Merkle Root        : {merkle_root.hex()}")
    print(f"  • Chain-Recorded Merkle Root  : 3ba3edfd7a7b12b27ac72c3e67768f617fc81bc3888a51323a9fb8aa4b1e5e4a")
    print(f"  • Merkle Root Verified        : {merkle_root.hex() == '3ba3edfd7a7b12b27ac72c3e67768f617fc81bc3888a51323a9fb8aa4b1e5e4a'}")
    print(f"  • Nonce Search Space          : 2^32 = {nonce_space:,}")
    print(f"  • Real Difficulty Target      : {target:#x}")
    print(f"  • Expected Tries (avg)        : {expected_tries:,.0f}")
    print("\n  • Fixed Real Header Fields (First 8 of 19 header bytes shown, excl. nonce):")
    for i, b in enumerate(header76[:8]):
        print(f"    - Header Byte h[{i:02d}] = 0x{b:02x}")
    print("    - [...]")

    # ==========================================
    # 2. ACTIVE PROCESSING PIPELINE (BRUTE-FORCE WORK LOOP)
    # ==========================================
    print("\n[STEP 2] Executing SHA-256d Nonce Search Work Loop...")
    print(f"{'Cycle':<6} | {'Hashes Checked':<16} | {'% of Space':<12} | {'Active Work & Processing Status'}")
    print("-" * 80)

    CHECKPOINT = 2_000_000
    BUDGET_SECONDS = 20
    start_time = time.perf_counter()
    nonce, total_hashes, found_nonce = 0, 0, None
    cycle = 0

    while True:
        cycle += 1
        cycle_start_hashes = total_hashes
        cycle_deadline = min(start_time + BUDGET_SECONDS,
                              time.perf_counter() + 10)  # also cap a single cycle's wall time
        while total_hashes - cycle_start_hashes < CHECKPOINT:
            if time.perf_counter() - start_time > BUDGET_SECONDS or nonce >= nonce_space:
                break
            h = sha256d(header76 + struct.pack("<I", nonce))
            total_hashes += 1
            if int.from_bytes(h[::-1], "big") < target:
                found_nonce = nonce
                break
            nonce += 1

        pct = nonce / nonce_space * 100
        if found_nonce is not None:
            status = f"✨ SUCCESS: Nonce found & verified below target (nonce={found_nonce:,})"
            print(f"{cycle:<6} | {total_hashes:<16,} | {pct:<12.4f} | {status}")
            break
        if time.perf_counter() - start_time > BUDGET_SECONDS:
            status = f"⏱️ Time budget ({BUDGET_SECONDS}s) reached, no nonce below target yet"
            print(f"{cycle:<6} | {total_hashes:<16,} | {pct:<12.4f} | {status}")
            break
        status = f"🔍 Searching (Total Hashes Checked: {total_hashes:,})"
        print(f"{cycle:<6} | {total_hashes:<16,} | {pct:<12.4f} | {status}")

    elapsed = (time.perf_counter() - start_time) * 1000

    # ==========================================
    # 3. OUTPUT DATA & VERIFIED SOLUTION
    # ==========================================
    print("\n" + "=" * 80)
    print(" ✅ [STEP 3] OUTPUT DATA & CRYPTOGRAPHIC VERIFICATION RESULTS")
    print("=" * 80)

    rate = total_hashes / (elapsed / 1000)
    if found_nonce is not None:
        final_hash = sha256d(header76 + struct.pack("<I", found_nonce))[::-1].hex()
        print(f"  • Total Processing Time     : {elapsed:.2f} ms")
        print(f"  • Hashes Checked           : {total_hashes:,} (vs. {expected_tries:,.0f} brute-force average)")
        print(f"  • Hash Rate                : {rate:,.0f} h/s (pure Python + hashlib)")
        print(f"  • Recovered Nonce           : {found_nonce:,}")
        print(f"  • Matches Public Record     : {found_nonce == KNOWN_NONCE}")
        print(f"  • Resulting Block Hash      : {final_hash}")
        print(f"  • Below Real Target         : True\n")
        print("  • Final Header Field Mapping (version, prev-hash, merkle-root, time, bits, nonce):")
        print(f"    {'Field':<14} | {'Value'}")
        print(    "    ---------------------------------------------------------------")
        fields = [("version", f"{1}"), ("prev_hash", PREV_HASH.hex()),
                  ("merkle_root", merkle_root.hex()), ("time", str(TIME_)),
                  ("bits", f"{BITS:#x}"), ("nonce", str(found_nonce))]
        for name, val in fields:
            print(f"    {name:<14} | {val}")
        print(    "    ---------------------------------------------------------------")
    else:
        pct_to_real = total_hashes / KNOWN_NONCE * 100
        full_space_hours = (nonce_space / rate) / 3600
        print(f"  • Total Processing Time     : {elapsed:.2f} ms")
        print(f"  • Hashes Checked           : {total_hashes:,} / {nonce_space:,} nonce space")
        print(f"  • Hash Rate                : {rate:,.0f} h/s (pure Python + hashlib)")
        print(f"  • Progress Toward Real Nonce: {pct_to_real:.4f}% (public nonce = {KNOWN_NONCE:,}, not used by search)")
        print(f"  • Est. Full-Space Search    : ≈ {full_space_hours:.1f} hours at this rate")
        print("  ❌ Nonce not found within the time budget — this is the real cost of PoW mining.")

if __name__ == "__main__":
    run_transparent_bench()
