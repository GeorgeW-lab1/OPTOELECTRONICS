# ============================================================================
# FAA NAS STATUS CHANNEL  (paste this whole block ABOVE the "# ORCHESTRATOR" banner)
# ============================================================================
# Source: FAA Air Traffic Control System Command Center airport status feed
#         https://nasstatus.faa.gov/api/airport-status-information  (XML, no key)
# Coverage: US airports only (ground stops, ground delay programs, arrival /
#           departure delays, closures).
#
# Optional filter:  export FAA_AIRPORTS="JFK,ORD,LAX"   (default = all airports)
#
# Each record is flattened to one compact text line, sent through the same
# [index | 3 bytes | CRC-8] phase-channel framing used for headlines, decoded,
# and compared with what was sent. The feed's Update_Time goes through the
# 32-bit channel the same way.

import xml.etree.ElementTree as ET

FAA_API = "https://nasstatus.faa.gov/api/airport-status-information"
FAA_POLL_SECONDS = 60
FAA_MAX_RECORDS = 12          # records decoded per feed update (most severe first)
FAA_WATCH = {a.strip().upper() for a in os.environ.get("FAA_AIRPORTS", "").split(",") if a.strip()}

FAA_SAMPLE_XML = """<AIRPORT_STATUS_INFORMATION>
<Update_Time>Tue Nov 17 14:05:00 2026 GMT</Update_Time>
<Dtd_File>http://www.fly.faa.gov/AirportStatus.dtd</Dtd_File>
<Delay_type><Name>Ground Stop Programs</Name><Ground_Stop_List>
<Program><ARPT>EWR</ARPT><Reason>thunderstorms</Reason><End_Time>3:00 pm EST</End_Time></Program>
</Ground_Stop_List></Delay_type>
<Delay_type><Name>Ground Delay Programs</Name><Ground_Delay_List>
<Ground_Delay><ARPT>SFO</ARPT><Reason>low ceilings</Reason><Avg>58 minutes</Avg><Max>2 hours</Max></Ground_Delay>
</Ground_Delay_List></Delay_type>
<Delay_type><Name>Arrival/Departure Delay Info</Name><Arrival_Departure_Delay_List>
<Delay><ARPT>ORD</ARPT><Reason>volume</Reason><Arrival_Departure Type="Departure"><Min>16 minutes</Min><Max>30 minutes</Max><Trend>Increasing</Trend></Arrival_Departure></Delay>
</Arrival_Departure_Delay_List></Delay_type>
<Delay_type><Name>Airport Closures</Name><Airport_Closure_List>
<Airport><ARPT>PHL</ARPT><Reason>runway repair</Reason><Start>Nov 17 at 06:00 UTC.</Start><Reopen>Nov 18 at 11:00 UTC.</Reopen></Airport>
</Airport_Closure_List></Delay_type>
</AIRPORT_STATUS_INFORMATION>"""

# Lower number = more severe (used to pick which records get decoded first)
_FAA_SEVERITY = [("closure", 0), ("ground stop", 1), ("ground delay", 2), ("delay", 3)]
_FAA_FIELD_ORDER = [("Reason", ""), ("Type", ""), ("Avg", "avg "), ("Min", "min "), ("Max", "max "),
                    ("Trend", ""), ("Start", "from "), ("Reopen", "reopen "), ("End_Time", "until ")]
_FAA_KIND_SHORT = [("closure", "CLOSURE"), ("ground stop", "GROUND STOP"),
                   ("ground delay", "GDP"), ("delay", "DELAY")]


def _faa_kind_short(kind):
    low = kind.lower()
    for key, short in _FAA_KIND_SHORT:
        if key in low:
            return short
    return kind[:12].upper()


def _faa_severity(kind):
    low = kind.lower()
    for key, rank in _FAA_SEVERITY:
        if key in low:
            return rank
    return 9


def parse_faa_update_time(text):
    """'Fri Sep 15 12:04:41 2023 GMT' -> unix seconds (UTC), or None."""
    try:
        dt = datetime.strptime(text.strip().replace(" GMT", ""), "%a %b %d %H:%M:%S %Y")
        return int(dt.replace(tzinfo=timezone.utc).timestamp())
    except Exception:
        return None


def parse_faa_xml(xml_text):
    """Returns (update_time_text, records). Each record: {airport, kind, line}."""
    root = ET.fromstring(xml_text)
    update_time = (root.findtext("Update_Time") or "").strip()
    records = []
    for dtype in root.iter("Delay_type"):
        kind = (dtype.findtext("Name") or "Unknown").strip()
        for lst in dtype:
            if lst.tag == "Name":
                continue
            for rec in lst:                       # one program / delay / closure
                fields = {}
                for el in rec.iter():
                    if el is not rec and el.text and el.text.strip():
                        fields[el.tag] = el.text.strip()
                    if "Type" in el.attrib:       # Arrival_Departure Type="Departure"
                        fields["Type"] = el.attrib["Type"]
                airport = fields.get("ARPT", "").upper()
                if not airport or (FAA_WATCH and airport not in FAA_WATCH):
                    continue
                parts = [f"{label}{fields[k].rstrip('.')}" for k, label in _FAA_FIELD_ORDER if k in fields]
                records.append({"airport": airport, "kind": kind,
                                "line": f"{airport}|{_faa_kind_short(kind)}|{'|'.join(parts)}"})
    records.sort(key=lambda r: (_faa_severity(r["kind"]), r["airport"]))
    return update_time, records


class FAAFetcher(threading.Thread):
    """Polls the FAA NAS status feed; queues a snapshot only when the content changes.
    If the feed is unreachable at startup it uses a clearly-labelled SAMPLE feed."""

    def __init__(self, url=FAA_API, poll_seconds=FAA_POLL_SECONDS):
        super().__init__(daemon=True)
        self.url = url
        self.poll_seconds = poll_seconds
        self.pending = None
        self.last_sig = None
        self.have_live = False
        self.lock = threading.Lock()
        self.running = True

    def _fetch_xml(self):
        req = urllib.request.Request(self.url, headers={"User-Agent": "rp-ghost/1.0",
                                                        "Accept": "application/xml"})
        with urllib.request.urlopen(req, timeout=10) as resp:
            return resp.read().decode("utf-8", errors="replace")

    def _ingest(self, xml_text, simulated):
        update_time, records = parse_faa_xml(xml_text)
        sig = (update_time, tuple(r["line"] for r in records))
        with self.lock:
            if sig == self.last_sig:
                return
            self.last_sig = sig
            self.pending = {"update_time": update_time, "records": records, "simulated": simulated}

    def run(self):
        fails = 0
        while self.running:
            try:
                self._ingest(self._fetch_xml(), simulated=False)
                self.have_live = True
                fails = 0
            except Exception as e:
                fails += 1
                print(f"[FAA] Fetch failed: {e}")
                if not self.have_live and fails >= 3 and self.last_sig is None:
                    print("[FAA] Feed unreachable - using SAMPLE data (not real conditions).")
                    self._ingest(FAA_SAMPLE_XML, simulated=True)
            for _ in range(self.poll_seconds):
                if not self.running:
                    break
                time.sleep(1)

    def pop_update(self):
        with self.lock:
            snap, self.pending = self.pending, None
            return snap

    def stop(self):
        self.running = False


def decode_faa_snapshot(viewport, snap, windows=NEWS_WINDOWS, max_retries=NEWS_MAX_RETRIES):
    """Sends the feed's Update_Time and each record line through the phase channel."""
    ut = parse_faa_update_time(snap["update_time"])
    dec_ut, _, ok_ut, m_ut = (transmit_u32(viewport, ut, windows, max_retries)
                              if ut is not None else (None, 0, False, 0.0))
    out = []
    for rec in snap["records"][:FAA_MAX_RECORDS]:
        text, frames, retries, failed, margin = transmit_headline(viewport, rec["line"], windows, max_retries)
        sent = rec["line"].encode("utf-8")[:NEWS_MAX_BYTES].decode("utf-8", errors="replace")
        out.append({"airport": rec["airport"], "kind": rec["kind"], "text": text, "frames": frames,
                    "retries": retries, "failed": failed, "margin": margin,
                    "match": failed == 0 and text == sent})
    return dec_ut, ok_ut, m_ut, out


def print_faa_snapshot(snap, dec_ut, ok_ut, results):
    tag = " (SAMPLE DATA)" if snap["simulated"] else ""
    total = len(snap["records"])
    print(f" [FAA] FEED UPDATE{tag} | {total} active record(s)"
          f"{' for ' + ','.join(sorted(FAA_WATCH)) if FAA_WATCH else ''}")
    if ok_ut:
        print(f"   Feed time (decoded): {time.strftime('%Y-%m-%d %H:%M:%S', time.gmtime(dec_ut))} UTC "
              f"({format_age(time.time() - dec_ut)} ago) (CRC PASS)")
    else:
        print(f"   Feed time: {snap['update_time'] or 'unknown'} (channel decode unavailable / CRC FAIL)")
    if not results:
        print("   No delays, stops or closures reported.")
    for n, r in enumerate(results, 1):
        integrity = "" if r["failed"] == 0 else f" | {r['failed']} frame(s) unrecoverable"
        print(f"   [{n:02d}] {r['text']}")
        print(f"        {r['frames']} frames | CRC retries {r['retries']} | min bit margin "
              f"{r['margin']:.1f} sigma | {'MATCHES feed' if r['match'] else 'MISMATCH'}{integrity}")
    if total > len(results):
        print(f"   ... {total - len(results)} lower-severity record(s) not decoded (FAA_MAX_RECORDS={FAA_MAX_RECORDS})")


# ============================================================================
# EDITS TO main()  (three one-line additions)
# ============================================================================
#
# 1) After   blocks.start()   add:
#        faa = FAAFetcher()
#        faa.start()
#
# 2) In the loop, right before the final   print("-" * 78)   / time.sleep(1.0)   add:
#        snap = faa.pop_update()
#        if snap:
#            dec_ut, ok_ut, _m, faa_results = decode_faa_snapshot(viewport, snap)
#            print_faa_snapshot(snap, dec_ut, ok_ut, faa_results)
#
# 3) In the finally: block add   faa.stop()   and   faa.join(timeout=2.0)
