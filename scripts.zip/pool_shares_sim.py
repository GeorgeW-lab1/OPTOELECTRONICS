#!/usr/bin/env python3
"""Pool share submissions, in theory and in a toy simulation (educational).

Setup: every hash is a Bernoulli trial.
  share target : hash < 2^32 / d_s   (low difficulty, submitted to the pool as proof of work done)
  block target : hash < 2^32 / D     (rare; the pool wins the block reward)
Theory:
  P(share | hash) = 1/d_s, so a miner doing h hashes submits ~Poisson(h/d_s) shares.
  Shares per block ~ D/d_s (a block is also a valid share).
  Proportional payout: miner i gets reward * shares_i / shares_total for that round.
  Expected payout of miner i = reward * h_i / H, the same as its hashrate fraction.

Usage: python pool_shares_sim.py [--D 12] [--ds 6] [--hashes 150000] [--log 30]
"""
import argparse
import hashlib

import numpy as np

MINERS = {"alice": 5, "bob": 3, "carol": 2}  # hashes per tick (relative hashrate)


def h32(miner: str, tick: int, k: int) -> int:
    return int.from_bytes(hashlib.sha256(f"{miner}|{tick}|{k}".encode()).digest()[:4], "big")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--D", type=int, default=12, help="block difficulty bits (D = 2^bits)")
    ap.add_argument("--ds", type=int, default=6, help="share difficulty bits")
    ap.add_argument("--hashes", type=int, default=150_000, help="total hashes to run")
    ap.add_argument("--log", type=int, default=30, help="submission lines to print")
    ap.add_argument("--plot", default="pool_shares.png")
    a = ap.parse_args()

    D, ds = 1 << a.D, 1 << a.ds
    block_thr, share_thr = (1 << 32) // D, (1 << 32) // ds
    H = sum(MINERS.values())
    per_tick = H
    ticks = a.hashes // per_tick

    print(f"Block difficulty D = {D}, share difficulty d_s = {ds}")
    print(f"Theory: {D/ds:.0f} shares per block on average, "
          f"1 share per {ds} hashes, 1 block per {D} hashes\n")
    print(f"{'tick':>6} {'miner':<6} {'hash32':>10}  result")

    round_shares = {m: 0 for m in MINERS}
    total_shares = {m: 0 for m in MINERS}
    cum = {m: [] for m in MINERS}
    blocks_at, shares_per_block = [], []
    payouts_prop = {m: 0.0 for m in MINERS}
    payouts_pps = {m: 0.0 for m in MINERS}
    pps_rate = 1.0 / (D / ds)  # reward 1 per block; PPS pays reward/(D/ds) per share
    shown = 0

    for t in range(ticks):
        for m, rate in MINERS.items():
            for k in range(rate):
                v = h32(m, t, k)
                if v < share_thr:
                    round_shares[m] += 1
                    total_shares[m] += 1
                    payouts_pps[m] += pps_rate
                    is_block = v < block_thr
                    if shown < a.log:
                        tag = "BLOCK FOUND (also a share)" if is_block else "share submitted"
                        print(f"{t:>6} {m:<6} {v:>10}  {tag}")
                        shown += 1
                    if is_block:
                        n = sum(round_shares.values())
                        shares_per_block.append(n)
                        for mm in MINERS:  # proportional split of reward = 1
                            payouts_prop[mm] += round_shares[mm] / n
                        round_shares = {mm: 0 for mm in MINERS}
                        blocks_at.append(t)
        for m in MINERS:
            cum[m].append(total_shares[m])

    n_blocks = len(blocks_at)
    print(f"\nRan {ticks*per_tick} hashes, {n_blocks} blocks, {sum(total_shares.values())} shares")
    print(f"Expected shares: {ticks*per_tick/ds:.0f}, expected blocks: {ticks*per_tick/D:.1f}\n")
    print(f"{'miner':<6} {'hash frac':>9} {'shares':>7} {'share frac':>10} "
          f"{'prop. pay':>9} {'PPS pay':>8} {'ideal':>7}")
    tot_blocks_val = n_blocks
    for m, rate in MINERS.items():
        frac = rate / H
        sf = total_shares[m] / sum(total_shares.values())
        print(f"{m:<6} {frac:>9.3f} {total_shares[m]:>7} {sf:>10.3f} "
              f"{payouts_prop[m]:>9.2f} {payouts_pps[m]:>8.2f} {frac*ticks*per_tick/D:>7.2f}")
    if shares_per_block:
        s = np.array(shares_per_block)
        print(f"\nShares per block: mean {s.mean():.1f} (theory ~{D/ds:.0f}), sd {s.std():.1f} "
              f"(theory ~{np.sqrt(D/ds*(D/ds-1)):.0f}, geometric)")
    print("Note: PPS pays per share regardless of luck (pool bears variance); "
          "proportional pays per round (miners bear it).")

    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt

        fig, ax = plt.subplots(1, 2, figsize=(11, 4))
        x = np.arange(ticks)
        for m in MINERS:
            ax[0].plot(x, cum[m], label=f"{m} (h={MINERS[m]}/tick)")
        for b in blocks_at:
            ax[0].axvline(b, color="k", alpha=0.25, lw=0.8)
        ax[0].set(title="Cumulative shares submitted (lines = pool blocks)", xlabel="tick")
        ax[0].legend()
        if shares_per_block:
            ax[1].hist(shares_per_block, bins=20, density=True, alpha=0.6, label="simulated")
            xs = np.linspace(1, max(shares_per_block), 200)
            mu = D / ds
            ax[1].plot(xs, np.exp(-xs / mu) / mu, "k", label="geometric theory")
            ax[1].set(title="Shares per block", xlabel="shares between blocks")
            ax[1].legend()
        fig.tight_layout()
        fig.savefig(a.plot, dpi=130)
        print(f"\nPlot saved to {a.plot}")
    except ImportError:
        print("(matplotlib not installed; skipping plot)")


if __name__ == "__main__":
    main()
