"""
RP-GHOST predictor, rebuilt to follow "Anticipatory Noise Correlations in an
Optoelectronic Time-Code Latch" (Wagenknecht).

Mapping to the paper
  Sec 2  noise model      lambda=10,000, sigma_c=0.5%  ->  Var(z)=1+sigma_c^2*lambda=1.25,
                          slot-to-slot correlation 0.20 (shared laser term)
  Sec 5  scenarios        BEFORE arm: N is loaded first and a 0.02-sigma tilt toward Y[k+2] is
                          injected (S1). This is the paper's positive control / leak arm.
                          AFTER arm: noise is recorded and hashed (commitment), N is created
                          afterwards from an independent source (the live exchange tick).
  Sec 6  statistics       leads L=1..4, 5-sigma threshold, 10,000-permutation shuffle null
  Sec 7  protocol         preregistered config hash, random interleaving of arms,
                          rho_leak = rho_before - rho_after, rho_anticipation = rho_after,
                          positive control must be recovered or the pipeline is "too weak"

No keystrokes are sent. A cycle is flagged as a SIGNAL only when the AFTER arm shows a 5-sigma
correlation AND the positive control was recovered AND every per-cycle gate passes. In a
synthetic simulation the AFTER arm is null by construction, so expect no signals. That is the
paper's own result.
"""
import hashlib
import json
import math
import socket
import threading
import time
from collections import deque

import numpy as np

try:
    import orjson  # pip install orjson (optional, faster parsing)
    _loads = orjson.loads
except ImportError:
    _loads = json.loads

try:
    import websocket  # pip install websocket-client
    HAS_WS = True
except ImportError:
    HAS_WS = False

try:
    import cv2
    HAS_CV2 = True
except ImportError:
    HAS_CV2 = False


# ----------------------------------------------------------------------------
# Paper constants (Sec 2, 5, 6, 7)
# ----------------------------------------------------------------------------
LAMBDA = 10000.0          # mean photoelectrons per slot
SIGMA_C = 0.005           # shared laser term (0.5%)
N_SLOTS = 16              # 16-slot window, 16-bit code N
LEADS = (1, 2, 3, 4)      # preregistered leads
LEAK_LEAD = 2             # the positive control tilts z[k] toward Y[k+2]
DECODE_LEAD = 2           # decoder reads bit j from column (j - 2) mod 16
N_SIGMA = 5.0             # detection threshold
MIN_CYCLES = 40           # cycles per arm before any test is run
ROLL_CYCLES = 400         # rolling window of cycles kept per arm

# Per-cycle gates carried over from the earlier versions (they now flag signals only)
Z_MIN = 4.0               # every price bit must have |z| >= this
JOINT_CONF_MIN = 0.999
DELTA_BUF_LEN = 64
MIN_BUF = 64
ENTROPY_MAX_BITS = 0.25
STREAK = 5
MIN_ABS_DELTA = 2.0


def noise_stats(lambd, sigma_c):
    """Paper eq. (5): Var(z), sigma_z and the slot-to-slot correlation."""
    shared = sigma_c ** 2 * lambd
    var_z = 1.0 + shared
    return var_z, math.sqrt(var_z), shared / var_z


def _phi(z):
    return 0.5 * (1.0 + math.erf(z / math.sqrt(2.0)))


def sign_entropy(deltas):
    n = len(deltas)
    counts = (sum(d > 0 for d in deltas), sum(d < 0 for d in deltas), sum(d == 0 for d in deltas))
    h = 0.0
    for c in counts:
        if c:
            p = c / n
            h -= p * math.log2(p)
    return h, counts


# ----------------------------------------------------------------------------
# Viewport (synthetic: Poisson shot noise plus a shared laser term)
# ----------------------------------------------------------------------------
class OptoelectronicViewport:
    """Standardised noise samples z_k. NOTE: the webcam is opened if requested but is not read;
    replace generate_window_block with real detector counts for a hardware test."""

    def __init__(self, lambd=LAMBDA, sigma_c=SIGMA_C, camera_index=0, use_webcam=False):
        self.lambd = lambd
        self.sigma_c = sigma_c
        self.cap = None
        if use_webcam and HAS_CV2:
            cap = cv2.VideoCapture(camera_index)
            if cap is not None and cap.isOpened():
                self.cap = cap
                print("[INIT] Webcam opened, but noise is still synthetic (frames are not read).")
        if self.cap is None:
            print("[INIT] Using calibrated synthetic optical viewport.")

    def generate_window_block(self, n_windows, n_slots, tilt=None):
        """n_windows independent 16-slot windows. The shared term delta is drawn per window."""
        delta = np.random.normal(0.0, self.sigma_c, size=(n_windows, 1))
        lam = self.lambd * (1.0 + delta)
        counts = np.random.poisson(np.clip(lam, 1.0, None), size=(n_windows, n_slots))
        Z = (counts - self.lambd) / np.sqrt(self.lambd)
        if tilt is not None:
            Z += tilt
        return Z

    def release(self):
        if self.cap is not None:
            self.cap.release()


# ----------------------------------------------------------------------------
# FIFO queue
# ----------------------------------------------------------------------------
class FifoTargetQueue:
    def __init__(self, max_capacity=100):
        self.buffer = deque(maxlen=max_capacity)

    def push(self, timestamp, price, encoded_bits):
        self.buffer.append({"timestamp": timestamp, "price": price, "encoded_bits": encoded_bits})

    def pop_at(self, index=2):
        temp_list = list(self.buffer)
        if 0 <= index < len(temp_list):
            popped_item = temp_list.pop(index)
            self.buffer = deque(temp_list, maxlen=self.buffer.maxlen)
            return popped_item
        return None

    def __len__(self):
        return len(self.buffer)


# ----------------------------------------------------------------------------
# Price code (16 bits). No reference-price clamp: the old clamp overwrote noisy bits
# with the true price, which is exactly the answer leaking into the decoder.
# ----------------------------------------------------------------------------
def encode_price_bits(price, n_slots=N_SLOTS):
    code = int(price / 10) & 0xFFFF
    return np.array([(code >> (n_slots - 1 - k)) & 1 for k in range(n_slots)], dtype=int)


def bits_to_code(bits):
    code = 0
    for b in bits:
        code = (code << 1) | int(b)
    return code


# ----------------------------------------------------------------------------
# Lead-lag statistics with a permutation null (Sec 6 and 7)
# ----------------------------------------------------------------------------
class ArmRecord:
    """Per-cycle column means of the noise block and the code bits Y for one arm."""

    def __init__(self, maxlen=ROLL_CYCLES):
        self.M = deque(maxlen=maxlen)
        self.Y = deque(maxlen=maxlen)

    def add(self, col_means, y_bits):
        self.M.append(np.asarray(col_means, dtype=float))
        self.Y.append(np.asarray(y_bits, dtype=float))

    def __len__(self):
        return len(self.M)


def lead_stats(arm, leads, n_slots, n_perms):
    """Pooled correlation of noise column means with Y[k+L], plus a z-score against a null
    built by shuffling Y across cycles. Columns and bit positions are demeaned across cycles,
    so only genuine covariation counts (constant high bits of the price carry no test power)."""
    C = len(arm)
    M = np.array(arm.M)
    Y = np.array(arm.Y)
    Mc = M - M.mean(axis=0)
    Yc = Y - Y.mean(axis=0)

    obs, den = {}, {}
    for L in leads:
        x, y = Mc[:, :n_slots - L], Yc[:, L:]
        d = math.sqrt(float((x * x).sum() * (y * y).sum()))
        den[L] = d
        obs[L] = float((x * y).sum() / d) if d > 0 else 0.0

    perm_vals = {L: [] for L in leads}
    done = 0
    while done < n_perms:
        P = min(250, n_perms - done)
        idx = np.argsort(np.random.random((P, C)), axis=1)
        Yp = Yc[idx]                                   # (P, C, n_slots)
        for L in leads:
            if den[L] > 0:
                s = np.einsum('ck,pck->p', Mc[:, :n_slots - L], Yp[:, :, L:])
                perm_vals[L].append(s / den[L])
        done += P

    out = {}
    for L in leads:
        if den[L] > 0 and perm_vals[L]:
            arr = np.concatenate(perm_vals[L])
            sd = arr.std()
            z = (obs[L] - arr.mean()) / sd if sd > 0 else 0.0
        else:
            z = 0.0
        out[L] = (obs[L], z)
    return out


# ----------------------------------------------------------------------------
# Exchange feeds (push-based WebSocket, top-of-book mid price)
# ----------------------------------------------------------------------------
def _parse_deribit(d):
    p = d.get("params")
    if p and p.get("channel", "").startswith("quote."):
        q = p["data"]
        return (float(q["best_bid_price"]) + float(q["best_ask_price"])) / 2.0


def _parse_bitmex(d):
    if d.get("table") == "quote" and d.get("data"):
        q = d["data"][-1]
        if q.get("bidPrice") and q.get("askPrice"):
            return (float(q["bidPrice"]) + float(q["askPrice"])) / 2.0


def _parse_coinbase(d):
    if d.get("type") == "ticker" and d.get("best_bid") and d.get("best_ask"):
        return (float(d["best_bid"]) + float(d["best_ask"])) / 2.0


def _parse_kraken(d):
    if d.get("channel") == "ticker" and d.get("data"):
        t = d["data"][0]
        return (float(t["bid"]) + float(t["ask"])) / 2.0


def _parse_okx(d):
    if d.get("data") and "bidPx" in d["data"][0]:
        t = d["data"][0]
        return (float(t["bidPx"]) + float(t["askPx"])) / 2.0


EXCHANGES = {
    "deribit": {
        "url": "wss://www.deribit.com/ws/api/v2",
        "sub": {"jsonrpc": "2.0", "id": 1, "method": "public/subscribe",
                "params": {"channels": ["quote.BTC-PERPETUAL"]}},
        "parse": _parse_deribit,
    },
    "bitmex": {
        "url": "wss://ws.bitmex.com/realtime",
        "sub": {"op": "subscribe", "args": ["quote:XBTUSD"]},
        "parse": _parse_bitmex,
    },
    "coinbase": {
        "url": "wss://ws-feed.exchange.coinbase.com",
        "sub": {"type": "subscribe", "product_ids": ["BTC-USD"], "channels": ["ticker"]},
        "parse": _parse_coinbase,
    },
    "kraken": {
        "url": "wss://ws.kraken.com/v2",
        "sub": {"method": "subscribe", "params": {"channel": "ticker", "symbol": ["BTC/USD"]}},
        "parse": _parse_kraken,
    },
    "okx": {
        "url": "wss://ws.okx.com:8443/ws/v5/public",
        "sub": {"op": "subscribe", "args": [{"channel": "tickers", "instId": "BTC-USDT"}]},
        "parse": _parse_okx,
    },
}


class AsyncPriceFetcher(threading.Thread):
    """Push-based BTC mid-price stream from a selectable exchange, with optional throttle."""

    def __init__(self, exchange="deribit", delay_seconds=0.0):
        super().__init__(daemon=True)
        cfg = EXCHANGES[exchange]
        self.url, self.sub, self.parse = cfg["url"], cfg["sub"], cfg["parse"]
        self.exchange = exchange
        self.delay_seconds = delay_seconds
        self._last_publish = 0.0
        self.latest_price = 0.0
        self.update_event = threading.Event()
        self.last_recv_ns = 0
        self.running = True
        self.ws = None

    def _on_open(self, ws):
        ws.send(json.dumps(self.sub))

    def _on_message(self, ws, message):
        try:
            price = self.parse(_loads(message))
        except Exception:
            return
        if not price:
            return
        now = time.perf_counter()
        if now - self._last_publish < self.delay_seconds:
            return
        self._last_publish = now
        self.latest_price = price               # price is written before the timestamp
        self.last_recv_ns = time.perf_counter_ns()
        self.update_event.set()

    def run(self):
        if not HAS_WS:
            print("[FETCH] Missing dependency: pip install websocket-client")
            return
        while self.running:
            try:
                self.ws = websocket.WebSocketApp(
                    self.url, on_open=self._on_open, on_message=self._on_message)
                self.ws.run_forever(
                    ping_interval=20, ping_timeout=10,
                    sockopt=((socket.IPPROTO_TCP, socket.TCP_NODELAY, 1),),
                )
            except Exception:
                pass
            if self.running:
                time.sleep(0.2)

    def get_price(self):
        return self.latest_price

    def stop(self):
        self.running = False
        if self.ws:
            self.ws.close()


def wait_for_tick_after(fetcher, t_ns, timeout=2.0):
    """Block until a tick that arrived strictly after t_ns. Guarantees N is created after the commitment."""
    deadline = time.perf_counter() + timeout
    while time.perf_counter() < deadline:
        if fetcher.last_recv_ns > t_ns:
            return fetcher.get_price(), fetcher.last_recv_ns
        fetcher.update_event.wait(timeout=0.05)
        fetcher.update_event.clear()
    return None, None


# ----------------------------------------------------------------------------
# Main pipeline
# ----------------------------------------------------------------------------
def run_full_predictor_pipeline(exchange="deribit", delay_seconds=0.1, n_windows=20000,
                                leak_eps_sigma=0.02, balanced_detection=False,
                                n_perms=10000, report_every=25, max_cycles=None):
    np.random.seed(2026)
    sigma_c = 0.0 if balanced_detection else SIGMA_C
    var_z, sigma_z, slot_corr = noise_stats(LAMBDA, sigma_c)
    eps_abs = leak_eps_sigma * sigma_z            # tilt in z units; paper: 0.02 sigma_z

    prereg = dict(lambda_=LAMBDA, sigma_c=sigma_c, n_slots=N_SLOTS, leads=list(LEADS),
                  n_sigma=N_SIGMA, n_perms=n_perms, n_windows=n_windows,
                  leak_eps_sigma=leak_eps_sigma, leak_lead=LEAK_LEAD, min_cycles=MIN_CYCLES)
    prereg_hash = hashlib.sha256(json.dumps(prereg, sort_keys=True).encode()).hexdigest()

    print("==========================================================================")
    print("  RP-GHOST COMMIT-REVEAL PREDICTOR (paper-faithful, no keystrokes)         ")
    print("==========================================================================")
    print(f"[PREREG] config hash {prereg_hash[:16]}...  (record this before trusting any result)")
    print(f"[NOISE ] Var(z)={var_z:.3f}  sigma_z={sigma_z:.3f}  slot correlation={slot_corr:.3f}"
          f"{'  (balanced detection: shared term removed)' if balanced_detection else ''}")
    print(f"[CTRL  ] positive-control tilt = {leak_eps_sigma} sigma_z = {eps_abs:.4f} (z units), before arm only")

    viewport = OptoelectronicViewport(lambd=LAMBDA, sigma_c=sigma_c)
    fifo_queue = FifoTargetQueue(max_capacity=50)
    delta_buf = deque(maxlen=DELTA_BUF_LEN)
    fetcher = AsyncPriceFetcher(exchange=exchange, delay_seconds=delay_seconds)
    fetcher.start()
    print(f"[FETCH ] Streaming from {exchange}")

    before, after = ArmRecord(), ArmRecord()
    analysis = dict(pipeline_ok=False, anticipation_ok=False)
    after_hits = after_total = signal_hits = signal_total = 0
    col_idx = (np.arange(N_SLOTS) - DECODE_LEAD) % N_SLOTS

    try:
        cycle = 0
        while max_cycles is None or cycle < max_cycles:
            if not fetcher.update_event.wait(timeout=1.0):
                continue
            fetcher.update_event.clear()
            price0 = fetcher.get_price()
            if price0 <= 0.0:
                continue
            cycle += 1

            arm = "before" if np.random.random() < 0.5 else "after"   # random interleaving

            if arm == "before":
                # N is loaded first; a leak (or the injected positive control) can act
                Y = encode_price_bits(price0)
                tilt = None
                if eps_abs > 0.0:
                    tilt = np.zeros(N_SLOTS)
                    tilt[:N_SLOTS - LEAK_LEAD] = 2.0 * eps_abs * (Y[LEAK_LEAD:] - 0.5)
                Z = viewport.generate_window_block(n_windows, N_SLOTS, tilt)
                m = Z.mean(axis=0)
                before.add(m, Y)
                bit_z = (m / (Z.std(axis=0, ddof=1) / math.sqrt(n_windows)))[col_idx]
                dec = (bit_z > 0).astype(int)
                ok = int((dec[DECODE_LEAD:] == Y[DECODE_LEAD:]).sum())
                print(f"[{cycle}] BEFORE arm (leak/positive control) | bits recovered {ok}/{N_SLOTS - DECODE_LEAD}"
                      f" | leak arm, never produces a signal")
                fifo_queue.push(time.time(), price0, Y)
                if len(fifo_queue) >= 3:
                    fifo_queue.pop_at(index=2)

            else:
                # 1. Record the noise and commit to it. N does not exist yet.
                Z = viewport.generate_window_block(n_windows, N_SLOTS, None)
                commit = hashlib.sha256(Z.tobytes()).hexdigest()
                commit_ns = time.perf_counter_ns()

                # 2. Decode a prediction from the committed noise only (no reference price)
                m = Z.mean(axis=0)
                col_z = m / (Z.std(axis=0, ddof=1) / math.sqrt(n_windows))
                bit_z = col_z[col_idx]
                recovered_bits = (bit_z > 0).astype(int)
                p_hat = float(bits_to_code(recovered_bits) * 10)
                delta = p_hat - price0

                # 3. Reveal: create N from the exchange feed strictly after the commitment
                price1, recv_ns = wait_for_tick_after(fetcher, commit_ns, timeout=2.0)
                if price1 is None:
                    print(f"[{cycle}] AFTER arm: no tick after commitment, window discarded")
                    continue
                Y = encode_price_bits(price1)
                after.add(m, Y)
                fifo_queue.push(time.time(), price1, Y)
                if len(fifo_queue) >= 3:
                    fifo_queue.pop_at(index=2)
                realized = price1 - price0
                if delta != 0 and realized != 0:
                    after_total += 1
                    after_hits += int((delta > 0) == (realized > 0))

                # 4. Per-cycle certainty on the 16 price bits
                price_z = np.abs(bit_z)
                min_z = float(price_z.min())
                joint_conf = float(np.prod([_phi(z) for z in price_z]))
                certain = (min_z >= Z_MIN) and (joint_conf >= JOINT_CONF_MIN)

                # 5. Entropy / agreement / streak / size gates on the delta buffer
                delta_buf.append(delta)
                h, (n_pos, n_neg, n_zero) = sign_entropy(delta_buf)
                low_entropy = len(delta_buf) >= MIN_BUF and h <= ENTROPY_MAX_BITS
                dominant = 1 if n_pos > n_neg else (-1 if n_neg > n_pos else 0)
                agrees = delta != 0 and dominant != 0 and (delta > 0) == (dominant > 0)
                recent = list(delta_buf)[-STREAK:]
                streak_ok = len(recent) == STREAK and (all(d > 0 for d in recent) or all(d < 0 for d in recent))
                big_enough = abs(delta) >= MIN_ABS_DELTA

                gates = {
                    "positive control recovered": analysis["pipeline_ok"],
                    "after-arm 5-sigma": analysis["anticipation_ok"],
                    "certain": certain,
                    "low entropy": low_entropy,
                    "agrees": agrees,
                    "streak": streak_ok,
                    "big enough": big_enough,
                }
                failed = [name for name, ok in gates.items() if not ok]
                reveal_ms = (recv_ns - commit_ns) / 1e6

                print(f"[{cycle}] AFTER arm | commit {commit[:10]} | reveal +{reveal_ms:.1f} ms | "
                      f"pred ${p_hat:,.0f} vs P0 ${price0:,.2f} (Δ {delta:+,.0f}) | realized {realized:+.2f} | "
                      f"min|z| {min_z:.2f} | entropy {h:.2f}")

                if not failed:
                    direction = "UP" if delta > 0 else ("DOWN" if delta < 0 else "FLAT")
                    print(f"    [SIGNAL] All gates passed -> predicted direction {direction} (no keystroke sent)")
                    if realized != 0:
                        signal_total += 1
                        signal_hits += int((delta > 0) == (realized > 0))
                else:
                    print(f"    [GATE] No signal: {', '.join(failed)}")

            # ---- periodic analysis (frozen estimators, permutation null) ----
            if cycle % report_every == 0:
                if len(before) >= MIN_CYCLES and len(after) >= MIN_CYCLES:
                    sb = lead_stats(before, LEADS, N_SLOTS, n_perms)
                    sa = lead_stats(after, LEADS, N_SLOTS, n_perms)
                    pc_rho, pc_z = sb[LEAK_LEAD]
                    analysis["pipeline_ok"] = pc_z >= N_SIGMA
                    best_L = max(LEADS, key=lambda L: sa[L][1])
                    analysis["anticipation_ok"] = sa[best_L][1] >= N_SIGMA
                    print("\n[ANALYSIS] ------------------------------------------------------")
                    print(f"  cycles: before {len(before)}, after {len(after)}   (null = {n_perms:,} shuffles of Y)")
                    print(f"  positive control, lead +{LEAK_LEAD}: rho={pc_rho:+.4f}  z={pc_z:+.1f}  "
                          f"-> {'RECOVERED' if analysis['pipeline_ok'] else 'MISSED (pipeline too weak)'}")
                    for L in LEADS:
                        print(f"  after arm lead +{L}: rho={sa[L][0]:+.4f}  z={sa[L][1]:+.1f}")
                    print(f"  rho_leak (lead +{LEAK_LEAD}) = {sb[LEAK_LEAD][0] - sa[LEAK_LEAD][0]:+.4f}   "
                          f"rho_anticipation = {sa[LEAK_LEAD][0]:+.4f}")
                    verdict = "UNEXPLAINED, check N source independence and replicate" \
                        if analysis["anticipation_ok"] else "no anticipation detected"
                    print(f"  verdict: {verdict}")
                    if after_total:
                        bz = (after_hits - after_total / 2) / (0.5 * math.sqrt(after_total))
                        print(f"  market direction hit rate (after arm): {after_hits}/{after_total} "
                              f"= {after_hits / after_total:.3f}  (z vs coin flip {bz:+.1f})")
                    if signal_total:
                        print(f"  flagged signals that matched the next move: {signal_hits}/{signal_total}")
                    print("[ANALYSIS] ------------------------------------------------------\n")
                else:
                    print(f"[ANALYSIS] waiting for {MIN_CYCLES} cycles per arm "
                          f"(before {len(before)}, after {len(after)})")

    except KeyboardInterrupt:
        pass
    finally:
        fetcher.stop()
        viewport.release()
        print("\n[DONE] Predictor pipeline terminated safely.")


if __name__ == "__main__":
    # Exchange options: "deribit", "bitmex", "coinbase", "kraken", "okx"
    run_full_predictor_pipeline(
        exchange="deribit",
        delay_seconds=0.1,
        n_windows=20000,          # noise windows per cycle
        leak_eps_sigma=0.02,      # paper's positive control; set 0.0 to model a clean latch
        balanced_detection=False, # True removes the shared laser term (sigma_c = 0)
        n_perms=10000,            # paper: 10,000 permutations (lower it to speed up reports)
        report_every=25,
    )
