#!/usr/bin/env python3
"""
P2 test from the paper: does a frame-derived (device) nonce find SHA-256d
solutions faster than an independent nonce?  Search space is 2^k nonces.

Per frame:
  digest d_t = SHA256(frame); x_t = (#moving px)+5; r_t = 2 + SHA256(E) mod (x-3)
  header = d_t || nonce(8 bytes);  solution = SHA256d(header) has k leading 0 bits
Two arms scan the SAME number of nonces per frame:
  device : start nonce built from RAW frame quantities (x, r, mask bits),
           i.e. the "prediction" H1/H2 claim could exploit
  control: start nonce from secrets, drawn AFTER the frame (independent)
Both then scan per-frame consecutive nonces.

Statistic: mean trials per solution T; speed-up = 2^g with g = log2(2^k / T).
Stopping at m solutions: sigma_g = 1/(sqrt(m) ln 2) bits.
H1+H2 predict g > 0 for the device arm only. A classical deterministic camera
plus SHA-256 should give g = 0 within error.

Usage
  python rp_pow_test.py --synthetic --k 16 --m 30
  python rp_pow_test.py --k 20 --m 19            # webcam
"""
import argparse, hashlib, math, secrets, time
import numpy as np

try:
    import cv2
except ImportError:
    cv2 = None

W, H = 128, 96
MASK64 = (1 << 64) - 1


def webcam_frames(index):
    cap = cv2.VideoCapture(index)
    if not cap.isOpened():
        raise RuntimeError(f"cannot open webcam {index}; try --synthetic")
    cap.set(cv2.CAP_PROP_BUFFERSIZE, 1)
    for _ in range(5):
        cap.read()
    try:
        while True:
            ok, f = cap.read()
            if not ok:
                continue
            g = cv2.cvtColor(f, cv2.COLOR_BGR2GRAY)
            yield cv2.resize(g, (W, H), interpolation=cv2.INTER_AREA)
    finally:
        cap.release()


def synthetic_frames():
    rng = np.random.default_rng()
    t = 0
    while True:
        f = rng.normal(100, 6, (H, W))
        cx, cy = int(W / 2 + 40 * math.sin(t / 7)), int(H / 2 + 25 * math.cos(t / 11))
        f[max(cy - 10, 0):cy + 10, max(cx - 10, 0):cx + 10] += 60
        t += 1
        yield np.clip(f, 0, 255).astype(np.uint8)


def scan(prefix, start, n, k, need):
    """Scan up to n nonces from start; stop after `need` hits. Returns (hits, trials)."""
    base, sh, shift = hashlib.sha256(prefix), hashlib.sha256, 64 - k
    hits = 0
    for i in range(n):
        h = base.copy()
        h.update(((start + i) & MASK64).to_bytes(8, "big"))
        if int.from_bytes(sh(h.digest()).digest()[:8], "big") >> shift == 0:
            hits += 1
            if hits >= need:
                return hits, i + 1
    return hits, n


class Arm:
    def __init__(self, name, m):
        self.name, self.need, self.hits, self.trials = name, m, 0, 0

    def done(self):
        return self.hits >= self.need

    def feed(self, prefix, start, n, k):
        h, t = scan(prefix, start, n, k, self.need - self.hits)
        self.hits += h
        self.trials += t

    def g(self, k):
        T = self.trials / self.hits
        return math.log2(2 ** k / T), 1 / (math.sqrt(self.hits) * math.log(2)), T


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--k", type=int, default=16, help="leading zero bits (space 2^k)")
    ap.add_argument("--m", type=int, default=30, help="solutions per arm (19 gives 2x at 3 sigma)")
    ap.add_argument("--per-frame", type=int, default=50000)
    ap.add_argument("--thr", type=int, default=8)
    ap.add_argument("--camera", type=int, default=0)
    ap.add_argument("--synthetic", action="store_true")
    ap.add_argument("--max-frames", type=int, default=100000)
    a = ap.parse_args()
    if not 1 <= a.k <= 64:
        raise SystemExit("k must be in 1..64")

    src = webcam_frames(a.camera) if (not a.synthetic and cv2) else synthetic_frames()
    prev = next(src)
    dev, ctl = Arm("device ", a.m), Arm("control", a.m)
    t0, frames = time.time(), 0
    print(f"space 2^{a.k} = {2 ** a.k:,} nonces; expected hashes/arm ~ {a.m * 2 ** a.k:,}")

    while not (dev.done() and ctl.done()) and frames < a.max_frames:
        cur = next(src)
        mask = np.abs(cur.astype(np.int16) - prev.astype(np.int16)) > a.thr
        x = int(mask.sum()) + 5
        E = np.packbits(mask).tobytes()
        r = 2 + int.from_bytes(hashlib.sha256(E).digest(), "big") % (x - 3)
        prefix = hashlib.sha256(cur.tobytes()).digest()

        # device arm: raw frame quantities, no hashing, as the hypothesis would use
        d_start = ((x & 0x3FFF) << 50) | ((r & 0x3FFF) << 36) | (int.from_bytes(E[:5], "big") >> 4)
        # control arm: independent source, drawn after the frame is fixed
        c_start = secrets.randbits(64)

        if not dev.done():
            dev.feed(prefix, d_start, a.per_frame, a.k)
        if not ctl.done():
            ctl.feed(prefix, c_start, a.per_frame, a.k)
        prev = cur
        frames += 1
        print(f"\rframes {frames}  device {dev.hits}/{a.m}  control {ctl.hits}/{a.m}   ",
              end="", flush=True)

    print(f"\n\n{frames} frames, {time.time() - t0:.1f} s")
    res = {}
    for arm in (dev, ctl):
        if arm.hits == 0:
            print(f"{arm.name}: no solutions found")
            continue
        g, sg, T = arm.g(a.k)
        res[arm.name] = (g, sg)
        print(f"{arm.name}: {arm.hits} solutions in {arm.trials:,} hashes; "
              f"mean {T:,.0f} (expected {2 ** a.k:,}); g = {g:+.3f} +/- {sg:.3f} bits")
    if len(res) == 2:
        gd, sd = res["device "]
        gc, sc = res["control"]
        diff, sig = gd - gc, math.hypot(sd, sc)
        print(f"\ndevice minus control: {diff:+.3f} +/- {sig:.3f} bits  (z = {diff / sig:+.2f})")
        print(f"smallest detectable speed-up at 3 sigma: 2^{3 * sig:.2f} = {2 ** (3 * sig):.2f}x")
        if abs(diff / sig) < 3:
            print("RESULT: null. No device speed-up; g is bounded by the interval above.")
        elif diff > 0:
            print("RESULT: device arm faster at >3 sigma. Re-run with fresh frames and a "
                  "separate device before believing it (check seeding, caching, bugs).")
        else:
            print("RESULT: device arm SLOWER at >3 sigma. Not the hypothesis; look for a bug.")


if __name__ == "__main__":
    main()
