import numpy as np
import hashlib
import itertools
from typing import List, Tuple, Set
import math
class PhotonicSecretRecoverySimulation:
    """
    Python implementation of the Two-Level Photonic Recognition and 
    Temporally Directed Secret Recovery architecture described in the theoretical paper.
    """
    def __init__(self, secret_bits: List[int], p: float = 0.5, salt: str = "photon_salt_2026"):
        self.secret = np.array(secret_bits, dtype=int)
        self.n = len(self.secret)
        self.p = p
        self.salt = salt.encode('utf-8')
        self.commitment = self._compute_commitment(self.secret)

    def _compute_commitment(self, K: np.ndarray) -> str:
        """Computes cryptographic commitment C = H(s || K)"""
        k_bytes = ''.join(map(str, K)).encode('utf-8')
        h = hashlib.sha256()
        h.update(self.salt)
        h.update(k_bytes)
        return h.hexdigest()

    def generate_observations(self, m_observations: int) -> np.ndarray:
        """
        Simulates photonic observations X_i(t) = K_i AND R_i(t)
        R_i(t) is a Bernoulli random variable with probability p of being 1.
        Shape: (m_observations, n)
        """
        R = np.random.choice([0, 1], size=(m_observations, self.n), p=[1.0 - self.p, self.p])
        # AND-gate constraint applied per position across observations
        X = np.bitwise_and(self.secret, R)
        return X

    def apply_noise_cancellation(self, X: np.ndarray) -> np.ndarray:
        """
        Simulates a digital noise-cancellation process:
        S_c(t) = S(t) - N_hat(t)
        Here we model quantum/detector noise and a moving average / threshold estimator.
        """
        # Add synthetic Gaussian noise representing detector fluctuations
        noise = np.random.normal(0, 0.1, size=X.shape)
        S = X.astype(float) + noise
        
        # Estimated noise via rolling mean or simple low-pass thresholding
        n_hat = np.mean(noise, axis=0, keepdims=True) + 0.05 * np.sin(S)
        S_c = S - n_hat
        
        # Binarize back for recognition level 1
        return (S_c > 0.5).astype(int)

    def level_one_recognition(self, X: np.ndarray) -> Tuple[Set[int], np.ndarray]:
        """
        Level 1: Never-seen-zero recognition.
        Maintains observation counter Z_i(m) = sum(X_i(t) == 0).
        Returns the never-seen-zero set U_m and initial candidate bitstring B_m.
        """
        m = X.shape[0]
        zeros_count = np.sum(X == 0, axis=0)
        u_set = {i for i in range(self.n) if zeros_count[i] == 0}
        
        b_m = np.zeros(self.n, dtype=int)
        for i in u_set:
            b_m[i] = 1
            
        return u_set, b_m

    def level_two_recognition(self, u_set: Set[int], b_m: np.ndarray, max_budget: int = 100000) -> Tuple[bool, np.ndarray, int]:
        """
        Level 2: Hamming-weight recognition.
        Enumerates correction subsets F subset U_m in increasing order of cardinality k.
        Verifies candidate K_hat against commitment C within max_budget.
        """
        u_list = sorted(list(u_set))
        u = len(u_list)
        total_hashes = 0
        
        for k in range(u + 1):
            # Number of combinations for current Hamming weight k
            comb_count = np.comb = int(math.comb(u, k)) if k <= u else 0
            if total_hashes + comb_count > max_budget:
                print(f"[-] Hash budget B_max ({max_budget}) exceeded at correction weight k={k}.")
                return False, np.array([]), total_hashes
                
            for combo in itertools.combinations(u_list, k):
                total_hashes += 1
                # Construct candidate K_hat = B_m XOR F
                k_hat = b_m.copy()
                for idx in combo:
                    k_hat[idx] = 1 - k_hat[idx] # flip 1 to 0
                    
                if self._compute_commitment(k_hat) == self.commitment:
                    return True, k_hat, total_hashes
                    
        return False, np.array([]), total_hashes

    def run_simulation(self, m_observations: int = 10, max_budget: int = 500000):
        print(f"[*] Initializing Photonic Secret Recovery Simulation (n={self.n}, p={self.p}, m={m_observations})")
        print(f"[*] True Secret: {''.join(map(str, self.secret))}")
        print(f"[*] Commitment: {self.commitment[:16]}...")
        
        # 1. Generate photon observations
        X_raw = self.generate_observations(m_observations)
        
        # 2. Apply noise cancellation hypothesis
        X_clean = self.apply_noise_cancellation(X_raw)
        
        # 3. Level 1 Recognition
        u_set, b_m = self.level_one_recognition(X_clean)
        print(f"[+] Level 1 complete. Never-seen-zero set size |U_m| = {len(u_set)} / {self.n}")
        
        # 4. Level 2 Recognition (Hamming-weight search)
        success, k_hat, hashes = self.level_two_recognition(u_set, b_m, max_budget)
        
        if success:
            print(f"[+] SUCCESS: Reconstructed secret matches commitment!")
            print(f"    Reconstructed: {''.join(map(str, k_hat))}")
            print(f"    Total Hash Evaluations: {hashes}")
        else:
            print(f"[-] RECOVERY FAILED within budget or parameters.")
            
        return success, hashes

if __name__ == "__main__":
    np.random.seed(42)
    # Test with a 32-bit secret
    secret_example = [1, 0, 1, 1, 0, 0]
    sim = PhotonicSecretRecoverySimulation(secret_bits=secret_example, p=0.6, salt="wagenknecht_2026")
    sim.run_simulation(m_observations=82, max_budget=10000000000000000000)
