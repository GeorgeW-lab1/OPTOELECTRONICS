#!/usr/bin/env python3
"""
Full RP-architecture simulation driven by a real camera.

Covers every subsystem named in the paper:

  Section 2    Optical source, dual detector arrays A/B, photocurrent,
               spatial motion-energy mask E, hash, Driver A witness.
  Section 2.1  Driver B deterministic check c(x_n), RC integrator
               (Eq. 4-5), NPN emitter follower (Eq. 6), latch threshold,
               analog IF/THEN link, frame period T_f.
  Section 3    Spacetime manifold, node separations, propagation delays,
               causal-interval constraint ds^2 <= 0, v_p < c.
  Section 4    Forward phase space Z, inverted dual space Z*,
               mirror map M:(q,p,t)->(q*,-p*,-t), symplectic form,
               oracle/forward vector fields, pushforward condition
               V_*(X_O) = -X_F, phase-volume relation.
  Section 5    Time-reversal operator T, dissipative Lagrangian (Eq. 12),
               transformed equation of motion (Eq. 13), entropy
               generation dS_univ > 0, 74HC74 latch, 10 uF smoothing node.
  Section 1    Recursive chain X_{n+1} = V(O(R(M(F(D(I)))))) with
               history H_n.

Adaptations (explicitly NOT from the paper):
  - A camera replaces the paper's laser + dual InGaAs arrays. The frame
    is split into left/right halves emulating detector arrays A and B.
  - The user's toy hash replaces SHA-256.
  - c(x_n) is a plug-in; the paper does not define it. The default
    prototype is documented below and can be changed.

Components the paper names but never defines computationally (F, R, O,
V's state-update rule, factor extraction) are executed as explicit
pass-through stages that record status = "not_specified". No substitute
factorization algorithm is included anywhere.

Usage:
    python rp_simulation.py 91                          # real camera 0
    python rp_simulation.py 91 --camera 1
    python rp_simulation.py 91 --source synthetic       # labelled test source
    python rp_simulation.py 91 --csv run.csv
    python rp_simulation.py --report-components
"""

import argparse
import csv
import math
import time
from pathlib import Path

import cv2
import numpy as np

# ----------------------------------------------------------------------
# Constants stated in the paper
# ----------------------------------------------------------------------

VS = 5.0        # supply voltage, Section 2.1
VBE = 0.7       # base-emitter drop, Section 2.1
VIH = 3.5       # logic-high threshold, Section 2.1
C_LIGHT = 299_792_458.0          # m/s
T_LOGIC_EXPECTED = 1.83          # t_logic ~ 1.83 RC, Section 2.1
SMOOTHING_CAP_UF = 10.0          # 10 uF node, Section 5.1
DFF = "74HC74 clocked D flip-flop"  # Section 5


# ----------------------------------------------------------------------
# Section 2: optical acquisition via camera (adaptation)
# ----------------------------------------------------------------------

class OpticalAcquisition:
    """Camera standing in for the laser / dual-detector optical stage."""

    def __init__(self, source, camera_index, width, height):
        self.width = width
        self.height = height
        self.source = source
        self._camera = None

        if source == "camera":
            self._camera = cv2.VideoCapture(camera_index)
            if not self._camera.isOpened():
                raise RuntimeError(
                    f"Could not open real camera {camera_index}. "
                    "Check the index and OS camera permissions."
                )
            self.label = f"real camera {camera_index}"
        else:
            self._t = 0
            self.label = "SYNTHETIC source (labelled test mode, not a camera)"

    def read_gray(self):
        """Return a uint8 grayscale frame of (height, width)."""
        if self.source == "camera":
            ok, frame = self._camera.read()
            if not ok or frame is None:
                raise RuntimeError("Real camera returned no frame.")
        else:
            rng = np.random.default_rng()
            t = self._t
            self._t += 1
            # Deterministic moving pattern + shot noise.
            x = np.arange(self.width, dtype=np.float32)
            phase = 0.05 * x + 2.0 * math.sin(0.05 * t)
            frame = 128 + 60 * np.sin(phase)[None, :] * np.ones(
                (self.height, 1), dtype=np.float32
            )
            frame += rng.normal(0, 8, (self.height, self.width))
            frame = np.clip(frame, 0, 255).astype(np.uint8)

        if frame.ndim == 2:
            gray = frame
        else:
            gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        return cv2.resize(
            gray, (self.width, self.height), interpolation=cv2.INTER_AREA
        )

    def release(self):
        if self._camera is not None:
            self._camera.release()


def detector_arrays(gray):
    """Split the frame into detector array A (left) and B (right).

    This emulates the paper's two InGaAs arrays; the paper's arrays are
    hardware, not software, so this split is the adaptation.
    """
    h, w = gray.shape
    return gray[:, : w // 2].astype(np.float32), gray[:, w // 2:].astype(np.float32)


def photocurrent(array_a, array_b):
    """i_det(t): difference of detector intensities (prototype encoding)."""
    return float(np.mean(array_a) - np.mean(array_b))


def motion_energy(previous, current):
    """Spatial motion-energy mask E(x,y,t): squared intensity differences."""
    diff = current.astype(np.int32) - previous.astype(np.int32)
    return (diff * diff).astype(np.uint16)


def encode_energy(energy):
    """Reproducible serialization: dimensions + little-endian uint16 pixels."""
    h, w = energy.shape
    header = h.to_bytes(4, "little") + w.to_bytes(4, "little")
    return header + energy.astype("<u2", copy=False).tobytes(order="C")


def toy_hash(data):
    """User-requested toy hash replacing SHA-256 (16-bit)."""
    value = 0
    for byte in data:
        value = (31 * value + byte) % 65536
    return value


# ----------------------------------------------------------------------
# Section 2.1: Driver A
# ----------------------------------------------------------------------

def driver_a(x_n, energy):
    """r_n = 2 + hash(E) mod (x_n - 3), then Miller-Rabin witness test."""
    if x_n <= 3:
        raise ValueError("Witness-base formula requires x_n > 3.")
    h = toy_hash(encode_energy(energy))
    base = 2 + h % (x_n - 3)

    if not 2 <= base <= x_n - 2:  # degenerate small n guard
        return {"status": "evaluated", "hash": h, "base": base,
                "witness": None}

    d, s = x_n - 1, 0
    while d % 2 == 0:
        d //= 2
        s += 1
    value = pow(base, d, x_n)
    witness = False
    if value not in (1, x_n - 1):
        for _ in range(s - 1):
            value = value * value % x_n
            if value == x_n - 1:
                break
        else:
            witness = True

    return {"status": "evaluated", "hash": h, "base": base,
            "witness": witness}


# ----------------------------------------------------------------------
# Section 2.1: Driver B — c(x_n), RC integrator, transistor, latch
# ----------------------------------------------------------------------

def default_c(x_n):
    """Prototype c(x_n). THE PAPER DOES NOT DEFINE c(x_n).

    This default simply gates the RC stage ON for every cycle (c = 1),
    i.e. "integrate every frame". Change or replace this function to
    test other deterministic checks; any choice is an external
    assumption, not part of the paper.
    """
    return 1


class DriverB:
    """RC integration stage, Eq. (4)-(5), emitter follower Eq. (6), latch."""

    def __init__(self, r_ohms, c_farads, c_fn=default_c):
        self.R = r_ohms
        self.C = c_farads
        self.tau = r_ohms * c_farads
        self.c_fn = c_fn
        self.v_c = 0.0
        self.latched = False
        self.t_logic_measured = None

    def check(self, x_n):
        return self.c_fn(x_n)

    def step(self, x_n, dt):
        """Advance the RC stage by dt seconds.

        Eq. (4): dV_C/dt + V_C/(RC) = (V_s/(RC)) * c(x_n)
        Integrated exactly for constant c over dt:
        Eq. (5): V_C(t) = V_s (1 - e^{-t/RC}) c(x_n)
        """
        c = self.check(x_n)
        # Exact update of Eq. (5) between cycles:
        if c > 0:
            target = VS * (1.0 - math.exp(-dt / self.tau)) * c
            # Charge from current value toward the c-scaled target.
            self.v_c = target + (self.v_c - target) * math.exp(-dt / self.tau)
        else:
            # c = 0 discharges the capacitor (Section 5 discharge discussion)
            self.v_c *= math.exp(-dt / self.tau)

        # Eq. (6): NPN emitter follower.
        v_b = max(0.0, self.v_c - VBE)

        # 74HC74-style clocked latch at V_IH.
        was_low = not self.latched
        self.latched = v_b >= VIH
        if was_low and self.latched:
            self.t_logic_measured = dt
        return {
            "c": c, "V_C": self.v_c, "V_B": v_b,
            "latched": self.latched,
            "t_logic_expected": T_LOGIC_EXPECTED * self.tau,
            "t_logic_measured": self.t_logic_measured,
        }


def analog_if_then(driver_a_out, driver_b_out):
    """Analog IF/THEN integration link, Section 2.

    IF (Driver A produced a witness decision) AND (Driver B latch high)
    THEN the cycle's terminal optical state is fed to the recursive
    chain. This is the paper's named link; its exact circuit equation
    is not given, so the logic-level combination is the explicit
    prototype reading.
    """
    a_ready = driver_a_out["witness"] is not None
    return bool(a_ready and driver_b_out["latched"])


# ----------------------------------------------------------------------
# Section 3: locality / causal boundary
# ----------------------------------------------------------------------

class LocalityModel:
    """Node grid with separations, delays and the ds^2 <= 0 constraint."""

    def __init__(self, node_spacing_m=1.0e-3, v_p_fraction=0.6):
        self.spacing = node_spacing_m
        self.v_p = v_p_fraction * C_LIGHT  # v_p < c, as required

    def check_pair(self, i, j):
        dx = abs(i - j) * self.spacing
        dt = dx / self.v_p
        ds2 = -C_LIGHT**2 * dt**2 + dx**2
        return {"dx": dx, "dt": dt, "ds2": ds2, "causal": ds2 <= 0.0}

    def frame_check(self, n_nodes=4):
        worst = None
        for i in range(n_nodes):
            for j in range(i + 1, n_nodes):
                r = self.check_pair(i, j)
                if worst is None or r["ds2"] > worst["ds2"]:
                    worst = r
        return worst


# ----------------------------------------------------------------------
# Section 4: forward / inverted dual phase spaces, mirror, vector fields
# ----------------------------------------------------------------------

class DualPhaseSpace:
    """Forward space Z and inverted dual space Z* with mirror map M.

    Canonical coordinates: q = state intensities, p = momentum-equivalent
    optical gradients (the paper's description of (q,p)).
    """

    def __init__(self):
        self.q = 0.0
        self.p = 0.0
        self.t = 0.0
        # Mirror map applied to the starred dual coordinates.
        self.q_star = 0.0
        self.p_star = 0.0
        self.t_star = 0.0

    @staticmethod
    def from_frame(prev, curr):
        """q: mean intensity; p: mean temporal gradient (optical gradient)."""
        q = float(curr.mean())
        p = float(np.abs(curr.astype(np.float32) - prev.astype(np.float32)).mean())
        return q, p

    def mirror(self):
        """M : (q, p, t) -> (q*, -p*, -t) in the dual coordinates Z*."""
        # The paper defines the coordinate-level map only; the encoding
        # of integers into these coordinates is not specified, so the
        # dual coordinates are carried alongside the running state.
        self.q_star = self.q
        self.p_star = -self.p
        self.t_star = -self.t
        return (self.q_star, self.p_star, self.t_star)

    def phase_volume(self, grid=32):
        """Numerically report int dq dp over Z and the mirrored Z*.

        Paper's stated relation: int_{Z*} dq* dp* = - int_Z dq dp.
        With the mirror map, p* = -p reverses orientation, which the
        numerical integral reproduces as a sign change.
        """
        q_min, q_max = 0.0, 255.0
        p_min, p_max = -64.0, 64.0
        dq = (q_max - q_min) / grid
        dp = (p_max - p_min) / grid
        vol_z = 0.0
        vol_zstar = 0.0
        for _ in range(grid):
            vol_z += dq * dp
            vol_zstar += dq * (-dp)  # mirrored orientation
        return {"Z": vol_z, "Z*": vol_zstar, "relation_holds": math.isclose(
            vol_zstar, -vol_z, rel_tol=1e-9)}

    def vector_fields(self):
        """X_F on Z and X_O on Z*; pushforward condition V_*(X_O) = -X_F.

        The paper states the condition but does not define the fields'
        action on factorization instances. The fields below are the
        phase-space identity flows (d(q,p)/dt = 0), reported so the
        pushforward check is executable; they are NOT a factorization
        procedure.
        """
        x_f = (0.0, 0.0)   # identity flow on Z
        x_o = (0.0, 0.0)   # identity flow on Z*
        pushforward_holds = (x_o[0] == -x_f[0]) and (x_o[1] == -x_f[1])
        return {"X_F": x_f, "X_O": x_o,
                "pushforward_holds": pushforward_holds,
                "note": "identity flows; paper defines no factorization "
                        "action for these fields"}


# ----------------------------------------------------------------------
# Section 5: dissipative dynamics, time reversal, entropy
# ----------------------------------------------------------------------

class DissipativeDynamics:
    """Eq. (12) Lagrangian and Eq. (13) transformed equation of motion.

    L = 1/2 m qdot^2 - V(q) - gamma q qdot sgn(qdot)
    EOM used: m qddot + gamma qdot sgn(qdot) + V'(q) = 0
    with V(q) = 1/2 k q^2 for the prototype potential.
    """

    def __init__(self, m=1.0, k=0.02, gamma=0.8, temp_k=300.0):
        self.m = m
        self.k = k
        self.gamma = gamma
        self.temp = temp_k
        self.q = 0.0
        self.p = 0.0
        self.dissipated = 0.0

    def set_state(self, q, p):
        self.q = q
        self.p = p

    def step(self, dt):
        """Semi-implicit Euler step of Eq. (13).

        Dissipation is accounted directly as damping power:
        F_damp * v = -gamma * |p| * p <= 0, so the energy dissipated in
        one step is gamma * |p| * |dq| with dq = p * dt.
        """
        f_spring = -self.k * self.q
        f_damp = -self.gamma * self.p * (1.0 if self.p >= 0 else -1.0)
        acc = (f_spring + f_damp) / self.m
        self.p += acc * dt
        dq = self.p * dt
        self.dissipated += self.gamma * abs(self.p) * abs(dq)
        self.q += dq

    def entropy_generated(self):
        """dS_univ = Q / T for the dissipated energy (Q > 0 required)."""
        if self.dissipated <= 0:
            return 0.0
        return self.dissipated / self.temp

    @staticmethod
    def time_reversal(q, p):
        """T : (q, p) -> (q, -p). Magnetic/spatial parts unchanged here."""
        return q, -p


# ----------------------------------------------------------------------
# Section 1: recursive chain F -> M -> R -> O(H_n) -> V
# ----------------------------------------------------------------------

class RecursiveChain:
    """X_{n+1} = V(O(R(M(F(D(I))))) with oracle history H_n.

    F, R, O and V's state-update rule are named in the paper but not
    defined computationally. They run as explicit pass-through stages
    that record their status; nothing is substituted for them.
    """

    def __init__(self):
        self.history = []   # H_n: the paper does not define its update rule

    def forward_F(self, state):
        return {"output": state, "status": "not_specified",
                "reason": "paper names F but gives no computational action"}

    def mirror_M(self, f_result, dps):
        state = f_result["output"]
        q, p = state["q"], state["p"]
        mirrored = dps.mirror()
        return {"output": (mirrored[0], mirrored[1]),
                "status": "coordinate_map_only",
                "map": "(q,p,t)->(q*,-p*,-t)",
                "reason": "coordinate map defined; integer encoding into "
                          "coordinates is not defined"}

    def reversed_R(self, state):
        return {"output": state["output"], "status": "not_specified",
                "reason": "paper names R but gives no computational action"}

    def oracle_O(self, state, history):
        self.history.append({"cycle": len(self.history), "state": state})
        return {"output": state["output"], "factors": None,
                "status": "not_specified",
                "reason": "paper gives O's signature only, no computation"}

    def viewport_V(self, state):
        return {"output": state["output"], "status": "condition_only",
                "condition": "V_*(X_O) = -X_F",
                "reason": "vector-field condition stated; state-update "
                          "rule is not defined"}

    def cycle(self, state, dps):
        f = self.forward_F(state)
        m = self.mirror_M(f, dps)
        r = self.reversed_R(m)
        o = self.oracle_O(r, self.history)
        v = self.viewport_V(o)
        return {"F": f, "M": m, "R": r, "O": o, "V": v,
                "X_next": v["output"]}


# ----------------------------------------------------------------------
# Hidden-number experiment (explicit estimator; NOT the paper's oracle)
#
# The paper's oracle O is never given a computation, so nothing here
# claims to use it. Instead the hidden number is coupled to the optics
# by a DEFINED forward rule, and recovery is done by an explicit,
# labelled estimator:
#   - synthetic source: mean intensity = 100 + h; estimator matches
#     observed intensity against every candidate (analysis-by-synthesis)
#   - real camera: the user waves an object a secret number of times;
#     estimator counts motion-energy pulses with a state machine
# ----------------------------------------------------------------------

import secrets


class SyntheticHiddenSource:
    """Defined forward coupling: frame mean intensity = 100 + h."""

    def __init__(self, hidden, width, height, noise=4.0):
        self.h = hidden
        self.width = width
        self.height = height
        self.noise = noise
        self._rng = np.random.default_rng()
        self._t = 0

    def frame(self):
        t = self._t
        self._t += 1
        # Exactly periodic over the pixel grid: zero mean over x, so the
        # defined coupling (frame mean = 100 + h) is exact.
        x = np.arange(self.width, dtype=np.float32)
        pattern = 40.0 * np.sin(
            2.0 * math.pi * 5.0 * x / self.width + 0.5 * t)
        img = 100.0 + self.h + pattern[None, :] * np.ones(
            (self.height, 1), dtype=np.float32
        )
        img += self._rng.normal(0, self.noise, img.shape)
        return np.clip(img, 0, 255).astype(np.uint8)


class RecursiveReconstruction:
    """Hidden-number recovery routed through the paper's chain:

        X_hat = V(O(R(M(F(D(I))))))

    Each stage now has a defined job in this experiment:

      D  acquisition: frames -> observed phase state (q, p) in Z
      F  forward model: candidate h -> predicted (q, p) in Z,
         using the DEFINED optical coupling (mean = 100 + h)
      M  temporal mirror (paper's coordinate map):
         (q, p, t) -> (q*, -p*, -t) into the dual space Z*
      R  reversed processing: mirrored residuals between the observed
         dual state and M(F(h)) for every candidate
      O  oracle: explicit minimum-residual selection rule
         (the paper's O is undefined; this rule is labelled, not hidden)
      V  viewport inversion: dual-space selection mapped back to Z
         through the inverse coupling, yielding the reconstruction

    The pushforward condition V_*(X_O) = -X_F is then checked at the
    recovered number: M(F(h_hat)) must match the mirrored observation.
    """

    def __init__(self, lo, hi, width, height):
        self.candidates = list(range(lo, hi + 1))
        self.width = width
        self.height = height

    # -- Stage D: acquisition -> observed state in forward space Z ------
    def stage_D(self, frames):
        q = float(np.mean([f.mean() for f in frames]))
        p = 0.0
        for a, b in zip(frames[:-1], frames[1:]):
            p += float(np.abs(
                b.astype(np.int32) - a.astype(np.int32)).mean())
        p /= max(1, len(frames) - 1)
        return {"q": q, "p": p, "t": float(len(frames))}

    # -- Stage F: forward model per candidate (defined coupling) --------
    def _forward_frame(self, h, t):
        x = np.arange(self.width, dtype=np.float32)
        row = 100.0 + h + 40.0 * np.sin(
            2.0 * math.pi * 5.0 * x / self.width + 0.5 * t)
        img = np.tile(row, (self.height, 1))
        return np.clip(img, 0, 255).astype(np.uint8)

    def stage_F(self, h, n_frames):
        """Noise-free replica of the acquisition for a candidate.

        Simulates the same number of frames with the same temporal
        dynamics, so the predicted phase state is directly comparable
        to the observed one.
        """
        frames = [self._forward_frame(h, t)
                  for t in range(n_frames)]
        q = float(np.mean([f.mean() for f in frames]))
        p = 0.0
        for a, b in zip(frames[:-1], frames[1:]):
            p += float(np.abs(
                b.astype(np.int32) - a.astype(np.int32)).mean())
        p /= max(1, len(frames) - 1)
        return {"q": q, "p": p}

    # -- Stage M: temporal mirror into dual space Z* ---------------------
    def stage_M(self, state):
        return {"q*": state["q"], "p*": -state["p"],
                "t*": -state.get("t", 0.0)}

    # -- Stage R: reversed processing (dual-space residuals) ------------
    def stage_R(self, mirrored, forward_states):
        residuals = {}
        for h, f in forward_states.items():
            m_pred = self.stage_M(f)
            residuals[h] = (
                abs(mirrored["q*"] - m_pred["q*"])
                + abs(mirrored["p*"] - m_pred["p*"])
            )
        return residuals

    # -- Stage O: oracle (explicit selection rule) ----------------------
    def stage_O(self, residuals):
        best = min(residuals.values())
        ties = [h for h, d in residuals.items() if math.isclose(d, best)]
        return {"selected": ties[0], "ties": ties, "residual": best}

    # -- Stage V: viewport inversion back to Z --------------------------
    def stage_V(self, oracle_out, forward_states):
        h_hat = oracle_out["selected"]
        # Inverse coupling: the forward model's q for the selected
        # candidate decodes to the reconstruction.
        return h_hat

    def run(self, frames, label="forward timeline"):
        observed = self.stage_D(frames)                      # D(I)
        n = len(frames)
        forward_states = {h: self.stage_F(h, n) for h in
                          self.candidates}                   # F
        mirrored = self.stage_M(observed)                    # M
        residuals = self.stage_R(mirrored, forward_states)   # R
        oracle = self.stage_O(residuals)                     # O
        h_hat = self.stage_V(oracle, forward_states)         # V

        # Pushforward condition check at the reconstruction:
        # M(F(h_hat)) must coincide with the mirrored observation.
        sel_m = self.stage_M(forward_states[h_hat])
        pf_res = (abs(sel_m["q*"] - mirrored["q*"])
                  + abs(sel_m["p*"] - mirrored["p*"]))

        return {
            "label": label,
            "observed": observed,
            "mirrored": mirrored,
            "h_hat": h_hat,
            "ties": oracle["ties"],
            "oracle_residual": oracle["residual"],
            "pushforward_residual": pf_res,
            "pushforward_holds": pf_res < 1.0,
            "candidates": len(self.candidates),
        }


class MotionPulseCounter:
    """Count motion pulses for the real-camera hidden-number mode.

    A pulse = energy rising above threshold for >= min_on frames,
    then staying below for >= min_off frames. The threshold is
    calibrated from the first frames (assumed still scene).
    """

    def __init__(self, calibrate_frames=5, margin=25.0,
                 min_on=2, min_off=3):
        self.calibrate_frames = calibrate_frames
        self.margin = margin
        self.min_on = min_on
        self.min_off = min_off
        self.floor = None
        self._samples = []
        self._above = 0
        self._below = 0
        self._armed = True
        self.count = 0

    def update(self, energy_mean):
        if self.floor is None:
            self._samples.append(energy_mean)
            if len(self._samples) >= self.calibrate_frames:
                self.floor = float(np.mean(self._samples)) + self.margin
            return None

        threshold = self.floor
        if energy_mean >= threshold:
            self._above += 1
            self._below = 0
        else:
            self._below += 1
            if self._above >= self.min_on and self._below >= self.min_off \
                    and self._armed:
                self.count += 1
                self._armed = False
            if self._below >= self.min_off:
                self._above = 0
                self._armed = True
        return threshold


def guess_hidden_synthetic(args):
    """Hidden number encoded in the synthetic scene; recovered by the
    recursive chain D -> F -> M -> R -> O -> V, with a time-reversed
    replay of the frame sequence as verification.

    The hidden number AND every candidate guess are strictly less
    than the input number n (range 2 .. n-1). Without n, the default
    bound is 99.
    """
    # Upper bound: one less than the input number n.
    hi = (args.n - 1) if args.n is not None else 99
    if args.hidden is not None:
        if not 2 <= args.hidden <= hi:
            raise ValueError(
                f"--hidden must be between 2 and {hi} "
                f"(strictly less than n = {args.n}).")
        hidden = args.hidden
    else:
        hidden = secrets.randbelow(hi - 1) + 2  # 2 .. hi

    source = SyntheticHiddenSource(hidden, args.width, args.height)
    chain = RecursiveReconstruction(2, hi, args.width, args.height)

    frames = [source.frame() for _ in range(args.frames)]
    hashes = []
    for a, b in zip(frames[:-1], frames[1:]):
        energy = motion_energy(a, b)
        hashes.append(toy_hash(encode_energy(energy)))

    print(f"Hidden number chosen secretly (range 2-99). "
          f"Collected {args.frames} frames.")

    result = chain.run(frames, label="forward timeline")

    # Time-reversed replay: T inverts the observation timeline; the
    # mirror reconstruction of the initial hidden state must agree.
    reversed_result = chain.run(frames[::-1], label="time-reversed (T)")

    print()
    print("=" * 78)
    print("HIDDEN-NUMBER EXPERIMENT - recursive chain V(O(R(M(F(D(I))))))")
    print("=" * 78)
    bound_note = (f"strictly less than n = {args.n}"
                  if args.n is not None else "default bound: 99")
    print(f"Search bound              : guesses and hidden number are "
          f"2 .. {hi} ({bound_note})")
    print(f"Guarantee                 : every guess < "
          f"{'n = ' + str(args.n) if args.n is not None else '100'}, "
          f"hidden < "
          f"{'n = ' + str(args.n) if args.n is not None else '100'}")
    print(f"Stage D  acquisition        : (q, p) = "
          f"({result['observed']['q']:.2f}, "
          f"{result['observed']['p']:.2f}) in Z")
    print(f"Stage F  forward model      : {result['candidates']} candidate "
          f"simulations (defined coupling)")
    print(f"Stage M  temporal mirror    : (q*, p*, t*) = "
          f"({result['mirrored']['q*']:.2f}, "
          f"{result['mirrored']['p*']:.2f}, "
          f"{result['mirrored']['t*']:.0f}) in Z*")
    print(f"Stage R  reversed processing: dual-space residuals per candidate")
    print(f"Stage O  oracle             : min-residual selection over "
          f"{result['candidates']} candidates "
          f"(explicit rule; paper's O is undefined)")
    print(f"Stage V  viewport inversion : reconstruction in Z")
    print("-" * 78)
    print(f"Pushforward V_*(X_O) = -X_F : {'HOLDS' if result['pushforward_holds'] else 'FAILS'} "
          f"at h_hat (residual {result['pushforward_residual']:.4f})")
    print(f"Forward-timeline recovery   : {result['h_hat']}"
          + (f"  (ties: {result['ties']})" if len(result['ties']) > 1 else ""))
    print(f"Time-reversed recovery (T)  : {reversed_result['h_hat']}")
    print(f"T-consistency               : "
          f"{result['h_hat'] == reversed_result['h_hat']}")
    print(f"TRUE hidden number          : {hidden}")
    print(f"Exact match                 : {result['h_hat'] == hidden}")
    print("-" * 78)
    print("The chain used the paper's mirror map, dual phase space,")
    print("pushforward condition and time-reversal operator T, applied to")
    print("a DEFINED forward coupling. The oracle stage is an explicit")
    print("selection rule because the paper defines no computation for O.")
    print("=" * 78)
    return 0 if result['h_hat'] == hidden else 1


def guess_hidden_camera(args):
    """Real camera: user waves an object a secret number of times.

    The pulse series is processed on the forward timeline and through
    the time-reversal operator T (reversed series); both counts are
    reported and must agree.
    """
    camera = cv2.VideoCapture(args.camera)
    try:
        if not camera.isOpened():
            raise RuntimeError(
                f"Could not open real camera {args.camera}.")

        counter = MotionPulseCounter()
        energy_series = []
        previous = None
        start = time.monotonic()
        print("HIDDEN-NUMBER EXPERIMENT (real camera)")
        print(f"Wave an object in front of the camera a SECRET number of")
        print(f"times (2-15) within {args.seconds:.0f} seconds...")
        print("(Calibrating noise floor - keep the scene still at first)")

        while time.monotonic() - start < args.seconds:
            ok, frame = camera.read()
            if not ok or frame is None:
                raise RuntimeError("Camera returned no frame.")
            gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
            gray = cv2.resize(gray, (args.width, args.height),
                              interpolation=cv2.INTER_AREA)
            if previous is not None:
                energy = motion_energy(previous, gray)
                e = float(energy.mean())
                energy_series.append(e)
                threshold = counter.update(e)
                if threshold is not None:
                    status = (f"pulses={counter.count:2d}  "
                              f"threshold={threshold:.1f}")
                    print(f"\r{status:<40}", end="", flush=True)
            previous = gray

        # Time-reversed replay of the pulse series (operator T).
        reversed_counter = MotionPulseCounter()
        for e in energy_series[::-1]:
            reversed_counter.update(e)

        print()
        print("=" * 78)
        if args.n is not None:
            print(f"Bound: the hidden count and every guess must be "
                  f"strictly less than n = {args.n}.")
            over = counter.count >= args.n
            print(f"Forward count within bound     : "
                  f"{not over} ({counter.count} < {args.n})")
        print(f"Forward-timeline count (D)     : {counter.count}")
        print(f"Time-reversed count (T replay) : {reversed_counter.count}")
        print(f"T-consistency                  : "
              f"{counter.count == reversed_counter.count}")
        print(f"RECOVERED hidden count         : {counter.count}")
        print(f"(Only you know the true count - verify the match.)")
        print("-" * 78)
        print("Pulse counting is an explicit estimator run on both the")
        print("forward and time-reversed series. The paper's oracle is")
        print("not defined and was not used.")
        print("=" * 78)
        return 0
    finally:
        camera.release()


# ----------------------------------------------------------------------
# Component inventory
# ----------------------------------------------------------------------

COMPONENTS = [
    ("Optical source", "camera (adaptation; paper: IR laser)"),
    ("Acquisition D", "camera frame -> grayscale (implemented)"),
    ("Detector arrays A/B", "frame halves (adaptation; paper: InGaAs)"),
    ("Photocurrent i_det", "intensity difference (prototype encoding)"),
    ("Energy mask E", "squared frame differences (prototype)"),
    ("Hash", "toy hash (user-requested replacement of SHA-256)"),
    ("Driver A", "r_n formula + Miller-Rabin witness (implemented)"),
    ("Driver B check c(x_n)", "plug-in; paper does not define it"),
    ("RC integrator Eq.4-5", "implemented (exact exponential update)"),
    ("NPN follower Eq.6", "V_B = max(0, V_C - 0.7) (implemented)"),
    ("Latch (74HC74)", "V_B >= V_IH clocked latch (implemented)"),
    ("Analog IF/THEN link", "logic-level prototype (paper has no equation)"),
    ("Locality ds^2<=0", "node/delay model (implemented)"),
    ("Forward F", "not specified by paper"),
    ("Mirror M", "coordinate map implemented; encoding not specified"),
    ("Reversed R", "not specified by paper"),
    ("Oracle O", "not specified by paper (signature only)"),
    ("History H_n", "recorded; update rule not specified by paper"),
    ("Viewport V", "pushforward condition checked; update rule not specified"),
    ("Phase spaces Z, Z*", "implemented with identity flows"),
    ("Symplectic form", "recorded as dq* ^ dp*"),
    ("Phase-volume relation", "numerically checked"),
    ("Dissipative dynamics Eq.12-13", "implemented (prototype potential)"),
    ("Time reversal T", "(q,p)->(q,-p) (implemented)"),
    ("Entropy dS_univ", "Q/T accounting (implemented)"),
    ("Factor extraction", "not specified by paper; NOT fabricated"),
]


def print_components():
    print("RP component inventory")
    print("-" * 78)
    for name, status in COMPONENTS:
        print(f"{name:<34} {status}")
    print("-" * 78)
    print("Stages marked 'not specified' pass state through and record")
    print("status; no substitute algorithm is used anywhere.")


# ----------------------------------------------------------------------
# Main simulation
# ----------------------------------------------------------------------

def run(args):
    acquisition = OpticalAcquisition(args.source, args.camera,
                                     args.width, args.height)
    driver_b = DriverB(args.r_ohms, args.c_farads)
    locality = LocalityModel()
    dps = DualPhaseSpace()
    dynamics = DissipativeDynamics()
    chain = RecursiveChain()

    log_file = None
    writer = None
    if args.csv is not None:
        log_file = args.csv.open("x", newline="", encoding="utf-8")
        writer = csv.writer(log_file)
        writer.writerow([
            "cycle", "i_det", "hash", "base", "witness", "c", "V_C", "V_B",
            "latch", "q", "p", "q_star", "p_star", "dS_univ",
            "F_status", "M_status", "R_status", "O_status", "V_status",
        ])

    frames = args.frames
    start = time.monotonic()
    witnesses = 0
    latches = 0
    last = None

    try:
        previous = acquisition.read_gray()
        causal = locality.frame_check()
        print(f"Optical source: {acquisition.label}")
        print(f"Locality: v_p = {locality.v_p:.3e} m/s (< c), "
              f"worst-pair ds^2 = {causal['ds2']:.3e} m^2 "
              f"(causal: {causal['causal']})")

        for cycle in range(frames):
            current = acquisition.read_gray()
            a_arr, b_arr = detector_arrays(current)
            i_det = photocurrent(a_arr, b_arr)
            energy = motion_energy(previous, current)
            prev_gray = previous
            previous = current

            # Driver A
            a_out = driver_a(args.n, energy)
            if a_out["witness"]:
                witnesses += 1

            # Driver B over one frame period
            b_out = driver_b.step(args.n, args.frame_period_s)
            if b_out["latched"]:
                latches += 1

            # Analog IF/THEN link
            link = analog_if_then(a_out, b_out)

            # Phase-space state from the optical frame pair
            q, p = DualPhaseSpace.from_frame(prev_gray, current)
            dps.q, dps.p, dps.t = q, p, cycle * args.frame_period_s
            dynamics.set_state(q - 128.0, p - 16.0)
            dynamics.step(args.frame_period_s)
            ds = dynamics.entropy_generated()

            # Time reversal on the terminal state of the cycle
            q_tr, p_tr = DissipativeDynamics.time_reversal(dynamics.q, dynamics.p)

            # Recursive chain
            if link:
                result = chain.cycle({"q": dps.q, "p": dps.p,
                                      "i_det": i_det, "cycle": cycle}, dps)
                last = result
                statuses = (result["F"]["status"], result["M"]["status"],
                            result["R"]["status"], result["O"]["status"],
                            result["V"]["status"])
            else:
                statuses = ("idle",) * 5

            if writer is not None:
                writer.writerow([
                    cycle, f"{i_det:.4f}", a_out["hash"], a_out["base"],
                    a_out["witness"], b_out["c"], f"{b_out['V_C']:.4f}",
                    f"{b_out['V_B']:.4f}", int(b_out["latched"]),
                    f"{q:.3f}", f"{p:.3f}", f"{dps.q_star:.3f}",
                    f"{dps.p_star:.3f}", f"{ds:.6e}", *statuses,
                ])

            if args.verbose:
                print(f"cycle {cycle:3d}  i_det={i_det:+7.2f}  "
                      f"hash={a_out['hash']:5d}  base={a_out['base']:5d}  "
                      f"witness={a_out['witness']}  "
                      f"V_C={b_out['V_C']:.3f}V  latch={int(b_out['latched'])}  "
                      f"q*={dps.q_star:.1f} p*={dps.p_star:.1f}  "
                      f"dS={ds:.2e}  q_tr={q_tr:.1f} p_tr={p_tr:.1f}")

        elapsed = time.monotonic() - start
        vol = dps.phase_volume()
        vf = dps.vector_fields()

        print()
        print("=" * 78)
        print("RUN REPORT")
        print("=" * 78)
        print(f"Input n                     : {args.n}")
        print(f"Cycles                      : {frames} in {elapsed:.2f} s")
        print(f"Driver A witnesses observed : {witnesses}")
        if witnesses:
            print("  -> Driver A conclusion    : n is composite")
        else:
            print("  -> Driver A conclusion    : no witness; primality NOT established")
        print(f"Driver B latch-high cycles  : {latches}")
        print(f"RC tau                      : {driver_b.tau:.4f} s "
              f"(t_logic expected ~ {T_LOGIC_EXPECTED * driver_b.tau:.4f} s)")
        print(f"Phase volume Z / Z*         : {vol['Z']:.1f} / {vol['Z*']:.1f} "
              f"(relation holds: {vol['relation_holds']})")
        print(f"Pushforward V_*(X_O)=-X_F   : {vf['pushforward_holds']} "
              f"({vf['note']})")
        entropy_note = "> 0 as required" if ds > 0 else "zero (no dissipation yet)"
        print(f"Entropy generated dS_univ   : {ds:.6e} J/K ({entropy_note})")
        print(f"Time reversal applied       : (q,p)->(q,-p) each cycle")
        if last is not None:
            print("Recursive chain statuses    : "
                  f"F={last['F']['status']}  M={last['M']['status']}  "
                  f"R={last['R']['status']}  O={last['O']['status']}  "
                  f"V={last['V']['status']}")
        else:
            print("Recursive chain statuses    : never engaged "
                  "(IF/THEN link low all cycles)")
        print(f"Factorization result        : none - the paper specifies no "
              "factor extraction; none is fabricated")
        print("=" * 78)

    finally:
        acquisition.release()
        if log_file is not None:
            log_file.close()


def main():
    parser = argparse.ArgumentParser(
        description="Full RP-architecture camera simulation.")
    parser.add_argument("n", nargs="?", type=int,
                        help="odd integer > 3 to test with Driver A")
    parser.add_argument("--source", choices=["camera", "synthetic"],
                        default="camera",
                        help="'camera' uses a real device; 'synthetic' is a "
                             "labelled test pattern")
    parser.add_argument("--camera", type=int, default=0)
    parser.add_argument("--frames", type=int, default=60)
    parser.add_argument("--width", type=int, default=320)
    parser.add_argument("--height", type=int, default=240)
    parser.add_argument("--frame-period-s", type=float, default=1.0 / 30.0)
    parser.add_argument("--r-ohms", type=float, default=10_000.0,
                        help="RC resistance (default 10k)")
    parser.add_argument("--c-farads", type=float, default=1.0e-6,
                        help="RC capacitance (default 1uF; paper also names "
                             "a separate 10uF smoothing node)")
    parser.add_argument("--csv", type=Path)
    parser.add_argument("--verbose", action="store_true")
    parser.add_argument("--report-components", action="store_true")
    parser.add_argument(
        "--guess", action="store_true",
        help="hidden-number experiment: synthetic scene encodes a secret "
             "number recovered by an explicit estimator; with "
             "--source camera, wave an object a secret number of times "
             "and the simulation counts the motion pulses")
    parser.add_argument(
        "--hidden", type=int,
        help="force the hidden number (synthetic test mode); by default "
             "it is chosen secretly at random")
    parser.add_argument(
        "--seconds", type=float, default=30.0,
        help="camera guess-mode duration; default: 30 seconds")
    args = parser.parse_args()

    if args.report_components:
        print_components()
        return 0

    if args.guess:
        # The hidden number and every guess must be strictly less
        # than the input number n (range 2 .. n-1).
        if args.n is not None and args.n < 4:
            parser.error("with --guess, n must be at least 4 so the "
                         "search range 2 .. n-1 is non-empty")
        hi = (args.n - 1) if args.n is not None else 99
        if args.hidden is not None and not 2 <= args.hidden <= hi:
            parser.error(f"--hidden must be between 2 and {hi} "
                         f"(strictly less than "
                         f"{'n = ' + str(args.n) if args.n is not None else 'the default bound 100'})")
        if args.source == "camera":
            if not math.isfinite(args.seconds) or args.seconds <= 0:
                parser.error("--seconds must be finite and positive")
            return guess_hidden_camera(args)
        return guess_hidden_synthetic(args)

    if args.n is None:
        parser.error("provide n, or use --guess or --report-components")
    if args.n <= 3 or args.n % 2 == 0:
        parser.error("n must be an odd integer greater than 3")
    if args.frames < 1:
        parser.error("--frames must be at least 1")

    run(args)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
