from sympy import randprime, factorint


N = 9999999999999999999999999999

print("N:", N)
print("Bit length:", N.bit_length())

# Factorisation
factors = factorint(N)

print("Factors:", factors)
print("Verified:", all(N % f == 0 for f in factors))
