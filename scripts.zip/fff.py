#!/usr/bin/env python3
"""tg.py - Turing state-machine text generator, elected by a combinatoric mechanism.
Every token is voted by subsets of 15 atoms. Stages per step: I identity -> II correspondence
-> III verification (continuity) -> O recycling; --pipeline reverse runs O -> III -> II -> I.
  python tg.py generate --prompt "A process" | dataset | train      (needs numpy)"""
from __future__ import annotations
import argparse, builtins, csv, gzip, json, math, os, pickle, random, re
from collections import Counter, defaultdict
from pathlib import Path
from types import SimpleNamespace as NS
import numpy as np

TOKEN_RE = re.compile(r"[A-Za-z]+(?:['’][A-Za-z]+)*|\d+(?:\.\d+)?|[^\w\s]")
PUNCT, END, SPECIAL = set(".,!?;:"), {".", "!", "?"}, {""}
CORPUS = ("The process begins with a simple observation of local flows. As patterns emerge, structural "
 "constraints shape the boundary conditions. Non-isomorphic transformations map states across mismatched "
 "dimensions. Causal ascent drives the system toward higher informational complexity. Through adiabatic "
 "continuation, the generator balances exploration and selective focus. A state machine reads a symbol, "
 "writes a symbol, moves its head, and changes state. The tape preserves the history of every emitted "
 "token. Transitions are explicit, inspectable, and reproducible. Observation becomes description, "
 "description becomes relation, and relation becomes abstraction. Synthesis gathers prior evidence, while "
 "reflection consolidates the generated sequence.")
D = dict(order=5, alpha=.25, warm=20000, tokens=200, seed=7, masks=512, beam=12, tau=.95, eps=.6, temp=.85,
         levels=15, ledger_w=.9, keep_learning=True, state="OBSERVE", assoc=14, pipeline="reverse", atoms=None)
OPT = dict(rows=8, cols=8, thr=127., conf=25., hf_max=2000, hf_stream=True)
ALIAS = dict(masks="--n-masks", eps="--epsilon", temp="--temperature", ledger_w="--ledger-weight",
             state="--initial-state", assoc="--template-associates", warm="--warm-limit")
CYCLE = {"OBSERVE": ("DESCRIBE", 3, 20), "DESCRIBE": ("RELATE", 14, 120), "RELATE": ("ABSTRACT", 5, 22),
         "ABSTRACT": ("SYNTHESIZE", 4, 24), "SYNTHESIZE": ("REFLECT", 6, 24), "REFLECT": ("HALT", 5, 24)}
SYNW = dict(OBSERVE=1.2, DESCRIBE=11.25, RELATE=1.25, ABSTRACT=1.3)
W = 18                                                  # memory width

# ---- text + numeric helpers --------------------------------------------------------------------
tok = TOKEN_RE.findall
def detok(ts):
    out = ""
    for t in ts:
        out = t if not out else out + (t if t in set(".,!?;:%)]}»”’") or out[-1] in "([{«“‘" else " " + t)
    return out
content = lambda t: len(t) > 3 and t not in PUNCT
def softmax(v, T):
    a = np.asarray(v, float) / max(1e-6, T); e = np.exp(np.clip(a - a.max(), -60, 60)); return e / e.sum()
def ramp(i, n): u = min(1., max(0., i / max(1, n - 1))); return 3 * u * u - 2 * u ** 3
def hfeat(t, w):                                        # deterministic token -> vector
    b = t.lower().encode("utf-8", "ignore"); v = np.zeros(w)
    if not b: return v
    for i, x in enumerate(b): v[i % w] += ((x % 31) - 15) / 15; v[(i * 3 + 1) % w] += ((x % 17) - 8) / 8
    v /= len(b); v[0] += min(len(b), 20) / 20; v[1] += sum(chr(x).isalpha() for x in b) / len(b)
    return np.tanh(v)
_phi = {}
def phi(t):
    if t not in _phi: _phi[t] = hfeat(t, W)
    return _phi[t]
def fold(r, t): return .7 * r + phi(t)                  # recycle token into memory
def unit(r): n = np.linalg.norm(r); return r / n if n > 1e-12 else r
def delta(a, b): return float(np.clip(.5 * np.linalg.norm(a - b), 0, 1))   # continuity Delta
def fold_all(ts):
    r = np.zeros(W)
    for t in ts: r = fold(r, t)
    return r

# ---- language model ----------------------------------------------------------------------------
class NGram:
    def __init__(s, order, alpha):
        s.order, s.alpha = max(1, order), alpha
        s.counts, s.vocab = [defaultdict(Counter) for _ in range(s.order)], Counter()
    def train(s, text):
        t = [""] * (s.order - 1) + tok(text) + [""]
        for i in range(s.order - 1, len(t)):
            s.vocab[t[i]] += 1
            for n in range(s.order): s.counts[n][tuple(t[i - n:i])][t[i]] += 1
    def cand(s, ctx, limit):
        c = Counter()
        for n in range(min(s.order - 1, len(ctx)), -1, -1):
            f = s.counts[n].get(tuple(ctx[len(ctx) - n:]))
            if f:
                for t, k in f.items(): c[t] += (1 + 1.7 * n) * k
                if n >= 1: break
        if not c: c.update(s.vocab)
        tot, V = sum(c.values()), max(1, len(s.vocab))
        r = [(t, math.log(max((k + s.alpha) / (tot + s.alpha * V), 1e-12))) for t, k in c.items()]
        return sorted(r, key=lambda x: -x[1])[:max(1, limit)]
def associations(m):
    a, bad = defaultdict(Counter), SPECIAL | PUNCT
    for c, ts in (m.counts[1].items() if m.order > 1 else ()):
        for t, k in ts.items():
            if c and c[0] not in bad and t not in bad: a[c[0]][t] += k; a[t][c[0]] += k
    return a
def natural_rate(m, ts):
    p = list(zip(ts, ts[1:]))
    return sum(1 for a, b in p if m.counts[1].get((a,), {}).get(b)) / len(p) if p and m.order > 1 else 1.
def novelty(g4, ts):
    if len(ts) < 4 or not g4: return 1.
    cov = set()
    for i in range(len(ts) - 3):
        if tuple(ts[i:i + 4]) in g4: cov.update(range(i, i + 4))
    return 1 - len(cov) / len(ts)

# ---- Turing control + fragment projection ------------------------------------------------------
class Machine:
    def __init__(s, state="OBSERVE"): s.reset(state)
    def reset(s, state="OBSERVE"):
        if state not in CYCLE: raise ValueError(f"Unknown initial state: {state}")
        s.state, s.n, s.steps = state, 0, 0
    def step(s, t):                                     # END after `lo` steps advances; > hi steps halts
        nxt, lo, hi = CYCLE[s.state]; was = s.n; s.steps += 1; s.n += 1
        if was > hi: s.state = "HALT"
        elif t in END and was >= lo: s.state, s.n = nxt, 0
        return s.state

class Frag:
    """Quantised fragment states, a transition ledger, and the fragment score."""
    def __init__(s, seed, levels, lw):
        r = np.random.default_rng(seed); s.L, s.lw = max(2, levels), lw
        s.wc, s.ww, s.wt = r.normal(0, 1.7, (5, 3)), r.normal(0, .7, (5, 4)), r.normal(0, .7, (5, 2))
        s.led, s.locked, s.prev, s.cache = defaultdict(Counter), False, None, {}
    def feats(s, ctx, t, lp, rk):
        rc = ctx[-4:]; cv = np.zeros(5)
        for i, w in enumerate(rc): cv += hfeat(w, 5) * .65 ** (len(rc) - i - 1)
        if rc: cv /= len(rc)
        tv = np.array([np.tanh(lp), 1 / (1 + rk), float(t[:1].isupper()), float(t in ".,!?;:"), min(len(t), 24) / 24])
        return np.tanh(cv @ s.wc), np.tanh(hfeat(t, 5) @ s.ww), np.tanh(tv @ s.wt)
    def state(s, ctx, t, lp, rk):
        v = (np.concatenate(s.feats(ctx, t, lp, rk)) + 1) / 2 * s.L
        s.cache[t] = tuple(int(i) for i in np.clip(np.floor(v), 0, s.L - 1)); return s.cache[t]
    def bonus(s, t):
        st = s.cache.get(t)
        return math.log1p(s.led.get(s.prev, {}).get(st, 0)) if st is not None and s.prev is not None else 0.
    def score(s, ctx, t, lp, rk, lam):
        g1, g2, g3 = s.feats(ctx, t, lp, rk); n = np.array([np.linalg.norm(g) for g in (g1, g2, g3)]); m = n.mean()
        cons = float(np.clip(.55 * n.std() / (m + 1e-9) + .45 * (1 - m), 0, 1))
        ref = np.array([g1.mean(), g2.mean(), g3.mean(), np.tanh(lp)]); ref /= max(np.linalg.norm(ref), 1e-12)
        c = np.array([g1[0], g2[0], g3[0], np.tanh(lp + .1 * rk)]); c /= max(np.linalg.norm(c), 1e-12)
        fs = 1.6 * (float(ref @ c) + 1) / 2 - 1.15 * cons
        return (1 - lam) * (1.75 * lp + 1.25 * fs) + lam * (1.25 * lp + .85 * fs) + s.lw * s.bonus(t), cons
    def commit(s, t):
        st = s.cache[t]
        if not s.locked and s.prev is not None: s.led[s.prev][st] += 1
        s.prev = st; s.cache.clear()
    def stats(s): return dict(states=len(s.led), transitions=sum(len(v) for v in s.led.values()), locked=s.locked)

def warm(m, fr, toks):                                  # pre-fill the ledger from the corpus
    prev, ctx = None, [""] * (m.order - 1)
    for t in toks:
        rk, lp = next(((i, v) for i, (c, v) in enumerate(m.cand(ctx, 40)) if c == t), (40, -8.))
        st = fr.state(ctx, t, lp, rk)
        if prev is not None: fr.led[prev][st] += 1
        prev = st; ctx.append(t)
    fr.cache.clear()

# ---- state rules, heuristics, atoms ------------------------------------------------------------
def state_bonus(st, t):
    return 1. if st == "ABSTRACT" and len(t) >= 7 and t not in PUNCT else .8 if st == "DESCRIBE" and content(t) \
        else .4 if st == "RELATE" and content(t) else .2 if st == "REFLECT" else 0.
def blocker(st, tape):
    if st == "DESCRIBE": r = {t for t in tape[-12:] if content(t)}; return lambda t: t in r
    if st == "RELATE": r = set(tape[-8:]); return lambda t: t in r
    if st == "ABSTRACT": return lambda t: not (t in PUNCT or len(t) <= 3 or len(t) >= 7)
    return lambda t: False
def harm(ctx, c, k=.75):                                # in equation context prefer "1" over "i"
    r = ctx[-16:]
    if not r or {"II", "III"} & set(r) or not set("=+-*/^()") & set(r): return 0.
    if not any(t.lower() == "i" for t in r) or "1" in r: return 0.
    return k if c == "1" else -k if c.lower() == "i" else 0.
ATOMS = {  # order = mask bit order; each atom scores one candidate record c
    "ngram": lambda c: c.lp, "ramp": lambda c: c.lam * c.lp, "alignment": lambda c: c.al,
    "consistency": lambda c: -c.cons, "ledger": lambda c: c.led, "turing_state": lambda c: c.sb,
    "harmonization": lambda c: c.harm, "association": lambda c: c.assoc, "continuity": lambda c: -c.delta,
    "corpus_4gram": lambda c: c.g4, "state_filter": lambda c: -1. if c.blocked else 0.,
    "tau_gate": lambda c: -1. if c.cons > c.tau else 0., "epsilon_gate": lambda c: -1. if c.delta > c.eps else 0.,
    "rank_prior": lambda c: 1 / (1 + c.rk), "repetition": lambda c: -1. if c.rep else 0.}
class Masks:
    """Up to `n` of the 2^k-1 non-empty atom subsets; each votes for one token per step."""
    def __init__(s, n, seed, names=None):
        names = list(names or ATOMS); s.fns = [ATOMS[k] for k in names]; k = len(names); sp = 2 ** k - 1; n = max(1, min(int(n), sp))
        codes = list(range(1, sp + 1)) if n == sp else random.Random(seed).sample(range(1, sp + 1), n)
        s.M, s.n = np.array([[(c >> b) & 1 for b in range(k)] for c in codes], float), len(codes)
def gate(ds, eps):                                      # stage III: Delta <= eps, relax x1.5 if empty
    e, r = max(1e-6, eps), 0
    while e < 1 and not any(d <= e for d in ds): e, r = min(1., e * 1.5), r + 1
    return [i for i, d in enumerate(ds) if d <= e], r

# ---- generation --------------------------------------------------------------------------------
class Gen:
    def __init__(s, e, prompt, o, trace=False):
        s.e, s.o, s.trace, s.rng = e, o, trace, random.Random(o["seed"]); s.fr = Frag(o["seed"], o["levels"], o["ledger_w"])
        pt = tok(prompt) or ["The"]; s.anch = [t for t in pt if content(t)]; s.tape = list(pt); slots = []
        for w in s.anch[:2]:                            # template:  <prompt> is <ASSOC> and <ASSOC>
            ch = next(([t for t, _ in e.assoc[v].most_common(max(1, o["assoc"])) if t not in SPECIAL]
                       for v in (w, w.lower(), w.capitalize()) if e.assoc.get(v)), [])
            if ch: slots.append(s.rng.choice(ch))
        if slots: s.tape += ["is"] + [x for i, t in enumerate(slots) for x in (["and"] if i else []) + [t]]
        s.tpl = detok(s.tape)
        if trace: print(f"[template] {s.tpl}  ({len(slots)} slot(s) filled)")
        if e.warm: warm(e.m, s.fr, e.warm); s.fr.locked = not o["keep_learning"]
        s.mc, s.sm, s.syn = Masks(o["masks"], o["seed"], o["atoms"]), {k: np.zeros(W) for k in CYCLE}, np.zeros(W)
        s.mach = Machine(o["state"]); s.prevst, s.raw = s.mach.state, fold_all(s.tape)

    def assoc_score(s, t):
        tot = 0
        for a in s.anch:
            for v in (a, a.lower(), a.capitalize()):
                c = s.e.assoc.get(v)
                if c: tot += c.get(t, 0) or c.get(t.lower(), 0); break
        return math.log1p(tot)
    def ident(s, xs, st, key):                          # stage I: Turing-state constraints
        if s.mach.n < 3: xs = [x for x in xs if key(x) not in END] or xs
        b = blocker(st, s.tape); return [x for x in xs if not b(key(x))] or xs
    def correspond(s, pool, st, lam, mt):               # stage II: score against context + memory
        tape, fr, out = s.tape, s.fr, []
        if st == "REFLECT":
            ps = unit(s.sm["SYNTHESIZE"]); gap = delta(ps, unit(s.raw))
        for rk, (t, lp) in enumerate(pool):
            fr.state(tape, t, lp, rk); sc, cons = fr.score(tape, t, lp, rk, lam)
            sc += harm(tape, t) + state_bonus(st, t)
            if st == "SYNTHESIZE" and np.linalg.norm(s.syn) >= 1e-9: sc += .8 * float(phi(t) @ s.syn)
            elif st == "REFLECT": sc += gap - delta(ps, unit(fold(s.raw, t)))
            if cons <= s.o["tau"]:
                out.append(NS(t=t, lp=lp, sc=sc, cons=cons, delta=delta(mt, unit(fold(s.raw, t)))))
        if not out:
            t, lp = pool[0]; fr.state(tape, t, lp, 0); sc, cons = fr.score(tape, t, lp, 0, lam)
            out = [NS(t=t, lp=lp, sc=sc, cons=cons, delta=delta(mt, unit(fold(s.raw, t))))]
        return out
    def vote(s, pool, st, lam, mt):                     # combinatoric election over atom subsets
        tape, fr, o, seen = s.tape, s.fr, s.o, {}
        for rk, (t, lp) in enumerate(pool): seen.setdefault(t, (rk, lp))
        tail, r6, bl, rows = tuple(tape[-3:]), set(tape[-6:]), blocker(st, tape), []
        for t, (rk, lp) in seen.items():
            tot, cons = fr.score(tape, t, lp, rk, lam)
            c = NS(lp=lp, lam=lam, al=float(np.clip((tot - lp) / 2.5 + .5, 0, 1)), cons=cons, led=fr.bonus(t),
                   sb=state_bonus(st, t), harm=harm(tape, t), assoc=s.assoc_score(t), rk=rk, tau=o["tau"], eps=o["eps"],
                   delta=delta(mt, unit(fold(s.raw, t))), g4=float(len(tail) == 3 and tail + (t,) in s.e.g4),
                   blocked=bl(t), rep=content(t) and t in r6)
            rows.append([f(c) for f in s.mc.fns])
        A = np.array(rows); sd = A.std(0); z = np.where(sd > 1e-9, (A - A.mean(0)) / np.where(sd > 1e-9, sd, 1), 0)
        toks = list(seen); return Counter(toks[i] for i in (z @ s.mc.M.T).argmax(0))
    def choose(s, cs, votes):                           # the vote is the distribution; score breaks ties
        cs = [c for c in cs if votes.get(c.t, 0) > 0] or cs
        for c in cs: c.sc = math.log1p(votes.get(c.t, 0)) + .01 * c.sc
        cs = sorted(cs, key=lambda c: -c.sc)[:max(1, s.o["beam"])]; p = softmax([c.sc for c in cs], s.o["temp"])
        return cs[0] if s.o["temp"] <= .01 else s.rng.choices(cs, weights=p, k=1)[0]
    def step(s, st, lam):
        mt, o = unit(s.raw), s.o
        pool = [(t, lp) for t, lp in s.e.m.cand(s.tape, max(40, o["beam"] * 8)) if t not in SPECIAL]
        fb = 0 if pool else 1; pool = pool or [(".", -8.)]
        if o["pipeline"] == "reverse":                  # O -> III -> II -> I
            keep, rx = gate([delta(mt, unit(fold(s.raw, t))) for t, _ in pool], o["eps"]); pool = [pool[i] for i in keep]
            cs = s.correspond(pool, st, lam, mt); votes = s.vote(pool, st, lam, mt); cs = s.ident(cs, st, lambda c: c.t)
        else:                                           # I -> II -> III -> O
            pool = s.ident(pool, st, lambda x: x[0]); cs = s.correspond(pool, st, lam, mt); votes = s.vote(pool, st, lam, mt)
            keep, rx = gate([c.delta for c in cs], o["eps"]); cs = [cs[i] for i in keep]
        return s.choose(cs, votes), votes, rx, fb
    def segment(s):
        em, fb, rx, ag, start, st0, n = [], 0, 0, [], len(s.tape), s.mach.state, s.o["tokens"]
        for i in range(max(1, n - start)):
            st = s.mach.state; c, votes, r, f = s.step(st, ramp(start + i, max(1, n))); fb += f; rx += r
            ag.append(max(votes.values()) / s.mc.n)
            s.fr.commit(c.t); s.tape.append(c.t); s.raw = fold(s.raw, c.t); em.append(c.t)   # stage O
            if s.trace:
                print(f"[{start + i:03d}] {st:<10} {c.t!r:<16} p={math.exp(c.lp):.2f} score={c.sc:+.3f} D={c.cons:.3f} "
                      f"delta={c.delta:.3f} votes={votes.get(c.t, 0)}/{s.mc.n}")
            nxt = s.mach.step(c.t); s.sm[st] = .7 * s.sm[st] + phi(c.t)
            if nxt == "SYNTHESIZE" and s.prevst != "SYNTHESIZE":     # compose earlier stages into a synthesis state
                s.syn = unit(sum(w * unit(s.sm[k]) for k, w in SYNW.items())); s.sm["SYNTHESIZE"] = s.syn
            s.prevst = nxt
            if nxt == "HALT": closed = c.t in END; break
        else: closed = False
        if em and em[-1] not in END:                    # close an unfinished segment
            if em[-1] in PUNCT: em[-1] = s.tape[-1] = "."
            else: em.append("."); s.tape.append(".")
            closed = True; s.raw = fold_all(s.tape)
        return dict(template=s.tpl, state=st0, end_state=s.mach.state, steps=s.mach.steps, tokens=em, text=detok(em),
                    natural_rate=natural_rate(s.e.m, em), novelty=novelty(s.e.g4, em), fallbacks=fb, relaxations=rx,
                    closed=closed, mechanism_agreement=float(np.mean(ag)))
    def run(s):
        segs = []
        while len(s.tape) < s.o["tokens"]:
            segs.append(s.segment())
            if s.mach.state == "HALT": s.mach.reset()
        return detok(s.tape), segs

# ---- corpus ingestion --------------------------------------------------------------------------
FIELDS = ("text", "content", "body", "sentence", "document")
def jtexts(o):
    if isinstance(o, str): yield o
    elif isinstance(o, dict):
        f = next((k for k in FIELDS if isinstance(o.get(k), str)), None)
        if f: yield o[f]
        else:
            for v in o.values(): yield from jtexts(v)
    elif isinstance(o, list):
        for v in o: yield from jtexts(v)
def optical(path):                                      # grayscale -> 16x16 mean pool -> BIT0/BIT1/ERASURE grid
    from PIL import Image
    R, C = max(1, int(OPT["rows"])), max(1, int(OPT["cols"])); lo, hi = OPT["thr"] - OPT["conf"], OPT["thr"] + OPT["conf"]
    with Image.open(path) as im: px = np.asarray(im.convert("L").resize((C * 16, R * 16), Image.Resampling.LANCZOS), np.float32)
    P = px.reshape(R, 16, C, 16).mean((1, 3)); sym = np.where(P >= hi, "BIT1", np.where(P <= lo, "BIT0", "ERASURE"))
    return " ".join([f"OPTICAL_IMAGE ROWS {R} COLS {C}"] + [f"ROW{i} " + " ".join(r) for i, r in enumerate(sym)])
def hf_rows(spec):                                      # hf:<name>[:<config>[:<split>[:<field>]]]
    from datasets import DatasetDict, load_dataset, load_from_disk
    name, cfg, split, field = ([x.strip() for x in spec[3:].split(":")] + [""] * 4)[:4]
    if not name: raise ValueError("Empty Hugging Face dataset name (use hf:<name>).")
    if Path(name).exists():
        ds = load_from_disk(name)
        if isinstance(ds, DatasetDict): ds = ds[split or "train"] if (split or "train") in ds else next(iter(ds.values()))
    else: ds = load_dataset(name, cfg or None, split=split or "train", streaming=bool(OPT["hf_stream"]))
    out, col = [], field or None
    for r in ds:
        col = col or next((k for k in FIELDS if isinstance(r.get(k), (str, list))), None) or next((k for k, v in r.items() if isinstance(v, str)), None)
        if col is None or col not in r: raise ValueError(f"No usable text column in {name}; columns: {list(r)}")
        v = r[col]; v = " ".join(x for x in v if isinstance(x, str)) if isinstance(v, list) else v
        if isinstance(v, str) and v.strip(): out.append(v.strip())
        if len(out) >= OPT["hf_max"]: break
    if not out: raise ValueError(f"No text rows read from {name!r}.")
    return out
def read_one(f):
    x = f.suffix.lower()
    if x in {".png", ".jpg", ".jpeg", ".bmp", ".tif", ".tiff", ".webp"}: return [optical(f)]
    if x == ".jsonl": return [t for l in f.read_text("utf-8-sig").splitlines() if l.strip() for t in jtexts(json.loads(l))]
    if x == ".json": return list(jtexts(json.loads(f.read_text("utf-8-sig"))))
    if x == ".csv":
        with f.open(newline="", encoding="utf-8-sig") as h: rows = list(csv.reader(h))
        hd = [c.strip().lower() for c in rows[0]] if rows else []; col = next((hd.index(k) for k in FIELDS if k in hd), None)
        return [r[col or 0] for r in (rows[1:] if col is not None else rows) if r and len(r) > (col or 0)]
    return [f.read_text("utf-8-sig")]
def load_corpus(srcs=None):
    if not srcs: return CORPUS, ["<builtin>"]
    texts, used = [], []
    for src in srcs:
        if str(src).startswith("hf:"): texts += hf_rows(str(src)); used.append(str(src)); continue
        p = Path(src); ext = {".txt", ".md", ".text", ".rst", ".json", ".jsonl", ".csv", ".png", ".jpg", ".jpeg", ".bmp", ".tif", ".tiff", ".webp"}
        if not p.exists(): raise FileNotFoundError(f"Corpus source not found: {src}")
        for f in sorted(q for q in p.rglob("*") if q.suffix.lower() in ext) if p.is_dir() else [p]:
            ch = [t.strip() for t in read_one(f) if t and t.strip()]
            if ch: texts += ch; used.append(str(f))
    if not texts: raise ValueError("No usable text found in the corpus sources.")
    return "\n\n".join(texts), used

# ---- engine, persistence, dataset --------------------------------------------------------------
class Safe(pickle.Unpickler):                           # data-only unpickling
    def find_class(s, mod, name):
        if mod == "builtins" and name in {"set", "frozenset"}: return getattr(builtins, name)
        raise pickle.UnpicklingError(f"Blocked unsafe object in model file: {mod}.{name}")
class Engine:
    def __init__(s, text=None, sources=None, order=5, alpha=.25, warm=20000):
        s.text, s.sources, s.warm_n = CORPUS if text is None else text, sources or ["<text>"], int(warm)
        s.m = NGram(order, alpha)
        if not tok(s.text): raise ValueError("Corpus contains no recognizable tokens.")
        s.m.train(s.text); s.derive()
    def derive(s):
        s.toks, s.assoc = tok(s.text), associations(s.m); s.warm = s.toks[:max(0, s.warm_n)] or None
        s.sents = [tok(x) for x in re.split(r"(?<=[.!?])\s+", s.text.strip()) if x.strip()]
        s.g4 = {tuple(t[i:i + 4]) for t in s.sents for i in range(len(t) - 3)}
    def save(s, path):
        p = Path(path); p = p if p.suffix else p.with_suffix(".tengine"); p.parent.mkdir(parents=True, exist_ok=True)
        st = dict(format="turing-text-engine", version=1, order=s.m.order, alpha=s.m.alpha, total_tokens=sum(s.m.vocab.values()),
                  vocab=dict(s.m.vocab), counts=[{c: dict(t) for c, t in lv.items()} for lv in s.m.counts],
                  corpus_text=s.text, sources=s.sources, warm_limit=s.warm_n)
        with gzip.open(str(p) + ".tmp", "wb") as h: pickle.dump(st, h, protocol=4)
        os.replace(str(p) + ".tmp", p); return p
    @staticmethod
    def load(path):
        try:
            with gzip.open(path, "rb") as h: st = Safe(h).load()
        except (OSError, EOFError, pickle.UnpicklingError) as ex: raise ValueError(f"Could not read model file: {ex}")
        if not isinstance(st, dict) or st.get("format") != "turing-text-engine" or st.get("version") != 1:
            raise ValueError("Not a Turing text-engine model file (version 1).")
        e = Engine.__new__(Engine); e.text, e.sources, e.warm_n = st["corpus_text"], list(st["sources"]), int(st["warm_limit"])
        e.m = NGram(st["order"], st["alpha"]); e.m.counts = [defaultdict(Counter, {tuple(c): Counter(t) for c, t in lv.items()}) for lv in st["counts"]]
        e.m.vocab = Counter(st["vocab"]); e.derive(); return e
    def generate(s, prompt="A process", trace=False, **kw):
        o = {**D, **{k: v for k, v in kw.items() if v is not None or k == "atoms"}}
        o.update(tokens=max(1, o["tokens"]), tau=float(np.clip(o["tau"], 0, 1)), eps=float(np.clip(o["eps"], 0, 1)), temp=max(0., o["temp"]))
        g = Gen(s, prompt, o, trace); text, segs = g.run(); ag = [x["mechanism_agreement"] for x in segs]
        return dict(prompt=prompt, seed=o["seed"], text=text, segments=segs, n_tokens=len(tok(text)), n_segments=len(segs),
                    mean_natural_rate=float(np.mean([x["natural_rate"] for x in segs])), mean_novelty=float(np.mean([x["novelty"] for x in segs])),
                    mean_agreement=float(np.mean(ag)) if ag else None, relaxations=sum(x["relaxations"] for x in segs),
                    fallbacks=sum(x["fallbacks"] for x in segs), ledger=g.fr.stats())
    def auto_prompts(s, n, seed=7, k=3):
        rng, pool, out = random.Random(seed), [t for t in s.sents if any(content(w) for w in t)], []
        rng.shuffle(pool)
        for t in pool:
            p = " ".join([w for w in t if w not in PUNCT][:rng.randint(1, k)])
            if p and p not in out: out.append(p)
            if len(out) >= n: break
        return out or ["A process"]
def build_dataset(e, prompts, seeds=(7,), out=None, segments=True, **kw):
    rows = []
    for p in prompts:
        for sd in seeds:
            r = {"id": len(rows), **e.generate(p, seed=sd, **kw)}; r.pop("ledger"); rows.append(r)
            if not segments: r.pop("segments")
            print(f"[dataset] {len(rows)}/{len(prompts) * len(seeds)} prompt={p!r} seed={sd}")
    if out:
        o = Path(out); o.parent.mkdir(parents=True, exist_ok=True)
        cols = "id prompt seed text n_tokens n_segments mean_natural_rate mean_novelty mean_agreement relaxations fallbacks".split()
        with o.open("w", newline="" if o.suffix == ".csv" else None, encoding="utf-8") as h:
            if o.suffix.lower() == ".csv": w = csv.DictWriter(h, cols, extrasaction="ignore"); w.writeheader(); w.writerows(rows)
            else: h.writelines(json.dumps(r, ensure_ascii=False) + "\n" for r in rows)
    return rows

# ---- CLI ---------------------------------------------------------------------------------------
def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0], formatter_class=argparse.ArgumentDefaultsHelpFormatter)
    sub = ap.add_subparsers(dest="cmd")
    def add(p, gen):
        p.add_argument("--corpus", nargs="+"); p.add_argument("--model-in")
        for k in ("order", "alpha", "warm"): p.add_argument(ALIAS.get(k, "--" + k), dest=k, type=type(D[k]), default=D[k])
        for k, v in OPT.items():
            if k != "hf_stream": p.add_argument("--" + k.replace("_", "-"), dest=k, type=type(v), default=v)
        p.add_argument("--no-hf-streaming", action="store_true")
        if gen:
            for k, v in D.items():
                if k in ("order", "alpha", "warm", "atoms"): continue
                f = ALIAS.get(k, "--" + k.replace("_", "-"))
                if isinstance(v, bool): p.add_argument(f, dest=k, action="store_true")
                elif k == "pipeline": p.add_argument(f, dest=k, choices=["forward", "reverse"], default=v)
                elif k == "state": p.add_argument(f, dest=k, choices=[x for x in CYCLE], default=v)
                else: p.add_argument(f, dest=k, type=type(v), default=v)
            p.add_argument("--atoms", nargs="+", choices=list(ATOMS), default=None)
    g = sub.add_parser("generate"); add(g, True)
    g.add_argument("--prompt", default="A process"); g.add_argument("--trace", action="store_true")
    g.add_argument("--model-out"); g.add_argument("--output")
    d = sub.add_parser("dataset"); add(d, True)
    d.add_argument("--prompts-file"); d.add_argument("--prompts", nargs="*"); d.add_argument("--n-prompts", type=int, default=25)
    d.add_argument("--n-seeds", type=int, default=2)
    d.add_argument("--output", default="generated_dataset.jsonl"); d.add_argument("--no-segments", action="store_true")
    t = sub.add_parser("train"); add(t, False); t.add_argument("--model-out", default="model.tengine")
    a = ap.parse_args(argv)
    if not a.cmd: ap.print_help(); return 0
    if getattr(a, "temp", 0) < 0: ap.error("--temperature must be zero or greater")
    OPT.update({k: getattr(a, k) for k in OPT if k != "hf_stream"}); OPT["hf_stream"] = not a.no_hf_streaming
    if a.model_in: e = Engine.load(a.model_in)
    else:
        text, src = load_corpus(a.corpus); e = Engine(text, src, a.order, a.alpha, a.warm)
        print("Training corpus sources:", *src, sep="\n  - ")
    print(f"Corpus tokens: {len(e.toks):,} | vocabulary: {len(e.m.vocab):,} | n-gram order: {e.m.order}")
    if a.cmd == "train": print(f"Saved model: {e.save(a.model_out)}"); return 0
    kw = {k: getattr(a, k) for k in D if k not in ("order", "alpha", "warm")}
    if a.cmd == "generate":
        r = e.generate(a.prompt, a.trace, **{**kw, "seed": a.seed}); print("\n" + r["text"] + "\n")
        print("Generation summary:"); print(json.dumps({k: v for k, v in r.items() if k not in ("text", "segments")}, indent=2))
        if a.trace:
            for i, sg in enumerate(r["segments"], 1): print(f"[{i}] {json.dumps(sg, default=str)}")
        if a.output: Path(a.output).write_text(r["text"], "utf-8")
        if a.model_out: print(f"Saved model: {e.save(a.model_out)}")
    else:
        ps = [l.strip() for l in Path(a.prompts_file).read_text("utf-8").splitlines() if l.strip()] if a.prompts_file else \
             [p.strip() for p in a.prompts or [] if p.strip()] or e.auto_prompts(max(1, a.n_prompts), a.seed)
        kw.pop("seed"); rows = build_dataset(e, ps, range(a.seed, a.seed + max(1, a.n_seeds)), a.output, not a.no_segments, **kw)
        print(f"Dataset complete: {len(rows)} rows -> {a.output}")
    return 0
if __name__ == "__main__": raise SystemExit(main())
