#!/usr/bin/env python3
"""
photon_preimage.py - preimage demo + decoder, single file.

Simulated known-solution optoelectronic circuit read through a Z-channel:
    secret bit 1 -> always observed 1
    secret bit 0 -> observed 1 with probability p (photon noise), else 0

  Level 1: a bit ever seen as 0 is certainly 0. U = bits never seen 0.
  Level 2: try 0, 1, 2, ... flips (1 -> 0) over U, checking each candidate against
           a salted SHA-256 commitment, bounded by a per-word hash budget.

NOTE: a decoder, not a solver. The simulated latch is loaded with the secret by the
simulator. Leading zeros in the target come from grinding the salt (~2^D hashes);
the photon channel does not reduce that work.
"""
import argparse
import hashlib
import itertools
import secrets
from math import comb

import numpy as np

VCC, V_BE = 5.0, 0.7
TAU = 10e3 * 15e-6           # RC = 0.15 s
CLK = 0.100                  # 10 Hz clock, one bit slot per tick
FRAME_DT = 0.00005             # 200 fps simulation


def commit(salt, v, nbits):
    return hashlib.sha256(f"{salt}:{v:0{(nbits + 3) // 4}X}".encode()).hexdigest()


def lz_bits(hexdigest):
    return 256 - int(hexdigest, 16).bit_length()


def zeros_info(h):
    hexz = len(h) - len(h.lstrip("0"))
    return f"{h}  [{lz_bits(h)} zero bits, {hexz} hex 0s]"


def grind_salt(secret, nbits, d):
    tries = 0
    while True:
        tries += 1
        salt = secrets.token_hex(8)
        t = commit(salt, secret, nbits)
        if lz_bits(t) >= d:
            return salt, t, tries


class PhotonCircuit:
    def __init__(self, secret, nbits, rng, mean_photons=40.0, thr=0.45):
        self.secret, self.nbits, self.rng = secret, nbits, rng
        self.lam, self.thr, self.hyst = mean_photons, thr, 0.03
        self.state, self.vc, self.t = False, 0.0, 0.0

    def _b_out(self, intensity):
        if self.state and intensity < self.thr - self.hyst:
            self.state = False
        elif not self.state and intensity > self.thr + self.hyst:
            self.state = True
        drive = VCC if self.state else 0.0
        self.vc += (drive - self.vc) * (1 - np.exp(-FRAME_DT / TAU))
        return self.vc > V_BE

    def word(self):
        bits, frames = 0, int(round(CLK / FRAME_DT))
        for slot in range(self.nbits):
            d = 0
            for _ in range(frames):
                self.t += FRAME_DT
                nB = self.rng.poisson(self.lam * (1 + 0.8 * np.sin(2 * np.pi * 0.4 * self.t)))
                nA = self.rng.poisson(self.lam * (1 + 0.8 * np.sin(2 * np.pi * 0.7 * self.t + 1)))
                d = bool(nA & 1) and self._b_out(nB / (2 * self.lam))
            y = (self.secret >> (self.nbits - 1 - slot)) & 1
            bits = (bits << 1) | int(bool(y) or d)
        return bits


class PhotonStatistics:
    def __init__(self, nbits):
        self.nbits, self.n = nbits, 0
        self.zeros = np.zeros(nbits, int)

    def update(self, word):
        self.n += 1
        for i in range(self.nbits):
            if not (word >> (self.nbits - 1 - i)) & 1:
                self.zeros[i] += 1

    def noise_rate(self):
        z = self.zeros > 0
        if not z.any() or self.n == 0:
            return 0.5
        return float(np.clip(1.0 - self.zeros[z].sum() / (self.n * z.sum()), 0.01, 0.97))


def decode_v2(stats, verify, nbits, budget=5000):
    U = [i for i in range(nbits) if stats.zeros[i] == 0]
    masks = [1 << (nbits - 1 - i) for i in U]
    base, tries = sum(masks), 0
    for k in range(len(U) + 1):
        if tries + comb(len(U), k) > budget:
            break
        for flip in itertools.combinations(masks, k):
            cand = base
            for m in flip:
                cand ^= m
            tries += 1
            if verify(cand):
                return cand, len(U), tries
    return None, len(U), tries


def cmd_preimage_photon(a):
    n = max(4, a.bits - a.bits % 4)
    w = (n + 3) // 4
    rng = np.random.default_rng(a.seed)
    secret = int(rng.integers(0, 1 << n)) if n < 63 else secrets.randbits(n)

    if a.zeros:
        salt, target, g = grind_salt(secret, n, a.zeros)
        print(f"ground salt in {g:,} hashes (expected ~{2 ** a.zeros:,})")
    else:
        salt = secrets.token_hex(8)
        target = commit(salt, secret, n)
    print(f"salt   = {salt}\ntarget = {zeros_info(target)}\n")

    log = []

    def verify(c):
        h = commit(salt, c, n)
        log.append((c, h))
        return h == target

    circ, stats = PhotonCircuit(secret, n, rng), PhotonStatistics(n)
    found = None
    for word in range(1, a.max_words + 1):
        stats.update(circ.word())
        before = len(log)
        cand, nU, _ = decode_v2(stats, verify, n, a.budget)
        print(f"word {word:3d}: |U|={nU:3d} (bits never seen 0)  "
              f"hashes this word={len(log) - before:6d}  p~{stats.noise_rate():.2f}")
        if cand is not None:
            found = cand
            break

    k = a.show
    print(f"\n{len(log):,} hashes computed in total. First {k}:")
    for c, h in log[:k]:
        print(f"  {c:0{w}X}  {zeros_info(h)}")
    print(f"Last {k}:")
    for c, h in log[-k:]:
        print(f"  {c:0{w}X}  {zeros_info(h)}{'  <== PREIMAGE' if h == target else ''}")

    if found is None:
        print("\nno preimage found (raise --budget or --max-words)")
        return
    print(f"\ncorrect: {found == secret}")
    print(f"blind brute force would need ~{2.0 ** (n - 1):.2e} hashes on average; "
          f"the channel needed {len(log):,}")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--bits", type=int, default=64)
    ap.add_argument("--seed", type=int, default=1)
    ap.add_argument("--show", type=int, default=10)
    ap.add_argument("--budget", type=int, default=500)
    ap.add_argument("--max-words", type=int, default=20)
    ap.add_argument("--zeros", type=int, default=32)
    a = ap.parse_args()
    cmd_preimage_photon(a)


if __name__ == "__main__":
    main()
