#!/usr/bin/env python3
"""
bitcoin_stratum_proxy.py - RP-GHOST Predictive Optoelectronic Proxy & Share Transcoder for Bitcoin SHA-256 (BzMiner / ASIC / CPU).
Handles local Bitcoin Stratum V1 handshake emulation, extraNonce injection, webcam entropy & Poisson viewport
optoelectronic transaction encoding, and share transcoding before relaying upstream to the Bitcoin pool.
"""

import argparse
import hashlib
import json
import math
import os
import socket
import struct
import threading
import time

import numpy as np

try:
    import cv2
    HAS_OPENCV = True
except ImportError:
    HAS_OPENCV = False

LAMBDA_BASE = 10000.0
SIGMA_C = 0.005
N_SLOTS = 40
WEBCAM_INDEX = int(os.environ.get("WEBCAM_INDEX", "0"))

CHUNK_BYTES = 3
LARGE_DECODE_WINDOWS = 4000
LARGE_DECODE_RETRIES = 8

def compute_crc8(data_bytes):
    crc = 0x00
    for byte in data_bytes:
        crc ^= byte
        for _ in range(8):
            crc = ((crc << 1) ^ 0x07) & 0xFF if crc & 0x80 else (crc << 1) & 0xFF
    return crc

def bits_to_code(bits):
    code = 0
    for bit in bits:
        code = (code << 1) | (int(bit) & 1)
    return code

def int_to_bits(value, width):
    return [(value >> (width - 1 - k)) & 1 for k in range(width)]

def make_payload_tilt(bits, eps_abs):
    bits = np.asarray(bits, dtype=float)
    strength = max(float(eps_abs), 0.25)
    return 2.0 * strength * (bits - 0.5)

def encode_text_frame(index, chunk):
    chunk = bytes(chunk).ljust(CHUNK_BYTES, b"\x00")[:CHUNK_BYTES]
    body = bytes([index & 0xFF]) + chunk
    crc = compute_crc8(body)
    return np.array(int_to_bits(body[0], 8)
                    + [b for byte in chunk for b in int_to_bits(byte, 8)]
                    + int_to_bits(crc, 8), dtype=int)

def decode_text_frame(bits):
    bits = np.asarray(bits, dtype=int).flatten()
    index = bits_to_code(bits[:8])
    chunk = bytes(bits_to_code(bits[8 + 8 * i: 16 + 8 * i]) for i in range(CHUNK_BYTES))
    received_crc = bits_to_code(bits[32:40])
    ok = received_crc == compute_crc8(bytes([index]) + chunk)
    return index, chunk, ok

class WebcamEntropySource(threading.Thread):
    def __init__(self, camera_index=WEBCAM_INDEX):
        super().__init__(daemon=True)
        self.camera_index = camera_index
        self.running = True
        self.latest_hash = 0

    def run(self):
        if not HAS_OPENCV:
            while self.running:
                time.sleep(1.0 / 30.0)
                dummy = np.random.randint(0, 255, (480, 640, 3), dtype=np.uint8)
                self.latest_hash = int(hashlib.sha256(dummy.tobytes()).hexdigest()[:4], 16)
            return
        cap = cv2.VideoCapture(self.camera_index)
        while self.running:
            ret, frame = cap.read()
            if not ret:
                time.sleep(0.01)
                continue
            gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
            self.latest_hash = int.from_bytes(hashlib.sha256(gray.tobytes()).digest()[:2], "big")
        cap.release()

    def stop(self):
        self.running = False

class OptoelectronicViewport:
    def __init__(self, lambd=LAMBDA_BASE, sigma_c=SIGMA_C):
        self.lambd = lambd
        self.sigma_c = sigma_c

    def generate_window_block(self, n_windows, n_slots, tilt=None, webcam_hash=0):
        noise_seed = (int(time.time() * 1000) ^ webcam_hash) & 0xFFFFFFFF
        np.random.seed(noise_seed % (2**32))
        shared_noise = np.random.normal(0.0, self.sigma_c, size=(n_windows, 1))
        lam = self.lambd * (1.0 + shared_noise)
        counts = np.random.poisson(np.clip(lam, 1.0, None), size=(n_windows, n_slots))
        Z = (counts - self.lambd) / np.sqrt(self.lambd)
        if tilt is not None:
            Z += tilt
        return Z

def transmit_bytes_hex(viewport, hex_str, webcam_hash=0, windows=LARGE_DECODE_WINDOWS, max_retries=LARGE_DECODE_RETRIES):
    raw = bytes.fromhex(hex_str)
    chunks = [raw[i:i + CHUNK_BYTES] for i in range(0, len(raw), CHUNK_BYTES)]
    received = bytearray()
    for i, chunk in enumerate(chunks):
        bits = encode_text_frame(i, chunk)
        sigma_z = math.sqrt(1.0 + SIGMA_C ** 2 * LAMBDA_BASE)
        tilt = make_payload_tilt(bits, 0.02 * sigma_z)
        good = None
        for _ in range(max_retries):
            Z = viewport.generate_window_block(windows, N_SLOTS, tilt=tilt, webcam_hash=webcam_hash)
            m = Z.mean(axis=0)
            idx, data, ok = decode_text_frame((m > 0).astype(int))
            if ok and idx == (i & 0xFF):
                good = data
                break
        if good is None:
            good = chunk
        received += good
    dec_hex = bytes(received)[:len(raw)].hex()
    print(f"[OPTO-HASH (BTC)] Input Hex: {hex_str} | Webcam Hash: {hex(webcam_hash)} | Transcoded Opto-Hash: {dec_hex}")
    return dec_hex

class Bitcoin_RP_GHOST_Proxy:
    def __init__(self, upstream_host, upstream_port, local_port):
        self.upstream_host = upstream_host
        self.upstream_port = upstream_port
        self.local_port = local_port
        
        self.upstream_sock = None
        self.miner_sock = None
        self.running = True
        self.lock = threading.Lock()

        self.latest_job_notify = None
        self.webcam = WebcamEntropySource()
        self.webcam.start()
        self.viewport = OptoelectronicViewport()

    def connect_upstream(self):
        while self.running:
            try:
                print(f"[PROXY] Connecting to upstream Bitcoin pool at {self.upstream_host}:{self.upstream_port}...")
                sock = socket.create_connection((self.upstream_host, self.upstream_port), timeout=20)
                sock.settimeout(None)
                sock.setsockopt(socket.SOL_SOCKET, socket.SO_KEEPALIVE, 1)
                with self.lock:
                    self.upstream_sock = sock
                print("[PROXY] Connected upstream successfully.")
                return
            except Exception as e:
                print(f"[PROXY] Upstream connection failed: {e}. Retrying in 5 seconds...")
                time.sleep(5)

    def start_local_listener(self):
        server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        server.bind(("0.0.0.0", self.local_port))
        server.listen(1)
        print(f"[PROXY] Local Bitcoin Stratum server listening on port {self.local_port} for BzMiner / ASIC...")
        
        self.miner_sock, addr = server.accept()
        print(f"[PROXY] Miner connected from {addr}")

    def run_bridge(self):
        threading.Thread(target=self._upstream_to_proxy_loop, daemon=True).start()
        threading.Thread(target=self._miner_handler_loop, daemon=True).start()

    def _upstream_to_proxy_loop(self):
        while self.running:
            if not self.upstream_sock:
                time.sleep(1.0)
                continue
            buffer = ""
            try:
                while self.running:
                    chunk = self.upstream_sock.recv(4096).decode("utf-8", errors="ignore")
                    if not chunk:
                        raise ConnectionError("Upstream connection closed by pool.")
                    buffer += chunk
                    while "\n" in buffer:
                        line, buffer = buffer.split("\n", 1)
                        line = line.strip()
                        if not line:
                            continue
                        try:
                            msg = json.loads(line)
                            if msg.get("method") == "mining.notify":
                                self.latest_job_notify = line
                                print(f"[UPSTREAM] Received Bitcoin SHA-256 job from pool. Forwarding...")
                                if self.miner_sock:
                                    with self.lock:
                                        self.miner_sock.sendall((line + "\n").encode("utf-8"))
                                continue
                        except json.JSONDecodeError:
                            pass
                        
                        if self.miner_sock:
                            with self.lock:
                                self.miner_sock.sendall((line + "\n").encode("utf-8"))
            except Exception as e:
                print(f"[PROXY] Upstream read error: {e}. Reconnecting...")
                with self.lock:
                    if self.upstream_sock:
                        try:
                            self.upstream_sock.close()
                        except:
                            pass
                        self.upstream_sock = None
                self.connect_upstream()

    def _miner_handler_loop(self):
        buffer = ""
        while self.running and self.miner_sock:
            try:
                chunk = self.miner_sock.recv(4096).decode("utf-8", errors="ignore")
                if not chunk:
                    break
                buffer += chunk
                while "\n" in buffer:
                    line, buffer = buffer.split("\n", 1)
                    line = line.strip()
                    if not line:
                        continue
                    try:
                        msg = json.loads(line)
                        method = msg.get("method")
                        msg_id = msg.get("id")

                        if method == "mining.subscribe":
                            resp = {
                                "id": msg_id,
                                "result": [
                                    [["mining.notify", "ae680123"], ["mining.set_difficulty", "b4f6"]],
                                    "00000000",
                                    4
                                ],
                                "error": None
                            }
                            self.miner_sock.sendall((json.dumps(resp) + "\n").encode("utf-8"))
                            print("[PROXY] Handled Bitcoin miner subscription.")
                            continue
                        elif method == "mining.authorize":
                            resp = {"id": msg_id, "result": True, "error": None}
                            self.miner_sock.sendall((json.dumps(resp) + "\n").encode("utf-8"))
                            print("[PROXY] Handled Bitcoin miner authorization. Sending difficulty & active job...")
                            
                            diff_msg = {"id": None, "method": "mining.set_difficulty", "params": [512]}
                            self.miner_sock.sendall((json.dumps(diff_msg) + "\n").encode("utf-8"))
                            
                            if self.latest_job_notify:
                                self.miner_sock.sendall((self.latest_job_notify + "\n").encode("utf-8"))
                            continue
                        elif method == "mining.submit":
                            params = msg.get("params")
                            print(f"[OPTO-SUBMIT (BTC)] Intercepted Bitcoin share submission: {params}")
                            if len(params) >= 5:
                                raw_nonce = str(params[4])
                                clean_nonce_hex = raw_nonce.lower().removeprefix("0x").rjust(8, "0")
                                encoded_opto_nonce = transmit_bytes_hex(self.viewport, clean_nonce_hex[:8], webcam_hash=self.webcam.latest_hash)
                                params[4] = encoded_opto_nonce
                                msg["params"] = params
                                line = json.dumps(msg)
                                print(f"[OPTO-SUBMIT (BTC)] Transcoded Bitcoin nonce via RP-GHOST channel.")
                    except json.JSONDecodeError:
                        pass

                    with self.lock:
                        if self.upstream_sock:
                            self.upstream_sock.sendall((line + "\n").encode("utf-8"))
            except Exception as e:
                print(f"[PROXY] Miner handler error: {e}")
                break

def main():
    parser = argparse.ArgumentParser(description="Bitcoin SHA-256 RP-GHOST Proxy")
    parser.add_argument("-p", "--pool", required=True, help="Upstream Bitcoin pool URL (e.g. btc.viabtc.com:3333)")
    parser.add_argument("-l", "--local-port", type=int, default=3333, help="Local proxy port (default: 3333)")
    args = parser.parse_args()

    cleaned = args.pool
    for pfx in ("stratum+tcp://", "stratum+ssl://", "tcp://"):
        if cleaned.lower().startswith(pfx):
            cleaned = cleaned[len(pfx):]
            break
    host, port = cleaned.split("/")[0].rsplit(":", 1)

    proxy = Bitcoin_RP_GHOST_Proxy(host, int(port), args.local_port)
    try:
        proxy.connect_upstream()
        proxy.start_local_listener()
        proxy.run_bridge()
        while True:
            time.sleep(1.0)
    except KeyboardInterrupt:
        proxy.running = False
        proxy.webcam.stop()
        print("\n[PROXY] Shutdown complete.")

if __name__ == "__main__":
    main()
