"""
optoelectronics_mask.py - camera version of the matched-control experiment for the
Two-Level Photonic Recognition paper (Experiment D plus the matched controls).

Idea
  The secret K is encoded PHYSICALLY: a printed strip of n cells in front of the camera
  (dark cell = 1, clear cell = 0), preceded by one clear reference cell. The decoder never
  reads K. It only sees the camera and a salted SHA-256 commitment C = H(salt || K).
    Level 1: per cell and frame, X_i = 1 if the cell is bright (>= --frac x reference cell).
             A clear cell (K_i = 0) is always bright, so it never shows a zero
             (dual convention, Remark 5.3). A dark/attenuated cell (K_i = 1) shows a zero as soon
             as one frame catches it dark. U = cells that never showed a zero.
    Level 2: start from base = 1 outside U, 0 inside U, then flip subsets of U from 0 to 1 in
             increasing size (budget --bmax hashes per stage) until the commitment matches.
  Matched control: run again with the strip removed or a different strip in view, using the same
  --secret. Same decoder, same commitment, no physical link: nothing should be recovered.

No laser, no calibration step: the reference cell tracks ambient light in every frame.

Steps
    pip install opencv-python numpy
    1. python optoelectronics_mask.py --secret 101100111010001101011010 --make-mask mask.png
       Print mask.png (or draw it) so the strip is wide and flat; leave the first cell white.
    2. python optoelectronics_mask.py --secret 101100111010001101011010 --preview
       Point the camera so the strip fills the frame width, the grid overlay lines up with the cells.
    3. Control: repeat step 2 with the strip removed (blank paper) or a different strip.
    No camera?  python optoelectronics_mask.py --camera synthetic --synthetic-mask secret|other|none
"""

import argparse
import hashlib
import itertools
import math
import random

import numpy as np

GRID_W, GRID_H = 128, 96
BAND = (29, 67)                 # rows of the frame the strip must cross
MIN_REF = 20                    # reference cell darker than this = lens covered, skip frame


def pack(bits):
    return int("".join(map(str, bits)), 2).to_bytes((len(bits) + 7) // 8, "big")


# ------------------------------------------------------------------- sources
class SyntheticMask:
    """Stand-in for a camera looking at a printed strip."""

    def __init__(self, bits, seed=None):
        self.rng = np.random.default_rng(seed)
        self.bits = bits            # None = blank paper
        self.t = 0

    def read(self):
        self.t += 1
        n = len(self.bits) if self.bits is not None else 0
        g = np.full((GRID_H, GRID_W), 200.0)
        g *= 1 + 0.1 * math.sin(self.t / 7.0)                  # ambient flicker
        if self.bits is not None:
            for i, k in enumerate(self.bits):
                if k:
                    cols = np.array_split(np.arange(GRID_W), n + 1)[i + 1]
                    g[BAND[0] - 5:BAND[1] + 5, cols[0]:cols[-1] + 1] = 40 * (1 + 0.1 * math.sin(self.t / 7.0))
        g += self.rng.normal(0, 6, g.shape)
        return np.clip(g, 0, 255).astype(np.uint8)

    def show(self, gray, bits, n):
        pass

    def close(self):
        pass


class Camera:
    def __init__(self, source, preview):
        import cv2
        self.cv2, self.preview = cv2, preview
        src = int(source) if str(source).isdigit() else source
        self.is_file = not isinstance(src, int)
        self.cap = cv2.VideoCapture(src)
        if not self.cap.isOpened():
            raise RuntimeError(f"Could not open camera/source: {source!r}")

    def read(self):
        cv2 = self.cv2
        ok, frame = self.cap.read()
        if not ok and self.is_file:
            self.cap.set(cv2.CAP_PROP_POS_FRAMES, 0)
            ok, frame = self.cap.read()
        if not ok:
            raise RuntimeError("Camera produced no frame")
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        return cv2.resize(gray, (GRID_W, GRID_H), interpolation=cv2.INTER_AREA)

    def show(self, gray, bits, n):
        if not self.preview:
            return
        cv2 = self.cv2
        big = cv2.cvtColor(cv2.resize(gray, (GRID_W * 6, GRID_H * 6), interpolation=cv2.INTER_NEAREST),
                           cv2.COLOR_GRAY2BGR)
        cols = np.array_split(np.arange(GRID_W), n + 1)
        for i, c in enumerate(cols):
            x0, x1 = int(c[0] * 6), int((c[-1] + 1) * 6)
            col = (255, 160, 0) if i == 0 else ((0, 200, 0) if bits[i - 1] else (0, 0, 220))
            cv2.rectangle(big, (x0, BAND[0] * 6), (x1, BAND[1] * 6), col, 2)
        cv2.imshow("optoelectronics_mask (blue=reference, green=bright X=1, red=dark X=0)", big)
        cv2.waitKey(1)

    def close(self):
        self.cap.release()
        if self.preview:
            self.cv2.destroyAllWindows()


# ------------------------------------------------------------------ Level 1 read
def read_cells(gray, n, frac):
    """Returns (X bits for the n cells, reference brightness)."""
    band = gray[BAND[0]:BAND[1], :].astype(float)
    means = []
    for c in np.array_split(np.arange(GRID_W), n + 1):
        trim = len(c) // 5                                    # ignore blurred cell edges
        lo, hi = c[0] + trim, c[-1] + 1 - trim
        if hi <= lo:
            lo, hi = c[0], c[-1] + 1
        means.append(band[:, lo:hi].mean())
    ref = means[0]
    return [int(m >= frac * ref) for m in means[1:]], ref


def make_mask(K, path):
    import cv2
    n, cw, h = len(K), 60, 160
    img = np.full((h, (n + 1) * cw), 255, np.uint8)           # cell 0 = white reference
    for i, k in enumerate(K):
        if k:
            img[:, (i + 1) * cw:(i + 2) * cw] = 0
    cv2.imwrite(path, img)
    print(f"wrote {path}: {n + 1} cells ({cw}px each), cell 0 white reference, dark cell = 1")


# ------------------------------------------------------------------------ main
def main():
    ap = argparse.ArgumentParser(description="Camera matched-control experiment (physical mask as the secret)")
    ap.add_argument("--camera", default="0", help="camera index, video file, or 'synthetic'")
    ap.add_argument("--secret", help="bit string of K, e.g. 101100... (default: random)")
    ap.add_argument("--n", type=int, default=24)
    ap.add_argument("--make-mask", metavar="PNG", help="write the printable strip for --secret and exit")
    ap.add_argument("--synthetic-mask", choices=["secret", "other", "none"], default="secret")
    ap.add_argument("--frac", type=float, default=0.5, help="bright if cell >= frac x reference cell")
    ap.add_argument("--bmax", type=int, default=2000, help="hash budget per stage")
    ap.add_argument("--max-frames", type=int, default=300)
    ap.add_argument("--seed", type=int, default=None)
    ap.add_argument("--preview", action="store_true")
    args = ap.parse_args()

    rng = random.Random(args.seed)
    if args.secret:
        K = [int(c) for c in args.secret]
        n = len(K)
    else:
        n = args.n
        K = [rng.getrandbits(1) for _ in range(n)]
        print(f"random secret (use --secret to reuse it): {''.join(map(str, K))}")
    if args.make_mask:
        return make_mask(K, args.make_mask)

    weight = sum(K)
    radius = 0
    while sum(math.comb(n, j) for j in range(radius + 2)) <= args.bmax:
        radius += 1
    if weight <= radius or n - weight <= 0:
        print(f"WARNING: K has only {weight} ones; a blank scene can guess it (search radius {radius}). "
              "Use a secret with more ones so the control is meaningful.")

    salt = rng.randbytes(16)
    commit = hashlib.sha256(salt + pack(K)).digest()
    print(f"commitment C = {commit.hex()[:16]}...  salt = {salt.hex()[:8]}...  n = {n}  "
          f"brute force: up to 2^{n} = {2 ** n:,} hashes")
    print("the decoder below only sees camera frames, C and the salt\n")

    if args.camera == "synthetic":
        other = [rng.getrandbits(1) for _ in range(n)]
        bits = {"secret": K, "other": other, "none": None}[args.synthetic_mask]
        src = SyntheticMask(bits, args.seed)
        print(f"[synthetic] strip in view: {args.synthetic_mask}")
    else:
        src = Camera(args.camera, args.preview)

    seen_zero, last_U, hashes, valid = [False] * n, None, 0, 0
    bright = np.zeros(n)
    recovered = None
    try:
        for _ in range(args.max_frames):
            gray = src.read()
            bits, ref = read_cells(gray, n, args.frac)
            src.show(gray, bits, n)
            if ref < MIN_REF:
                continue
            valid += 1
            bright += bits
            for i, b in enumerate(bits):
                if not b:
                    seen_zero[i] = True                        # a zero proves the cell is a 1
            U = tuple(i for i in range(n) if not seen_zero[i])
            if U == last_U:                                    # same candidate set as last stage
                continue
            last_U = U
            base = [0 if i in U else 1 for i in range(n)]
            cum = 0
            for k in range(len(U) + 1):                        # flip k cells of U from 0 to 1
                layer = math.comb(len(U), k)
                if cum + layer > args.bmax:
                    break
                cum += layer
                for F in itertools.combinations(U, k):
                    cand = base[:]
                    for i in F:
                        cand[i] = 1
                    hashes += 1
                    if hashlib.sha256(salt + pack(cand)).digest() == commit:
                        recovered = (cand, valid, len(U), k)
                        break
                if recovered:
                    break
            if recovered:
                break
    finally:
        src.close()

    print(f"frames used: {valid}   hash evaluations: {hashes:,}")
    if valid:
        rates = bright / valid
        print("fraction of frames each cell was bright (clear ~ 1.00, dark ~ 0.00):")
        print("  " + " ".join(f"{r:.2f}" for r in rates))
    if recovered:
        cand, m, u, k = recovered
        print(f"\nRECOVERED K after {m} frames (|U|={u}, radius k={k}): {''.join(map(str, cand))}")
        print(f"matches the committed secret: {cand == K}")
    else:
        print("\nNOT recovered. If the strip was in view: check alignment/lighting, lower --frac for "
              "faint dark cells, or raise --max-frames.\nIf it was a control run, this is the expected result.")


if __name__ == "__main__":
    main()
