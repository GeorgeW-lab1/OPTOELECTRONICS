#!/usr/bin/env python3
"""
bitcoin_stratum_proxy.py - Transparent Stratum V1 relay for Bitcoin SHA-256 miners.

Each miner that connects locally gets its own upstream connection to the pool.
Every message is passed through unchanged, so the pool's real extranonce1,
extranonce2_size, difficulty, jobs, and accept/reject responses reach the miner.
The proxy only logs traffic (jobs, submits, and the pool's answer to each submit).

Usage:
    python3 bitcoin_stratum_proxy.py -p stratum+tcp://btc.viabtc.com:3333 -l 3333
Then point the miner at  stratum+tcp://<this-machine-ip>:3333  with its normal
wallet/worker credentials.
"""

import argparse
import json
import socket
import threading
import time


def log(tag, msg):
    print(f"{time.strftime('%H:%M:%S')} [{tag}] {msg}", flush=True)


def parse_pool(url):
    cleaned = url.strip()
    for pfx in ("stratum+tcp://", "stratum+ssl://", "stratum://", "tcp://"):
        if cleaned.lower().startswith(pfx):
            cleaned = cleaned[len(pfx):]
            break
    hostport = cleaned.split("/")[0]
    host, port = hostport.rsplit(":", 1)
    return host, int(port)


def send_line(sock, lock, line):
    with lock:
        sock.sendall((line + "\n").encode("utf-8"))


def read_lines(sock):
    """Yield complete newline-terminated lines from a socket until it closes."""
    buf = b""
    while True:
        data = sock.recv(4096)
        if not data:
            return
        buf += data
        while b"\n" in buf:
            line, buf = buf.split(b"\n", 1)
            line = line.strip()
            if line:
                yield line.decode("utf-8", errors="ignore")


class Session:
    """One miner <-> one upstream pool connection."""

    def __init__(self, miner_sock, addr, host, port, verbose):
        self.miner = miner_sock
        self.addr = addr
        self.host = host
        self.port = port
        self.verbose = verbose
        self.pool = None
        self.miner_lock = threading.Lock()
        self.pool_lock = threading.Lock()
        self.pending_submits = {}  # request id -> params
        self.accepted = 0
        self.rejected = 0
        self.closed = threading.Event()

    def close(self):
        if self.closed.is_set():
            return
        self.closed.set()
        for s in (self.miner, self.pool):
            if s:
                try:
                    s.shutdown(socket.SHUT_RDWR)
                except OSError:
                    pass
                try:
                    s.close()
                except OSError:
                    pass
        log("SESSION", f"{self.addr} closed (accepted={self.accepted}, rejected={self.rejected})")

    def run(self):
        try:
            log("PROXY", f"Miner {self.addr} connected. Connecting to {self.host}:{self.port}...")
            self.pool = socket.create_connection((self.host, self.port), timeout=20)
            self.pool.settimeout(None)
            self.pool.setsockopt(socket.SOL_SOCKET, socket.SO_KEEPALIVE, 1)
            log("PROXY", "Upstream connected.")
        except Exception as e:
            log("PROXY", f"Upstream connection failed: {e}")
            self.close()
            return

        t = threading.Thread(target=self._pool_to_miner, daemon=True)
        t.start()
        self._miner_to_pool()
        self.close()

    def _miner_to_pool(self):
        try:
            for line in read_lines(self.miner):
                try:
                    msg = json.loads(line)
                except json.JSONDecodeError:
                    msg = None

                if isinstance(msg, dict):
                    method = msg.get("method")
                    if method == "mining.submit":
                        self.pending_submits[msg.get("id")] = msg.get("params")
                        log("SUBMIT", f"{msg.get('params')}")
                    elif method == "mining.authorize":
                        params = msg.get("params") or [""]
                        log("AUTH", f"worker {params[0]}")
                    elif self.verbose:
                        log("MINER->POOL", line)
                elif self.verbose:
                    log("MINER->POOL", line)

                send_line(self.pool, self.pool_lock, line)  # forwarded unchanged
        except Exception as e:
            if not self.closed.is_set():
                log("PROXY", f"Miner read error: {e}")

    def _pool_to_miner(self):
        try:
            for line in read_lines(self.pool):
                try:
                    msg = json.loads(line)
                except json.JSONDecodeError:
                    msg = None

                if isinstance(msg, dict):
                    method = msg.get("method")
                    if method == "mining.notify":
                        log("JOB", f"job {msg['params'][0]} clean={msg['params'][-1]}")
                    elif method == "mining.set_difficulty":
                        log("DIFF", f"pool difficulty {msg.get('params')}")
                    elif msg.get("id") in self.pending_submits:
                        params = self.pending_submits.pop(msg["id"])
                        if msg.get("result") is True:
                            self.accepted += 1
                            log("ACCEPTED", f"job {params[1]} nonce {params[4]} "
                                            f"(total accepted={self.accepted})")
                        else:
                            self.rejected += 1
                            log("REJECTED", f"job {params[1]} nonce {params[4]} "
                                            f"error={msg.get('error')} (total rejected={self.rejected})")
                    elif self.verbose:
                        log("POOL->MINER", line)
                elif self.verbose:
                    log("POOL->MINER", line)

                send_line(self.miner, self.miner_lock, line)  # forwarded unchanged
        except Exception as e:
            if not self.closed.is_set():
                log("PROXY", f"Upstream read error: {e}")
        finally:
            # Upstream gone: drop the miner so it reconnects and redoes the full handshake.
            if not self.closed.is_set():
                log("PROXY", "Upstream closed. Disconnecting miner so it re-handshakes.")
            self.close()


def main():
    parser = argparse.ArgumentParser(description="Transparent Bitcoin Stratum V1 proxy")
    parser.add_argument("-p", "--pool", required=True,
                        help="Upstream pool, e.g. stratum+tcp://btc.viabtc.com:3333")
    parser.add_argument("-l", "--local-port", type=int, default=3333,
                        help="Local listening port (default: 3333)")
    parser.add_argument("-v", "--verbose", action="store_true",
                        help="Log every raw message in both directions")
    args = parser.parse_args()

    host, port = parse_pool(args.pool)

    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    server.bind(("0.0.0.0", args.local_port))
    server.listen(16)
    log("PROXY", f"Listening on port {args.local_port}, relaying to {host}:{port}")

    try:
        while True:
            miner_sock, addr = server.accept()
            miner_sock.setsockopt(socket.SOL_SOCKET, socket.SO_KEEPALIVE, 1)
            session = Session(miner_sock, addr, host, port, args.verbose)
            threading.Thread(target=session.run, daemon=True).start()
    except KeyboardInterrupt:
        log("PROXY", "Shutting down.")
    finally:
        server.close()


if __name__ == "__main__":
    main()
