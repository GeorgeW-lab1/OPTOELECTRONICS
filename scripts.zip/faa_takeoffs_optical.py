#!/usr/bin/env python3
"""
FAA TAKEOFF STATUS OVER A REAL OPTICAL LINK  (screen -> webcam)
---------------------------------------------------------------
Replaces the NumPy-simulated rp-ghost channel with a physical one:

  TRANSMIT  The script draws a 8x6 grid of black/white cells on your screen.
            40 cells carry one [8-bit index | 24-bit data | 8-bit CRC-8] frame,
            8 reference cells (4 white, 4 black) track exposure drift.
  RECEIVE   Your webcam, pointed at the screen, films the grid. Each cell's real
            pixel brightness (averaged over a few frames) is thresholded to a bit.
  CHECK     CRC-8 per frame, retry on failure, then the text is reassembled.

Records come from the FAA NAS status feed (US airports only): departure delays
and airport closures.  Optional: FAA_INCLUDE_PROGRAMS=1 adds ground stops / GDPs.

SETUP    pip install opencv-python numpy
         Point the webcam at the monitor (or at a phone/tablet screen showing
         this window). Keep room lighting steady and avoid glare on the screen.

RUN      python faa_takeoffs_optical.py                 real hardware
         python faa_takeoffs_optical.py --sim --sample --once    no hardware test
         options: --camera N  --fullscreen  --settle N  --avg N  --max-records N

HONEST NOTE  This is a real light link, but it only carries data this script
sends. It does not obtain information the script doesn't already have.
"""

import argparse
import os
import sys
import threading
import time
import urllib.request
import xml.etree.ElementTree as ET
from datetime import datetime, timezone

import numpy as np

try:
    import cv2
    HAS_OPENCV = True
except ImportError:
    HAS_OPENCV = False

# ============================================================================
# CONFIG
# ============================================================================

COLS, ROWS = 8, 6                 # 48 cells: rows 0-4 = 40 payload bits, row 5 = reference
N_BITS = 40
CELL_PX = 120                     # cell size on screen -> 960x720 image
CHUNK_BYTES = 3
MAX_BYTES = 96
MAX_RETRIES = 5
REF_PATTERN = np.array([1, 0, 1, 0, 1, 0, 1, 0], dtype=int)
MIN_CONTRAST = 15.0               # min (white - black) gray levels per cell at calibration
MIN_SPAN = 0.30                   # min normalized reference span to trust a capture

FAA_API = "https://nasstatus.faa.gov/api/airport-status-information"
POLL_SECONDS = 60
IDLE_PRINT_SECONDS = 30
WATCH = {a.strip().upper() for a in os.environ.get("FAA_AIRPORTS", "").split(",") if a.strip()}
INCLUDE_PROGRAMS = os.environ.get("FAA_INCLUDE_PROGRAMS", "") not in ("", "0", "false", "False")

SAMPLE_XML = """<AIRPORT_STATUS_INFORMATION>
<Update_Time>Tue Nov 17 14:05:00 2026 GMT</Update_Time>
<Delay_type><Name>Ground Stop Programs</Name><Ground_Stop_List>
<Program><ARPT>EWR</ARPT><Reason>thunderstorms</Reason><End_Time>3:00 pm EST</End_Time></Program>
</Ground_Stop_List></Delay_type>
<Delay_type><Name>Arrival/Departure Delay Info</Name><Arrival_Departure_Delay_List>
<Delay><ARPT>ORD</ARPT><Reason>volume</Reason><Arrival_Departure Type="Departure"><Min>16 minutes</Min><Max>30 minutes</Max><Trend>Increasing</Trend></Arrival_Departure></Delay>
<Delay><ARPT>JFK</ARPT><Reason>weather</Reason><Arrival_Departure Type="Arrival"><Min>20 minutes</Min><Max>45 minutes</Max><Trend>Stable</Trend></Arrival_Departure><Arrival_Departure Type="Departure"><Min>31 minutes</Min><Max>45 minutes</Max><Trend>Decreasing</Trend></Arrival_Departure></Delay>
<Delay><ARPT>SEA</ARPT><Reason>low visibility</Reason><Arrival_Departure Type="Arrival"><Min>15 minutes</Min><Max>29 minutes</Max><Trend>Stable</Trend></Arrival_Departure></Delay>
</Arrival_Departure_Delay_List></Delay_type>
<Delay_type><Name>Airport Closures</Name><Airport_Closure_List>
<Airport><ARPT>PHL</ARPT><Reason>runway repair</Reason><Start>Nov 17 at 06:00 UTC.</Start><Reopen>Nov 18 at 11:00 UTC.</Reopen></Airport>
</Airport_Closure_List></Delay_type>
</AIRPORT_STATUS_INFORMATION>"""

# ============================================================================
# CRC-8 + FRAMING
# ============================================================================


def crc8(data):
    crc = 0
    for byte in data:
        crc ^= byte
        for _ in range(8):
            crc = ((crc << 1) ^ 0x07) & 0xFF if crc & 0x80 else (crc << 1) & 0xFF
    return crc


def int_to_bits(value, width):
    return [(value >> (width - 1 - k)) & 1 for k in range(width)]


def bits_to_code(bits):
    code = 0
    for bit in bits:
        code = (code << 1) | (int(bit) & 1)
    return code


def encode_frame(index, chunk):
    chunk = bytes(chunk).ljust(CHUNK_BYTES, b"\x00")[:CHUNK_BYTES]
    body = bytes([index & 0xFF]) + chunk
    return np.array(int_to_bits(body[0], 8) + [b for by in chunk for b in int_to_bits(by, 8)]
                    + int_to_bits(crc8(body), 8), dtype=int)


def decode_frame(bits):
    bits = np.asarray(bits, dtype=int).flatten()
    index = bits_to_code(bits[:8])
    chunk = bytes(bits_to_code(bits[8 + 8 * i: 16 + 8 * i]) for i in range(CHUNK_BYTES))
    return index, chunk, bits_to_code(bits[32:40]) == crc8(bytes([index]) + chunk)


# ============================================================================
# DISPLAY + CAMERA BACKENDS (real OpenCV, or a simulated camera for testing)
# ============================================================================


class CvDisplay:
    WIN = "RP-GHOST optical transmitter (point the webcam here)"

    def __init__(self, fullscreen=False):
        if fullscreen:
            cv2.namedWindow(self.WIN, cv2.WND_PROP_FULLSCREEN)
            cv2.setWindowProperty(self.WIN, cv2.WND_PROP_FULLSCREEN, cv2.WINDOW_FULLSCREEN)
        else:
            cv2.namedWindow(self.WIN, cv2.WINDOW_AUTOSIZE)
            cv2.moveWindow(self.WIN, 40, 40)

    def show(self, img):
        cv2.imshow(self.WIN, img)
        cv2.waitKey(1)

    def pump(self):
        cv2.waitKey(1)

    def close(self):
        cv2.destroyAllWindows()


class CvCamera:
    def __init__(self, index=0, width=640, height=480):
        self.cap = cv2.VideoCapture(index)
        self.cap.set(cv2.CAP_PROP_FRAME_WIDTH, width)
        self.cap.set(cv2.CAP_PROP_FRAME_HEIGHT, height)
        self.cap.set(cv2.CAP_PROP_BUFFERSIZE, 1)
        if not self.cap.isOpened():
            raise RuntimeError(f"could not open camera index {index}")

    def read(self):
        ok, frame = self.cap.read()
        if not ok:
            raise RuntimeError("camera read failed")
        return cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY).astype(np.float32)

    def close(self):
        self.cap.release()


class FakeDisplay:
    def __init__(self):
        self.img = self.prev = np.zeros((ROWS * CELL_PX, COLS * CELL_PX), np.uint8)
        self.since = 99

    def show(self, img):
        self.prev, self.img, self.since = self.img, img, 0

    def pump(self):
        pass

    def close(self):
        pass


class FakeCamera:
    """Pretend webcam: sees the screen at half size, offset, with ambient light,
    sensor noise, exposure flicker and 2 frames of display latency."""

    def __init__(self, display, latency=2, noise=4.0):
        self.display, self.latency, self.noise = display, latency, noise
        self.rng = np.random.default_rng(7)

    def read(self):
        d = self.display
        d.since += 1
        shown = d.prev if d.since <= self.latency else d.img
        small = shown[::2, ::2].astype(np.float32)               # 360 x 480
        canvas = np.full((480, 640), 25.0, np.float32)
        canvas[60:60 + small.shape[0], 80:80 + small.shape[1]] = 25.0 + 0.6 * small
        canvas *= 1.0 + self.rng.normal(0, 0.02)                  # exposure drift
        canvas += self.rng.normal(0, self.noise, canvas.shape)
        return np.clip(canvas, 0, 255)

    def close(self):
        pass


# ============================================================================
# OPTICAL LINK
# ============================================================================


def render_pattern(cells):
    grid = np.asarray(cells, dtype=np.uint8).reshape(ROWS, COLS) * 255
    return np.kron(grid, np.ones((CELL_PX, CELL_PX), dtype=np.uint8))


class OpticalLink:
    def __init__(self, camera, display, settle=3, avg=2):
        self.cam, self.disp, self.settle, self.avg = camera, display, settle, avg
        self.B = self.W = None
        self.slices = None
        self.frames_sent = 0

    def _capture(self):
        for _ in range(self.settle):                  # discard frames while screen/camera catch up
            self.cam.read()
        return np.mean([self.cam.read() for _ in range(self.avg)], axis=0)

    def calibrate(self):
        self.disp.show(render_pattern(np.zeros(ROWS * COLS)))
        black = self._capture()
        self.disp.show(render_pattern(np.ones(ROWS * COLS)))
        white = self._capture()
        diff = white - black
        mask = diff > 0.5 * np.percentile(diff, 99.5)
        ys, xs = np.where(mask)
        if len(ys) < 0.01 * diff.size:
            raise RuntimeError("screen not found: camera sees no brightness change. "
                               "Point the webcam at the transmitter window.")
        y0, y1 = np.percentile(ys, [0.5, 99.5]).astype(int)
        x0, x1 = np.percentile(xs, [0.5, 99.5]).astype(int)
        cw, ch = (x1 - x0) / COLS, (y1 - y0) / ROWS
        self.slices = []
        for r in range(ROWS):
            for c in range(COLS):
                self.slices.append((slice(int(y0 + (r + 0.2) * ch), int(y0 + (r + 0.8) * ch)),
                                    slice(int(x0 + (c + 0.2) * cw), int(x0 + (c + 0.8) * cw))))
        self.B, self.W = self._cells(black), self._cells(white)
        weak = int(np.sum(self.W - self.B < MIN_CONTRAST))
        if weak:
            raise RuntimeError(f"{weak} cell(s) have too little contrast: raise screen brightness, "
                               "reduce glare, or move the camera closer.")
        return (x0, y0, x1, y1), float(np.mean(self.W - self.B))

    def _cells(self, img):
        return np.array([img[s].mean() for s in self.slices])

    def transfer(self, bits40):
        """Shows 40 bits (+ reference row) and reads them back from the camera.
        Returns (decoded_bits, eye_opening 0..1+)."""
        cells = np.concatenate([np.asarray(bits40, dtype=int), REF_PATTERN])
        self.disp.show(render_pattern(cells))
        self.frames_sent += 1
        x = (self._cells(self._capture()) - self.B) / (self.W - self.B)    # 0 = black, 1 = white
        ref = x[N_BITS:]
        ref_w, ref_b = ref[REF_PATTERN == 1].mean(), ref[REF_PATTERN == 0].mean()
        span = ref_w - ref_b
        thr = (ref_w + ref_b) / 2.0
        decoded = (x[:N_BITS] > thr).astype(int)
        eye = 0.0 if span < MIN_SPAN else float(max(0.0, np.min(np.abs(x[:N_BITS] - thr)) / (span / 2.0)))
        return decoded, eye


def transmit_text(link, text, max_retries=MAX_RETRIES):
    """Returns (decoded_text, frames, retries, failed, min_eye)."""
    raw = text.encode("utf-8")[:MAX_BYTES] + b"\x00"
    chunks = [raw[i:i + CHUNK_BYTES] for i in range(0, len(raw), CHUNK_BYTES)]
    received = bytearray()
    retries = failed = 0
    min_eye = float("inf")
    for i, chunk in enumerate(chunks):
        good = None
        for _ in range(max_retries):
            dbits, eye = link.transfer(encode_frame(i, chunk))
            idx, data, ok = decode_frame(dbits)
            if ok and idx == (i & 0xFF):
                good, min_eye = data, min(min_eye, eye)
                break
            retries += 1
        if good is None:
            failed += 1
            good = b"?" * CHUNK_BYTES
        received += good
    out = bytes(received).split(b"\x00", 1)[0].decode("utf-8", errors="replace")
    return out, len(chunks), retries, failed, (0.0 if min_eye == float("inf") else min_eye)


def transmit_u32(link, value, max_retries=MAX_RETRIES):
    value &= 0xFFFFFFFF
    bits = np.array(int_to_bits(value, 32) + int_to_bits(crc8(value.to_bytes(4, "big")), 8), dtype=int)
    for _ in range(max_retries):
        dbits, _ = link.transfer(bits)
        got = bits_to_code(dbits[:32])
        if bits_to_code(dbits[32:40]) == crc8(got.to_bytes(4, "big")):
            return got, True
    return None, False


# ============================================================================
# FAA FEED (departure delays + closures)
# ============================================================================


def format_age(age_sec):
    s = max(0, int(age_sec))
    d, rem = divmod(s, 86400)
    h, rem = divmod(rem, 3600)
    m, sec = divmod(rem, 60)
    if d:
        return f"{d}d {h}h"
    if h:
        return f"{h}h {m}m"
    return f"{m}m {sec}s" if m else f"{sec}s"


def parse_update_time(text):
    try:
        dt = datetime.strptime(text.strip().replace(" GMT", ""), "%a %b %d %H:%M:%S %Y")
        return int(dt.replace(tzinfo=timezone.utc).timestamp())
    except Exception:
        return None


def _clean(el, tag):
    return (el.findtext(tag) or "").strip().rstrip(".")


def parse_takeoff_records(xml_text):
    root = ET.fromstring(xml_text)
    update_time = (root.findtext("Update_Time") or "").strip()
    records = []

    def add(airport, kind, rank, parts):
        airport = airport.upper()
        if airport and (not WATCH or airport in WATCH):
            records.append({"airport": airport, "kind": kind, "rank": rank,
                            "line": "|".join([airport, kind] + [p for p in parts if p])})

    for dtype in root.iter("Delay_type"):
        name = (dtype.findtext("Name") or "").lower()
        for lst in dtype:
            if lst.tag == "Name":
                continue
            for rec in lst:
                arpt, reason = _clean(rec, "ARPT"), _clean(rec, "Reason")
                if "closure" in name:
                    st, ro = _clean(rec, "Start"), _clean(rec, "Reopen")
                    add(arpt, "CLOSED", 0, [reason, "from " + st if st else "", "reopen " + ro if ro else ""])
                elif "arrival" in name or "departure" in name:
                    for ad in rec.findall("Arrival_Departure"):
                        if ad.attrib.get("Type", "").lower() != "departure":
                            continue
                        mn, mx, tr = _clean(ad, "Min"), _clean(ad, "Max"), _clean(ad, "Trend")
                        add(arpt, "DEP DELAY", 1, [reason, "min " + mn if mn else "",
                                                   "max " + mx if mx else "", tr])
                elif INCLUDE_PROGRAMS and "ground stop" in name:
                    et = _clean(rec, "End_Time")
                    add(arpt, "GROUND STOP (inbound held)", 2, [reason, "until " + et if et else ""])
                elif INCLUDE_PROGRAMS and "ground delay" in name:
                    avg, mx = _clean(rec, "Avg"), _clean(rec, "Max")
                    add(arpt, "GDP (inbound held)", 3, [reason, "avg " + avg if avg else "",
                                                        "max " + mx if mx else ""])
    records.sort(key=lambda r: (r["rank"], r["airport"]))
    return update_time, records


class FAAFetcher(threading.Thread):
    def __init__(self, url=FAA_API, poll_seconds=POLL_SECONDS, live=True):
        super().__init__(daemon=True)
        self.url, self.poll_seconds, self.live = url, poll_seconds, live
        self.pending = self.last_sig = None
        self.have_live = False
        self.lock = threading.Lock()
        self.running = True

    def _fetch_xml(self):
        req = urllib.request.Request(self.url, headers={"User-Agent": "faa-takeoffs/2.0",
                                                        "Accept": "application/xml"})
        with urllib.request.urlopen(req, timeout=10) as resp:
            return resp.read().decode("utf-8", errors="replace")

    def ingest(self, xml_text, simulated):
        update_time, records = parse_takeoff_records(xml_text)
        sig = (update_time, tuple(r["line"] for r in records))
        with self.lock:
            if sig == self.last_sig:
                return
            self.last_sig = sig
            self.pending = {"update_time": update_time, "records": records, "simulated": simulated}

    def run(self):
        if not self.live:
            self.ingest(SAMPLE_XML, simulated=True)
            return
        fails = 0
        while self.running:
            try:
                self.ingest(self._fetch_xml(), simulated=False)
                self.have_live, fails = True, 0
            except Exception as e:
                fails += 1
                print(f"[FAA] Fetch failed: {e}")
                if not self.have_live and fails >= 3 and self.last_sig is None:
                    print("[FAA] Feed unreachable - using SAMPLE data (not real conditions).")
                    self.ingest(SAMPLE_XML, simulated=True)
            for _ in range(self.poll_seconds):
                if not self.running:
                    break
                time.sleep(1)

    def pop_update(self):
        with self.lock:
            snap, self.pending = self.pending, None
            return snap

    def stop(self):
        self.running = False


# ============================================================================
# DECODE + DISPLAY
# ============================================================================


def decode_snapshot(link, snap, max_records):
    ut = parse_update_time(snap["update_time"])
    dec_ut, ok_ut = transmit_u32(link, ut) if ut is not None else (None, False)
    results = []
    for rec in snap["records"][:max_records]:
        text, frames, retries, failed, eye = transmit_text(link, rec["line"])
        sent = rec["line"].encode("utf-8")[:MAX_BYTES].decode("utf-8", errors="replace")
        results.append({"text": text, "frames": frames, "retries": retries, "failed": failed,
                        "eye": eye, "match": failed == 0 and text == sent})
    return dec_ut, ok_ut, results


def print_snapshot(snap, dec_ut, ok_ut, results, max_records, channel_label):
    tag = " (SAMPLE DATA)" if snap["simulated"] else ""
    total = len(snap["records"])
    closed = sum(1 for r in snap["records"] if r["kind"] == "CLOSED")
    delays = sum(1 for r in snap["records"] if r["kind"] == "DEP DELAY")
    print("-" * 78)
    print(f" [FAA TAKEOFFS] UPDATE{tag} | {total} record(s) | {closed} closed, {delays} departure delay(s)")
    print(f" Channel: {channel_label}")
    if ok_ut:
        print(f"   Feed time (decoded): {time.strftime('%Y-%m-%d %H:%M:%S', time.gmtime(dec_ut))} UTC "
              f"({format_age(time.time() - dec_ut)} ago) (CRC PASS)")
    else:
        print(f"   Feed time: {snap['update_time'] or 'unknown'} (optical decode failed / CRC FAIL)")
    if not results:
        print("   No departure delays or closures reported.")
    for n, r in enumerate(results, 1):
        integrity = "" if r["failed"] == 0 else f" | {r['failed']} frame(s) unrecoverable"
        print(f"   [{n:02d}] {r['text']}")
        print(f"        {r['frames']} frames | CRC retries {r['retries']} | min eye opening "
              f"{r['eye'] * 100:.0f}% | {'MATCHES feed' if r['match'] else 'MISMATCH'}{integrity}")
    if total > len(results):
        print(f"   ... {total - len(results)} more record(s) not decoded (--max-records {max_records})")
    print("-" * 78)


def main():
    ap = argparse.ArgumentParser(description="FAA takeoff status over a real screen->webcam optical link")
    ap.add_argument("--sim", action="store_true", help="use a simulated camera (no hardware)")
    ap.add_argument("--sample", action="store_true", help="use built-in sample FAA data (no network)")
    ap.add_argument("--once", action="store_true", help="decode one update and exit")
    ap.add_argument("--camera", type=int, default=0)
    ap.add_argument("--fullscreen", action="store_true")
    ap.add_argument("--settle", type=int, default=3, help="frames discarded after each pattern change")
    ap.add_argument("--avg", type=int, default=2, help="frames averaged per read")
    ap.add_argument("--max-records", type=int, default=8)
    args = ap.parse_args()

    print("=" * 78)
    print(" FAA TAKEOFF STATUS DECODER - OPTICAL LINK (screen -> webcam)")
    print("=" * 78)

    if args.sim:
        display = FakeDisplay()
        camera = FakeCamera(display)
        label = "SIMULATED CAMERA (--sim): same decode path, no physical light"
    else:
        if not HAS_OPENCV:
            sys.exit("OpenCV is required for the real optical link:  pip install opencv-python\n"
                     "(or run with --sim to test without hardware)")
        display = CvDisplay(args.fullscreen)
        try:
            camera = CvCamera(args.camera)
        except Exception as e:
            sys.exit(f"[CAMERA] {e}")
        label = f"REAL OPTICAL (screen -> camera #{args.camera})"

    link = OpticalLink(camera, display, settle=args.settle, avg=args.avg)
    try:
        box, contrast = link.calibrate()
    except Exception as e:
        display.close()
        sys.exit(f"[CALIBRATION FAILED] {e}")
    print(f"[OPTICAL] Calibrated: screen at x={box[0]}..{box[2]}, y={box[1]}..{box[3]} in camera view, "
          f"mean contrast {contrast:.0f} gray levels")

    faa = FAAFetcher(live=not args.sample)
    faa.start()
    print("[START] Waiting for FAA feed. Press Ctrl+C to exit.\n")
    last_print = time.time()
    try:
        while True:
            snap = faa.pop_update()
            if snap:
                dec_ut, ok_ut, results = decode_snapshot(link, snap, args.max_records)
                print_snapshot(snap, dec_ut, ok_ut, results, args.max_records, label)
                last_print = time.time()
                if args.once:
                    break
            elif time.time() - last_print >= IDLE_PRINT_SECONDS:
                print(f" [FAA TAKEOFFS] no change since last update ({time.strftime('%H:%M:%S')})")
                last_print = time.time()
            display.pump()                      # keep the OpenCV window responsive while idle
            time.sleep(0.2)
    except KeyboardInterrupt:
        print("\n[STOP] Shutting down...")
    finally:
        faa.stop()
        camera.close()
        display.close()
        print("[DONE] Terminated.")


if __name__ == "__main__":
    main()
