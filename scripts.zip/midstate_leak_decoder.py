"""
Simulation: recover a SHA-256 midstate from a NOISY SIMULATED LEAKAGE channel.

Setup (toy model):
  - A secret message prefix (one 64-byte block) is hashed; the internal state after
    that block is the 256-bit "midstate" (8 x 32-bit words).
  - A synthetic channel leaks each midstate bit with Gaussian noise, confidence gating,
    bit flips and partial reveals (same channel model as the original script).
  - Decoder: vote accumulation -> majority guess -> Chase-style list decoding over
    the least-confident bits.
  - Verification: resume SHA-256 from the candidate midstate with the known suffix
    block and compare against the known final digest.

This is not a cryptanalytic attack: the leakage is simulated directly from the secret.
"""
import os, struct, itertools, time
import numpy as np

K = [
0x428a2f98,0x71374491,0xb5c0fbcf,0xe9b5dba5,0x3956c25b,0x59f111f1,0x923f82a4,0xab1c5ed5,
0xd807aa98,0x12835b01,0x243185be,0x550c7dc3,0x72be5d74,0x80deb1fe,0x9bdc06a7,0xc19bf174,
0xe49b69c1,0xefbe4786,0x0fc19dc6,0x240ca1cc,0x2de92c6f,0x4a7484aa,0x5cb0a9dc,0x76f988da,
0x983e5152,0xa831c66d,0xb00327c8,0xbf597fc7,0xc6e00bf3,0xd5a79147,0x06ca6351,0x14292967,
0x27b70a85,0x2e1b2138,0x4d2c6dfc,0x53380d13,0x650a7354,0x766a0abb,0x81c2c92e,0x92722c85,
0xa2bfe8a1,0xa81a664b,0xc24b8b70,0xc76c51a3,0xd192e819,0xd6990624,0xf40e3585,0x106aa070,
0x19a4c116,0x1e376c08,0x2748774c,0x34b0bcb5,0x391c0cb3,0x4ed8aa4a,0x5b9cca4f,0x682e6ff3,
0x748f82ee,0x78a5636f,0x84c87814,0x8cc70208,0x90befffa,0xa4506ceb,0xbef9a3f7,0xc67178f2]
IV = [0x6a09e667,0xbb67ae85,0x3c6ef372,0xa54ff53a,0x510e527f,0x9b05688c,0x1f83d9ab,0x5be0cd19]
M32 = 0xffffffff
rotr = lambda x, n: ((x >> n) | (x << (32 - n))) & M32

def compress(state, block):
    w = list(struct.unpack(">16I", block))
    for i in range(16, 64):
        s0 = rotr(w[i-15], 7) ^ rotr(w[i-15], 18) ^ (w[i-15] >> 3)
        s1 = rotr(w[i-2], 17) ^ rotr(w[i-2], 19) ^ (w[i-2] >> 10)
        w.append((w[i-16] + s0 + w[i-7] + s1) & M32)
    a, b, c, d, e, f, g, h = state
    for i in range(64):
        S1 = rotr(e, 6) ^ rotr(e, 11) ^ rotr(e, 25)
        ch = (e & f) ^ (~e & g)
        t1 = (h + S1 + ch + K[i] + w[i]) & M32
        S0 = rotr(a, 2) ^ rotr(a, 13) ^ rotr(a, 22)
        maj = (a & b) ^ (a & c) ^ (b & c)
        t2 = (S0 + maj) & M32
        h, g, f, e, d, c, b, a = g, f, e, (d + t1) & M32, c, b, a, (t1 + t2) & M32
    return [(x + y) & M32 for x, y in zip(state, [a, b, c, d, e, f, g, h])]

def state_to_bits(state):
    return np.unpackbits(np.frombuffer(struct.pack(">8I", *state), dtype=np.uint8))

def bits_to_state(bits):
    return list(struct.unpack(">8I", np.packbits(bits).tobytes()))

def run():
    seed = 42
    rng = np.random.default_rng(seed)
    m = 256

    # --- Ground truth: midstate after block 1; known suffix block 2 and final digest
    block1 = rng.bytes(64)
    block2 = rng.bytes(64)
    secret_state = compress(IV, block1)
    secret_bits = state_to_bits(secret_state)
    target_digest = compress(secret_state, block2)

    def verify(bits):
        return compress(bits_to_state(bits), block2) == target_digest

    print("=" * 78)
    print(" SHA-256 MIDSTATE RECOVERY FROM NOISY SIMULATED LEAKAGE")
    print("=" * 78)
    print(f"  Target final state : {''.join(f'{x:08x}' for x in target_digest)}")
    print(f"  Midstate bits      : {m}  (brute force 2^{m})\n")
    print(f"{'Cycle':<6} | {'Seen':<6} | {'Unseen':<7} | Status")
    print("-" * 78)

    ch = np.random.default_rng(seed + 1)
    tau, c0, pooled_std = 127.0, 25.0, 40.0 / 16   # 256-pixel average -> std/16
    flip_eps, reveal_rate = 0.02, 0.45
    ones = np.zeros(m, np.int32); zeros = np.zeros(m, np.int32)
    seen = np.zeros(m, bool)
    hashes, found = 0, None
    t0 = time.perf_counter()

    for cycle in range(1, 60):
        pooled = secret_bits * 255.0 + ch.normal(0, pooled_std, m)
        dec = np.full(m, -1, np.int8)
        dec[pooled > tau + c0] = 1
        dec[pooled < tau - c0] = 0
        valid = dec != -1
        dec[valid & (ch.random(m) < flip_eps)] ^= 1
        obs = np.where(valid & (ch.random(m) < reveal_rate), dec, -1)
        ones += (obs == 1); zeros += (obs == 0)
        seen |= (obs != -1)
        n_seen = int(seen.sum())

        if n_seen < m:
            print(f"{cycle:<6} | {n_seen:<6} | {m-n_seen:<7} | collecting frames...")
            continue

        guess = (ones > zeros).astype(np.uint8)
        hashes += 1
        if verify(guess):
            found = guess
            print(f"{cycle:<6} | {n_seen:<6} | 0       | SUCCESS: 0-flip majority guess verified")
            break

        uncertain = np.argsort(np.abs(ones - zeros))[:16]
        for k in range(1, 5):
            for subset in itertools.combinations(uncertain, k):
                hashes += 1
                cand = guess.copy(); cand[list(subset)] ^= 1
                if verify(cand):
                    found = cand; break
            if found is not None:
                print(f"{cycle:<6} | {n_seen:<6} | 0       | SUCCESS: Chase decode, k={k} flips")
                break
        if found is not None:
            break
        print(f"{cycle:<6} | {n_seen:<6} | 0       | list decoding failed this cycle ({hashes:,} checks)")

    ms = (time.perf_counter() - t0) * 1000
    print("\n" + "=" * 78)
    if found is not None:
        words = bits_to_state(found)
        print(f"  Recovered midstate : {''.join(f'{x:08x}' for x in words)}")
        print(f"  Matches secret     : {words == secret_state}")
        print(f"  Candidates checked : {hashes:,}   Time: {ms:.1f} ms")
    else:
        print("  Failed to recover midstate within budget.")

"""
Simulation: recover the SHA-256 midstate of a PoW header from NOISY SIMULATED LEAKAGE.
Real PoW midstates are public; here the leak channel is synthetic, as in
midstate_leak_decoder.py. Verification = finish the double-SHA256 from the candidate
midstate and compare with the known block hash.
"""
import struct, itertools, time
import numpy as np

def pad80():
    return b"\x80" + b"\x00" * 39 + struct.pack(">Q", 640)

def pow_hash_from_midstate(midstate, tail12, nonce):
    st = compress(midstate, tail12 + struct.pack("<I", nonce) + pad80())
    inner = struct.pack(">8I", *st)
    return compress(IV, inner + b"\x80" + b"\x00" * 23 + struct.pack(">Q", 256))

def run(difficulty_bits=12):
    seed = 42
    rng = np.random.default_rng(seed)
    m = 256

    # --- Build a solved toy block: header prefix + nonce meeting low difficulty
    prefix76 = "0000e04046373980d03a2a80ddee4b63537698b7cfca077648c8b0edc6c744db"
    secret_state = compress(IV, prefix76[:64])      # the midstate to "recover"
    secret_bits = state_to_bits(secret_state)
    tail12 = prefix76[64:76]
    target = 1 << (256 - difficulty_bits)
    nonce = 0
    while True:
        d = pow_hash_from_midstate(secret_state, tail12, nonce)
        if int.from_bytes(struct.pack(">8I", *d)[::-1], "big") < target:
            break
        nonce += 1
    block_hash = d

    def verify(bits):
        return pow_hash_from_midstate(bits_to_state(bits), tail12, nonce) == block_hash

    print("=" * 78)
    print(" PoW MIDSTATE RECOVERY FROM NOISY SIMULATED LEAKAGE")
    print("=" * 78)
    print(f"  Block hash : {struct.pack('>8I', *block_hash)[::-1].hex()}")
    print(f"  Nonce      : {nonce}   Midstate bits: {m}\n")
    print(f"{'Cycle':<6} | {'Seen':<6} | {'Unseen':<7} | Status")
    print("-" * 78)

    ch = np.random.default_rng(seed + 1)
    tau, c0, pooled_std = 127.0, 25.0, 40.0 / 16
    flip_eps, reveal_rate = 0.02, 0.45
    ones = np.zeros(m, np.int32); zeros = np.zeros(m, np.int32)
    seen = np.zeros(m, bool)
    checks, found = 0, None
    t0 = time.perf_counter()

    for cycle in range(1, 60):
        pooled = secret_bits * 255.0 + ch.normal(0, pooled_std, m)
        dec = np.full(m, -1, np.int8)
        dec[pooled > tau + c0] = 1
        dec[pooled < tau - c0] = 0
        valid = dec != -1
        dec[valid & (ch.random(m) < flip_eps)] ^= 1
        obs = np.where(valid & (ch.random(m) < reveal_rate), dec, -1)
        ones += (obs == 1); zeros += (obs == 0)
        seen |= (obs != -1)
        n_seen = int(seen.sum())
        if n_seen < m:
            print(f"{cycle:<6} | {n_seen:<6} | {m-n_seen:<7} | collecting frames...")
            continue

        guess = (ones > zeros).astype(np.uint8)
        checks += 1
        if verify(guess):
            found = guess
            print(f"{cycle:<6} | {n_seen:<6} | 0       | SUCCESS: 0-flip majority guess verified")
            break
        uncertain = np.argsort(np.abs(ones - zeros))[:16]
        for k in range(1, 5):
            for subset in itertools.combinations(uncertain, k):
                checks += 1
                cand = guess.copy(); cand[list(subset)] ^= 1
                if verify(cand):
                    found = cand; break
            if found is not None:
                print(f"{cycle:<6} | {n_seen:<6} | 0       | SUCCESS: Chase decode, k={k} flips")
                break
        if found is not None:
            break
        print(f"{cycle:<6} | {n_seen:<6} | 0       | list decoding failed ({checks:,} checks)")

    ms = (time.perf_counter() - t0) * 1000
    print("\n" + "=" * 78)
    if found is not None:
        words = bits_to_state(found)
        print(f"  Recovered midstate : {''.join(f'{x:08x}' for x in words)}")
        print(f"  Matches secret     : {words == secret_state}")
        print(f"  Candidates checked : {checks:,}   Time: {ms:.1f} ms")
    else:
        print("  Failed to recover midstate within budget.")

if __name__ == "__main__":
    run()
