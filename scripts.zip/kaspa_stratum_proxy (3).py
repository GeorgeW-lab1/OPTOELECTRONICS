#!/usr/bin/env python3
"""
kaspa_stratum_proxy.py - Transparent Stratum relay for Kaspa (kHeavyHash) miners such as BzMiner.
(Bitcoin SHA-256 pools also work with --algo sha256.)

Each miner that connects locally gets its own upstream connection to the pool.
Every message is passed through unchanged, so the pool's real extranonce, difficulty,
jobs and accept/reject answers reach the miner. The proxy logs what happens, including
the pool's reply to the login, every share submitted, and the pool's verdict on each.

Optional --rp-ghost passes each share nonce through the simulated RP-GHOST channel.
The original nonce is always the one submitted, so shares can never be corrupted.

Usage:
    python kaspa_stratum_proxy.py -p stratum+tcp://<pool-host>:<port> -l 3333 -v
Miner (BzMiner example):
    bzminer.exe -a kaspa -p stratum+tcp://127.0.0.1:3333 -w <account>.<worker>
"""

import argparse
import hashlib
import json
import math
import os
import socket
import threading
import time

try:
    import numpy as np
except ImportError:  # only needed for --rp-ghost
    np = None

try:
    import cv2
    HAS_OPENCV = True
except ImportError:
    HAS_OPENCV = False


def log(tag, msg):
    print(f"{time.strftime('%H:%M:%S')} [{tag}] {msg}", flush=True)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------
def parse_pool(url):
    cleaned = url.strip()
    for pfx in ("stratum+tcp://", "stratum+ssl://", "stratum://", "tcp://"):
        if cleaned.lower().startswith(pfx):
            cleaned = cleaned[len(pfx):]
            break
    hostport = cleaned.split("/")[0]
    host, port = hostport.rsplit(":", 1)
    return host, int(port)


def nonce_index(params, algo):
    """Index of the nonce in mining.submit params, or None if the shape is unexpected."""
    if not isinstance(params, list):
        return None
    if algo == "kaspa":
        return len(params) - 1 if len(params) >= 3 else None   # [worker, job_id, nonce]
    if algo == "kawpow":
        return 2 if len(params) >= 5 else None                 # [worker, job_id, nonce, header_hash, mix_hash]
    return 4 if len(params) >= 5 else None                      # [worker, job, en2, ntime, nonce]


def submit_fields(params, algo):
    try:
        return params[1], params[nonce_index(params, algo)]
    except Exception:
        return "?", "?"


def send_line(sock, lock, line):
    with lock:
        sock.sendall((line + "\n").encode("utf-8"))


def read_lines(sock):
    """Yield complete newline-terminated lines from a socket until it closes."""
    buf = b""
    while True:
        data = sock.recv(4096)
        if not data:
            return
        buf += data
        while b"\n" in buf:
            line, buf = buf.split(b"\n", 1)
            line = line.strip()
            if line:
                yield line.decode("utf-8", errors="ignore")


# ---------------------------------------------------------------------------
# RP-GHOST optoelectronic channel (simulated Poisson viewport + webcam entropy)
# ---------------------------------------------------------------------------
LAMBDA_BASE = 10000.0
SIGMA_C = 0.005
N_SLOTS = 40
WEBCAM_INDEX = int(os.environ.get("WEBCAM_INDEX", "0"))
CHUNK_BYTES = 3
LARGE_DECODE_WINDOWS = 4000
LARGE_DECODE_RETRIES = 8


def compute_crc8(data_bytes):
    crc = 0x00
    for byte in data_bytes:
        crc ^= byte
        for _ in range(8):
            crc = ((crc << 1) ^ 0x07) & 0xFF if crc & 0x80 else (crc << 1) & 0xFF
    return crc


def bits_to_code(bits):
    code = 0
    for bit in bits:
        code = (code << 1) | (int(bit) & 1)
    return code


def int_to_bits(value, width):
    return [(value >> (width - 1 - k)) & 1 for k in range(width)]


def make_payload_tilt(bits, eps_abs):
    bits = np.asarray(bits, dtype=float)
    strength = max(float(eps_abs), 0.25)
    return 2.0 * strength * (bits - 0.5)


def encode_text_frame(index, chunk):
    chunk = bytes(chunk).ljust(CHUNK_BYTES, b"\x00")[:CHUNK_BYTES]
    body = bytes([index & 0xFF]) + chunk
    crc = compute_crc8(body)
    return np.array(int_to_bits(body[0], 8)
                    + [b for byte in chunk for b in int_to_bits(byte, 8)]
                    + int_to_bits(crc, 8), dtype=int)


def decode_text_frame(bits):
    bits = np.asarray(bits, dtype=int).flatten()
    index = bits_to_code(bits[:8])
    chunk = bytes(bits_to_code(bits[8 + 8 * i: 16 + 8 * i]) for i in range(CHUNK_BYTES))
    received_crc = bits_to_code(bits[32:40])
    ok = received_crc == compute_crc8(bytes([index]) + chunk)
    return index, chunk, ok


class WebcamEntropySource(threading.Thread):
    def __init__(self, camera_index=WEBCAM_INDEX):
        super().__init__(daemon=True)
        self.camera_index = camera_index
        self.running = True
        self.latest_hash = 0

    def run(self):
        if not HAS_OPENCV:
            while self.running:
                time.sleep(1.0 / 30.0)
                dummy = np.random.randint(0, 255, (480, 640, 3), dtype=np.uint8)
                self.latest_hash = int(hashlib.sha256(dummy.tobytes()).hexdigest()[:4], 16)
            return
        cap = cv2.VideoCapture(self.camera_index)
        while self.running:
            ret, frame = cap.read()
            if not ret:
                time.sleep(0.01)
                continue
            gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
            self.latest_hash = int.from_bytes(hashlib.sha256(gray.tobytes()).digest()[:2], "big")
        cap.release()

    def stop(self):
        self.running = False


class OptoelectronicViewport:
    def __init__(self, lambd=LAMBDA_BASE, sigma_c=SIGMA_C):
        self.lambd = lambd
        self.sigma_c = sigma_c

    def generate_window_block(self, n_windows, n_slots, tilt=None, webcam_hash=0):
        seed = (int(time.time() * 1000) ^ webcam_hash) & 0xFFFFFFFF
        rng = np.random.RandomState(seed)  # local RNG; global numpy state untouched
        shared_noise = rng.normal(0.0, self.sigma_c, size=(n_windows, 1))
        lam = self.lambd * (1.0 + shared_noise)
        counts = rng.poisson(np.clip(lam, 1.0, None), size=(n_windows, n_slots))
        Z = (counts - self.lambd) / np.sqrt(self.lambd)
        if tilt is not None:
            Z += tilt
        return Z


def transmit_bytes_hex(viewport, hex_str, webcam_hash=0,
                       windows=LARGE_DECODE_WINDOWS, max_retries=LARGE_DECODE_RETRIES):
    """Encode hex bytes through the simulated channel and decode them.
    Returns (decoded_hex, all_chunks_decoded_ok)."""
    raw = bytes.fromhex(hex_str)
    chunks = [raw[i:i + CHUNK_BYTES] for i in range(0, len(raw), CHUNK_BYTES)]
    received = bytearray()
    all_ok = True
    for i, chunk in enumerate(chunks):
        bits = encode_text_frame(i, chunk)
        sigma_z = math.sqrt(1.0 + SIGMA_C ** 2 * LAMBDA_BASE)
        tilt = make_payload_tilt(bits, 0.02 * sigma_z)
        good = None
        for _ in range(max_retries):
            Z = viewport.generate_window_block(windows, N_SLOTS, tilt=tilt, webcam_hash=webcam_hash)
            idx, data, ok = decode_text_frame((Z.mean(axis=0) > 0).astype(int))
            if ok and idx == (i & 0xFF):
                good = data
                break
        if good is None:
            all_ok = False
            good = chunk
        received += good
    return bytes(received)[:len(raw)].hex(), all_ok


class RPGhost:
    """Passes a share's nonce through the RP-GHOST channel. The original nonce is
    always what gets submitted, whatever the channel decodes."""

    def __init__(self, use_webcam=True):
        if np is None:
            raise SystemExit("--rp-ghost needs numpy:  pip install numpy")
        self.viewport = OptoelectronicViewport()
        self.webcam = WebcamEntropySource() if use_webcam else None
        if self.webcam:
            self.webcam.start()

    def transcode_nonce(self, nonce):
        clean = nonce.lower().removeprefix("0x")
        if len(clean) % 2 or not 2 <= len(clean) <= 32:
            return nonce
        try:
            int(clean, 16)
        except ValueError:
            return nonce
        wh = self.webcam.latest_hash if self.webcam else 0
        decoded, ok = transmit_bytes_hex(self.viewport, clean, webcam_hash=wh)
        log("OPTO-HASH", f"in={clean} webcam={hex(wh)} out={decoded} channel_ok={ok}")
        if decoded != clean:
            log("OPTO-HASH", "Decoded nonce differs from original; submitting original nonce.")
        return nonce

    def stop(self):
        if self.webcam:
            self.webcam.stop()


# ---------------------------------------------------------------------------
# Proxy session: one miner <-> one upstream pool connection
# ---------------------------------------------------------------------------
class Session:
    def __init__(self, miner_sock, addr, host, port, verbose, suggest_diff, ghost, algo):
        self.miner = miner_sock
        self.addr = addr
        self.host = host
        self.port = port
        self.verbose = verbose
        self.suggest_diff = suggest_diff
        self.ghost = ghost
        self.algo = algo

        self.pool = None
        self.miner_lock = threading.Lock()
        self.pool_lock = threading.Lock()
        self.pending_submits = {}    # request id -> params
        self.pending_requests = {}   # request id -> "mining.subscribe" / "mining.authorize"
        self.suggested = False
        self.closed = threading.Event()

        self.jobs = 0
        self.submits = 0
        self.accepted = 0
        self.rejected = 0
        self.difficulty = None
        self.authorized = None

    # -- lifecycle ---------------------------------------------------------
    def close(self):
        if self.closed.is_set():
            return
        self.closed.set()
        for s in (self.miner, self.pool):
            if s:
                try:
                    s.shutdown(socket.SHUT_RDWR)
                except OSError:
                    pass
                try:
                    s.close()
                except OSError:
                    pass
        log("SESSION", f"{self.addr} closed (submitted={self.submits}, "
                       f"accepted={self.accepted}, rejected={self.rejected})")

    def run(self):
        try:
            log("PROXY", f"Miner {self.addr} connected. Connecting to {self.host}:{self.port}...")
            self.pool = socket.create_connection((self.host, self.port), timeout=20)
            self.pool.settimeout(None)
            self.pool.setsockopt(socket.SOL_SOCKET, socket.SO_KEEPALIVE, 1)
            self.pool.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
            log("PROXY", "Upstream connected.")
        except Exception as e:
            log("PROXY", f"Upstream connection failed: {e}")
            self.close()
            return

        threading.Thread(target=self._pool_to_miner, daemon=True).start()
        threading.Thread(target=self._stats_loop, daemon=True).start()
        self._miner_to_pool()
        self.close()

    def _stats_loop(self):
        while not self.closed.wait(30):
            log("STATS", f"jobs={self.jobs} submitted={self.submits} accepted={self.accepted} "
                         f"rejected={self.rejected} pool_diff={self.difficulty} "
                         f"authorized={self.authorized}")

    # -- miner -> pool -----------------------------------------------------
    def _miner_to_pool(self):
        try:
            for line in read_lines(self.miner):
                try:
                    msg = json.loads(line)
                except json.JSONDecodeError:
                    msg = None

                is_authorize = False
                if isinstance(msg, dict):
                    method = msg.get("method")
                    if method == "mining.submit":
                        params = msg.get("params")
                        self.submits += 1
                        log("SUBMIT", f"{params}")
                        ni = nonce_index(params, self.algo)
                        if self.ghost and ni is not None:
                            params[ni] = self.ghost.transcode_nonce(str(params[ni]))
                            msg["params"] = params
                            line = json.dumps(msg)
                        self.pending_submits[msg.get("id")] = params
                    elif method in ("mining.subscribe", "mining.authorize"):
                        self.pending_requests[msg.get("id")] = method
                        if method == "mining.authorize":
                            is_authorize = True
                            params = msg.get("params") or [""]
                            log("AUTH", f"worker {params[0]}")
                        elif self.verbose:
                            log("MINER->POOL", line)
                    elif self.verbose:
                        log("MINER->POOL", line)
                elif self.verbose:
                    log("MINER->POOL", line)

                send_line(self.pool, self.pool_lock, line)  # forwarded

                # After authorize, optionally ask the pool for an easier share difficulty.
                if is_authorize and self.suggest_diff and not self.suggested:
                    self.suggested = True
                    req = {"id": "proxy-suggest", "method": "mining.suggest_difficulty",
                           "params": [self.suggest_diff]}
                    send_line(self.pool, self.pool_lock, json.dumps(req))
                    log("DIFF", f"Requested pool difficulty {self.suggest_diff}")
        except Exception as e:
            if not self.closed.is_set():
                log("PROXY", f"Miner read error: {e}")

    # -- pool -> miner -----------------------------------------------------
    def _handle_pool_message(self, msg, line):
        """Log what the pool said. Returns False if the message is the proxy's own."""
        if msg.get("id") == "proxy-suggest":
            log("DIFF", f"Pool reply to difficulty request: {line}")
            return False

        method = msg.get("method")
        mid = msg.get("id")

        if method == "mining.notify":
            self.jobs += 1
            p = msg.get("params") or []
            extra = f" clean={p[-1]}" if self.algo == "sha256" and p else ""
            if self.verbose or self.jobs <= 3:
                log("JOB", f"job {p[0] if p else '?'}{extra} (total jobs={self.jobs})")
        elif method == "mining.set_difficulty":
            p = msg.get("params") or [None]
            self.difficulty = p[0]
            log("DIFF", f"pool difficulty {p}")
        elif method == "mining.set_target":
            log("TARGET", f"pool share target {msg.get('params')}")
        elif method == "mining.set_extranonce":
            log("EXTRANONCE", f"{msg.get('params')}")
        elif method is None and mid in self.pending_requests:
            req = self.pending_requests.pop(mid)
            if req == "mining.authorize":
                ok = msg.get("result") is True
                self.authorized = ok
                if ok:
                    log("AUTH-RESULT", "Pool ACCEPTED the login.")
                else:
                    log("AUTH-RESULT", f"Pool REJECTED the login: result={msg.get('result')} "
                                       f"error={msg.get('error')}  <-- check username/address format")
            else:
                log("SUBSCRIBE-RESULT", f"result={msg.get('result')} error={msg.get('error')}")
        elif method is None and mid in self.pending_submits:
            params = self.pending_submits.pop(mid)
            job, nonce = submit_fields(params, self.algo)
            if msg.get("result") is True:
                self.accepted += 1
                log("ACCEPTED", f"job {job} nonce {nonce} (accepted={self.accepted})")
            else:
                self.rejected += 1
                log("REJECTED", f"job {job} nonce {nonce} error={msg.get('error')} "
                                f"(rejected={self.rejected})")
        elif self.verbose:
            log("POOL->MINER", line)
        return True

    def _pool_to_miner(self):
        try:
            for line in read_lines(self.pool):
                try:
                    msg = json.loads(line)
                except json.JSONDecodeError:
                    msg = None

                if isinstance(msg, dict):
                    try:
                        if not self._handle_pool_message(msg, line):
                            continue
                    except Exception as e:   # logging must never break the relay
                        log("PROXY", f"Log handler error (ignored): {e}")
                elif self.verbose:
                    log("POOL->MINER", line)

                send_line(self.miner, self.miner_lock, line)  # forwarded unchanged
        except Exception as e:
            if not self.closed.is_set():
                log("PROXY", f"Upstream read error: {e}")
        finally:
            if not self.closed.is_set():
                log("PROXY", "Upstream closed. Disconnecting miner so it re-handshakes.")
            self.close()


# ---------------------------------------------------------------------------
def main():
    parser = argparse.ArgumentParser(description="Transparent Stratum proxy for Kaspa (default) or Bitcoin SHA-256")
    parser.add_argument("-p", "--pool", required=True,
                        help="Upstream pool, e.g. stratum+tcp://<host>:<port> (plain TCP port, not TLS)")
    parser.add_argument("-l", "--local-port", type=int, default=3333,
                        help="Local listening port (default: 3333)")
    parser.add_argument("--algo", choices=["kaspa", "sha256", "digibyte", "kawpow"], default="kaspa",
                        help="Share format: kaspa (3-param submit, default); sha256 or digibyte "
                             "(Bitcoin-style 5-param submit; DigiByte = its SHA-256d algorithm); "
                             "kawpow for Ravencoin (nonce is submit param 3)")
    parser.add_argument("-d", "--suggest-diff", type=float, default=None,
                        help="Ask the pool for this share difficulty (the pool may ignore it)")
    parser.add_argument("--rp-ghost", action="store_true",
                        help="Pass each share nonce through the RP-GHOST optoelectronic channel")
    parser.add_argument("--no-webcam", action="store_true",
                        help="With --rp-ghost: skip webcam entropy (use 0)")
    parser.add_argument("-v", "--verbose", action="store_true",
                        help="Log every raw message in both directions")
    args = parser.parse_args()

    host, port = parse_pool(args.pool)
    coin = args.algo
    if args.algo == "digibyte":
        args.algo = "sha256"   # DGB SHA-256d uses standard Bitcoin Stratum V1 messages
    ghost = RPGhost(use_webcam=not args.no_webcam) if args.rp_ghost else None
    if ghost:
        log("PROXY", "RP-GHOST transcoding enabled.")

    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    server.bind(("0.0.0.0", args.local_port))
    server.listen(16)
    log("PROXY", f"[{coin}] Listening on port {args.local_port}, relaying to {host}:{port}")

    try:
        while True:
            miner_sock, addr = server.accept()
            miner_sock.setsockopt(socket.SOL_SOCKET, socket.SO_KEEPALIVE, 1)
            miner_sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
            session = Session(miner_sock, addr, host, port, args.verbose,
                              args.suggest_diff, ghost, args.algo)
            threading.Thread(target=session.run, daemon=True).start()
    except KeyboardInterrupt:
        log("PROXY", "Shutting down.")
    finally:
        server.close()
        if ghost:
            ghost.stop()


if __name__ == "__main__":
    main()
