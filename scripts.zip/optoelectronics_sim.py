"""
Time-stepped simulation of the optoelectronic circuit in optoelectronics_v2.png

Blocks (top to bottom in the diagram):
  Optical bench      : IR laser -> Reflector (delta intensity) -> IR detector A / B
  Parallel drivers   : Driver A (randomized) -> a
                       Driver B (deterministic) -> RC node (tau 50 ms) -> NPN -> b
  Main circuit       : AND(a,b) -> 150 ms delay -> and_dly
                       and_dly -> Accumulator (running AND)
                       OR(a,b) = Y (time code, forces HIGH) -> OR with and_dly (leak path) -> D
                       74HC74 D flip-flop clocked at 10 Hz -> SELECT (Q), observe (not Q)
                       The main circuit runs 2x longer than the probe.
  Independent probe  : AND(a,b) -> flip noise (p = probe_err) -> probe log (truth + measured)
"""

import random
from collections import deque
from dataclasses import dataclass, field

DT_MS = 1                 # simulation step (ms)
CLOCK_PERIOD_MS = 100     # 10 Hz clock, T = 100 ms
DELAY_MS = 150            # delay block
RC_TAU_MS = 50            # RC node time constant
RAIL_V = 5.0              # NPN +5 V rail
NPN_THRESHOLD_V = 0.7     # IF V(C) > 0.7 V THEN output HIGH


# ----------------------------------------------------------------- optical bench
class IRLaser:
    def __init__(self, power=1.0):
        self.power = power

    def emit(self):
        return self.power


class Reflector:
    """Produces a change in intensity (delta) split across the two ROIs."""

    def __init__(self, delta=0.3, rng=None):
        self.delta = delta
        self.rng = rng or random.Random()

    def reflect(self, power):
        # right ROI (A) and left ROI (B) each get a slightly different intensity
        right = power * (1 + self.rng.uniform(-self.delta, self.delta))
        left = power * (1 + self.rng.uniform(-self.delta, self.delta))
        return right, left


class IRDetector:
    def __init__(self, name, threshold=1.0):
        self.name = name
        self.threshold = threshold

    def read(self, intensity):
        return int(intensity > self.threshold)


# ----------------------------------------------------------------------- drivers
class DriverA:
    """Randomized driver: output depends on x and a random coin."""

    def __init__(self, rng):
        self.rng = rng

    def drive(self, x, detector_bit):
        coin = self.rng.getrandbits(1)
        return int((x ^ coin) | detector_bit) if detector_bit else coin


class DriverB:
    """Deterministic driver: output is a pure function of x and detector B."""

    def drive(self, x, detector_bit):
        return int(x and detector_bit) or int(x)


class RCNode:
    """First-order RC: V(C) moves toward the drive level with time constant tau."""

    def __init__(self, tau_ms=RC_TAU_MS, rail=RAIL_V):
        self.tau = tau_ms
        self.rail = rail
        self.v = 0.0

    def step(self, drive_bit, dt_ms=DT_MS):
        target = self.rail if drive_bit else 0.0
        self.v += (target - self.v) * (dt_ms / self.tau)
        return self.v


class NPN:
    """IF V(C) > 0.7 V THEN output HIGH."""

    def __init__(self, threshold=NPN_THRESHOLD_V):
        self.threshold = threshold

    def out(self, v):
        return int(v > self.threshold)


# ------------------------------------------------------------------ main circuit
class DelayLine:
    def __init__(self, delay_ms=DELAY_MS, dt_ms=DT_MS):
        self.buf = deque([0] * int(delay_ms / dt_ms), maxlen=int(delay_ms / dt_ms))

    def step(self, bit):
        out = self.buf[0]
        self.buf.append(bit)
        return out


class Accumulator:
    """Running AND of every sample seen so far."""

    def __init__(self):
        self.value = 1

    def update(self, bit):
        self.value &= bit
        return self.value


class DFlipFlop74HC74:
    """Rising-edge D flip-flop. Q -> SELECT, not Q -> observe."""

    def __init__(self):
        self.q = 0
        self._prev_clk = 0

    def step(self, d, clk):
        if clk and not self._prev_clk:
            self.q = d
        self._prev_clk = clk
        return self.q, 1 - self.q


class Clock:
    def __init__(self, period_ms=CLOCK_PERIOD_MS):
        self.period = period_ms

    def level(self, t_ms):
        return int((t_ms % self.period) < self.period / 2)


# ------------------------------------------------------------- independent probe
@dataclass
class Probe:
    probe_err: float
    rng: random.Random
    log: list = field(default_factory=list)

    def sample(self, t_ms, a, b):
        truth = a & b
        measured = truth ^ int(self.rng.random() < self.probe_err)  # flip noise
        self.log.append({"t_ms": t_ms, "truth": truth, "measured": measured})
        return measured


# --------------------------------------------------------------------- top level
def run(x=1, duration_ms=1000, probe_err=0.05, seed=None):
    rng = random.Random(seed)

    laser, reflector = IRLaser(), Reflector(rng=rng)
    det_a, det_b = IRDetector("A"), IRDetector("B")
    drv_a, drv_b = DriverA(rng), DriverB()
    rc, npn = RCNode(), NPN()
    delay, acc, ff, clock = DelayLine(), Accumulator(), DFlipFlop74HC74(), Clock()
    probe = Probe(probe_err, rng)

    main_duration = 2 * duration_ms          # main circuit runs 2x longer
    trace = []

    for t in range(0, main_duration, DT_MS):
        # optical bench -> detectors
        right, left = reflector.reflect(laser.emit())
        bit_a, bit_b = det_a.read(right), det_b.read(left)

        # parallel drivers
        a = drv_a.drive(x, bit_a)
        v_c = rc.step(drv_b.drive(x, bit_b))
        b = npn.out(v_c)

        # main circuit
        and_dly = delay.step(a & b)
        y = a | b                              # time code, forces HIGH
        d = and_dly | y                        # leak path OR
        clk = clock.level(t)
        select, observe = ff.step(d, clk)
        acc_val = acc.update(and_dly) if t >= DELAY_MS else 1

        # independent probe stops at duration
        if t < duration_ms and t % CLOCK_PERIOD_MS == 0:
            probe.sample(t, a, b)

        trace.append(dict(t=t, a=a, b=b, v_c=v_c, and_dly=and_dly, y=y, d=d,
                          select=select, observe=observe, acc=acc_val))

    return trace, probe.log


if __name__ == "__main__":
    trace, probe_log = run(x=1, duration_ms=1000, probe_err=0.05, seed=42)

    print("t(ms)  a b  V(C)  and_dly Y D  SELECT observe ACC")
    for row in trace[::100]:
        print(f"{row['t']:5d}  {row['a']} {row['b']}  {row['v_c']:.2f}  "
              f"{row['and_dly']:5d}   {row['y']} {row['d']}  "
              f"{row['select']:5d}   {row['observe']:5d}   {row['acc']}")

    errors = sum(r["truth"] != r["measured"] for r in probe_log)
    print(f"\nProbe samples: {len(probe_log)}, flipped by noise: {errors}")
    print(f"Main circuit ran {trace[-1]['t'] + DT_MS} ms (2x probe duration)")
