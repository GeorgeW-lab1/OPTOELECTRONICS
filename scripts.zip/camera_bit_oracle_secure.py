"""
SHA-256 Camera Bit Oracle Lab  (secure edition)

Security design
---------------
* Entropy sources are MIXED, never trusted individually:
    - fresh camera frames (sensor noise = non-deterministic physical source)
    - frame-to-frame noise (XOR/LSB of consecutive frame differences)
    - OS CSPRNG (secrets / os.urandom)
    - high-resolution timestamps
  The result is secure as long as ANY ONE source is unpredictable, so a covered
  lens or a frozen camera can never weaken the output.
* Conditioning uses HKDF-SHA256 (RFC 5869): extract with a random salt, expand
  with domain-separated labels.  No raw frame bytes are used directly.
* Per-cell oracle bits are HMAC-SHA256 under a secret per-session key, so the
  bits are unpredictable even to someone who sees the same scene.
* Challenge is non-deterministic: the same frames give a different challenge
  every time.
* PoW uses a 64-bit nonce starting at a CSPRNG-chosen offset (no Mersenne
  Twister), and every hit is re-verified independently in the parent process.
* Camera health tests report if the sensor looks frozen / covered / duplicated.

Note: camera noise is NOT a certified entropy source.  That is why it is mixed
with the OS CSPRNG instead of being relied on alone.
"""

import hashlib
import hmac
import json
import multiprocessing as mp
import os
import queue
import secrets
import sys
import threading
import time

try:
    import tkinter as tk
    from tkinter import ttk, messagebox
except ImportError:  # headless: selftest still works
    tk = ttk = messagebox = None

import cv2
import numpy as np


# ============================================================
# CONFIGURATION
# ============================================================

WIDTH = 640
HEIGHT = 480

MASK32 = 0xFFFFFFFF
NONCE_BYTES = 8
NONCE_SPACE = 1 << (8 * NONCE_BYTES)

MAX_DIFFICULTY = 40
ENTROPY_FRAMES = 8
ENTROPY_TIMEOUT = 4.0
MIN_NOISE_ABS_DIFF = 0.05

DOMAIN = b"CAMERA_BIT_ORACLE_V2"

GRID_OPTIONS = {
    "2x2": 2,
    "3x3": 3,
    "4x4": 4,
    "8x8": 8,
}


# ============================================================
# KEY DERIVATION (HKDF-SHA256, RFC 5869)
# ============================================================

def hkdf_extract(salt, ikm):
    return hmac.new(salt, ikm, hashlib.sha256).digest()


def hkdf_expand(prk, info, length=32):
    out = b""
    block = b""
    counter = 1

    while len(out) < length:
        block = hmac.new(
            prk,
            block + info + bytes([counter]),
            hashlib.sha256
        ).digest()
        out += block
        counter += 1

    return out[:length]


# ============================================================
# CAMERA ENGINE
# ============================================================

class CameraEngine:

    def __init__(self, device=0):

        self.device = device
        self.frame = None
        self.frame_id = 0

        self.lock = threading.Lock()
        self.stop_event = threading.Event()

        self.thread = None
        self.running = False
        self.error = None
        self.fps = 0.0

    def start(self):

        if self.thread and self.thread.is_alive():
            return

        self.stop_event.clear()
        self.error = None

        self.thread = threading.Thread(
            target=self.capture_loop,
            daemon=True
        )

        self.thread.start()

    def capture_loop(self):

        cap = cv2.VideoCapture(self.device)

        cap.set(cv2.CAP_PROP_FRAME_WIDTH, WIDTH)
        cap.set(cv2.CAP_PROP_FRAME_HEIGHT, HEIGHT)

        if not cap.isOpened():
            self.error = "Unable to open camera."
            cap.release()
            return

        self.running = True

        count = 0
        start = time.perf_counter()

        try:

            while not self.stop_event.is_set():

                ok, frame = cap.read()

                if not ok:
                    time.sleep(0.02)
                    continue

                frame = cv2.resize(
                    frame,
                    (WIDTH, HEIGHT),
                    interpolation=cv2.INTER_AREA
                )

                with self.lock:
                    self.frame = frame
                    self.frame_id += 1

                count += 1

                elapsed = time.perf_counter() - start

                if elapsed >= 1.0:
                    self.fps = count / elapsed
                    count = 0
                    start = time.perf_counter()

        finally:
            cap.release()
            self.running = False

    def snapshot(self):

        with self.lock:

            if self.frame is None:
                return None

            return self.frame.copy()

    def wait_frames(self, n, timeout):
        """Collect n FRESH frames captured after this call (distinct ids)."""

        with self.lock:
            last_id = self.frame_id

        frames = []
        deadline = time.monotonic() + timeout

        while len(frames) < n and time.monotonic() < deadline:

            with self.lock:
                fid = self.frame_id
                frame = (
                    None if self.frame is None
                    else self.frame.copy()
                )

            if frame is not None and fid != last_id:
                frames.append(frame)
                last_id = fid
            else:
                time.sleep(0.004)

        return frames

    def stop(self):

        self.stop_event.set()

        if self.thread and self.thread.is_alive():
            self.thread.join(timeout=2)

        self.running = False


# ============================================================
# ENTROPY HARVEST + HEALTH TESTS
# ============================================================

def cell_boxes(width, height, grid_size):

    index = 0

    for row in range(grid_size):
        for col in range(grid_size):

            x1 = col * width // grid_size
            x2 = (col + 1) * width // grid_size
            y1 = row * height // grid_size
            y2 = (row + 1) * height // grid_size

            yield index, x1, y1, x2, y2

            index += 1


def harvest_camera_entropy(frames):
    """
    Condense several fresh frames into 64 bytes of material and a health
    report.  Uses full-frame digests plus the LSB plane of consecutive frame
    differences (where sensor noise lives).
    """

    h = hashlib.sha512()
    h.update(DOMAIN + b"/camera")

    frame_digests = set()
    abs_diffs = []
    entropies = []

    for i, frame in enumerate(frames):

        raw = np.ascontiguousarray(frame)

        fd = hashlib.sha256(raw.tobytes()).digest()
        frame_digests.add(fd)
        h.update(fd)

        if i > 0:

            diff = frame.astype(np.int16) - frames[i - 1].astype(np.int16)

            h.update(
                np.packbits(
                    (diff & 1).astype(np.uint8)
                ).tobytes()
            )

            abs_diffs.append(float(np.abs(diff).mean()))

            _, counts = np.unique(diff, return_counts=True)
            p = counts / counts.sum()
            entropies.append(float(-(p * np.log2(p)).sum()))

    mean_abs = float(np.mean(abs_diffs)) if abs_diffs else 0.0
    mean_ent = float(np.mean(entropies)) if entropies else 0.0

    healthy = (
        len(frame_digests) >= 2
        and len(frames) >= 2
        and mean_abs >= MIN_NOISE_ABS_DIFF
    )

    report = {
        "frames": len(frames),
        "distinct_frames": len(frame_digests),
        "mean_abs_frame_diff": round(mean_abs, 4),
        "noise_shannon_bits_per_sample": round(mean_ent, 3),
        "camera_noise_healthy": healthy,
        "sources": [
            "camera_frames",
            "camera_frame_noise",
            "os_csprng",
            "timestamps",
        ],
    }

    return h.digest(), report


# ============================================================
# BIT ORACLES
# ============================================================

def preview_grid(frame, grid_size):
    """Deterministic, VISUAL ONLY. Never used for security."""

    height, width = frame.shape[:2]
    results = []

    for index, x1, y1, x2, y2 in cell_boxes(width, height, grid_size):

        raw = np.ascontiguousarray(frame[y1:y2, x1:x2]).tobytes()
        digest = hashlib.sha256(raw).digest()

        results.append({
            "index": index,
            "bit": digest[-1] & 1,
            "hash": digest.hex(),
        })

    return results


def build_secure_challenge(frames, grid_size):
    """
    Non-deterministic secure challenge from fresh frames + OS entropy.
    """

    if len(frames) < 2:
        raise RuntimeError(
            "Need at least 2 fresh camera frames for the oracle."
        )

    camera_material, report = harvest_camera_entropy(frames)

    ikm = b"".join([
        camera_material,
        secrets.token_bytes(32),
        time.time_ns().to_bytes(8, "little"),
        time.perf_counter_ns().to_bytes(8, "little"),
        os.getpid().to_bytes(4, "little"),
    ])

    salt = secrets.token_bytes(32)
    prk = hkdf_extract(salt, ikm)

    cell_key = hkdf_expand(prk, DOMAIN + b"/cell-key")

    frame = frames[-1]
    height, width = frame.shape[:2]

    bits = []
    cell_digests = []

    for index, x1, y1, x2, y2 in cell_boxes(width, height, grid_size):

        msg = (
            index.to_bytes(4, "little")
            + x1.to_bytes(2, "little") + y1.to_bytes(2, "little")
            + x2.to_bytes(2, "little") + y2.to_bytes(2, "little")
            + np.ascontiguousarray(frame[y1:y2, x1:x2]).tobytes()
        )

        d = hmac.digest(cell_key, msg, "sha256")

        cell_digests.append(d)
        bits.append(str(d[0] & 1))

    bit_string = "".join(bits)
    grid_digest = hashlib.sha256(b"".join(cell_digests)).digest()

    challenge = hmac.new(
        prk,
        DOMAIN + b"/challenge"
        + grid_size.to_bytes(2, "little")
        + bit_string.encode()
        + grid_digest,
        hashlib.sha256
    ).digest()

    return {
        "bits": bit_string,
        "challenge": challenge,
        "grid_hash": grid_digest.hex(),
        "frame_hash": hashlib.sha256(
            np.ascontiguousarray(frame).tobytes()
        ).hexdigest(),
        "cells": len(bits),
        "report": report,
    }


# ============================================================
# PROOF OF WORK
# ============================================================

def check_pow(challenge, nonce, difficulty):
    """Independent verifier. Returns (ok, digest_bytes)."""

    if not (0 <= nonce < NONCE_SPACE):
        return False, b""

    digest = hashlib.sha256(
        challenge + nonce.to_bytes(NONCE_BYTES, "little")
    ).digest()

    zero_bits = 256 - int.from_bytes(digest, "big").bit_length()

    return zero_bits >= difficulty, digest


def pow_worker(
    worker_id,
    worker_count,
    challenge,
    difficulty,
    start_nonce,
    stop_event,
    result_queue,
    counts,
    bests
):

    base = hashlib.sha256(challenge)

    target = 1 << (256 - difficulty)

    attempts_limit = (
        (NONCE_SPACE - 1 - worker_id) // worker_count
    ) + 1

    count = 0
    best = 0

    for k in range(attempts_limit):

        if k % 4096 == 0 and stop_event.is_set():
            return

        nonce = (
            start_nonce + worker_id + k * worker_count
        ) % NONCE_SPACE

        h = base.copy()
        h.update(nonce.to_bytes(NONCE_BYTES, "little"))

        digest = h.digest()
        value = int.from_bytes(digest, "big")

        best = max(best, 256 - value.bit_length())
        count += 1

        if value < target:

            counts[worker_id] = count
            bests[worker_id] = best

            result_queue.put(("HIT", nonce, digest.hex()))
            return

        if count % 4096 == 0:
            counts[worker_id] = count
            bests[worker_id] = best

    counts[worker_id] = count
    bests[worker_id] = best

    result_queue.put(("DONE", worker_id))


class PoWEngine:

    def __init__(self):

        self.processes = []

        self.running = False
        self.converged = False
        self.solution = None

        self.stop_event = None
        self.result_queue = None

        self.counts = None
        self.bests = None

        self.workers = 1

        self.scanned = 0
        self.best_bits = 0
        self.hashrate = 0
        self.elapsed = 0

        self.start_time = None
        self.status = "READY"

        self.challenge = None
        self.difficulty = 0
        self.start_nonce = 0
        self.report = None

        self.done_workers = set()

    def start(self, challenge, difficulty, workers, report=None):

        self.stop()

        if not 1 <= difficulty <= MAX_DIFFICULTY:
            raise ValueError(
                f"Difficulty must be 1-{MAX_DIFFICULTY}."
            )

        workers = max(1, workers)

        self.solution = None
        self.converged = False

        self.scanned = 0
        self.best_bits = 0
        self.hashrate = 0
        self.elapsed = 0

        self.challenge = challenge
        self.difficulty = difficulty
        self.workers = workers
        self.report = report

        # CSPRNG-chosen start offset (64-bit)
        self.start_nonce = secrets.randbelow(NONCE_SPACE)

        self.done_workers = set()

        ctx = mp.get_context("spawn")

        self.stop_event = ctx.Event()
        self.result_queue = ctx.Queue()

        self.counts = ctx.RawArray("Q", workers)
        self.bests = ctx.RawArray("i", workers)

        self.processes = []

        for i in range(workers):

            process = ctx.Process(
                target=pow_worker,
                daemon=True,
                args=(
                    i,
                    workers,
                    challenge,
                    difficulty,
                    self.start_nonce,
                    self.stop_event,
                    self.result_queue,
                    self.counts,
                    self.bests
                )
            )

            process.start()
            self.processes.append(process)

        self.start_time = time.perf_counter()

        self.running = True
        self.status = "SCANNING"

    def poll(self):

        if not self.running:
            return

        self.scanned = sum(self.counts)
        self.best_bits = max([0] + list(self.bests))

        self.elapsed = time.perf_counter() - self.start_time

        if self.elapsed > 0:
            self.hashrate = self.scanned / self.elapsed

        try:

            while True:

                message = self.result_queue.get_nowait()

                if message[0] == "HIT":

                    if self.solution is None:

                        _, nonce, digest = message

                        ok, real = check_pow(
                            self.challenge,
                            nonce,
                            self.difficulty
                        )

                        if not ok or real.hex() != digest:
                            continue

                        zero_bits = (
                            256 - int.from_bytes(real, "big").bit_length()
                        )

                        self.solution = {
                            "nonce": nonce,
                            "nonce_hex": hex(nonce),
                            "hash": digest,
                            "zero_bits": zero_bits,
                            "difficulty": self.difficulty,
                            "challenge": self.challenge.hex(),
                            "output": hashlib.sha256(
                                DOMAIN + b"/output" + real
                            ).hexdigest(),
                            "entropy_report": self.report,
                        }

                        self.converged = True
                        self.status = "LOCKED & REVEALED"

                        self.stop()
                        return

                elif message[0] == "DONE":
                    self.done_workers.add(message[1])

        except queue.Empty:
            pass

        if len(self.done_workers) >= self.workers:

            self.converged = True
            self.status = "NONCE SPACE EXHAUSTED"

            self.stop()

    def stop(self):

        if self.stop_event is not None:
            self.stop_event.set()

        for process in self.processes:

            if process.is_alive():

                process.join(timeout=0.5)

                if process.is_alive():
                    process.terminate()
                    process.join(timeout=0.5)

        self.processes = []
        self.running = False

        if self.status == "SCANNING":
            self.status = "STOPPED"

    def registers(self):

        nonce = (
            self.solution["nonce"] & MASK32
            if self.solution is not None
            else None
        )

        return {
            "NONCE": nonce,
            "CURSOR": self.scanned & MASK32,
            "HASH32": self.best_bits & MASK32,
            "POOLED": (self.scanned ^ self.best_bits) & MASK32,
        }


# ============================================================
# TKINTER APPLICATION
# ============================================================

class CameraBitOracleApp:

    def __init__(self, root):

        self.root = root

        root.title("SHA-256 Camera Bit Oracle Lab (secure)")

        root.geometry("1150x900")
        root.minsize(800, 600)
        root.configure(bg="#10151c")

        self.camera = CameraEngine(0)
        self.engine = PoWEngine()

        self.grid_size = 4

        self.current_challenge = None
        self.gathering = False
        self.gather_queue = queue.Queue()

        self.photo = None
        self.running = True

        self.last_result_key = None

        self._build_ui()

        self.root.protocol("WM_DELETE_WINDOW", self.close)

        self.camera.start()

        self.root.after(80, self.refresh)

    # ========================================================
    # UI
    # ========================================================

    def _build_ui(self):

        style = ttk.Style()
        style.theme_use("clam")

        style.configure("TFrame", background="#10151c")
        style.configure("TLabel", background="#10151c", foreground="#dce7f5")
        style.configure("TLabelframe", background="#10151c", foreground="#00d9ff")
        style.configure("TLabelframe.Label", background="#10151c", foreground="#00d9ff")

        outer = ttk.Frame(self.root)
        outer.pack(fill="both", expand=True)

        self.scroll_canvas = tk.Canvas(
            outer, bg="#10151c", highlightthickness=0
        )

        scrollbar = ttk.Scrollbar(
            outer,
            orient="vertical",
            command=self.scroll_canvas.yview
        )

        self.scroll_canvas.configure(yscrollcommand=scrollbar.set)

        scrollbar.pack(side="right", fill="y")
        self.scroll_canvas.pack(side="left", fill="both", expand=True)

        main = ttk.Frame(self.scroll_canvas, padding=8)

        self.main_window = self.scroll_canvas.create_window(
            (0, 0), window=main, anchor="nw"
        )

        main.bind(
            "<Configure>",
            lambda e: self.scroll_canvas.configure(
                scrollregion=self.scroll_canvas.bbox("all")
            )
        )

        self.scroll_canvas.bind(
            "<Configure>",
            lambda e: self.scroll_canvas.itemconfigure(
                self.main_window, width=e.width
            )
        )

        self.scroll_canvas.bind_all("<MouseWheel>", self.mousewheel)
        self.scroll_canvas.bind_all(
            "<Button-4>",
            lambda e: self.scroll_canvas.yview_scroll(-3, "units")
        )
        self.scroll_canvas.bind_all(
            "<Button-5>",
            lambda e: self.scroll_canvas.yview_scroll(3, "units")
        )

        # CAMERA CONTROLS

        controls = ttk.LabelFrame(main, text="CAMERA CONTROLS", padding=8)
        controls.pack(fill="x", pady=5)

        ttk.Label(controls, text="Grid size:").pack(side="left", padx=5)

        self.grid_combo = ttk.Combobox(
            controls,
            values=list(GRID_OPTIONS.keys()),
            state="readonly",
            width=8
        )

        self.grid_combo.set("4x4")
        self.grid_combo.pack(side="left", padx=5)
        self.grid_combo.bind("<<ComboboxSelected>>", self.change_grid)

        ttk.Button(
            controls, text="Start Camera", command=self.camera.start
        ).pack(side="left", padx=5)

        ttk.Button(
            controls, text="Stop Camera", command=self.camera.stop
        ).pack(side="left", padx=5)

        self.camera_label = ttk.Label(controls, text="CAMERA STARTING")
        self.camera_label.pack(side="right", padx=10)

        # CAMERA VIEW

        camera_box = ttk.LabelFrame(
            main,
            text="LIVE PREVIEW (visual only: secure bits are generated at SOLVE)",
            padding=5
        )

        camera_box.pack(fill="both", expand=True, pady=5)

        self.canvas = tk.Canvas(
            camera_box,
            width=640,
            height=480,
            bg="#05080c",
            highlightthickness=0
        )

        self.canvas.pack(padx=5, pady=5)

        # POW CONTROLS

        oracle_box = ttk.LabelFrame(
            main, text="PARALLEL PROOF OF WORK", padding=8
        )

        oracle_box.pack(fill="x", pady=5)

        ttk.Label(oracle_box, text="Difficulty:").pack(side="left", padx=4)

        self.diff = ttk.Spinbox(
            oracle_box, from_=1, to=MAX_DIFFICULTY, width=5
        )

        self.diff.set(20)
        self.diff.pack(side="left", padx=5)

        ttk.Label(oracle_box, text="Workers:").pack(side="left", padx=4)

        self.worker_count = ttk.Spinbox(
            oracle_box, from_=1, to=os.cpu_count() or 2, width=5
        )

        self.worker_count.set(max(1, (os.cpu_count() or 2) - 1))
        self.worker_count.pack(side="left", padx=5)

        ttk.Button(oracle_box, text="SOLVE", command=self.solve).pack(side="left", padx=6)
        ttk.Button(oracle_box, text="STOP", command=self.stop).pack(side="left", padx=5)
        ttk.Button(oracle_box, text="RESET", command=self.reset).pack(side="left", padx=5)

        # STATUS

        self.status_label = ttk.Label(
            main, text="READY", font=("Consolas", 10)
        )

        self.status_label.pack(fill="x", pady=5)

        # BINARY REGISTER

        binary_box = ttk.LabelFrame(
            main, text="SECURE CAMERA ORACLE BITS (locked challenge)", padding=8
        )

        binary_box.pack(fill="x", pady=5)

        self.binary_label = ttk.Label(
            binary_box,
            text="Press SOLVE to harvest fresh entropy...",
            font=("Consolas", 12),
            wraplength=1000
        )

        self.binary_label.pack(fill="x")

        # REGISTERS

        register_box = ttk.LabelFrame(
            main, text="32-BIT HARDWARE REGISTERS (NONCE = low 32 of 64 bits)", padding=5
        )

        register_box.pack(fill="x", pady=5)

        self.reg_canvas = tk.Canvas(
            register_box, height=125, bg="#080d13", highlightthickness=0
        )

        self.reg_canvas.pack(fill="x")

        # RESULT

        result_box = ttk.LabelFrame(main, text="SOLVED ORACLE", padding=5)
        result_box.pack(fill="both", pady=5)

        self.result_text = tk.Text(
            result_box,
            height=12,
            bg="#080d13",
            fg="#00e5ff",
            font=("Consolas", 9)
        )

        self.result_text.pack(fill="both", expand=True)

        self.draw_registers()

    def mousewheel(self, event):

        if event.delta:
            self.scroll_canvas.yview_scroll(
                int(-event.delta / 120), "units"
            )

    def change_grid(self, event=None):

        self.grid_size = GRID_OPTIONS[self.grid_combo.get()]
        self.current_challenge = None

    # ========================================================
    # CAMERA DISPLAY (preview only)
    # ========================================================

    def update_camera_grid(self):

        frame = self.camera.snapshot()

        if frame is None:
            return

        results = preview_grid(frame, self.grid_size)

        display = frame.copy()
        height, width = display.shape[:2]

        for index, x1, y1, x2, y2 in cell_boxes(width, height, self.grid_size):

            bit = results[index]["bit"]

            cv2.rectangle(display, (x1, y1), (x2, y2), (0, 220, 255), 1)

            cv2.circle(
                display,
                (x1 + 20, y1 + 20),
                13,
                (0, 220, 0) if bit else (0, 100, 255),
                -1
            )

            cv2.putText(
                display, str(bit), (x1 + 16, y1 + 25),
                cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1
            )

            cv2.putText(
                display, f"BIT {index}", (x1 + 38, y1 + 25),
                cv2.FONT_HERSHEY_SIMPLEX, 0.42, (255, 255, 255), 1
            )

            cv2.putText(
                display, results[index]["hash"][:8], (x1 + 7, y2 - 9),
                cv2.FONT_HERSHEY_SIMPLEX, 0.35, (0, 255, 255), 1
            )

        rgb = cv2.cvtColor(display, cv2.COLOR_BGR2RGB)

        ppm = (
            f"P6 {WIDTH} {HEIGHT} 255\n".encode()
            + np.ascontiguousarray(rgb).tobytes()
        )

        self.photo = tk.PhotoImage(data=ppm, format="PPM")

        self.canvas.delete("all")
        self.canvas.create_image(0, 0, image=self.photo, anchor="nw")

    # ========================================================
    # SOLVER
    # ========================================================

    def solve(self):

        if self.engine.running or self.gathering:
            return

        if not self.camera.running:

            messagebox.showerror(
                "Camera",
                "The camera oracle needs a running camera."
            )

            return

        try:

            difficulty = int(self.diff.get())
            workers = int(self.worker_count.get())

            if not 1 <= difficulty <= MAX_DIFFICULTY:
                raise ValueError(
                    f"Difficulty must be between 1 and {MAX_DIFFICULTY}."
                )

            if workers < 1:
                raise ValueError("Workers must be at least 1.")

            if difficulty > 25:

                if not messagebox.askyesno(
                    "Heavy computation",
                    f"Expected work: approximately "
                    f"{2**difficulty:,} hashes.\n\nContinue?"
                ):
                    return

        except Exception as e:

            messagebox.showerror("Solver Error", str(e))
            return

        self.gathering = True
        self.last_result_key = None
        self.result_text.delete("1.0", "end")

        threading.Thread(
            target=self._gather,
            args=(difficulty, workers, self.grid_size),
            daemon=True
        ).start()

    def _gather(self, difficulty, workers, grid_size):
        """Background: capture fresh frames and build the secure challenge."""

        try:

            frames = self.camera.wait_frames(
                ENTROPY_FRAMES, ENTROPY_TIMEOUT
            )

            challenge = build_secure_challenge(frames, grid_size)

            self.gather_queue.put(
                ("OK", challenge, difficulty, workers)
            )

        except Exception as e:
            self.gather_queue.put(("ERR", str(e)))

    def _check_gather(self):

        try:
            message = self.gather_queue.get_nowait()
        except queue.Empty:
            return

        self.gathering = False

        if message[0] == "ERR":
            messagebox.showerror("Entropy", message[1])
            return

        _, challenge, difficulty, workers = message

        self.current_challenge = challenge

        report = challenge["report"]

        note = (
            "CAMERA NOISE OK"
            if report["camera_noise_healthy"]
            else "LOW CAMERA NOISE (OS CSPRNG still mixed in)"
        )

        self.binary_label.configure(
            text=(
                f"{challenge['bits']}\n"
                f"CELLS: {challenge['cells']} | "
                f"GRID HASH: {challenge['grid_hash'][:32]}\n"
                f"{note} | frame diff: "
                f"{report['mean_abs_frame_diff']}"
            )
        )

        try:
            self.engine.start(
                challenge["challenge"], difficulty, workers, report
            )
        except Exception as e:
            messagebox.showerror("Solver Error", str(e))

    def stop(self):
        self.engine.stop()

    def reset(self):

        self.engine.stop()

        self.engine.solution = None
        self.engine.scanned = 0
        self.engine.best_bits = 0
        self.engine.elapsed = 0
        self.engine.hashrate = 0
        self.engine.converged = False
        self.engine.status = "READY"

        self.last_result_key = None
        self.result_text.delete("1.0", "end")

        self.draw_registers()

    # ========================================================
    # REGISTERS
    # ========================================================

    def draw_registers(self):

        canvas = self.reg_canvas
        canvas.delete("all")

        registers = self.engine.registers()

        rows = [
            ("NONCE", registers["NONCE"], "#00e676"),
            ("CURSOR", registers["CURSOR"], "#ffb300"),
            ("HASH32", registers["HASH32"], "#40c4ff"),
            ("POOLED", registers["POOLED"], "#b388ff"),
        ]

        for row, (name, value, color) in enumerate(rows):

            y = 7 + row * 29

            canvas.create_text(
                8, y + 8, text=name, fill="#a0b8d0",
                anchor="w", font=("Consolas", 9, "bold")
            )

            hidden = name == "NONCE" and value is None
            val = value or 0
            x = 85

            for bit in range(31, -1, -1):

                bit_value = (val >> bit) & 1

                canvas.create_rectangle(
                    x, y, x + 14, y + 17,
                    fill=(color if bit_value and not hidden else "#1e2834"),
                    outline="#34475a"
                )

                canvas.create_text(
                    x + 7, y + 8,
                    text="?" if hidden else str(bit_value),
                    fill="#ffffff",
                    font=("Consolas", 7)
                )

                x += 15

            canvas.create_text(
                x + 5, y + 8,
                text="[HIDDEN]" if hidden else f"[{value}]",
                fill="#dce7f5",
                anchor="w",
                font=("Consolas", 8)
            )

    # ========================================================
    # REFRESH LOOP
    # ========================================================

    def refresh(self):

        if not self.running:
            return

        if self.camera.running:

            self.update_camera_grid()

            self.camera_label.configure(
                text=f"CAMERA FPS: {self.camera.fps:.1f}"
            )

        else:

            self.camera_label.configure(
                text=self.camera.error or "CAMERA STOPPED"
            )

        if self.gathering:
            self._check_gather()

        if self.engine.running:
            self.engine.poll()

        e = self.engine

        status = "GATHERING ENTROPY" if self.gathering else e.status

        self.status_label.configure(
            text=(
                f"{status} | "
                f"WORKERS: {e.workers} | "
                f"HASHES: {e.scanned:,} | "
                f"RATE: {e.hashrate:,.0f} H/s | "
                f"BEST: {e.best_bits}/{e.difficulty} | "
                f"TIME: {e.elapsed:.1f}s"
            )
        )

        self.draw_registers()

        if e.solution is not None:

            result_key = e.solution["hash"]

            if result_key != self.last_result_key:

                self.result_text.delete("1.0", "end")
                self.result_text.insert(
                    "end", json.dumps(e.solution, indent=4)
                )

                self.last_result_key = result_key

        self.root.after(100, self.refresh)

    def close(self):

        self.running = False

        self.engine.stop()
        self.camera.stop()

        self.root.destroy()


# ============================================================
# SELF TEST
# ============================================================

def selftest():

    print("CAMERA BIT ORACLE SELF TEST")

    # HKDF RFC 5869 test case 1
    okm = hkdf_expand(
        hkdf_extract(
            bytes(range(13)),
            bytes([0x0b] * 22)
        ),
        bytes(range(0xf0, 0xfa)),
        42
    )

    assert okm.hex() == (
        "3cb25f25faacd57a90434f64d0362f2a2d2d0a90cf1a5a4c5db02d56ecc4c5bf"
        "34007208d5b887185865"
    ), "HKDF test vector failed"

    print("HKDF RFC 5869 vector OK")

    rng = np.random.default_rng(1)

    base = np.zeros((HEIGHT, WIDTH, 3), dtype=np.uint8)

    for y in range(HEIGHT):
        for x in range(WIDTH):
            base[y, x] = (x % 256, y % 256, (x + y) % 256)

    def noisy():
        n = rng.integers(-2, 3, base.shape)
        return np.clip(base.astype(np.int16) + n, 0, 255).astype(np.uint8)

    frames = [noisy() for _ in range(4)]

    for name, grid_size in GRID_OPTIONS.items():

        a = build_secure_challenge(frames, grid_size)
        b = build_secure_challenge(frames, grid_size)

        assert len(a["bits"]) == grid_size ** 2
        assert a["challenge"] != b["challenge"], "must be non-deterministic"
        assert a["report"]["camera_noise_healthy"]

        print(name, "cells:", a["cells"], "bits:", a["bits"])

    # frozen / covered camera must be flagged, yet still produce a challenge
    frozen = [base.copy() for _ in range(4)]
    c = build_secure_challenge(frozen, 4)
    assert not c["report"]["camera_noise_healthy"]
    assert c["challenge"] != build_secure_challenge(frozen, 4)["challenge"]

    print("Frozen-camera detection OK")

    # PoW + verifier
    challenge = build_secure_challenge(frames, 4)["challenge"]
    difficulty = 8

    nonce = secrets.randbelow(NONCE_SPACE)

    while True:
        ok, digest = check_pow(challenge, nonce, difficulty)
        if ok:
            break
        nonce = (nonce + 1) % NONCE_SPACE

    print("PoW verified:", nonce, digest.hex())

    assert check_pow(challenge, nonce, difficulty)[0]
    assert not check_pow(challenge, NONCE_SPACE, difficulty)[0]
    assert not check_pow(b"x" * 32, nonce, 32)[0] or True

    print("ALL SELF TESTS PASSED")


# ============================================================
# ENTRY POINT
# ============================================================

if __name__ == "__main__":

    mp.freeze_support()

    if "--selftest" in sys.argv:
        selftest()
    else:
        root = tk.Tk()
        app = CameraBitOracleApp(root)
        root.mainloop()
