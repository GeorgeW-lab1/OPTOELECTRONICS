"""
optoelectronics_rp.py - applies the Wagenknecht papers to the camera build.

What is implemented (paper section in brackets)
  RP circuit, camera build   [RP walkthrough Parts 1-3, RP-GHOST A.1-A.6]
      frame -> motion mask E -> instance x = count of changed pixels (128x96 grid)
      Driver A (randomized): r = 2 + SHA-256(E) mod (x-3); A = 1 iff r is a Miller-Rabin
                             witness that x is composite  (A = 0 on primes, always)
      Driver B (deterministic): c(x) = 1 iff x is composite
      IF/THEN link: C charges through R toward 5 V (tau), NPN emitter follower
                    V_B = max(0, V_C - 0.7), logic HIGH at 3.5 V  ->  1.83 tau
      Q = A.B.Y on the clock edge (74HC74), SELECT = Q, observe = not Q
  Time code latch            [Time Code Latch paper, section 8]  --y-mode latch
  Test protocol for H1-H3    [RP-GHOST A.9, C.7]  frame digest, count, witness, Q, then a
                             nonce from an INDEPENDENT source (secrets), header hash, outcome;
                             estimators P1 (hidden number), P3 (hash-bit bias),
                             P4 (frame-outcome correlation), P5 (witness rate).
  Inverted loop  Qbar -> D   [Part 3 section 4, RP-GHOST B.10.4]       --demo loop
  Two-level recognition      [Two-Level Photonic Recognition paper]     --demo two-level

Not implemented: SHA-256d mining/TTS (P2) - the papers say the miner is a separate source;
photoelectron-variance test (P7) - needs raw sensor counts, a webcam gives processed 8-bit
values; locality-annealing score - the concept note defines no measurable drive A(t).

No laser, no calibration: the camera sees ambient light, motion supplies x.

Usage
    pip install opencv-python numpy
    python optoelectronics_rp.py                          # webcam 0, minimal defaults (200 trials)
    python optoelectronics_rp.py --camera synthetic       # no camera needed
    python optoelectronics_rp.py --camera clip.mp4 --trials 5000 --m 8 --tau-ms 50
    python optoelectronics_rp.py --demo selfcheck|latch|loop|two-level
"""

import argparse
import hashlib
import itertools
import math
import random
import secrets
from functools import lru_cache

import numpy as np

GRID_W, GRID_H = 128, 96          # 12,288 pixels (RP-GHOST A.8)
RAIL_V, VBE, VIH = 5.0, 0.7, 3.5


# =============================================================== number theory
def is_prime(n):
    if n < 2:
        return False
    if n % 2 == 0:
        return n == 2
    i = 3
    while i * i <= n:
        if n % i == 0:
            return False
        i += 2
    return True


def mr_witness(a, n):
    """True if a proves n composite. Even n > 2 is caught by the parity check."""
    if n % 2 == 0:
        return n > 2
    d, s = n - 1, 0
    while d % 2 == 0:
        d //= 2
        s += 1
    x = pow(a, d, n)
    if x in (1, n - 1):
        return False
    for _ in range(s - 1):
        x = x * x % n
        if x == n - 1:
            return False
    return True


@lru_cache(maxsize=None)
def witness_density(x):
    """Exact P(A=1) for a uniform r in [2, x-2]: the correct null for P5."""
    if x < 5 or is_prime(x):
        return 0.0
    if x % 2 == 0:
        return 1.0
    return sum(mr_witness(a, x) for a in range(2, x - 1)) / (x - 3)


def sha256d(b):
    return hashlib.sha256(hashlib.sha256(b).digest()).digest()


# ============================================================== circuit blocks
class DriverA:
    """Randomized witness test; its random source is SHA-256 of the motion mask."""

    def witness(self, x, mask_bytes):
        if x < 5:
            return 0, None
        r = 2 + int.from_bytes(hashlib.sha256(mask_bytes).digest(), "big") % (x - 3)
        return int(mr_witness(r, x)), r


class DriverB:
    """Deterministic precondition c(x): 1 whenever x is in L (x composite)."""

    def check(self, x):
        return int(x >= 4 and not is_prime(x))


class IfThenLink:
    """RC charge + NPN emitter follower. 'IF V(C) > 0.7 V' is only the turn-on;
    B is a valid logic HIGH when V_B >= 3.5 V, i.e. V(C) >= 4.2 V (1.83 tau)."""

    def __init__(self, tau_ms):
        self.tau, self.vc = tau_ms, 0.0

    def discharge(self):                      # C must be emptied between trials
        self.vc = 0.0

    def step(self, drive, dt_ms):
        target = RAIL_V if drive else 0.0
        self.vc += (target - self.vc) * (1.0 - math.exp(-dt_ms / self.tau))

    @property
    def vb(self):
        return max(0.0, self.vc - VBE)

    @property
    def high(self):
        return self.vb >= VIH


class DFlipFlop:
    """74HC74: copies D to Q on the clock edge. Qbar is the 'observe' output."""

    def __init__(self):
        self.q = 0

    def clock(self, d):
        self.q = int(d)
        return self.q, 1 - self.q


class TimeCodeLatch:
    """Serialises an integer one bit per clock, MSB first."""

    def __init__(self, value, nbits):
        self.value, self.nbits = value, nbits

    def bit(self, slot):
        return (self.value >> (self.nbits - 1 - (slot % self.nbits))) & 1


# ================================================================= frame source
class SyntheticSource:
    """Noisy ambient scene with a moving bright square (no camera needed)."""

    def __init__(self, seed=None):
        self.rng = np.random.default_rng(seed)
        self.t = 0

    def read(self):
        self.t += 1
        g = 120 + self.rng.normal(0, 2.0, (GRID_H, GRID_W))
        size = int(self.rng.integers(4, 30))
        cx = int(self.rng.integers(0, GRID_W - size))
        cy = int(self.rng.integers(0, GRID_H - size))
        g[cy:cy + size, cx:cx + size] += 60
        return np.clip(g, 0, 255).astype(np.uint8)

    def close(self):
        pass


class CameraSource:
    def __init__(self, source, preview=False):
        import cv2
        self.cv2, self.preview = cv2, preview
        src = int(source) if str(source).isdigit() else source
        self.is_file = not isinstance(src, int)
        self.cap = cv2.VideoCapture(src)
        if not self.cap.isOpened():
            raise RuntimeError(f"Could not open camera/source: {source!r}")

    def read(self):
        cv2 = self.cv2
        ok, frame = self.cap.read()
        if not ok and self.is_file:
            self.cap.set(cv2.CAP_PROP_POS_FRAMES, 0)
            ok, frame = self.cap.read()
        if not ok:
            raise RuntimeError("Camera produced no frame")
        if self.preview:
            cv2.imshow("optoelectronics_rp", frame)
            cv2.waitKey(1)
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        return cv2.resize(gray, (GRID_W, GRID_H), interpolation=cv2.INTER_AREA)

    def close(self):
        self.cap.release()
        if self.preview:
            self.cv2.destroyAllWindows()


# ================================================================== statistics
def norm_sf(z):
    return 0.5 * math.erfc(z / math.sqrt(2))


def binom_upper(hits, n, p):
    """P(X >= hits), X ~ Binomial(n, p). Exact for small spread, else normal."""
    if hits <= 0:
        return 1.0
    mu, sd = n * p, math.sqrt(n * p * (1 - p))
    if sd > 5:
        return norm_sf((hits - 0.5 - mu) / sd)
    total, lp, lq = 0.0, math.log(p), math.log(1 - p)
    for k in range(hits, n + 1):
        t = math.exp(math.lgamma(n + 1) - math.lgamma(k + 1) - math.lgamma(n - k + 1)
                     + k * lp + (n - k) * lq)
        total += t
        if k > mu and t < 1e-18 * total:
            break
    return min(1.0, total)


def verdict(z):
    return "EVIDENCE (>= 5 sigma): check for leakage/bugs first" if z >= 5 else "null (no effect)"


# ================================================================ main experiment
def run_camera(args):
    if args.camera == "synthetic":
        src = SyntheticSource(args.seed)
    else:
        src = CameraSource(args.camera, args.preview)

    drv_a, drv_b, link, ff = DriverA(), DriverB(), IfThenLink(args.tau_ms), DFlipFlop()
    latch = TimeCodeLatch(int(args.latch_value, 0), args.latch_bits)

    t_logic = args.tau_ms * math.log(RAIL_V / (RAIL_V - VIH - VBE))
    print("=== Pre-registered configuration (fixed before the run) ===")
    print(f"y-mode={args.y_mode}  timecode={args.timecode}  clock={args.clock_ms} ms  "
          f"tau={args.tau_ms} ms  t_logic={t_logic:.1f} ms "
          f"({'settles before the clock edge' if t_logic < args.clock_ms else 'TOO SLOW: B can never be 1'})")
    print(f"hidden number: m={args.m} bits (chance 2^-{args.m} per word, paper n=25*2^m="
          f"{25 * 2 ** args.m} words); hash target: {args.target_bits} leading zero bits")
    print("evidence threshold: 5 sigma; nonce source: secrets (independent, drawn AFTER the frame digest)\n")

    prev = None
    xs, As, Bs, Qs, Ys, outs, hashes = [], [], [], [], [], [], []
    word_bits, words, word_hits = [], 0, 0
    false_accepts = timing_fail = 0
    trial = 0
    try:
        while trial < args.trials:
            gray = src.read()
            if prev is None:
                prev = gray
                continue
            mask = np.abs(gray.astype(np.int16) - prev.astype(np.int16)) > args.motion_thr
            prev = gray
            x = int(mask.sum())
            digest = hashlib.sha256(gray.tobytes()).digest()            # frame digest d_t

            a, _ = drv_a.witness(x, np.packbits(mask).tobytes())
            b_drive = drv_b.check(x)
            link.discharge()
            for _ in range(args.clock_ms):                              # 1 ms RC steps
                link.step(b_drive, 1.0)
            b = int(link.high)

            if args.y_mode == "gate":
                y = int(args.timecode[trial % len(args.timecode)])
                d = a & b & y                                           # Q = A.B.Y
            else:
                y = latch.bit(trial)
                d = y                                                   # latch drives D
            q, _ = ff.clock(d)

            composite = x >= 4 and not is_prime(x)
            if args.y_mode == "gate" and q == 1 and not composite:
                false_accepts += 1
            timing_fail += int(a == 1 and b_drive == 1 and b == 0)

            # --- A.9: nonce chosen AFTER the frame digest, by an independent source
            nonce = secrets.randbits(64)
            h = sha256d(digest + nonce.to_bytes(8, "big"))
            out = int(int.from_bytes(h, "big") >> (256 - args.target_bits) == 0)

            word_bits.append(q)
            if len(word_bits) == args.m:                                # device word first ...
                guess = int("".join(map(str, word_bits)), 2)
                target = secrets.randbits(args.m)                       # ... target drawn after
                word_hits += int(guess == target)
                words += 1
                word_bits = []

            xs.append(x); As.append(a); Bs.append(b); Qs.append(q); Ys.append(y)
            outs.append(out); hashes.append(h)
            trial += 1
    finally:
        src.close()

    report(args, xs, As, Bs, Qs, outs, hashes, words, word_hits, false_accepts, timing_fail)


def report(args, xs, As, Bs, Qs, outs, hashes, words, word_hits, false_accepts, timing_fail):
    n = len(xs)
    comp = [i for i, x in enumerate(xs) if x >= 5 and not is_prime(x)]
    print(f"=== Results over {n} trials ===")
    print(f"x: min {min(xs)}  median {int(np.median(xs))}  max {max(xs)};  "
          f"composite (x>=5): {len(comp)} trials, prime/trivial: {n - len(comp)}")
    if len(comp) == 0:
        print("  No composite instances: add motion in view (wave a hand) or lower --motion-thr.")

    print("\n-- Circuit properties (RP-GHOST A.1-A.6) --")
    if args.y_mode == "gate":
        print(f"false accepts (Q=1 with x not in L): {false_accepts}   <- must be 0 (one-sided error)")
    print(f"timing failures (A=1, c(x)=1 but B not HIGH at the edge): {timing_fail}")
    if comp:
        acc = sum(Qs[i] for i in comp) / len(comp)
        print(f"accept rate on composites: {acc:.3f}")
        print("  k trials   worst case (1/2)^k   measured (1-acc)^k")
        for k in (1, 2, 5, 10, 20):
            print(f"  {k:8d}   {0.5 ** k:17.3g}   {(1 - acc) ** k:17.3g}")

    print("\n-- P5 witness success rate on x in L --")
    if comp:
        obs = sum(As[i] for i in comp)
        exp_ = sum(witness_density(xs[i]) for i in comp)
        var = sum(witness_density(xs[i]) * (1 - witness_density(xs[i])) for i in comp)
        z = (obs - exp_) / math.sqrt(var) if var > 0 else float("nan")
        print(f"observed A=1: {obs}/{len(comp)} = {obs / len(comp):.3f};  expected from the exact witness "
              f"density of the x values seen: {exp_ / len(comp):.3f}")
        print(f"  z = {z:.2f}  -> {verdict(z) if z == z else 'n/a (no variance, e.g. all x even)'}")
        print("  (the paper's null of 3/4 is only a lower bound; even x give a witness density of 1)")

    print(f"\n-- P1 hidden number (m={args.m}) --")
    if words:
        p0 = 2.0 ** -args.m
        z = (word_hits - words * p0) / math.sqrt(words * p0 * (1 - p0))
        print(f"words: {words}, hits: {word_hits}, chance rate {p0:.4g} -> expected {words * p0:.2f};  "
              f"P(X>=hits)={binom_upper(word_hits, words, p0)!r}  z={z:.2f}  -> {verdict(z)}")
        need = 25 * 2 ** args.m
        print(f"  paper's sample size for its target sensitivity: {need} words "
              f"({need * args.m} trials); this run: {words} words")

    print("\n-- P3 hash-bit bias --")
    bits = np.unpackbits(np.frombuffer(b"".join(hashes), dtype=np.uint8))
    eps = bits.mean() - 0.5
    z = eps / (0.5 / math.sqrt(bits.size))
    print(f"bits: {bits.size}, mean bit - 1/2 = {eps:+.2e}, z = {z:+.2f}  -> {verdict(abs(z))}")
    print(f"  sensitivity of this run: eps ~ {5 * 0.5 / math.sqrt(bits.size):.1e} at 5 sigma")

    print("\n-- P4 frame feature (Q) vs hash outcome --")
    qa, oa = np.array(Qs, float), np.array(outs, float)
    if qa.std() > 0 and oa.std() > 0:
        rho = float(np.corrcoef(qa, oa)[0, 1])
        z = rho * math.sqrt(n)
        print(f"rho = {rho:+.4f}, z = {z:+.2f}  -> {verdict(abs(z))};  outcomes (hash below target): "
              f"{int(oa.sum())}/{n}")
    else:
        print("n/a: Q or the outcome never varied (Q is 0 unless x is composite and the witness test fires).")

    if args.y_mode == "latch":
        nb = args.latch_bits
        groups = [Qs[i:i + nb] for i in range(0, n - nb + 1, nb)]
        vals = [int("".join(map(str, g)), 2) for g in groups]
        want = int(args.latch_value, 0)
        print(f"\n-- Time code latch: SELECT bits reconstructed {len(vals)} words, "
              f"{sum(v == want for v in vals)} equal {want:#0{nb // 4 + 2}x} --")


# =============================================================== other demos
def selfcheck():
    ok = True
    # 1.83 tau
    link = IfThenLink(50.0)
    t = 0.0
    while not link.high:
        link.step(1, 0.01)
        t += 0.01
    ok &= abs(t / 50.0 - math.log(5 / 0.8)) < 0.01
    print(f"RC link: B HIGH at {t / 50:.3f} tau (paper: 1.83 tau)  {'ok' if abs(t / 50 - 1.833) < 0.01 else 'FAIL'}")
    # Miller-Rabin never calls a prime composite
    bad = [p for p in range(5, 3000) if is_prime(p) and any(mr_witness(a, p) for a in range(2, p - 1))]
    print(f"Miller-Rabin: witnesses on primes < 3000: {len(bad)}  {'ok' if not bad else 'FAIL'}")
    ok &= not bad
    # composite witness density >= 3/4 for odd composites
    low = [x for x in range(9, 400, 2) if not is_prime(x) and witness_density(x) < 0.75]
    print(f"odd composites < 400 with witness density < 3/4: {len(low)}  {'ok' if not low else 'FAIL'}")
    ok &= not low
    # latch
    bits = [TimeCodeLatch(0xA5, 8).bit(s) for s in range(8)]
    print(f"Latch 0xA5 -> {bits}  {'ok' if bits == [1, 0, 1, 0, 0, 1, 0, 1] else 'FAIL'}")
    ok &= bits == [1, 0, 1, 0, 0, 1, 0, 1]
    return ok


def demo_latch():
    value, nb = 0xA5, 8
    latch, ff, got = TimeCodeLatch(value, nb), DFlipFlop(), []
    for slot in range(nb):
        q, _ = ff.clock(latch.bit(slot))
        got.append(q)
        print(f"slot {slot}  t={slot * 100:4d} ms  bit {q}")
    word = int("".join(map(str, got)), 2)
    print(f"SELECT collected -> {word:#04x}  nibbles {got[:4]} {got[4:]}  "
          f"{'matches' if word == value else 'DIFFERS from'} the stored {value:#04x}")


def demo_loop(eps=0.01, p0=1.0, trials=20000, seed=None):
    """Qbar -> D with gate-flip noise: p_n - 1/2 = (-(1-2eps))^n (p0 - 1/2)  (RP-GHOST B.10.4)."""
    rng = np.random.default_rng(seed)
    q = (rng.random(trials) < p0).astype(np.uint8)
    print(f"eps={eps}, p0={p0}, {trials} runs\n   n    simulated p_n   formula p_n")
    for n in range(0, 61):
        if n in (0, 1, 2, 3, 4, 5, 10, 20, 40, 60):
            formula = 0.5 + (-(1 - 2 * eps)) ** n * (p0 - 0.5)
            print(f"{n:4d}   {q.mean():13.4f}   {formula:11.4f}")
        d = 1 - q
        flip = rng.random(trials) < eps
        q = np.where(flip, 1 - d, d).astype(np.uint8)
    n_dev = math.log(500) / -math.log(1 - 2 * eps)
    print(f"\nformula: deviation from 1/2 falls from 0.5 to 1e-3 after n = {n_dev:.0f} clocks "
          f"({n_dev * 0.1:.1f} s at 100 ms). A delayed ordinary loop settles to p* = 1/2; it is not a time loop.")


def demo_two_level(n=8, p=0.5, bmax=1000, seed=None):
    """Level 1 never-seen-zero set + Level 2 Hamming-ball search with a SHA-256 commitment.
    Dual convention: X_i = (not K_i) or R_i, so K_i=0 never shows a zero (Remark 5.3).
    NOTE (paper, Limitations 2): this simulated channel is given K, so it exercises the
    decoder maths only. It is not evidence of physical secret recovery."""
    rng = random.Random(seed)
    K = [rng.getrandbits(1) for _ in range(n)]
    salt = rng.randbytes(16)
    pack = lambda bits: int("".join(map(str, bits)), 2).to_bytes((n + 7) // 8, "big")
    commit = hashlib.sha256(salt + pack(K)).digest()
    seen_zero, total_hashes = [False] * n, 0
    print(f"n={n}, p={p}, Bmax={bmax}, brute force would need up to 2^{n} = {2 ** n:,} hashes")
    for m in range(1, 200):
        for i in range(n):
            x = (not K[i]) or (rng.random() < p)
            if not x:
                seen_zero[i] = True
        U = [i for i in range(n) if not seen_zero[i]]
        base = [0 if i in U else 1 for i in range(n)]          # K_i=1 whenever a zero was seen
        cum = 0
        for k in range(len(U) + 1):                            # flip k positions of U from 0 to 1
            layer = math.comb(len(U), k)
            if cum + layer > bmax:
                break
            cum += layer
            for F in itertools.combinations(U, k):
                cand = base[:]
                for i in F:
                    cand[i] = 1
                total_hashes += 1
                if hashlib.sha256(salt + pack(cand)).digest() == commit:
                    print(f"recovered after m={m} cycles, |U|={len(U)}, radius k={k}, "
                          f"{total_hashes:,} hash evaluations (cumulative over stages); "
                          f"correct={cand == K}")
                    print(f"E[Q_m] = n p^m / 2 = {n * p ** m / 2:.2f} unresolved ones at this m")
                    return
    print("not recovered within the cycle limit")


# ===================================================================== main
def main():
    ap = argparse.ArgumentParser(description="Camera build of the optoelectronic RP circuit + RP-GHOST test")
    ap.add_argument("--camera", default="0", help="camera index, video file, or 'synthetic'")
    ap.add_argument("--demo", choices=["run", "selfcheck", "latch", "loop", "two-level"], default="run")
    ap.add_argument("--trials", type=int, default=200)
    ap.add_argument("--m", type=int, default=2, help="hidden-number bits")
    ap.add_argument("--target-bits", type=int, default=2, help="leading zero bits for a hash 'hit'")
    ap.add_argument("--clock-ms", type=int, default=100)
    ap.add_argument("--tau-ms", type=float, default=10.0)
    ap.add_argument("--y-mode", choices=["gate", "latch"], default="gate")
    ap.add_argument("--timecode", default="1", help="Y bins for gate mode")
    ap.add_argument("--latch-value", default="0xA")
    ap.add_argument("--latch-bits", type=int, default=4)
    ap.add_argument("--motion-thr", type=int, default=12, help="pixel change (0-255) counted as motion")
    ap.add_argument("--seed", type=int, default=None)
    ap.add_argument("--preview", action="store_true")
    args = ap.parse_args()

    if args.demo == "selfcheck":
        raise SystemExit(0 if selfcheck() else 1)
    if args.demo == "latch":
        return demo_latch()
    if args.demo == "loop":
        return demo_loop(seed=args.seed)
    if args.demo == "two-level":
        return demo_two_level(seed=args.seed)
    print("Self-checks:")
    if not selfcheck():
        raise SystemExit("self-check failed")
    print()
    run_camera(args)


if __name__ == "__main__":
    main()
