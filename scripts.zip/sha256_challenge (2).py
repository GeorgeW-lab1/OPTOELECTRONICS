"""
Bit-Pooling Higher-Lower Search & Circuit Camera Lab
(Tkinter / OpenCV Framework with Visual Bit Registers, Serial-Hex Receive & Forced Serial Read)
Adapted from the RP-style optoelectronic decision circuit framework.

Oracle spec (rp_circuit_camera.py): a BitPoolingOracle holds the hidden target and answers
"target >= trial?" queries; a BitPoolingSearchEngine pools one bit per step, MSB first, driven
by camera motion triggers (or the Step / Solve buttons).

Target = the minimally SHA-256-padded message (header [+ decimal nonce]):
    msg || 0x80 || 0x00... || 64-bit big-endian bit length   (whole 64-byte blocks)
so the register depth is 512 bits per block, not a fixed size.

Decode: the pooled (guess) bits are de-padded with sha_unpad() and decoded back into
message text, header, nonce, SHA-256 hash and the sketch's POW line, live while pooling
(whole bytes revealed so far) and in full once the pool converges.

Export: Copy / Save converts the revealed oracle target into text (de-padded message) or hex.
"""

import asyncio
import hashlib
import queue
import random
import re
import sys
import threading
import time
import tkinter as tk
from tkinter import ttk, messagebox, filedialog

import numpy as np

try:
    import cv2
except ImportError:
    cv2 = None

try:
    import serial
    import serial.tools.list_ports
except ImportError:
    serial = None


# ==============================================================================
# SERIAL RECEIVER (serial port -> hex input)
# ==============================================================================
DIFF_CMD_FMT = "diff {n}\n"   # sent by the 'Send diff n' button; edit to match the sketch

# Sizes / padding, matching sha256_challenge.ino
CHALLENGE_BYTES = 32                    # 256-bit challenge -> 64 hex chars
NONCE_BYTES = 8                         # 64-bit nonce      -> 16 hex chars
HASH_BYTES = 32                         # SHA-256 digest    -> 64 hex chars
HASH_BITS = HASH_BYTES * 8              # 256 bits: highest difficulty
BLOCK_BITS = 512                        # one SHA-256 block: default oracle depth
EXPORT_CHOICES = ["Text (decoded from hex)", "Hex", "Hex + Text"]
MAX_HEADER = 159                        # sketch: MAX_INPUT 160 incl. terminator
HEX_DIGITS = CHALLENGE_BYTES * 2        # 64


def pad_hex(value: int, nbytes: int) -> str:
    """Fixed-width, zero-padded, UPPERCASE hex with no prefix (as the Arduino sends/expects)."""
    return f"{value:0{nbytes * 2}X}"


def sha_pad(msg: bytes) -> bytes:
    """SHA-256 padding: msg + 0x80 + zeros + 64-bit big-endian bit length (multiple of 64 bytes)."""
    out = bytearray(msg) + b"\x80"
    while len(out) % 64 != 56:
        out.append(0)
    return bytes(out) + (len(msg) * 8).to_bytes(8, "big")


def sha_unpad(padded: bytes) -> bytes:
    """Inverse of sha_pad. Raises ValueError unless it is valid, minimal SHA-256 padding."""
    if len(padded) < 64 or len(padded) % 64:
        raise ValueError("not a whole number of 64-byte blocks")
    length = int.from_bytes(padded[-8:], "big") // 8
    if length > len(padded) - 9 or sha_pad(padded[:length]) != padded:
        raise ValueError("invalid padding")
    return padded[:length]


def _split_message(text: str, header: str = ""):
    """Split decoded message text into (header, nonce_text or None)."""
    if header and text.startswith(header):
        rest = text[len(header):]
        if not rest:
            return header, None
        if rest.isdigit():
            return header, rest
    m = re.search(r"(\d{1,10})$", text)
    if m and not header:                    # header unknown: trailing digits are the nonce
        return text[:m.start()], m.group(1)
    return text, None


def decode_pool_bits(guess: int, depth: int, steps: int, header: str = "") -> dict:
    """
    Decode the oracle's pooled bits. Partial while steps < depth (only whole bytes revealed so
    far); once complete the register is de-padded and split into header / nonce / hash.
    """
    raw = guess.to_bytes(depth // 8, "big")
    pooled = f"{guess:0{depth // 4}X}"[: steps // 4].ljust(depth // 4, ".")
    info = dict(depth=depth, steps=steps, complete=False, pooled_hex=pooled,
                status="PENDING", length_bits=None, text="", header="", nonce=None,
                hash_hex="", zero_bits=None, line="", message=b"")

    if steps < depth:
        text = raw[: steps // 8].split(b"\x80")[0].decode("utf-8", "replace")
        info["status"] = "PARTIAL" if steps else "PENDING"
        info["text"] = text
        if header and text.startswith(header):
            info["header"] = header
            info["nonce"] = text[len(header):] or None
        return info

    info["complete"] = True
    try:
        msg = sha_unpad(raw)
    except ValueError:
        info["status"] = "INVALID PADDING"
        return info

    text = msg.decode("utf-8", "replace")
    hdr, nonce = _split_message(text, header)
    digest = hashlib.sha256(msg).digest()
    info.update(status="DEPADDED", message=msg, text=text, header=hdr, nonce=nonce,
                length_bits=int.from_bytes(raw[-8:], "big"), hash_hex=digest.hex(),
                zero_bits=HASH_BITS - int.from_bytes(digest, "big").bit_length())
    if nonce is not None and nonce == str(int(nonce)):
        info["line"] = build_pow_line(hdr, int(nonce), digest)
    return info


def meets_difficulty(digest: bytes, difficulty: int) -> bool:
    """True if the digest has at least `difficulty` leading zero bits (as checkDifficulty())."""
    return (int.from_bytes(digest, "big") >> (256 - difficulty)) == 0


def build_pow_line(header: str, nonce: int, digest: bytes) -> str:
    """
    Exactly the line the sketch prints when it finds a solution:
      POW:<nonce>:<hash>:<padded message>:<padded nonce>:<padded hash>:<header>
    """
    ntext = str(nonce).encode("ascii")
    msg = header.encode("utf-8") + ntext
    return ":".join(["POW", str(nonce), digest.hex(),
                     sha_pad(msg).hex(), sha_pad(ntext).hex(), sha_pad(digest).hex(),
                     header])


def mine_pow(header: str, difficulty: int, stop=None, limit: int = 1 << 32):
    """
    Same search as the sketch: SHA256(header + decimal nonce), nonce counting up from 0.
    Returns (nonce, digest, hashes); nonce is None if cancelled or the nonce space ran out.
    """
    prefix = hashlib.sha256(header.encode("utf-8"))
    for nonce in range(limit):
        if stop is not None and nonce % 20000 == 0 and stop.is_set():
            return None, None, nonce
        h = prefix.copy()
        h.update(str(nonce).encode("ascii"))
        digest = h.digest()
        if meets_difficulty(digest, difficulty):
            return nonce, digest, nonce + 1
    return None, None, limit


class SerialReceiver:
    """Serial channel. Receives hex; transmits only the DIFF command."""
    def __init__(self):
        self._port = None
        self.port_name = None
        self.baud = 115200

    @staticmethod
    def list_ports():
        if serial is None:
            return []
        return [p.device for p in serial.tools.list_ports.comports()]

    @property
    def is_open(self):
        return self._port is not None

    def open(self, name, baud=115200):
        self.close()
        if serial is None:
            raise RuntimeError("pyserial is not installed. Run: pip install pyserial")
        self._port = serial.Serial(name, baud, timeout=0)
        self.port_name = name
        self.baud = baud

    def close(self):
        if self._port is not None:
            try:
                self._port.close()
            except Exception:
                pass
        self._port = None
        self.port_name = None

    def send_diff(self, n: int):
        """Send the difficulty command, e.g. 'diff 12\\n'."""
        if self._port is None:
            return False
        try:
            self._port.write(DIFF_CMD_FMT.format(n=n).encode("ascii"))
            return True
        except Exception:
            self.close()
            return False

    def poll(self) -> bytes:
        """Return any bytes that arrived since the last call."""
        if self._port is None:
            return b""
        try:
            n = self._port.in_waiting
            return self._port.read(n) if n else b""
        except Exception:
            self.close()
            return b""


# ==============================================================================
# MESSAGE EXTRACTOR (serial text lines -> fields)
# ==============================================================================
class MessageExtractor:
    """
    Reassembles newline-terminated serial lines from sha256_challenge.ino:
        POW:<nonce>:<64-hex hash>:<padded message>:<padded nonce>:<padded hash>:<header>
        HEADER:<DATA string>
        [TERMINATED] / [IDLE] / [ERROR] ... (any line starting with '[')
    feed() returns a list of dicts, each with a "kind" key.
    """
    POW_RE = re.compile(r"^POW:(\d{1,10}):([0-9A-Fa-f]{64}):([0-9A-Fa-f]+):"
                        r"([0-9A-Fa-f]+):([0-9A-Fa-f]+):(.*)$")
    MAX_LINE = 1024                                 # longest sketch line is ~880 chars

    def __init__(self):
        self._buf = bytearray()
        self._overflow = False

    def reset(self):
        self._buf.clear()
        self._overflow = False

    def feed(self, data: bytes):
        out = []
        for b in data:
            if b == 0x0A:                                   # '\n' ends a message
                if not self._overflow:
                    msg = self._parse(bytes(self._buf).decode("utf-8", "replace").strip())
                    if msg is not None:
                        out.append(msg)
                self._buf.clear()
                self._overflow = False
            elif len(self._buf) < self.MAX_LINE:
                self._buf.append(b)
            else:
                self._overflow = True                       # discard the rest of a runaway line
        return out

    def _parse(self, line: str):
        if not line:
            return None
        m = self.POW_RE.match(line)
        if m:
            nonce = int(m.group(1))
            padded = (m.group(3), m.group(4), m.group(5))
            if nonce >= 1 << 32 or any(len(f) % 128 for f in padded):
                return dict(kind="BAD", text=line)          # padded fields are whole 64-byte blocks
            return dict(kind="POW", nonce=nonce, hash_hex=m.group(2).lower(),
                        header=m.group(6), line=line,
                        padded_msg=bytes.fromhex(m.group(3)),
                        padded_nonce=bytes.fromhex(m.group(4)),
                        padded_hash=bytes.fromhex(m.group(5)))
        if line.startswith("HEADER:"):
            return dict(kind="HEADER", header=line[7:])
        if line.startswith("POW:"):
            return dict(kind="BAD", text=line)              # right prefix, wrong format
        if line.startswith("["):
            return dict(kind="STATUS", text=line)
        return dict(kind="TEXT", text=line)


# ==============================================================================
# BIT-POOLING HIGHER-LOWER ORACLE CLASS
# ==============================================================================
class BitPoolingOracle:
    """
    Encapsulates the secret target and uses bit-pooling across successive
    frames/queries to accumulate bits MSB-first, mimicking the optoelectronic circuit.
    """
    def __init__(self, bit_depth=BLOCK_BITS, target=None):
        self.bit_depth = bit_depth
        self.max_val = (1 << bit_depth) - 1
        # plain-int clamp: numpy cannot clip values wider than 64 bits
        self._target = (max(0, min(int(target), self.max_val))
                        if target is not None else random.randint(0, self.max_val))

        # Pooling configuration matching hardware settings
        self.kernel_size = 4
        self.stride = 2
        self.pool_op = "POPCOUNT"
        self.schmitt_trigger = 0.5

        # Pooling accumulation state
        self.pooled_bits = 0
        self.pooled_count = 0
        self.is_done = False

    def reveal(self):
        if not self.is_done:
            return 0
        return self._target

    def query_bit(self, trial_val):
        """
        Oracle evaluation: determines if the secret target is >= the pooled trial value.
        Returns the individual bit (0 or 1) for the current bit position.
        """
        if self.is_done:
            return 0
        return 1 if self._target >= trial_val else 0

    def pool_step(self, val):
        """Applies hardware-style bit pooling (kernel, stride, operator) to a value."""
        bits = [(val >> i) & 1 for i in range(self.bit_depth)]

        pooled_out = []
        for i in range(0, len(bits), self.stride):
            block = bits[i: i + self.kernel_size]
            if not block:
                break

            if self.pool_op == "POPCOUNT":
                res_bit = 1 if (sum(block) / len(block)) >= self.schmitt_trigger else 0
            elif self.pool_op == "AND":
                res_bit = 1 if all(b == 1 for b in block) else 0
            elif self.pool_op == "OR":
                res_bit = 1 if any(b == 1 for b in block) else 0
            elif self.pool_op == "XOR":
                res_bit = sum(block) % 2
            elif self.pool_op == "MAJORITY":
                res_bit = 1 if sum(block) > (len(block) / 2.0) else 0
            else:
                res_bit = block[0]

            pooled_out.append(res_bit)

        out_val = 0
        for idx, b in enumerate(pooled_out):
            out_val |= (b << idx)
        return out_val

    @property
    def target(self):
        """Raises PermissionError if accessed before search completion."""
        if not self.is_done:
            raise PermissionError("SECURITY VIOLATION: Oracle target is classified until fully pooled!")
        return self._target


# ==============================================================================
# BIT-POOLING SEARCH ENGINE
# ==============================================================================
class BitPoolingSearchEngine:
    def __init__(self, bit_depth=BLOCK_BITS):
        self.bit_depth = bit_depth
        self.max_val = (1 << bit_depth) - 1
        self._lock = threading.RLock()      # camera thread steps, GUI thread resets

        # Hardware & Pooling Settings (persist across resets)
        self.kernel_size = 4
        self.stride = 2
        self.pool_op = "POPCOUNT"
        self.schmitt_trigger = 0.5

        # Registers
        self.guess_reg = 0
        self.target_reg = 0
        self.pooled_register = 0

        self.oracle = None
        self.reset()

    def reset(self, new_target=None, bit_depth=None):
        """New oracle. bit_depth resizes the registers (one SHA-256 block = 512 bits)."""
        with self._lock:
            if bit_depth is not None:
                self.bit_depth = bit_depth
                self.max_val = (1 << bit_depth) - 1
            self.oracle = BitPoolingOracle(self.bit_depth, new_target)
            self.oracle.kernel_size = self.kernel_size
            self.oracle.stride = self.stride
            self.oracle.pool_op = self.pool_op
            self.oracle.schmitt_trigger = self.schmitt_trigger

            self.current_guess = 0
            self.step_count = 0
            self.history = [self.current_guess]
            self.converged = False
            self.last_status = "READY"
            self._update_registers()

    def step(self):
        """Advances the bit-pooling search by evaluating one bit per step."""
        with self._lock:
            if self.converged or self.step_count >= self.bit_depth:
                return

            self.step_count += 1

            # Build trial value based on current pooled bits (MSB first)
            shift = self.bit_depth - self.step_count
            trial_val = self.oracle.pooled_bits | (1 << shift)

            # Query oracle for the bit, accumulate it into the oracle pool
            bit = self.oracle.query_bit(trial_val)
            self.oracle.pooled_bits |= (bit << shift)
            self.current_guess = self.oracle.pooled_bits

            self.history.append(self.current_guess)
            self._update_registers()

            # Check if full bit depth has been gathered
            if self.step_count >= self.bit_depth:
                if self.current_guess == self.oracle._target:
                    self.oracle.is_done = True      # automatically unlocks oracle access
                    self.converged = True
                    self.last_status = f"LOCKED & REVEALED AT {self.current_guess}"
                else:
                    self.last_status = "POOL MISMATCH"

    def _update_registers(self):
        self.guess_reg = self.current_guess
        try:
            self.target_reg = self.oracle.target
        except PermissionError:
            self.target_reg = 0             # masked while the search is active
        self.pooled_register = self.oracle.pool_step(self.current_guess)


# ==============================================================================
# CAMERA SOURCE HANDLING
# ==============================================================================
class Source:
    def __init__(self, index: int):
        if cv2 is None:
            raise RuntimeError("OpenCV is not installed. Run: pip install opencv-python")
        backend = cv2.CAP_DSHOW if sys.platform == "win32" else cv2.CAP_ANY
        cap = cv2.VideoCapture(index, backend)
        cap.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
        cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)
        if not (cap.isOpened() and cap.read()[0]):
            cap.release()
            raise RuntimeError(f"Cannot open camera {index}.")
        self.cap = cap
        self.rgb = None

    def read(self):
        ok, bgr = self.cap.read()
        if not ok:
            return None
        self.rgb = cv2.cvtColor(bgr, cv2.COLOR_BGR2RGB)
        return cv2.cvtColor(bgr, cv2.COLOR_BGR2GRAY)

    def close(self):
        self.cap.release()


def ppm_photo(rgb: np.ndarray) -> tk.PhotoImage:
    h, w, _ = rgb.shape
    data = b"P6 %d %d 255\n" % (w, h) + np.ascontiguousarray(rgb, np.uint8).tobytes()
    return tk.PhotoImage(data=data, format="PPM")


# ==============================================================================
# BACKGROUND SIMULATION THREAD
# ==============================================================================
class SimThread(threading.Thread):
    def __init__(self, cam_index, ctl, out, engine):
        super().__init__(daemon=True)
        self.cam_index = cam_index
        self.ctl = ctl
        self.out = out
        self.engine = engine

    def run(self):
        asyncio.run(self._run())

    async def _run(self):
        ctl, out, engine = self.ctl, self.out, self.engine
        try:
            src = Source(self.cam_index)
        except RuntimeError as e:
            out.put(("error", str(e)))
            out.put(("done", None))
            return
        out.put(("info", f"USB camera {self.cam_index} opened"))

        t_prev = time.perf_counter()
        idx = 0
        prev_even = False
        try:
            while not ctl["stop"]:
                gray = await asyncio.to_thread(src.read)
                if gray is None:
                    out.put(("info", "camera stopped delivering frames"))
                    break
                now = time.perf_counter()
                dt = min(max(now - t_prev, 1e-3), 0.25)
                t_prev = now

                small = cv2.resize(gray, (128, 96), interpolation=cv2.INTER_AREA)
                motion_detected = idx > 5 and np.std(small) > 5.0
                x = int(np.std(small) * 10) if motion_detected else 0

                # Two sequential even motion triggers advance the bit-pooling step
                even_now = x > 0 and x % 2 == 0
                even_state = even_now and prev_even
                prev_even = even_now

                if even_state and ctl.get("auto_step", True) and not engine.converged:
                    engine.step()

                rgb = src.rgb if src.rgb is not None else np.stack([gray] * 3, axis=-1)
                pw, ph = 320, 240
                h_img, w_img = rgb.shape[:2]
                preview = rgb[np.arange(ph) * h_img // ph][:, np.arange(pw) * w_img // pw].copy()

                if ctl.get("ir_heatmap", False):
                    preview[:, :, 0] = np.clip(preview[:, :, 0].astype(int) + 80, 0, 255)
                    preview[:, :, 2] = np.clip(preview[:, :, 2].astype(int) - 50, 0, 255)

                # Target exposed on convergence, or once a forced serial read loaded it
                exposed_target = (engine.oracle._target
                                  if (engine.converged or ctl.get("serial_loaded", False)) else 0)

                out.put(("frame", dict(
                    preview=preview, idx=idx, dt=dt, target=exposed_target,
                    guess=engine.current_guess, pooled=engine.pooled_register,
                    status=engine.last_status, steps=engine.step_count,
                    history=list(engine.history), converged=engine.converged
                )))
                idx += 1
                await asyncio.sleep(0.03)
        finally:
            src.close()
            out.put(("done", None))


# ==============================================================================
# MAIN GUI APPLICATION
# ==============================================================================
class App:
    def __init__(self, window):
        self.window = window
        self.window.title("Bit-Pooling Oracle Search Lab — Serial-Hex Input")
        self.q = queue.Queue()
        self.ctl = dict(stop=False, ir_heatmap=False, auto_step=True, serial_loaded=False)
        self.engine = BitPoolingSearchEngine(bit_depth=BLOCK_BITS)
        self.serial = SerialReceiver()
        self.extractor = MessageExtractor()
        self.rx_header = ""        # header / DATA string (the "hex" in the RX Hex box)
        self.rx_nonce = None       # decimal nonce of the POW line (device's or ours), if known
        self.rx_padded = b""       # that POW line's padded message = the oracle target
        self.rx_difficulty = None
        self._dec_text = None      # decode panel cache
        self._dec_parts = {}
        self.rx_line = ""          # converted POW line for rx_header (device's or ours)
        self.convert_mode = False  # RX Hex box shows the converted POW line
        self.mining_conv = False   # a local Convert search is running
        self.mine_stop = threading.Event()
        self.thread = None
        self.photo = None

        self._build_ui()
        self._draw_current()
        self.window.protocol("WM_DELETE_WINDOW", self._close)
        self.window.after(15, self._poll)

    # ---------------------------------------------------------------- UI
    def _build_ui(self):
        main_frame = ttk.Frame(self.window, padding=10)
        main_frame.pack(fill="both", expand=True)

        ctrl_frame = ttk.LabelFrame(main_frame, text="Laboratory Controls")
        ctrl_frame.pack(fill="x", padx=5, pady=5)

        ttk.Button(ctrl_frame, text="Start Lab", command=self.start_lab).pack(side="left", padx=5, pady=5)
        ttk.Button(ctrl_frame, text="Stop Lab", command=self.stop_lab).pack(side="left", padx=5, pady=5)
        ttk.Button(ctrl_frame, text="Step Bit Pool", command=self.step_search).pack(side="left", padx=5, pady=5)
        ttk.Button(ctrl_frame, text="Solve Pool", command=self.solve_pool).pack(side="left", padx=5, pady=5)
        ttk.Button(ctrl_frame, text="Reset Pool", command=self.reset_search).pack(side="left", padx=5, pady=5)

        self.v_ir = tk.BooleanVar(value=False)
        ttk.Checkbutton(ctrl_frame, text="IR Thermal Heatmap", variable=self.v_ir,
                        command=lambda: self.ctl.update(ir_heatmap=self.v_ir.get())).pack(side="left", padx=10)

        # Serial-hex frame (receives hex; sends the DIFF command)
        target_frame = ttk.LabelFrame(main_frame, text="Serial-Hex Input")
        target_frame.pack(fill="x", padx=5, pady=5)

        ttk.Label(target_frame, text="Port:").pack(side="left", padx=(5, 2), pady=5)
        self.port_combo = ttk.Combobox(target_frame, values=SerialReceiver.list_ports(), width=10)
        self.port_combo.pack(side="left", padx=2, pady=5)
        ttk.Button(target_frame, text="⟳", width=3, command=self._refresh_ports).pack(side="left", padx=1, pady=5)

        ttk.Label(target_frame, text="Baud:").pack(side="left", padx=(8, 2), pady=5)
        self.baud_combo = ttk.Combobox(target_frame, values=[9600, 19200, 38400, 57600, 115200, 230400],
                                       width=7)
        self.baud_combo.set("115200")
        self.baud_combo.pack(side="left", padx=2, pady=5)

        self.btn_connect = ttk.Button(target_frame, text="Connect", command=self.toggle_connect)
        self.btn_connect.pack(side="left", padx=5, pady=5)

        ttk.Label(target_frame, text="RX Hex:").pack(side="left", padx=(10, 2), pady=5)
        self.v_hex = tk.StringVar(value="")
        self.e_hex = ttk.Entry(target_frame, width=24, textvariable=self.v_hex)
        self.e_hex.pack(side="left", padx=2, pady=5)
        self.btn_convert = ttk.Button(target_frame, text="Convert", command=self.convert_rx)
        self.btn_convert.pack(side="left", padx=2, pady=5)
        ttk.Button(target_frame, text="Copy", command=self.copy_conv).pack(side="left", padx=2, pady=5)

        ttk.Button(target_frame, text="Randomize Target", command=self.randomize_target).pack(side="left", padx=5, pady=5)

        self.v_force_serial = tk.BooleanVar(value=False)
        self.chk_force_serial = ttk.Checkbutton(
            target_frame, text="Force Serial Read", variable=self.v_force_serial,
            command=self._on_force_serial)
        self.chk_force_serial.pack(side="left", padx=10, pady=5)

        ttk.Label(target_frame, text="diff n:").pack(side="left", padx=(10, 2), pady=5)
        self.diff_spin = ttk.Spinbox(target_frame, from_=0, to=HASH_BITS, increment=1, width=5)
        self.diff_spin.set(8)
        self.diff_spin.pack(side="left", padx=2, pady=5)
        ttk.Button(target_frame, text="Send diff n", command=self.send_diff).pack(side="left", padx=5, pady=5)

        # Export row: oracle target (hex) -> text
        exp_frame = ttk.LabelFrame(main_frame, text="Export Oracle Target (hex to text)")
        exp_frame.pack(fill="x", padx=5, pady=5)
        ttk.Label(exp_frame, text="Format:").pack(side="left", padx=(5, 2), pady=5)
        self.export_combo = ttk.Combobox(exp_frame, state="readonly", width=24, values=EXPORT_CHOICES)
        self.export_combo.set(EXPORT_CHOICES[0])
        self.export_combo.pack(side="left", padx=2, pady=5)
        ttk.Button(exp_frame, text="Copy", command=self.copy_export).pack(side="left", padx=5, pady=5)
        ttk.Button(exp_frame, text="Save to File...", command=self.save_export).pack(side="left", padx=2, pady=5)

        # Viewport and registers
        display_frame = ttk.Frame(main_frame)
        display_frame.pack(fill="both", expand=True, padx=5, pady=5)

        cam_frame = ttk.LabelFrame(display_frame, text="Optoelectronic Circuit Camera Viewport")
        cam_frame.pack(side="left", padx=5, pady=5)
        self.cam_canvas = tk.Canvas(cam_frame, width=320, height=240, bg="black")
        self.cam_canvas.pack(padx=5, pady=5)
        self.cam_img_id = self.cam_canvas.create_image(0, 0, anchor="nw")

        right_panel = ttk.Frame(display_frame)
        right_panel.pack(side="right", fill="both", expand=True, padx=5, pady=5)

        reg_frame = ttk.LabelFrame(right_panel, text="Bit-Pooling Hardware Registers")
        reg_frame.pack(fill="x", padx=5, pady=5)

        self.reg_canvas = tk.Canvas(reg_frame, width=560, height=140, bg="#121414", highlightthickness=0)
        self.reg_canvas.pack(padx=5, pady=5)

        # Selectable / copyable text view of the registers (hex + binary)
        dump_frame = ttk.LabelFrame(reg_frame, text="Register Dump (select / copy)")
        dump_frame.pack(fill="x", padx=5, pady=(0, 5))

        self.txt_dump = tk.Text(dump_frame, width=58, height=7, wrap="char",
                                font=("Consolas", 9), bg="#121414", fg="#d2e0f0",
                                insertbackground="#d2e0f0", selectbackground="#38445c",
                                relief="flat", undo=False)
        self.txt_dump.pack(fill="x", padx=5, pady=5)
        self._dump_text = None
        self.txt_dump.bind("<Key>", self._dump_key)
        self.txt_dump.bind("<Button-1>", lambda e: self.txt_dump.focus_set())

        self._menu_target = self.txt_dump
        self.dump_menu = tk.Menu(self.window, tearoff=0)
        self.dump_menu.add_command(label="Copy", command=self._copy_selection)
        self.dump_menu.add_command(label="Select All", command=self._select_all_dump)
        for seq in ("<Button-3>", "<Button-2>", "<Control-Button-1>"):
            self.txt_dump.bind(seq, self._dump_popup)

        dump_btns = ttk.Frame(dump_frame)
        dump_btns.pack(fill="x", padx=5, pady=(0, 5))
        ttk.Button(dump_btns, text="Copy Hex", command=lambda: self._copy_registers("hex")).pack(side="left", padx=2)
        ttk.Button(dump_btns, text="Copy Binary", command=lambda: self._copy_registers("bin")).pack(side="left", padx=2)
        ttk.Button(dump_btns, text="Copy All", command=lambda: self._copy_registers("all")).pack(side="left", padx=2)

        # Oracle decode: pooled bits -> de-padded message / header / nonce / hash / POW line
        dec_frame = ttk.LabelFrame(reg_frame, text="Oracle Decode: depadded pooled bits (select / copy)")
        dec_frame.pack(fill="x", padx=5, pady=(0, 5))

        self.txt_dec = tk.Text(dec_frame, width=70, height=13, wrap="char",
                               font=("Consolas", 9), bg="#121414", fg="#d2e0f0",
                               insertbackground="#d2e0f0", selectbackground="#38445c",
                               relief="flat", undo=False)
        self.txt_dec.pack(fill="x", padx=5, pady=5)
        self.txt_dec.bind("<Key>", self._dump_key)
        self.txt_dec.bind("<Button-1>", lambda e: self.txt_dec.focus_set())
        for seq in ("<Button-3>", "<Button-2>", "<Control-Button-1>"):
            self.txt_dec.bind(seq, self._dump_popup)

        dec_btns = ttk.Frame(dec_frame)
        dec_btns.pack(fill="x", padx=5, pady=(0, 5))
        for label, key in (("Copy Message", "text"), ("Copy Nonce", "nonce"), ("Copy Hash", "hash"),
                           ("Copy POW Line", "line"), ("Copy All", "all")):
            ttk.Button(dec_btns, text=label,
                       command=lambda k=key: self._copy_decode(k)).pack(side="left", padx=2)

        self.lbl_status = ttk.Label(reg_frame, text="Status: IDLE", font=("Consolas", 11), foreground="#00e5ff")
        self.lbl_status.pack(anchor="w", padx=10, pady=(5, 0))
        self.lbl_serial = ttk.Label(reg_frame, text="Serial: disconnected | RX: (none)",
                                    font=("Consolas", 10), foreground="#88a0c0")
        self.lbl_serial.pack(anchor="w", padx=10, pady=(0, 5))

        set_frame = ttk.LabelFrame(right_panel, text="Pooling & Algorithm Settings")
        set_frame.pack(fill="both", expand=True, padx=5, pady=5)

        ttk.Label(set_frame, text="Pooling Operator:").grid(row=0, column=0, sticky="w", padx=5, pady=5)
        self.op_combo = ttk.Combobox(set_frame, values=["POPCOUNT", "AND", "OR", "XOR", "MAJORITY"], state="readonly")
        self.op_combo.set("POPCOUNT")
        self.op_combo.grid(row=0, column=1, padx=5, pady=5)
        self.op_combo.bind("<<ComboboxSelected>>", self._update_pool_op)

        ttk.Label(set_frame, text="Kernel Size:").grid(row=1, column=0, sticky="w", padx=5, pady=5)
        self.kernel_spin = ttk.Spinbox(set_frame, from_=2, to=8, increment=2, width=5, command=self._update_kernel)
        self.kernel_spin.set(4)
        self.kernel_spin.grid(row=1, column=1, sticky="w", padx=5, pady=5)

    # ---------------------------------------------------------------- controls
    def start_lab(self):
        if self.thread is not None and self.thread.is_alive():
            return
        self.ctl["stop"] = False
        self.thread = SimThread(0, self.ctl, self.q, self.engine)
        self.thread.start()

    def stop_lab(self):
        self.ctl["stop"] = True

    def step_search(self):
        self.engine.step()
        self._draw_current()

    def solve_pool(self):
        """Run every remaining bit-pool step (MSB first) until the target is calculated."""
        while not self.engine.converged and self.engine.step_count < self.engine.bit_depth:
            self.engine.step()
        self._draw_current()

    def reset_search(self):
        self._load_target(None)
        self._clear_rx()

    def randomize_target(self):
        self._load_target(None)
        self._clear_rx()

    def _load_target(self, value):
        self.engine.reset(value)
        self.ctl["serial_loaded"] = False
        self._draw_current()

    # ---------------------------------------------------------------- serial hex
    def _refresh_ports(self):
        self.port_combo["values"] = SerialReceiver.list_ports()

    def toggle_connect(self):
        if self.serial.is_open:
            self.serial.close()
            self.btn_connect.config(text="Connect")
            self._refresh_serial_label()
            return
        name = self.port_combo.get().strip()
        if not name:
            messagebox.showerror("Serial Error", "Select a serial port first.")
            return
        try:
            self.serial.open(name, int(self.baud_combo.get()))
        except Exception as e:
            messagebox.showerror("Serial Error", str(e))
            return
        self.btn_connect.config(text="Disconnect")
        self._refresh_serial_label()

    def _clear_rx(self):
        self.mine_stop.set()                    # cancel any running Convert search
        self.mining_conv = False
        self.rx_header = ""
        self.rx_nonce = None
        self.rx_padded = b""
        self.rx_difficulty = None
        self.rx_line = ""
        self.convert_mode = False
        self.extractor.reset()
        self._show_rx()
        self._refresh_serial_label()

    def _on_force_serial(self):
        if self.v_force_serial.get():
            self._apply_rx()
        else:
            self.ctl["serial_loaded"] = False
            self._draw_current()

    def send_diff(self):
        """Send 'diff <n>' to the device using the value in the diff spinbox."""
        try:
            n = int(self.diff_spin.get())
        except ValueError:
            messagebox.showerror("Serial Error", "Difficulty must be an integer.")
            return
        if not 0 <= n <= HASH_BITS:
            messagebox.showerror("Serial Error", f"Difficulty must be 0-{HASH_BITS}.")
            return
        if not self.serial.is_open:
            messagebox.showerror("Serial Error", "Connect to a serial port first.")
            return
        if self.serial.send_diff(n):
            self._refresh_serial_label(f"TX: diff {n}")
        else:
            self.btn_connect.config(text="Connect")
            self._refresh_serial_label("(send failed)")

    def _set_header(self, text: str):
        if text != self.rx_header:              # new header: any old nonce / block is stale
            self.rx_nonce = None
            self.rx_padded = b""
        self.rx_header = text

    def _show_rx(self):
        """RX Hex box: the converted POW line in convert mode, otherwise the raw header."""
        if self.convert_mode and self.rx_line:
            self.v_hex.set(self.rx_line)
        else:
            self.v_hex.set(self.rx_header)
        self.e_hex.icursor(0)
        self.e_hex.xview_moveto(0)
        self.btn_convert.config(
            text="Cancel" if self.mining_conv else ("Show Raw" if self.convert_mode else "Convert"))

    def convert_rx(self):
        """Convert the RX Hex text into the sketch's POW line (searches the nonce from 0)."""
        if self.mining_conv:                    # pressed while searching: cancel
            self.mine_stop.set()
            self._refresh_serial_label("(cancelling...)")
            return
        if self.convert_mode:                   # pressed while converted: back to raw header
            self.convert_mode = False
            self._show_rx()
            self._refresh_serial_label("(showing raw header)")
            return

        header = self.v_hex.get().strip() or self.rx_header
        if header.upper().startswith("POW:"):
            messagebox.showinfo("Convert", "RX Hex already holds a POW line.")
            return
        if not header:
            messagebox.showerror("Convert", "RX Hex is empty: paste a header, or use Force Serial Read.")
            return
        if len(header) > MAX_HEADER:
            messagebox.showerror("Convert", f"Header is {len(header)} characters; the sketch allows {MAX_HEADER}.")
            return
        try:
            diff = int(self.diff_spin.get())
        except ValueError:
            messagebox.showerror("Convert", "Difficulty must be an integer.")
            return
        if not 0 <= diff <= HASH_BITS:
            messagebox.showerror("Convert", f"Difficulty must be 0-{HASH_BITS}.")
            return
        if diff > 26 and not messagebox.askokcancel(
                "Convert", f"Difficulty {diff} may take a very long time in Python. Continue?"):
            return

        self.mine_stop = threading.Event()
        self.mining_conv = True
        self._set_header(header)
        self._show_rx()                         # button becomes Cancel
        self._refresh_serial_label(f"(searching nonce, diff {diff}...)")
        threading.Thread(target=self._mine_worker, args=(header, diff, self.mine_stop),
                         daemon=True).start()

    def _mine_worker(self, header, diff, stop):
        res = mine_pow(header, diff, stop)
        self.q.put(("mined", dict(header=header, result=res, stop=stop)))

    def _on_mined(self, d):
        if d["stop"] is not self.mine_stop:     # result of an older, replaced search
            return
        self.mining_conv = False
        nonce, digest, hashes = d["result"]
        if nonce is None:
            self._show_rx()
            self._refresh_serial_label("(convert cancelled)")
            return
        self._set_header(d["header"])
        self.rx_nonce = nonce
        self.rx_padded = sha_pad(d["header"].encode("utf-8") + str(nonce).encode("ascii"))
        self.rx_line = build_pow_line(d["header"], nonce, digest)
        self.convert_mode = True
        self._show_rx()
        self._refresh_serial_label(f"(converted: nonce={nonce}, {hashes} hashes)")

    # ---------------------------------------------------------------- export (oracle hex -> text)
    def _export_text(self):
        """Oracle target (calculated by the bit pool) -> de-padded message text / hex."""
        o = self.engine.oracle
        if not (o.is_done or self.ctl.get("serial_loaded")):
            messagebox.showwarning(
                "Export", "Target is still classified. Run all bit-pool steps first "
                          "(Step Bit Pool / motion triggers / Solve Pool).")
            return None

        hex_str = pad_hex(o._target, self.engine.bit_depth // 8)    # padded block(s)
        raw = bytes.fromhex(hex_str)
        try:
            text = sha_unpad(raw).decode("utf-8", "replace")        # depad
        except ValueError:                                          # not a SHA block
            text = raw.strip(b"\x00").decode("utf-8", "replace")

        selection = self.export_combo.get()
        if selection == "Hex":
            return hex_str
        if selection == "Hex + Text":
            return f"Hex: {hex_str}\nText: {text}"
        return text

    def copy_export(self):
        """Copy the oracle target (as hex / text) to the clipboard."""
        text = self._export_text()
        if text is None:
            return
        try:
            self.window.clipboard_clear()
            self.window.clipboard_append(text)
            self.window.update_idletasks()
            self._refresh_serial_label(f"(copied {self.export_combo.get().lower()})")
        except tk.TclError as e:
            messagebox.showerror("Copy Error", str(e))

    def save_export(self):
        """Save the oracle target (as hex / text) to a file."""
        text = self._export_text()
        if text is None:
            return

        selection = self.export_combo.get()
        filename = {"Text (decoded from hex)": "oracle_text.txt",
                    "Hex": "oracle_hex.txt",
                    "Hex + Text": "oracle_hex_text.txt"}.get(selection, "oracle_export.txt")

        path = filedialog.asksaveasfilename(
            title="Save Oracle Export",
            defaultextension=".txt",
            initialfile=filename,
            filetypes=[("Text files", "*.txt"), ("All files", "*.*")])
        if not path:
            return

        try:
            with open(path, "w", encoding="utf-8", newline="\n") as f:
                f.write(text)
                if not text.endswith("\n"):
                    f.write("\n")
            saved_name = path.replace("\\", "/").rsplit("/", 1)[-1]
            self._refresh_serial_label(f"(saved {saved_name})")
            messagebox.showinfo("Export Successful", f"Successfully saved:\n{path}")
        except (OSError, UnicodeError) as e:
            messagebox.showerror("Save Error", str(e))

    def copy_conv(self):
        text = self.v_hex.get()
        if not text:
            return
        self.window.clipboard_clear()
        self.window.clipboard_append(text)
        self._refresh_serial_label("(copied RX Hex)")

    def _target_message(self) -> bytes:
        """Bytes the oracle must reveal: the minimally padded header (+ nonce) message."""
        if self.rx_padded:
            return self.rx_padded               # the POW line's padded message
        if not self.rx_header:
            return b""
        return sha_pad(self.rx_header.encode("utf-8"))

    def _apply_rx(self):
        """Load the received message (padded) as the oracle target and unmask TARGET."""
        if not self.rx_header:
            boxed = self.v_hex.get().strip()
            if boxed and not boxed.upper().startswith("POW:"):
                self._set_header(boxed)
        raw = self._target_message()
        if not raw:
            return
        self.engine.reset(int.from_bytes(raw, "big"), len(raw) * 8)
        self.ctl["serial_loaded"] = True
        self._refresh_serial_label(f"-> {len(raw)}B block")
        self._draw_current()

    def _refresh_serial_label(self, note=""):
        conn = f"{self.serial.port_name} @{self.serial.baud}" if self.serial.is_open else "disconnected"
        if self.rx_header:
            h = self.rx_header
            rx = h if len(h) <= 20 else f"{h[:8]}...{h[-8:]}"
            if self.rx_difficulty is not None:
                rx += f" d={self.rx_difficulty}"
        else:
            rx = "(none)"
        self.lbl_serial.config(text=f"Serial: {conn} | RX: {rx} {note}".rstrip())

    # ---------------------------------------------------------------- settings
    def _update_pool_op(self, _event):
        op = self.op_combo.get()
        self.engine.pool_op = op
        self.engine.oracle.pool_op = op
        self._draw_current()

    def _update_kernel(self):
        try:
            k = int(self.kernel_spin.get())
        except ValueError:
            return
        self.engine.kernel_size = k
        self.engine.oracle.kernel_size = k
        self._draw_current()

    # ---------------------------------------------------------------- drawing
    def _draw_current(self):
        e = self.engine
        e._update_registers()
        exposed = e.converged or self.ctl.get("serial_loaded", False)
        self._draw_bit_rows(e.oracle._target if exposed else 0,
                            e.current_guess, e.pooled_register, exposed)
        self.lbl_status.config(text=f"Status: {e.last_status} | Bit Step: {e.step_count}/{e.bit_depth}")

    def _draw_bit_rows(self, target_val, guess_val, pooled_val, exposed):
        self._update_dump(target_val, guess_val, pooled_val, exposed)
        self._update_decode()
        self.reg_canvas.delete("all")
        e = self.engine
        depth = e.bit_depth
        width = depth // 4
        pooled_digits = (len(range(0, depth, e.stride)) + 3) // 4
        revealed = f"{guess_val:0{width}X}"[: e.step_count // 4].ljust(width, ".")

        rows = [
            ("TARGET", "[HIDDEN]" if not exposed else f"{target_val:0{width}X}", "#00e676"),
            ("GUESS ", revealed, "#ffb300"),
            ("POOLED", f"{pooled_val:0{pooled_digits}X}", "#b388ff"),
        ]

        y = 14
        for label, text, color in rows:
            self.reg_canvas.create_text(10, y, text=label, fill="#88a0c0", anchor="w",
                                        font=("Consolas", 10, "bold"))
            for i in range(0, len(text), 64):               # wrap: 128 hex chars per block
                self.reg_canvas.create_text(80, y, text=text[i:i + 64], fill=color,
                                            anchor="w", font=("Consolas", 9))
                y += 15
            y += 10

        self.reg_canvas.create_text(10, y, anchor="w", fill="#d2e0f0", font=("Consolas", 9),
                                    text=f"{depth}-bit register | {e.step_count}/{depth} reconstruction steps")
        y += 14
        if int(self.reg_canvas.cget("height")) != y:
            self.reg_canvas.config(height=y)

    # ---------------------------------------------------------------- register dump (copy / paste)
    def _register_strings(self, target_val, guess_val, pooled_val, exposed):
        """Return {name: (hex, bin)} for each register; target is masked until exposed."""
        bd = self.engine.bit_depth
        digits = (bd + 3) // 4
        out = {}
        for name, val, hidden in (("TARGET", target_val, not exposed),
                                  ("GUESS", guess_val, False),
                                  ("POOLED", pooled_val, False)):
            if hidden:
                out[name] = ("[HIDDEN]", "[HIDDEN]")
            else:
                out[name] = (f"{val:0{digits}X}", f"{val:0{bd}b}")
        self._last_regs = out
        return out

    def _update_dump(self, target_val, guess_val, pooled_val, exposed):
        regs = self._register_strings(target_val, guess_val, pooled_val, exposed)
        lines = []
        for name, (h, b) in regs.items():
            lines.append(f"{name} HEX: {h}")
            lines.append(f"{name} BIN: {b}")
        text = "\n".join(lines)
        if text == self._dump_text:          # unchanged: keep the user's selection
            return
        self._dump_text = text
        self.txt_dump.delete("1.0", "end")
        self.txt_dump.insert("1.0", text)

    def _dump_key(self, event):
        """Read-only: allow copy, select-all and navigation; block everything else."""
        ctrl = (event.state & 0x4) != 0
        if ctrl and event.keysym.lower() in ("c", "a", "insert"):
            if event.keysym.lower() == "a":
                self._select_all_dump(event.widget)
                return "break"
            return None
        if event.keysym in ("Left", "Right", "Up", "Down", "Home", "End",
                            "Prior", "Next", "Shift_L", "Shift_R", "Control_L", "Control_R"):
            return None
        return "break"

    def _select_all_dump(self, widget=None):
        widget = widget or self._menu_target
        widget.tag_add("sel", "1.0", "end-1c")
        widget.focus_set()

    def _dump_popup(self, event):
        self._menu_target = event.widget
        event.widget.focus_set()
        self.dump_menu.tk_popup(event.x_root, event.y_root)
        return "break"

    def _copy_selection(self):
        try:
            text = self._menu_target.get("sel.first", "sel.last")
        except tk.TclError:
            return
        self.window.clipboard_clear()
        self.window.clipboard_append(text)

    # ---------------------------------------------------------------- oracle decode (depad)
    def _update_decode(self):
        """Decode the pooled (guess) bits: depad, then message / header / nonce / hash."""
        e = self.engine
        d = decode_pool_bits(e.current_guess, e.bit_depth, e.step_count, self.rx_header)
        none = "[PENDING]"

        try:
            diff = int(self.diff_spin.get())
        except (ValueError, tk.TclError):
            diff = None
        zb = d["zero_bits"]
        if zb is None:
            zero_line = none
        else:
            met = "" if diff is None else (" (meets)" if zb >= diff else " (below)")
            zero_line = f"{zb} bits, difficulty {diff if diff is not None else '?'}{met}"

        if d["status"] == "INVALID PADDING":
            msg_line = "[no valid SHA-256 padding: not a hashed message]"
        else:
            msg_line = repr(d["text"]) if d["text"] else none

        nbytes = d["depth"] // 8
        lines = [
            f"POOL: {d['steps']}/{d['depth']} bits  [{d['status']}]",
            f"POOLED HEX ({nbytes}B): {d['pooled_hex']}",
            f"LENGTH FIELD: {d['length_bits'] if d['length_bits'] is not None else none}"
            + (" bits" if d["length_bits"] is not None else ""),
            f"MESSAGE (depadded): {msg_line}",
            f"HEADER: {d['header'] or none}",
            f"NONCE: {d['nonce'] if d['nonce'] else none}",
            f"HASH: {d['hash_hex'] or none}",
            f"ZERO BITS: {zero_line}",
            f"POW LINE: {d['line'] or none}",
        ]
        text = "\n".join(lines)
        self._dec_parts = dict(text=d["text"], nonce=d["nonce"] or "", hash=d["hash_hex"],
                               line=d["line"], all=text)
        if text == self._dec_text:               # unchanged: keep the user's selection
            return
        self._dec_text = text
        self.txt_dec.delete("1.0", "end")
        self.txt_dec.insert("1.0", text)

    def _copy_decode(self, key):
        text = self._dec_parts.get(key, "")
        if not text:
            return
        self.window.clipboard_clear()
        self.window.clipboard_append(text)
        self._refresh_serial_label(f"(copied decode {key})")

    def _copy_registers(self, mode):
        regs = getattr(self, "_last_regs", None)
        if not regs:
            return
        lines = []
        for name, (h, b) in regs.items():
            if mode in ("hex", "all"):
                lines.append(f"{name} HEX: {h}" if mode == "all" else f"{name}: {h}")
            if mode in ("bin", "all"):
                lines.append(f"{name} BIN: {b}" if mode == "all" else f"{name}: {b}")
        self.window.clipboard_clear()
        self.window.clipboard_append("\n".join(lines))
        self._refresh_serial_label(f"(copied {mode})")

    # ---------------------------------------------------------------- polling
    def _poll(self):
        # Receive serial hex; always shown, only applied while Force Serial Read is on
        new = self.serial.poll()
        if new:
            for msg in self.extractor.feed(new):
                kind = msg["kind"]
                if kind == "POW":
                    self._set_header(msg["header"])
                    self.rx_nonce = msg["nonce"]
                    self.rx_padded = msg["padded_msg"]      # the device's padded message
                    self.rx_line = msg["line"]
                    self._show_rx()
                    self._refresh_serial_label(f"POW nonce={msg['nonce']}")
                    if self.v_force_serial.get():
                        self._apply_rx()
                elif kind == "HEADER":
                    if msg["header"] != self.rx_header:
                        self.rx_line = ""
                        self.convert_mode = False
                    self._set_header(msg["header"])
                    self._show_rx()
                    self._refresh_serial_label()
                    if self.v_force_serial.get():
                        self._apply_rx()
                elif kind in ("STATUS", "BAD"):
                    self._refresh_serial_label(f"[{kind}: {msg['text'][:24]}]")
        elif self.btn_connect.cget("text") == "Disconnect" and not self.serial.is_open:
            self.btn_connect.config(text="Connect")
            self._refresh_serial_label("(port lost)")

        try:
            for _ in range(100):
                ev = self.q.get_nowait()
                if ev[0] == "frame":
                    d = ev[1]
                    self.photo = ppm_photo(d["preview"])
                    self.cam_canvas.itemconfig(self.cam_img_id, image=self.photo)
                    exposed = d["converged"] or self.ctl.get("serial_loaded", False)
                    self._draw_bit_rows(d["target"], d["guess"], d["pooled"], exposed)
                    self.lbl_status.config(
                        text=f"Status: {d['status']} | Bit Step: {d['steps']}/{self.engine.bit_depth}")
                elif ev[0] == "mined":
                    self._on_mined(ev[1])
                elif ev[0] == "error":
                    messagebox.showerror("Camera Error", ev[1])
        except queue.Empty:
            pass
        self.window.after(30, self._poll)

    def _close(self):
        self.ctl["stop"] = True
        self.serial.close()
        self.window.destroy()


if __name__ == "__main__":
    root = tk.Tk()
    app = App(root)
    root.geometry("1200x1000")
    root.mainloop()
