#!/usr/bin/env python3
"""
predict_number.py - infer the hidden "isolated number" from a camera.

Author: George Wagenknecht

What it does
------------
The TimeCodeLatch holds an n-bit number and the 74HC74 flip-flop emits one bit
per clock edge (MSB first) on SELECT. If SELECT drives something the camera can
see - an LED, or a patch on an LCD screen - the number is not guessed, it is
*recovered* from the light:

  1. grab frames and reduce a region of interest (ROI) to one brightness value
  2. normalise it (removes auto-exposure drift and slow brightness changes)
  3. recover the clock frequency and phase from the brightness edges
  4. sample one bit in the middle of every clock slot
  5. find the frame boundary with a preamble (Barker-7 by default)
  6. majority-vote the repeated frames and pool the bits into hex

LCD screens
-----------
Filming an LCD is harder than filming an LED: pixels respond slowly (and unequally
for rising and falling), the backlight and rolling shutter add banding, and the
camera's auto-exposure drifts. This version handles those by normalising against
a rolling envelope, finding edges without hard thresholds, and treating rising and
falling edges separately. Pair it with lcd_transmitter.py to put the signal on a screen.

Usage
-----
  python predict_number.py --synthetic --lcd --secret 0xA5 --nbits 8   # simulated LCD
  python predict_number.py --cam 0 --nbits 8                           # webcam, auto ROI
  python predict_number.py --cam 0 --nbits 8 --select                  # pick ROI with mouse
  python predict_number.py --cam recording.mp4 --nbits 8 --roi 400,220,120,120

Camera mode needs:  pip install opencv-python numpy

Signal format expected (repeated continuously):
  [ preamble bits | nbits data bits, MSB first ]   one bit per clock period
"""
import argparse
import collections
import math
import sys
import time

import numpy as np

PREAMBLE = "1110010"  # Barker-7: sharp autocorrelation, easy to find in a stream


# --------------------------------------------------------------------------
# Transmitter side (used by the synthetic camera)
# --------------------------------------------------------------------------
class TimeCodeLatch:
    """Latch holding the isolated number; outputs one bit (MSB first) per clock"""

    def __init__(self, value, nbits):
        self.value, self.nbits = value, nbits

    def bit(self, slot):
        return (self.value >> (self.nbits - 1 - slot)) & 1


class DFlipFlop74HC74:
    """Rising-edge D flip-flop: Q <- D on CLK, Qbar is the complement"""

    def __init__(self):
        self.q = 0

    @property
    def qbar(self):
        return 1 - self.q

    def clock(self, d):
        self.q = d & 1
        return self.q


class SyntheticLED:
    """Simulates the optical SELECT output seen by a camera.

    Includes: unknown start phase, clock skew between device and camera,
    response time, ambient light, slow drift, sensor noise, dropped frames and
    optional random bit errors. With lcd=True it also adds typical LCD-capture
    problems: slow, asymmetric pixel response, refresh/banding ripple, and
    auto-exposure wander plus a sudden exposure step.
    """

    def __init__(self, secret, nbits, clock_hz, preamble, clock_skew, bit_error, seed, lcd=False):
        self.rng = np.random.default_rng(seed)
        self.latch = TimeCodeLatch(secret, nbits)
        self.ff = DFlipFlop74HC74()
        pre = [int(c) for c in preamble]
        self.stream = pre + [self.latch.bit(i) for i in range(nbits)]
        self.L = len(self.stream)
        self.period = 1.0 / (clock_hz * (1.0 + clock_skew))
        self.t0 = self.rng.uniform(0, self.period) + 0.35  # unknown phase
        self.bit_error, self.lcd = bit_error, lcd
        self.n_done = -1
        self.level, self.last_t, self.tau = 0.0, 0.0, 0.012
        self.ambient, self.gain, self.noise = 40.0, 110.0, 6.0

    def brightness(self, t):
        n = int(math.floor((t - self.t0) / self.period))
        while self.n_done < n:  # process every clock edge that has passed
            self.n_done += 1
            d = self.stream[self.n_done % self.L]
            if self.rng.random() < self.bit_error:
                d ^= 1
            self.ff.clock(d)
        dt = max(0.0, t - self.last_t)
        self.last_t = max(t, self.last_t)
        target = float(self.ff.q)
        tau = self.tau
        if self.lcd:
            tau = 0.030 if target > self.level else 0.018  # slow rise, quicker fall
        self.level += (target - self.level) * (1 - math.exp(-dt / tau))
        if self.lcd:
            g = 1 + 0.25 * math.sin(2 * math.pi * 0.11 * t) - (0.2 if t > 5 else 0.0)
            ripple = 0.05 * self.gain * math.sin(2 * math.pi * 29.7 * t)
            v = g * (self.ambient + self.gain * self.level) + ripple
            v += self.rng.normal(0, 1.5 * self.noise)
        else:
            drift = 8.0 * math.sin(2 * math.pi * 0.13 * t)
            v = self.ambient + self.gain * self.level + drift + self.rng.normal(0, self.noise)
        return float(np.clip(v, 0, 255))


# --------------------------------------------------------------------------
# Camera
# --------------------------------------------------------------------------
class Camera:
    """Yields (timestamp_seconds, ROI brightness) per frame.

    source    : camera index ("0"), or a video file path
    synthetic : if True, use SyntheticLED instead of hardware
    """

    def __init__(self, source, synthetic, sim=None, fps=30.0, roi=None, select=False,
                 manual_exposure=False, exposure=None, debug_roi="roi_debug.png"):
        self.synthetic, self.sim, self.fps, self.roi = synthetic, sim, fps, roi
        self.debug_roi = debug_roi
        if synthetic:
            return
        try:
            import cv2
        except ImportError:
            sys.exit("OpenCV is required for camera mode:  pip install opencv-python")
        self.cv2 = cv2
        self.is_file = not str(source).isdigit()
        self.cap = cv2.VideoCapture(source if self.is_file else int(source))
        if not self.cap.isOpened():
            sys.exit(f"Could not open camera/video source: {source}")
        if self.is_file:
            self.fps = self.cap.get(cv2.CAP_PROP_FPS) or fps
        else:
            self.cap.set(cv2.CAP_PROP_FPS, fps)
            self.fps = self.cap.get(cv2.CAP_PROP_FPS) or fps
            if manual_exposure or exposure is not None:
                # Best effort: 0.25 = manual on V4L2/most backends; ignored where unsupported.
                self.cap.set(cv2.CAP_PROP_AUTO_EXPOSURE, 0.25)
                if exposure is not None:
                    self.cap.set(cv2.CAP_PROP_EXPOSURE, exposure)
        if self.roi is None:
            self.roi = self._select_roi() if select else self._auto_roi()
        print(f"[camera] {self.fps:.1f} fps, ROI x,y,w,h = {self.roi}")

    def _select_roi(self):
        ok, frame = self.cap.read()
        if not ok:
            sys.exit("No frame received from camera.")
        r = self.cv2.selectROI("Select the LED / screen patch, then press ENTER", frame,
                               showCrosshair=True)
        self.cv2.destroyAllWindows()
        if r[2] == 0 or r[3] == 0:
            sys.exit("No ROI selected.")
        self._rewind()
        return tuple(int(x) for x in r)

    def _auto_roi(self, seconds=4.0):
        """Find the blinking region: highest temporal variance after removing global
        exposure changes, then take the whole connected blob (an LCD patch is big)."""
        cv2, small, last = self.cv2, [], None
        for _ in range(int(self.fps * seconds)):
            ok, frame = self.cap.read()
            if not ok:
                break
            last = frame
            g = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
            small.append(cv2.resize(g, (160, 120), interpolation=cv2.INTER_AREA).astype(np.float32))
        if len(small) < 10:
            sys.exit("Not enough frames to find the blinking region; use --roi or --select.")
        arr = np.stack(small)
        arr -= np.median(arr, axis=(1, 2), keepdims=True)  # remove global exposure wander
        std = cv2.GaussianBlur(np.std(arr, axis=0), (0, 0), 1.5)
        mask = (std > 0.55 * std.max()).astype(np.uint8)
        _, labels, stats, _ = cv2.connectedComponentsWithStats(mask)
        y, x = np.unravel_index(np.argmax(std), std.shape)
        bx, by, bw, bh = stats[labels[y, x]][:4]
        # shrink to the inner 70% so slow pixel edges and borders are excluded
        bx, by = bx + 0.15 * bw, by + 0.15 * bh
        bw, bh = max(2.0, 0.7 * bw), max(2.0, 0.7 * bh)
        sx, sy = last.shape[1] / 160.0, last.shape[0] / 120.0
        roi = (int(bx * sx), int(by * sy), int(max(8, bw * sx)), int(max(8, bh * sy)))
        if self.debug_roi:
            vis = last.copy()
            cv2.rectangle(vis, (roi[0], roi[1]), (roi[0] + roi[2], roi[1] + roi[3]), (0, 255, 0), 2)
            cv2.imwrite(self.debug_roi, vis)
            print(f"[camera] auto-ROI preview saved to {self.debug_roi} - check it is on the signal")
        self._rewind()
        return roi

    def _rewind(self):
        if self.is_file:
            self.cap.set(self.cv2.CAP_PROP_POS_FRAMES, 0)

    def frames(self, duration):
        if self.synthetic:
            rng, k = self.sim.rng, 0
            while True:
                t = k / self.fps + rng.normal(0, 0.002)
                k += 1
                if t > duration:
                    return
                if rng.random() < 0.02:  # dropped frame
                    continue
                yield t, self.sim.brightness(max(t, 0.0))
        else:
            cv2, idx, start = self.cv2, 0, time.perf_counter()
            x, y, w, h = self.roi
            while True:
                ok, frame = self.cap.read()
                if not ok:
                    return
                t = idx / self.fps if self.is_file else time.perf_counter() - start
                idx += 1
                if t > duration:
                    return
                g = cv2.cvtColor(frame[max(y, 0):y + h, max(x, 0):x + w], cv2.COLOR_BGR2GRAY)
                yield t, float(g.mean())

    def release(self):
        if not self.synthetic:
            self.cap.release()


# --------------------------------------------------------------------------
# Decoder
# --------------------------------------------------------------------------
def normalise(t, v, win_s=3.0):
    """Scale brightness to ~0..1 using a rolling 5th/95th-percentile envelope.
    Removes auto-exposure drift, gain steps and slow backlight changes."""
    n = len(v)
    fs = (n - 1) / (t[-1] - t[0])
    w = max(15, int(win_s * fs)) | 1
    gl, gh = np.percentile(v, [5, 95])
    lo, hi = np.empty(n), np.empty(n)
    for i in range(n):
        seg = v[max(0, i - w // 2): i + w // 2 + 1]
        lo[i], hi[i] = np.percentile(seg, [5, 95])
    k = max(3, int(0.5 * fs))
    ker = np.ones(k) / k
    smooth = lambda a: np.convolve(np.pad(a, (k // 2, k - 1 - k // 2), mode="edge"), ker, mode="valid")
    lo, hi = smooth(lo), smooth(hi)
    span = np.maximum(hi - lo, 0.35 * (gh - gl))
    return (v - lo) / span


def edge_events(t, x):
    """Soft edge detection: weights for rising and falling changes between frames,
    with the noise floor estimated robustly (no hard binary threshold)."""
    d = np.diff(x)
    tm = 0.5 * (t[1:] + t[:-1])
    sigma = 1.4826 * np.median(np.abs(d - np.median(d)))
    thr = float(np.clip(3 * sigma, 0.10, 0.30))
    return tm, np.clip(d - thr, 0, None), np.clip(-d - thr, 0, None)


def recover_clock(tm, wr, wf, f0, span, duration):
    """Find f, phase so that edges fall at (k + phase)/f. Rising and falling edges are
    scored separately because LCD pixels respond with different delays.
    Returns (f, phase, lock) or None."""
    keep = (wr + wf) > 0
    if keep.sum() < 6:
        return None
    tm, wr, wf = tm[keep], wr[keep], wf[keep]
    tot = wr.sum() + wf.sum()

    def score(freqs):
        E = np.exp(2j * np.pi * np.outer(freqs, tm))
        zr, zf = E @ wr, E @ wf
        return (np.abs(zr) + np.abs(zf)) / tot, zr, zf

    step = 0.05 / duration  # keeps phase error under ~0.05 cycle across the capture
    freqs = np.arange(f0 * (1 - span), f0 * (1 + span) + step, step)
    s, _, _ = score(freqs)
    f = freqs[int(np.argmax(s))]
    fine = np.linspace(f - step, f + step, 41)
    s, zr, zf = score(fine)
    i = int(np.argmax(s))
    phase = (np.angle(zr[i] + zf[i]) / (2 * np.pi)) % 1.0
    return float(fine[i]), float(phase), float(s[i])


def sample_slots(t, x, f, phase, thr=0.5, span=1.0):
    """One decision per clock slot, from the settled part (30%-85%) of the slot."""
    T = 1.0 / f
    kmin = int(math.ceil(t[0] * f - phase)) + 1
    kmax = int(math.floor(t[-1] * f - phase)) - 1
    bits, margins = [], []
    for k in range(kmin, kmax):
        b = (k + phase) * T
        i0, i1 = np.searchsorted(t, [b + 0.30 * T, b + 0.85 * T])
        if i1 <= i0:
            bits.append(-1)
            margins.append(0.0)
            continue
        m = x[i0:i1].mean()
        bits.append(int(m > thr))
        margins.append(min(1.0, abs(m - thr) / (span / 2)))
    return np.array(bits), np.array(margins)


def align_and_vote(bits, nbits, preamble):
    """Find frame start with the preamble, majority-vote repeated frames."""
    pre = np.array([int(c) for c in preamble], dtype=int)
    L = len(pre) + nbits
    good = bits >= 0
    idx = np.arange(len(bits))
    cands = []
    for off in range(L):
        pos = (idx + off) % L
        m = np.array([bits[(pos == p) & good].mean() if np.any((pos == p) & good) else 0.5
                      for p in range(L)])
        maj = (m >= 0.5).astype(int)
        if len(pre) and not np.array_equal(maj[:len(pre)], pre):
            continue
        cons = m[len(pre):]
        agree = np.maximum(cons, 1 - cons)
        value = int("".join(map(str, maj[len(pre):])), 2)
        cands.append({"value": value, "bit_conf": agree, "conf": float(agree.mean()),
                      "frames": int(len(bits) // L)})
    cands.sort(key=lambda c: -c["conf"])
    return cands


def decode(t, v, clock, nbits, preamble, wide=False):
    gl, gh = np.percentile(v, [5, 95])
    info = {"span": float(gh - gl)}
    if gh - gl < 8:
        info["error"] = (f"No visible modulation (brightness range {gh - gl:.1f}). "
                         "The ROI is probably not on the blinking region, or nothing is blinking.")
        return info
    x = normalise(t, v)
    tm, wr, wf = edge_events(t, x)
    D = t[-1] - t[0]
    info["events"] = int(((wr + wf) > 0).sum())
    res = None if wide else recover_clock(tm, wr, wf, clock, 0.04, D)
    if res is None or res[2] < 0.35:
        wide_res = recover_clock(tm, wr, wf, clock, 0.5, D)  # clock not near nominal? search wide
        if wide_res is not None and (res is None or wide_res[2] > res[2]):
            res = wide_res
    if res is None:
        info["error"] = (f"Too few brightness edges ({info['events']} usable) to recover the clock. "
                         "See the checklist below.")
        return info
    f, phase, lock = res
    bits, margins = sample_slots(t, x, f, phase)
    info.update(clock=f, lock=lock, n_slots=int(len(bits)), slot_margin=float(margins.mean()))
    cands = align_and_vote(bits, nbits, preamble)
    if not cands:  # maybe the ROI sees the inverse (dark = 1)
        inv = np.where(bits >= 0, 1 - bits, -1)
        cands = align_and_vote(inv, nbits, preamble)
        info["inverted"] = bool(cands)
    if not cands:
        info["error"] = (f"Clock found ({f:.3f} Hz, lock {lock:.2f}) but the preamble was not. "
                         "Capture longer, check --nbits/--preamble match the transmitter.")
        return info
    info["cands"] = cands
    return info


def fmt_hex(value, nbits):
    return f"0x{value:0{(nbits + 3) // 4}X}"


CHECKLIST = """\
Checklist for filming an LCD screen:
  * The screen must actually be blinking a patch at the clock rate (run lcd_transmitter.py).
  * Make the patch large (a third of the screen or more) and fill the camera view with it.
  * Look at roi_debug.png: the green box must sit inside the blinking patch. Otherwise use
    --select or --roi x,y,w,h.
  * Keep the camera still and the room light steady; try --manual-exposure.
  * Camera fps must be at least 20; check the reported fps.
  * Use --save-trace trace.csv to inspect the brightness over time."""


# --------------------------------------------------------------------------
def parse_int(s):
    return int(s, 0)


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--cam", default="0", help="camera index or video file (default 0)")
    ap.add_argument("--synthetic", action="store_true", help="simulate the circuit, no hardware")
    ap.add_argument("--lcd", action="store_true", help="synthetic: add LCD-capture artefacts")
    ap.add_argument("--secret", type=parse_int, default=None, help="synthetic only: the hidden number")
    ap.add_argument("--nbits", type=int, default=8, help="width of the isolated number")
    ap.add_argument("--clock", type=float, default=6.0, help="nominal clock in Hz (default 10)")
    ap.add_argument("--preamble", default=PREAMBLE, help=f"frame preamble bits (default {PREAMBLE})")
    ap.add_argument("--duration", type=float, default=None, help="capture seconds (default: ~8 frames)")
    ap.add_argument("--fps", type=float, default=30.0, help="requested camera fps")
    ap.add_argument("--roi", default=None, help="x,y,w,h of the LED / screen patch")
    ap.add_argument("--select", action="store_true", help="choose the ROI with the mouse")
    ap.add_argument("--manual-exposure", action="store_true", help="try to disable auto-exposure")
    ap.add_argument("--exposure", type=float, default=None, help="manual exposure value (driver specific)")
    ap.add_argument("--wide", action="store_true", help="search the clock over 0.5x-1.5x nominal")
    ap.add_argument("--seed", type=int, default=None)
    ap.add_argument("--clock-skew", type=float, default=0.007, help="synthetic: clock mismatch")
    ap.add_argument("--bit-error", type=float, default=0.02, help="synthetic: per-slot flip probability")
    ap.add_argument("--save-trace", default=None, help="write the brightness trace to CSV")
    args = ap.parse_args()

    L = len(args.preamble) + args.nbits
    duration = args.duration or max(10.0, 8 * L / args.clock)

    sim, secret = None, None
    if args.synthetic:
        rng = np.random.default_rng(args.seed)
        secret = args.secret if args.secret is not None else int(rng.integers(0, 2 ** args.nbits))
        if secret >> args.nbits:
            sys.exit(f"--secret does not fit in {args.nbits} bits")
        sim = SyntheticLED(secret, args.nbits, args.clock, args.preamble,
                           args.clock_skew, args.bit_error, args.seed, args.lcd)
    roi = tuple(int(x) for x in args.roi.split(",")) if args.roi else None

    cam = Camera(args.cam, args.synthetic, sim, args.fps, roi, args.select,
                 args.manual_exposure, args.exposure)
    traces = collections.defaultdict(lambda: collections.deque(maxlen=int(cam.fps * duration) + 64))

    print(f"[capture] {duration:.1f} s ({L} bits per frame, clock {args.clock} Hz)")
    for t, v in cam.frames(duration):
        traces["t"].append(t)
        traces["v"].append(v)
    cam.release()
    t, v = np.array(traces["t"]), np.array(traces["v"])
    print(f"[capture] {len(t)} frames")
    if len(t) < 30:
        sys.exit("Too few frames captured.")

    if args.save_trace:
        np.savetxt(args.save_trace, np.c_[t, v], delimiter=",", header="t_s,brightness", comments="")

    res = decode(t, v, args.clock, args.nbits, args.preamble, args.wide)
    print(f"[signal]  brightness range {res['span']:.1f}, usable edge events {res.get('events', 0)}")
    if "clock" in res:
        print(f"[clock]   {res['clock']:.3f} Hz (nominal {args.clock}), lock quality {res['lock']:.2f}")
        print(f"[slots]   {res['n_slots']} decoded, mean decision margin {res['slot_margin']:.2f}")
    if "error" in res:
        print("RESULT:   FAILED -", res["error"])
        print(CHECKLIST)
        sys.exit(1)

    best = res["cands"][0]
    if res.get("inverted"):
        print("[note]    signal polarity was inverted (dark = 1); corrected automatically")
    print()
    print(f"PREDICTED NUMBER : {best['value']}  ({fmt_hex(best['value'], args.nbits)}, "
          f"{best['value']:0{args.nbits}b})")
    print(f"CONFIDENCE       : {best['conf']:.1%} bit agreement over ~{best['frames']} frames")
    weak = [i for i, c in enumerate(best["bit_conf"]) if c < 0.8]
    if weak:
        print(f"WEAK BITS (slot, MSB=0): {weak}  - capture longer for more votes")
    if len(res["cands"]) > 1:
        print("AMBIGUOUS FRAMING: the preamble also matches at another offset. Alternatives:")
        for c in res["cands"][1:4]:
            print(f"   {c['value']} ({fmt_hex(c['value'], args.nbits)})  conf {c['conf']:.1%}")
    if args.synthetic:
        ok = best["value"] == secret
        print(f"\n[synthetic ground truth] secret = {secret} ({fmt_hex(secret, args.nbits)})  "
              f"-> {'MATCH' if ok else 'MISMATCH'}")
        sys.exit(0 if ok else 2)


if __name__ == "__main__":
    main()
