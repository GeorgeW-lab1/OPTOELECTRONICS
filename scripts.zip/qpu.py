
#!/usr/bin/env python3
"""
PARALLEL OPTICAL BIT POOLING
COMMIT-ONLY HIDDEN NUMBER RECOVERY v2

Author: George Wagenknecht

Architecture:
    Hidden Number Oracle
        -> SHA256 Commitment
        -> Parallel Bit Grid
        -> Display / USB Camera
        -> Full Frame Acquisition
        -> Vectorised Spatial Pooling
        -> Adaptive Bit Classification
        -> Confidence and Erasure Filtering
        -> Parallel Vote Accumulation
        -> Candidate Reconstruction
        -> SHA256 Verification
        -> Oracle Factor Reveal

Synthetic and camera modes share the same recognition pipeline.

The optional Qiskit circuit is diagnostic only.
This is not a quantum factorisation algorithm.
"""

from __future__ import annotations

import argparse
import hashlib
import itertools
import math
import os
import secrets
import sys
import time

import cv2
import numpy as np

from tqdm import tqdm

try:
    import sympy
except ImportError:
    sympy = None

try:
    from qiskit import QuantumCircuit
    QISKIT_AVAILABLE = True
except ImportError:
    QISKIT_AVAILABLE = False


# ============================================================
# ORACLE
# ============================================================

class HiddenNumberOracle:

    def __init__(self, number, bits):

        if number <= 0:
            raise ValueError("N must be positive")

        if bits % 8:
            raise ValueError("Bit width must be byte aligned")

        if number.bit_length() > bits:
            raise ValueError("Number exceeds bit width")

        self.number = number
        self.bits = bits
        self.byte_length = bits // 8

        self.salt = os.urandom(16)

        self.commitment = self.digest(number)

        # The oracle retains the factors.
        self.factors = None

    def encode(self, number):

        return number.to_bytes(
            self.byte_length,
            "big"
        )

    def digest(self, number):

        return hashlib.sha256(
            self.salt + self.encode(number)
        ).digest()

    def bit_vector(self):

        return np.array(
            [
                (self.number >> i) & 1
                for i in range(self.bits)
            ],
            dtype=np.uint8
        )

    def verify(self, candidate):

        if candidate < 0 or candidate.bit_length() > self.bits:
            return False

        return self.digest(candidate) == self.commitment

    def factor_number(self):

        if sympy is not None:

            factors = sympy.factorint(self.number)

            self.factors = [
                int(p)
                for p, exponent in factors.items()
                for _ in range(exponent)
            ]

        else:

            factors = []
            remaining = self.number
            divisor = 2

            while divisor * divisor <= remaining:

                while remaining % divisor == 0:
                    factors.append(divisor)
                    remaining //= divisor

                divisor = 3 if divisor == 2 else divisor + 2

            if remaining > 1:
                factors.append(remaining)

            self.factors = factors

        return self.factors

    def reveal(self, candidate):

        if not self.verify(candidate):
            return None

        if self.factors is None:
            self.factor_number()

        return {
            "number": self.number,
            "factors": self.factors,
            "commitment": self.commitment.hex(),
            "verified": True
        }


# ============================================================
# GRID GENERATION
# ============================================================

def create_bit_grid(bits, rows, cols, cell_size):

    grid = np.zeros(
        (rows, cols),
        dtype=np.uint8
    )

    grid.flat[:len(bits)] = bits

    image = np.repeat(
        np.repeat(
            grid * 255,
            cell_size,
            axis=0
        ),
        cell_size,
        axis=1
    )

    # Cell boundaries.
    image[::cell_size, :] = 70
    image[:, ::cell_size] = 70

    return cv2.cvtColor(
        image,
        cv2.COLOR_GRAY2BGR
    )


# ============================================================
# CAMERA
# ============================================================

class CameraSource:

    def __init__(self, index, width, height, fps):

        self.cap = cv2.VideoCapture(index)

        if not self.cap.isOpened():
            raise RuntimeError("Cannot open USB camera")

        self.cap.set(cv2.CAP_PROP_FRAME_WIDTH, width)
        self.cap.set(cv2.CAP_PROP_FRAME_HEIGHT, height)
        self.cap.set(cv2.CAP_PROP_FPS, fps)

    def read(self):

        ok, frame = self.cap.read()

        if not ok:
            return None

        return frame

    def close(self):
        self.cap.release()


class SyntheticSource:

    def read(self, image):
        return image.copy()

    def close(self):
        pass


# ============================================================
# ADAPTIVE SPATIAL POOLING
# ============================================================

def parallel_bit_pool(frame, rows, cols, threshold, confidence):

    if frame is None:
        raise ValueError("Empty frame")

    if frame.ndim == 3:

        gray = cv2.cvtColor(
            frame,
            cv2.COLOR_BGR2GRAY
        )

    else:
        gray = frame

    # Standardise the complete camera frame.
    resized = cv2.resize(
        gray,
        (cols * 16, rows * 16),
        interpolation=cv2.INTER_AREA
    )

    # Reshape into all spatial cells.
    cells = resized.reshape(
        rows,
        16,
        cols,
        16
    )

    pooled = cells.mean(
        axis=(1, 3),
        dtype=np.float32
    )

    # Global adaptive threshold.
    # The black/white distributions are estimated
    # from the pooled cells themselves.
    values = pooled.ravel()

    low = np.percentile(values, 15)
    high = np.percentile(values, 85)

    if high - low > 30:

        adaptive_threshold = (
            low + high
        ) / 2.0

        threshold_used = (
            0.5 * threshold +
            0.5 * adaptive_threshold
        )

    else:
        threshold_used = threshold

    observed = (
        pooled.ravel() > threshold_used
    ).astype(np.uint8)

    confidence_values = np.abs(
        pooled.ravel() - threshold_used
    )

    valid = (
        confidence_values >= confidence
    )

    return (
        observed,
        confidence_values,
        valid,
        pooled,
        threshold_used
    )


# ============================================================
# OPTIONAL QISKIT DIAGNOSTIC
# ============================================================

def run_qiskit_diagnostic():

    if not QISKIT_AVAILABLE:
        return None

    qc = QuantumCircuit(8, 8)

    qc.h(0)

    for q in range(7):
        qc.cx(q, q + 1)

    qc.measure(range(8), range(8))

    print("\nQISKIT DIAGNOSTIC")
    print(qc.draw())

    return qc


# ============================================================
# COMMIT-ONLY RECOGNISER
# ============================================================

class CommitOnlyRecogniser:

    def __init__(
        self,
        bits,
        salt,
        commitment,
        max_candidates
    ):

        self.bits = bits
        self.byte_length = bits // 8

        self.salt = salt
        self.commitment = commitment

        self.max_candidates = max_candidates

        self.ones = np.zeros(
            bits,
            dtype=np.uint64
        )

        self.zeros = np.zeros(
            bits,
            dtype=np.uint64
        )

        self.cycles = 0
        self.candidates_tested = 0

        self.recovered = None
        self.proof = None

    def digest(self, candidate):

        payload = candidate.to_bytes(
            self.byte_length,
            "big"
        )

        return hashlib.sha256(
            self.salt + payload
        ).digest()

    def observe(self, observed, valid):

        observed = np.asarray(
            observed,
            dtype=np.uint8
        )

        valid = np.asarray(
            valid,
            dtype=bool
        )

        if len(observed) != self.bits:
            raise ValueError("Incorrect observation width")

        if len(valid) != self.bits:
            raise ValueError("Incorrect validity width")

        # Vectorised vote accumulation.
        self.ones += (
            observed * valid
        ).astype(np.uint64)

        self.zeros += (
            (1 - observed) * valid
        ).astype(np.uint64)

        self.cycles += 1

        if np.all(self.ones + self.zeros > 0):
            self.decode()

    def decode(self):

        if self.recovered is not None:
            return

        totals = self.ones + self.zeros

        known = totals > 0

        if not np.all(known):
            return

        # Majority voting.
        bits = (
            self.ones > self.zeros
        ).astype(np.uint8)

        confidence = np.abs(
            self.ones.astype(np.int64) -
            self.zeros.astype(np.int64)
        )

        candidate = sum(
            int(bit) << i
            for i, bit in enumerate(bits)
        )

        # First test the direct reconstruction.
        self.candidates_tested += 1

        if self.digest(candidate) == self.commitment:

            self.accept(candidate, 0)
            return

        # Select least-confident bit positions.
        uncertain = np.argsort(
            confidence
        )[:min(16, self.bits)]

        # Bounded correction search.
        for corrections in range(
            1,
            min(4, len(uncertain)) + 1
        ):

            for positions in itertools.combinations(
                uncertain,
                corrections
            ):

                if self.candidates_tested >= self.max_candidates:
                    return

                corrected = candidate

                for position in positions:
                    corrected ^= 1 << int(position)

                self.candidates_tested += 1

                if self.digest(corrected) == self.commitment:

                    self.accept(
                        corrected,
                        corrections
                    )
                    return

    def accept(self, candidate, corrections):

        digest = self.digest(candidate)

        self.recovered = candidate

        self.proof = {
            "number": candidate,
            "binary": format(
                candidate,
                f"0{self.bits}b"
            ),
            "digest": digest.hex(),
            "commitment": self.commitment.hex(),
            "verified": digest == self.commitment,
            "independent_recheck": (
                self.digest(candidate) == self.commitment
            ),
            "cycles": self.cycles,
            "candidates": self.candidates_tested,
            "corrections": corrections
        }

    @property
    def known_count(self):

        return int(
            np.count_nonzero(
                self.ones + self.zeros
            )
        )

    @property
    def unknown_count(self):

        return self.bits - self.known_count


# ============================================================
# MAIN EXPERIMENT
# ============================================================

def run(args):

    if args.n <= 0:
        raise ValueError("N must be positive")

    if args.rows < 1:
        raise ValueError("Rows must be positive")

    # Determine byte-aligned grid dimensions.
    required_bits = max(
        8,
        ((args.n.bit_length() + 7) // 8) * 8
    )

    rows = args.rows
    cols = math.ceil(required_bits / rows)

    if args.cols is not None:
        cols = args.cols
        rows = math.ceil(required_bits / cols)

    # Ensure the total grid is byte aligned.
    while (rows * cols) % 8:
        cols += 1

    total_bits = rows * cols

    oracle = HiddenNumberOracle(
        args.n,
        total_bits
    )

    recogniser = CommitOnlyRecogniser(
        total_bits,
        oracle.salt,
        oracle.commitment,
        args.max_candidates
    )

    bits = oracle.bit_vector()

    grid = create_bit_grid(
        bits,
        rows,
        cols,
        args.cell_size
    )

    display = cv2.resize(
        grid,
        (
            grid.shape[1] * args.display_scale,
            grid.shape[0] * args.display_scale
        ),
        interpolation=cv2.INTER_NEAREST
    )

    # Select acquisition source.
    if args.camera is None:

        source = SyntheticSource()
        mode = "Synthetic"

    else:

        source = CameraSource(
            args.camera,
            args.width,
            args.height,
            args.fps
        )

        mode = "USB camera"

    print("\n" + "=" * 60)
    print("PARALLEL OPTICAL BIT POOLING v2")
    print("=" * 60)

    print("Author              : George Wagenknecht")
    print("Target              :", args.n)
    print("Bit width           :", total_bits)
    print("Grid                :", f"{rows} x {cols}")
    print("Source              :", mode)
    print("Commitment          :", oracle.commitment.hex())
    print("Salt                :", oracle.salt.hex())
    print("Reveal probability  :", args.reveal)
    print("Noise probability   :", args.noise)
    print("Qiskit available    :", QISKIT_AVAILABLE)

    if args.qiskit:
        run_qiskit_diagnostic()

    # Show the grid for physical camera acquisition.
    if args.camera is not None:

        cv2.namedWindow(
            "ORACLE BIT GRID - CAMERA TARGET",
            cv2.WINDOW_NORMAL
        )

        cv2.imshow(
            "ORACLE BIT GRID - CAMERA TARGET",
            display
        )

        print("\nPoint the camera at the displayed bit grid.")
        print("Press Q in a preview window to stop.")

    start = time.perf_counter()

    try:

        progress = tqdm(
            range(args.cycles),
            desc="Optical observations",
            unit="frame"
        )

        for cycle in progress:

            # One frame per cycle.
            if isinstance(source, SyntheticSource):
                frame = source.read(grid)
            else:
                frame = source.read()

            if frame is None:
                print("Camera frame unavailable")
                break

            # Parallel spatial pooling.
            (
                observed,
                confidence,
                valid,
                pooled,
                threshold_used
            ) = parallel_bit_pool(
                frame,
                rows,
                cols,
                args.threshold,
                args.confidence
            )

            # Independent simulated erasures.
            reveal_mask = (
                np.random.random(total_bits)
                < args.reveal
            )

            # Independent software noise.
            noise_mask = (
                np.random.random(total_bits)
                < args.noise
            )

            observed ^= noise_mask.astype(np.uint8)

            valid &= reveal_mask

            # Accumulate.
            recogniser.observe(
                observed,
                valid
            )

            progress.set_postfix(
                known=recogniser.known_count,
                unknown=recogniser.unknown_count,
                tested=recogniser.candidates_tested
            )

            if args.preview:

                preview = cv2.resize(
                    frame,
                    (800, 600)
                )

                cv2.imshow(
                    "CAMERA EXPOSURE",
                    preview
                )

                pooled_view = cv2.resize(
                    pooled,
                    (cols * 20, rows * 20),
                    interpolation=cv2.INTER_NEAREST
                )

                pooled_view = np.clip(
                    pooled_view,
                    0,
                    255
                ).astype(np.uint8)

                cv2.imshow(
                    "SPATIAL POOLING",
                    pooled_view
                )

                key = cv2.waitKey(1) & 0xFF

                if key == ord("q"):
                    break

            if recogniser.recovered is not None:
                break

    except KeyboardInterrupt:
        print("\nInterrupted")

    finally:

        source.close()
        cv2.destroyAllWindows()

    elapsed = time.perf_counter() - start

    # ========================================================
    # RESULTS
    # ========================================================

    print("\n" + "=" * 60)
    print("RECOGNISER RESULTS")
    print("=" * 60)

    print("Elapsed seconds :", round(elapsed, 4))
    print("Frames          :", recogniser.cycles)
    print("Known bits      :", recogniser.known_count)
    print("Unknown bits    :", recogniser.unknown_count)
    print("Candidates      :", recogniser.candidates_tested)

    if recogniser.proof:

        proof = recogniser.proof

        print("\nRECOVERY SUCCESSFUL")

        print("Number          :", proof["number"])
        print("Binary          :", proof["binary"])
        print("Commitment      :", proof["commitment"])
        print("Digest          :", proof["digest"])
        print("Hash verified   :", proof["verified"])
        print("Recheck         :", proof["independent_recheck"])
        print("Corrections     :", proof["corrections"])

        print("\n" + "=" * 60)
        print("ORACLE FACTOR REVEAL")
        print("=" * 60)

        result = oracle.reveal(
            recogniser.recovered
        )

        if result:

            print("Verified number :", result["number"])
            print("Prime factors   :", result["factors"])
            print("Commitment      :", result["commitment"])

            product = math.prod(result["factors"])

            print("Factor product  :", product)
            print("Product valid   :", product == result["number"])

        else:
            print("Oracle rejected reconstruction")

    else:

        print("\nRECOVERY NOT COMPLETED")
        print("No verified reconstruction was found.")

    print("\n" + "=" * 60)
    print("EXPERIMENT COMPLETE")
    print("=" * 60)


# ============================================================
# ARGUMENTS
# ============================================================

def main():

    parser = argparse.ArgumentParser(
        description="Parallel Optical Bit Pooling v2"
    )

    parser.add_argument(
        "--n",
        type=int,
        default=9999999999999999
    )

    parser.add_argument(
        "--cycles",
        type=int,
        default=800
    )

    parser.add_argument(
        "--rows",
        type=int,
        default=8
    )

    parser.add_argument(
        "--cols",
        type=int,
        default=None
    )

    parser.add_argument(
        "--cell-size",
        type=int,
        default=24
    )

    parser.add_argument(
        "--display-scale",
        type=int,
        default=2
    )

    parser.add_argument(
        "--camera",
        type=int,
        default=None
    )

    parser.add_argument(
        "--width",
        type=int,
        default=640
    )

    parser.add_argument(
        "--height",
        type=int,
        default=480
    )

    parser.add_argument(
        "--fps",
        type=float,
        default=30
    )

    parser.add_argument(
        "--threshold",
        type=float,
        default=127
    )

    parser.add_argument(
        "--confidence",
        type=float,
        default=25
    )

    parser.add_argument(
        "--reveal",
        type=float,
        default=0.8
    )

    parser.add_argument(
        "--noise",
        type=float,
        default=0.02
    )

    parser.add_argument(
        "--max-candidates",
        type=int,
        default=200000
    )

    parser.add_argument(
        "--preview",
        action="store_true"
    )

    parser.add_argument(
        "--qiskit",
        action="store_true"
    )

    args = parser.parse_args()

    if not 0 < args.reveal <= 1:
        parser.error("--reveal must be in (0, 1]")

    if not 0 <= args.noise < 1:
        parser.error("--noise must be in [0, 1)")

    if args.cycles < 1:
        parser.error("--cycles must be positive")

    if args.cell_size < 2:
        parser.error("--cell-size must be at least 2")

    if args.confidence < 0:
        parser.error("--confidence cannot be negative")

    run(args)


if __name__ == "__main__":
    main()
