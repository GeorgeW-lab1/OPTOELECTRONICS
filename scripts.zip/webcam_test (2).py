#!/usr/bin/env python3
"""
webcam_test.py - test harness for the pooled optical bit-recovery pipeline
described in "Subspace Folding and the Optical Denoiser".

Pipeline (same four folds as the paper):
  1. spatial pool   : warp camera image to the grid, mean over each cell core
  2. confidence gate: value -> {0, 1, erased}, using per-cell calibration
  3. temporal vote  : D_i = ones_i - zeros_i  (sufficient statistic)
  4. hash list search: SHA-256 verified Hamming-ball search over the
                       UNCERTAIN_BITS least reliable bits (per-decode budget)

Modes
  python webcam_test.py --selftest          math + list-decoder checks (no camera)
  python webcam_test.py --sim               full pipeline with a simulated camera
  python webcam_test.py --live --cam 0      real USB webcam pointed at this screen
  python webcam_test.py --noise --cam 0     camera only, no window: pooling-gain check

Live setup: point the webcam at the monitor showing the grid, keep it still,
dim the room a little, disable webcam auto-exposure if the driver allows it.
Needs: numpy (all modes), opencv-python (live mode only).

Hiding: the SHA-256 digest and salt live inside an opaque Commitment object.
They are never printed, drawn on the grid, logged or serialised, and the
recovered secret is never printed either. Pass a fixed secret via the
MAGIC_SECRET_HEX environment variable (not argv). Use --blind to drop the
ground-truth columns. The grid itself necessarily shows the secret's bits.
"""
import argparse
import hashlib
import hmac
import itertools
import math
import os
import sys
import time

import numpy as np

# ---------------------------------------------------------------- parameters
ROWS, COLS = 8, 16                 # 128 cells = 128 bits (fixes the 8x8 mismatch)
NBITS = ROWS * COLS
REVEAL_P = 0.45                    # r: probability a cell is revealed per frame
FLIP_P = 0.02                      # epsilon: bit flips injected before rendering
UNCERTAIN_BITS = 32
MAX_FLIPS = 4
LEVEL_BLACK, LEVEL_GRAY, LEVEL_WHITE = 0, 127, 255


# ---------------------------------------------------------------- theory
def theory(eps, r, m=NBITS):
    z = 2 * math.sqrt(eps * (1 - eps))
    base = 1 - r * (1 - z)
    expo = -math.log(base)
    h2 = -(eps * math.log2(eps) + (1 - eps) * math.log2(1 - eps))
    cap = r * (1 - h2)
    return dict(Z=z, base=base, exponent=expo, capacity=cap,
                shannon_frames=m / (m * cap),
                T_1e2=math.log(m / 1e-2) / expo,
                T_1e6=math.log(m / 1e-6) / expo)


# ---------------------------------------------------------------- commitment
class Commitment:
    """Opaque salted SHA-256 commitment.
    The digest and salt are held privately and are never printed, rendered on
    the grid, logged, pickled or shown by repr/str. The only operation exposed
    is verify(), which compares in constant time and returns a bool."""
    __slots__ = ("_salt", "_digest")

    def __init__(self, secret_int=None, salt_hex=None, digest_hex=None):
        """Either give secret_int (a salt and digest are generated), or give
        salt_hex + digest_hex (16 bytes / 32 bytes hex) from a commitment made
        elsewhere. secret_int is never required when verifying an external one."""
        if salt_hex is not None or digest_hex is not None:
            if secret_int is not None or salt_hex is None or digest_hex is None:
                raise ValueError("give secret_int, or both salt_hex and digest_hex")
            salt = bytes.fromhex(salt_hex)
            digest = bytes.fromhex(digest_hex)
            if len(salt) != 16 or len(digest) != 32:
                raise ValueError("salt must be 16 bytes hex, digest 32 bytes hex (SHA-256)")
            self._salt, self._digest = salt, digest
            return
        if secret_int is None:
            secret_int = int.from_bytes(os.urandom(16), "big")
        self._salt = os.urandom(16)
        self._digest = hashlib.sha256(
            self._salt + secret_int.to_bytes(16, "big")).digest()

    def verify(self, value):
        h = hashlib.sha256(self._salt + value.to_bytes(16, "big")).digest()
        return hmac.compare_digest(h, self._digest)

    def __repr__(self):
        return "<Commitment: hidden>"

    __str__ = __repr__

    def __reduce__(self):
        raise TypeError("Commitment is not serialisable")


def make_commitment(secret_int=None):
    if secret_int is None:
        secret_int = int.from_bytes(os.urandom(16), "big")
    return secret_int, Commitment(secret_int)


def external_commitment(salt_hex, digest_hex):
    """Wrap a commitment that was generated outside this script. No secret_int
    is known here, so there is nothing for the process to leak: it can only
    call .verify() with guesses built from camera evidence."""
    return Commitment(salt_hex=salt_hex, digest_hex=digest_hex)


def int_to_bits(x):
    return np.array([(x >> (NBITS - 1 - i)) & 1 for i in range(NBITS)], dtype=np.uint8)


def bits_to_int(bits):
    v = 0
    for b in bits:
        v = (v << 1) | int(b)
    return v


# ---------------------------------------------------------------- rendering
def render_cells(bits, reveal, flips):
    """Return (ROWS, COLS) array of grey levels actually displayed, plus the
    displayed bit grid (after flips)."""
    shown = bits.copy() ^ flips.astype(np.uint8)
    levels = np.where(shown == 1, LEVEL_WHITE, LEVEL_BLACK)
    levels = np.where(reveal, levels, LEVEL_GRAY)
    return levels.reshape(ROWS, COLS), shown.reshape(ROWS, COLS)


def uniform_cells(level):
    return np.full((ROWS, COLS), level, dtype=np.float64)


# ---------------------------------------------------------------- observers
class SimCamera:
    """Simulated camera: nonlinear response, vignetting, global flicker and
    pixel noise. Pixel noise is pooled analytically: mean of n iid noisy pixels
    has std sigma/sqrt(n), which is exactly what Fold 1 produces."""

    def __init__(self, pixel_noise=12.0, pixels_per_cell=144, gain=0.8,
                 offset=20.0, gamma=1.4, vignette=0.15, flicker=0.02, seed=0):
        self.rng = np.random.default_rng(seed)
        self.sigma = pixel_noise / math.sqrt(pixels_per_cell)
        self.gain, self.offset, self.gamma, self.flicker = gain, offset, gamma, flicker
        yy, xx = np.mgrid[0:ROWS, 0:COLS]
        d = np.hypot((yy - (ROWS - 1) / 2) / ROWS, (xx - (COLS - 1) / 2) / COLS)
        self.vig = 1 - vignette * (d / d.max())

    def pooled(self, cells):
        v = 255.0 * (np.asarray(cells, float) / 255.0) ** self.gamma
        v = v * self.gain * self.vig * (1 + self.rng.normal(0, self.flicker)) + self.offset
        return v + self.rng.normal(0, self.sigma, v.shape)

    def locate(self):
        return True

    def close(self):
        pass


class LiveObserver:
    """Shows the grid with OpenCV, grabs a webcam frame, finds the grid by
    homography, then pools each cell's core (Fold 1)."""

    CP = 24   # canonical pixels per cell after warping

    def __init__(self, cam_index, screen_w, screen_h, settle_ms, flush, fullscreen):
        import cv2
        self.cv2 = cv2
        self.cap = cv2.VideoCapture(cam_index)
        if not self.cap.isOpened():
            sys.exit(f"Cannot open webcam index {cam_index}. Try --cam 1.")
        self.settle_ms, self.flush = settle_ms, flush
        self.W, self.H = screen_w, screen_h
        # grid rectangle on screen, 2:1 aspect (16 cols x 8 rows), centred
        gw = int(min(screen_w * 0.8, screen_h * 0.8 * COLS / ROWS))
        gw -= gw % COLS
        self.cell_px = gw // COLS
        self.gw, self.gh = self.cell_px * COLS, self.cell_px * ROWS
        self.x0, self.y0 = (screen_w - self.gw) // 2, (screen_h - self.gh) // 2
        self.win = "grid (do not cover)"
        cv2.namedWindow(self.win, cv2.WINDOW_NORMAL)
        if fullscreen:
            cv2.setWindowProperty(self.win, cv2.WND_PROP_FULLSCREEN,
                                  cv2.WINDOW_FULLSCREEN)
        else:
            cv2.resizeWindow(self.win, screen_w, screen_h)
        self.H_mat = None

    def _canvas(self, cells):
        cv2 = self.cv2
        img = np.zeros((self.H, self.W), np.uint8)
        big = np.kron(np.asarray(cells, np.uint8), np.ones((self.cell_px,) * 2, np.uint8))
        img[self.y0:self.y0 + self.gh, self.x0:self.x0 + self.gw] = big
        return img

    def _grab(self, cells):
        cv2 = self.cv2
        cv2.imshow(self.win, self._canvas(cells))
        cv2.waitKey(self.settle_ms)
        for _ in range(self.flush):          # drain stale buffered frames
            self.cap.grab()
        ok, frame = self.cap.read()
        if not ok:
            sys.exit("Webcam read failed.")
        return cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY).astype(np.float32)

    def locate(self):
        cv2 = self.cv2
        white = self._grab(uniform_cells(255))
        white = self._grab(uniform_cells(255))
        blur = cv2.GaussianBlur(white, (5, 5), 0).astype(np.uint8)
        _, th = cv2.threshold(blur, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
        cnts, _ = cv2.findContours(th, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        if not cnts:
            print("locate: no bright region found"); return False
        c = max(cnts, key=cv2.contourArea)
        area_frac = cv2.contourArea(c) / (white.shape[0] * white.shape[1])
        peri = cv2.arcLength(c, True)
        quad = cv2.approxPolyDP(c, 0.02 * peri, True)
        if len(quad) != 4 or area_frac < 0.05:
            print(f"locate: need a clean quadrilateral (got {len(quad)} pts, "
                  f"{area_frac:.1%} of frame). Move closer / reduce glare.")
            return False
        pts = quad.reshape(4, 2).astype(np.float32)
        s, d = pts.sum(1), np.diff(pts, axis=1).ravel()
        src = np.array([pts[np.argmin(s)], pts[np.argmin(d)],
                        pts[np.argmax(s)], pts[np.argmax(d)]], np.float32)  # tl,tr,br,bl
        w, h = COLS * self.CP, ROWS * self.CP
        dst = np.array([[0, 0], [w, 0], [w, h], [0, h]], np.float32)
        self.H_mat = cv2.getPerspectiveTransform(src, dst)
        print(f"locate: grid found, covers {area_frac:.1%} of the webcam frame "
              f"(~{math.sqrt(area_frac * white.size / (COLS * ROWS)):.1f} px per cell side)")
        return True

    def pooled(self, cells):
        cv2 = self.cv2
        img = self._grab(cells)
        w, h = COLS * self.CP, ROWS * self.CP
        warp = cv2.warpPerspective(img, self.H_mat, (w, h))
        m = self.CP // 4                      # keep only the cell core
        core = warp.reshape(ROWS, self.CP, COLS, self.CP)[:, m:-m, :, m:-m]
        return core.mean(axis=(1, 3))         # Fold 1

    def close(self):
        self.cap.release()
        self.cv2.destroyAllWindows()


# ---------------------------------------------------------------- calibration
def calibrate(obs, n=8):
    def avg(level):
        return np.mean([obs.pooled(uniform_cells(level)) for _ in range(n)], axis=0)
    lo, gr, hi = avg(LEVEL_BLACK), avg(LEVEL_GRAY), avg(LEVEL_WHITE)
    span = hi - lo
    if np.any(span < 20):
        bad = int(np.sum(span < 20))
        print(f"calibration WARNING: {bad} cells have <20 grey levels of contrast")
    span = np.maximum(span, 1e-6)
    gz = (gr - lo) / span
    print(f"calibration: median contrast {np.median(span):.1f} levels, "
          f"gray sits at z={np.median(gz):.2f} (ideal 0.50)")
    return lo, span, gz


def gate(p, lo, span, gz, gate_width):
    """Fold 2: pooled values -> (state array, valid mask). state in {0,1}."""
    z = (p - lo) / span
    valid = np.abs(z - gz) >= gate_width
    bit = (z > gz).astype(np.uint8)
    return bit.ravel(), valid.ravel()


# ---------------------------------------------------------------- decoder
class Decoder:
    def __init__(self, commitment, eps_assumed):
        self._commitment = commitment
        self.ones = np.zeros(NBITS, np.int32)
        self.zeros = np.zeros(NBITS, np.int32)
        self.L = math.log((1 - eps_assumed) / eps_assumed)
        self.tests = 0
        self.decodes = 0

    def update(self, bit, valid):
        self.ones += (valid & (bit == 1))
        self.zeros += (valid & (bit == 0))

    @property
    def D(self):
        return self.ones - self.zeros

    def covered(self):
        return bool(np.all(self.ones + self.zeros > 0))

    def expected_errors(self):
        pe = 1.0 / (1.0 + np.exp(np.abs(self.D) * self.L))
        return float(pe.sum())

    def _check(self, value):
        self.tests += 1
        return self._commitment.verify(value)

    def decode(self):
        """Majority check, then Chase-style Hamming-ball search over the
        UNCERTAIN_BITS least reliable bits. Budget is per decode, not global."""
        self.decodes += 1
        D = self.D
        est = (D > 0).astype(np.uint8)
        base = bits_to_int(est)
        if self._check(base):
            return base
        order = np.argsort(np.abs(D), kind="stable")[:UNCERTAIN_BITS]
        masks = [1 << (NBITS - 1 - int(i)) for i in order]
        for k in range(1, MAX_FLIPS + 1):
            for combo in itertools.combinations(masks, k):
                x = base
                for m in combo:
                    x ^= m
                if self._check(x):
                    return x
        return None


# ---------------------------------------------------------------- selftest
def selftest():
    print("== selftest ==")
    # Fold 1: projector identity for s = 4 on a 8x8 pixel grid
    s, g = 4, 2
    a = np.ones((1, s)) / s
    A = np.kron(np.eye(g), a)
    Pi = np.kron(A, A)
    proj = (s * s) * Pi.T @ Pi
    assert np.allclose(proj @ proj, proj), "not idempotent"
    assert np.allclose(proj, proj.T), "not symmetric"
    print(f"  pooling: s^2 Pi^T Pi is an orthogonal projector (rank {int(round(np.trace(proj)))})")
    # Theory table
    t = theory(0.02, 0.45)
    print(f"  theory: base={t['base']:.3f} exponent={t['exponent']:.3f} nats "
          f"capacity={t['capacity']:.3f} bits/cell-frame")
    print(f"          Shannon floor {t['shannon_frames']:.2f} frames, "
          f"T(1e-2)={t['T_1e2']:.1f}, T(1e-6)={t['T_1e6']:.1f}")
    assert abs(t["base"] - 0.676) < 0.002 and abs(t["exponent"] - 0.392) < 0.002
    # List decoder: corrupt 3 of the 32 least-reliable bits and recover
    rng = np.random.default_rng(1)
    secret, commitment = make_commitment(int.from_bytes(rng.bytes(16), "big"))
    assert "hidden" in repr(commitment) and "hidden" in str(commitment)
    try:
        import pickle; pickle.dumps(commitment); raise AssertionError("picklable")
    except TypeError:
        pass
    print("  commitment: repr/str hidden, not picklable")
    dec = Decoder(commitment, 0.02)
    bits = int_to_bits(secret)
    margin = rng.integers(3, 9, NBITS)
    dec.ones = np.where(bits == 1, margin, 0).astype(np.int32)
    dec.zeros = np.where(bits == 0, margin, 0).astype(np.int32)
    wrong = rng.choice(np.argsort(margin, kind="stable")[:UNCERTAIN_BITS], 3, replace=False)
    for w in wrong:
        dec.ones[w], dec.zeros[w] = dec.zeros[w], dec.ones[w]
        # make wrong bits genuinely low-margin
        dec.ones[w] = min(dec.ones[w], 1) if bits[w] == 0 else dec.ones[w]
    out = dec.decode()
    print(f"  list decoder: recovered={out == secret} after {dec.tests} hash tests "
          f"(max {1 + 32 + 496 + 4960 + 35960})")
    assert out == secret
    print("selftest OK")



# ---------------------------------------------------------------- noise test
def noise_stats(frames, sizes=(1, 2, 4, 8, 16)):
    """Fold 1 check on a static scene. frames: (N, H, W) float array.
    Per-pixel temporal noise is measured, then re-measured after block pooling.
    If pixel noise were independent, std would fall as 1/s (variance 1/s^2)."""
    frames = np.asarray(frames, np.float64)
    n, h, w = frames.shape
    rows = []
    base = None
    for s in sizes:
        hh, ww = h - h % s, w - w % s
        blocks = frames[:, :hh, :ww].reshape(n, hh // s, s, ww // s, s).mean(axis=(2, 4))
        std = float(np.median(blocks.std(axis=0, ddof=1)))
        base = std if base is None else base
        rows.append((s, std, base / s, 20 * math.log10(base / std) if std > 0 else float("inf")))
    return rows


def noise_test(cam_index, n_frames):
    """Camera only: no window, no drawing, no feedback."""
    import cv2
    cap = cv2.VideoCapture(cam_index)
    if not cap.isOpened():
        sys.exit(f"Cannot open webcam index {cam_index}.")
    for _ in range(10):
        cap.grab()
    frames = []
    for _ in range(n_frames):
        ok, fr = cap.read()
        if not ok:
            sys.exit("Webcam read failed.")
        frames.append(cv2.cvtColor(fr, cv2.COLOR_BGR2GRAY))
    cap.release()
    print(f"captured {len(frames)} frames of {frames[0].shape[1]}x{frames[0].shape[0]} (static scene needed)")
    print("block s   std after pool   ideal (1/s)   gain dB")
    for s, std, ideal, gain in noise_stats(np.array(frames)):
        print(f"{s:7d} {std:16.3f} {ideal:13.3f} {gain:9.1f}")
    print("Real webcams fall short of 1/s (demosaicing, compression, shared noise): "
          "the gap is how much pooling you really get.")

# ---------------------------------------------------------------- run loop
def run(obs, args):
    rng = np.random.default_rng(args.seed)
    salt_env, digest_env = os.environ.get("MAGIC_SALT_HEX"), os.environ.get("MAGIC_DIGEST_HEX")
    if salt_env or digest_env:
        if not (salt_env and digest_env):
            sys.exit("set both MAGIC_SALT_HEX and MAGIC_DIGEST_HEX, or neither")
        commitment = external_commitment(salt_env, digest_env)
        truth_bits = None            # unknown here: no ground-truth columns possible
        args.blind = True
        print("external commitment loaded: secret unknown to this process, blind mode forced")
    else:
        env_secret = os.environ.get("MAGIC_SECRET_HEX")   # env, not argv: stays out of ps/history
        secret, commitment = make_commitment(int(env_secret, 16) if env_secret else None)
        truth_bits = int_to_bits(secret)
    dec = Decoder(commitment, args.eps_assumed)

    if not obs.locate():
        sys.exit("Could not locate the grid. See messages above.")
    lo, span, gz = calibrate(obs, args.calib_frames)

    t = theory(FLIP_P, REVEAL_P)
    print(f"paper prediction (r={REVEAL_P}, eps={FLIP_P}): "
          f"T~{t['T_1e2']:.0f} frames at 1% failure, floor {t['shannon_frames']:.1f}\n")
    if args.blind:
        print("frm cover  pass  E[err]  tests")
    else:
        print("frm cover rev  pass  correct  falseRev  bitsWrong  E[err]  tests")
    t0 = time.time()
    result = None
    if truth_bits is None and isinstance(obs, SimCamera):
        sys.exit("--sim needs truth_bits to render frames; an external commitment "
                 "only makes sense with --live, where the grid is drawn by whoever "
                 "holds the real secret, not by this process.")
    for f in range(1, args.frames + 1):
        reveal = rng.random(NBITS) < REVEAL_P
        flips = rng.random(NBITS) < args.flip
        cells, shown = render_cells(truth_bits, reveal, flips) if truth_bits is not None \
            else (None, None)
        p = obs.pooled(cells)
        bit, valid = gate(p, lo, span, gz, args.gate)
        dec.update(bit, valid)

        passed = int(valid.sum())
        if truth_bits is not None:
            shown_f = shown.ravel()
            correct = int((valid & reveal & (bit == shown_f)).sum())
            false_rev = int((valid & ~reveal).sum())
            wrong_now = int(((dec.D > 0).astype(np.uint8) != truth_bits).sum())
        ee = dec.expected_errors() if dec.covered() else float("nan")
        if args.blind:
            print(f"{f:3d} {int((dec.ones + dec.zeros > 0).sum()):5d} {passed:6d} "
                  f"{ee:7.2f} {dec.tests:6d}")
        else:
            print(f"{f:3d} {int((dec.ones + dec.zeros > 0).sum()):5d} {int(reveal.sum()):4d} "
                  f"{passed:5d} {correct:8d} {false_rev:9d} {wrong_now:10d} "
                  f"{ee:7.2f} {dec.tests:6d}")

        if dec.covered() and ee < args.search_below and dec.decodes < args.max_decodes:
            out = dec.decode()
            if out is not None:
                result = out
                print(f"\nSUCCESS at frame {f}: hash verified after {dec.decodes} decode(s), "
                      f"{dec.tests} SHA-256 tests, {time.time() - t0:.1f}s")
                break
    if result is None:
        print("\nNOT RECOVERED within frame limit." +
              ("" if truth_bits is None else
               " Look at 'falseRev' (gate too loose), 'pass' (gate too tight), "
               "and the calibration contrast."))
    else:
        print("hash verified: True (value not printed)")
    obs.close()
    return result is not None


def main():
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--selftest", action="store_true")
    ap.add_argument("--sim", action="store_true")
    ap.add_argument("--live", action="store_true")
    ap.add_argument("--noise", action="store_true",
                    help="camera-only pooling-gain test, opens no windows")
    ap.add_argument("--cam", type=int, default=0, help="webcam index")
    ap.add_argument("--screen", default="1280x720", help="WxH of the display, e.g. 1920x1080")
    ap.add_argument("--fullscreen", action="store_true")
    ap.add_argument("--settle-ms", type=int, default=120, help="wait after drawing a frame")
    ap.add_argument("--flush", type=int, default=3, help="stale webcam frames to drop")
    ap.add_argument("--frames", type=int, default=120)
    ap.add_argument("--calib-frames", type=int, default=8)
    ap.add_argument("--gate", type=float, default=0.20,
                    help="erasure half-width in normalised units (0..0.5)")
    ap.add_argument("--flip", type=float, default=FLIP_P, help="injected bit-flip rate")
    ap.add_argument("--eps-assumed", type=float, default=0.05,
                    help="epsilon used for reliability weights (use >flip for webcams)")
    ap.add_argument("--search-below", type=float, default=1.5,
                    help="run list search only when expected errors < this")
    ap.add_argument("--max-decodes", type=int, default=12)
    ap.add_argument("--blind", action="store_true",
                    help="no ground-truth columns; decoder progress only")
    ap.add_argument("--seed", type=int, default=None)
    ap.add_argument("--sim-noise", type=float, default=12.0, help="simulated pixel noise")
    args = ap.parse_args()

    if args.selftest:
        selftest(); return
    if args.sim:
        ok = run(SimCamera(pixel_noise=args.sim_noise, seed=args.seed or 0), args)
        sys.exit(0 if ok else 1)
    if args.noise:
        try:
            import cv2  # noqa: F401
        except ImportError:
            sys.exit("pip install opencv-python")
        noise_test(args.cam, 60); return
    if args.live:
        try:
            import cv2  # noqa: F401
        except ImportError:
            sys.exit("pip install opencv-python")
        w, h = (int(v) for v in args.screen.lower().split("x"))
        obs = LiveObserver(args.cam, w, h, args.settle_ms, args.flush, args.fullscreen)
        ok = run(obs, args)
        sys.exit(0 if ok else 1)
    ap.print_help()


if __name__ == "__main__":
    main()
