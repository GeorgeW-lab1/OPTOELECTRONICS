#!/usr/bin/env python3
"""
RP-GHOST with a prediction layer.

Each cycle the program:
  1. PREDICTS the next price change (in cents) with an online ridge AR(p) model,
  2. schedules the target instant T = t0 + 1 s,
  3. sends [T mod 1 min | predicted delta | CRC] through the whitened viewport
     (rp_ghost_opencv.run_cycle, with de-whitening and OpenCV webcam hash),
  4. decodes it, so the receiver holds "price change forecast for instant T",
  5. reveals the actual change, scores the forecast, and updates the model.

Price source: --prices FILE (one price per line, dollars) or a synthetic
AR(1) series. On synthetic data with real autocorrelation the model shows skill.
On real markets, expect close to none: this is a demonstration of the pipeline
and of honest walk-forward scoring, not a trading signal.

Usage:
  python rp_ghost_predict.py --no-camera --ticks 300
  python rp_ghost_predict.py --prices prices.csv --order 5
  python rp_ghost_predict.py --camera 0 --realtime --ticks 60   # 1 tick per second
"""
import argparse
import time
from datetime import datetime, timezone

import numpy as np

import rp_ghost_opencv as rg


class OnlineAR:
    """Ridge-regularised AR(p) with intercept, solved exactly each update."""

    def __init__(self, order=5, ridge=1.0, forget=0.995):
        self.p = order
        self.forget = forget
        d = order + 1
        self.A = ridge * np.eye(d)
        self.b = np.zeros(d)
        self.w = np.zeros(d)

    def _x(self, hist):
        h = np.zeros(self.p)
        recent = np.asarray(hist[-self.p:], dtype=float)[::-1]
        h[:len(recent)] = recent
        return np.append(h, 1.0)

    def predict(self, hist):
        return float(self._x(hist) @ self.w)

    def update(self, hist, actual):
        x = self._x(hist)
        self.A = self.forget * self.A + np.outer(x, x)
        self.b = self.forget * self.b + x * actual
        self.w = np.linalg.solve(self.A, self.b)


def synthetic_deltas(n, phi=0.3, scale=20.0, seed=0):
    rng = np.random.default_rng(seed)
    d = np.zeros(n)
    for t in range(1, n):
        d[t] = phi * d[t - 1] + rng.normal(0, scale)
    return np.round(d).astype(int)


def load_deltas(path):
    prices = np.loadtxt(path, dtype=float).ravel()
    return np.round(np.diff(prices) * 100).astype(int)  # cents


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--prices", help="text file with one price per line (dollars)")
    ap.add_argument("--ticks", type=int, default=300)
    ap.add_argument("--order", type=int, default=5, help="AR order p")
    ap.add_argument("--warmup", type=int, default=30, help="ticks before forecasts are trusted")
    ap.add_argument("--windows", type=int, default=rg.N_WINDOWS)
    ap.add_argument("--camera", type=int, default=0)
    ap.add_argument("--no-camera", action="store_true")
    ap.add_argument("--realtime", action="store_true", help="wait 1 s between ticks")
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--verbose", action="store_true")
    args = ap.parse_args()

    actual = load_deltas(args.prices) if args.prices else synthetic_deltas(args.ticks, seed=args.seed)
    actual = actual[: args.ticks] if not args.prices else actual
    src = args.prices or "synthetic AR(1), phi=0.3"
    print(f"{len(actual)} ticks from {src}; AR({args.order}), warmup {args.warmup}")

    hasher = rg.WebcamHasher(args.camera, enabled=not args.no_camera)
    viewport = rg.OptoelectronicViewport(seed=args.seed)
    model = OnlineAR(args.order)

    hist, rows = [], []
    crc_fail = 0
    try:
        for t, d_true in enumerate(actual):
            pred = model.predict(hist) if t >= args.warmup else 0.0
            pred_c = int(np.clip(round(pred), -32768, 32767))

            r = rg.run_cycle(viewport, hasher, delta_cents=pred_c, dewhiten=True, w=args.windows)
            if not r["crc_ok"]:
                crc_fail += 1
                received = None
            else:
                received = r["delta"]            # forecast as delivered after decoding
                target = datetime.fromtimestamp(r["t_hat_ns"] / 1e9, tz=timezone.utc)

            if received is not None and t >= args.warmup:
                last = hist[-1] if hist else 0
                rows.append((received, d_true, last))
                if args.verbose:
                    print(f"t={t:4d} target={target.isoformat(timespec='milliseconds')} "
                          f"forecast={received:+5d}c actual={d_true:+5d}c")

            model.update(hist, d_true)
            hist.append(int(d_true))
            if args.realtime:
                time.sleep(1.0)
    finally:
        hasher.release()

    if not rows:
        print("no scored forecasts")
        return
    f, a, l = (np.array(x, dtype=float) for x in zip(*rows))
    mae = lambda e: np.mean(np.abs(e))
    mask = a != 0
    dir_acc = np.mean(np.sign(f[mask]) == np.sign(a[mask])) if mask.any() else float("nan")
    print(f"\nscored forecasts : {len(rows)}   (CRC failures: {crc_fail})")
    print(f"MAE model        : {mae(f - a):8.2f} cents")
    print(f"MAE zero         : {mae(a):8.2f} cents   (predict no change)")
    print(f"MAE last value   : {mae(l - a):8.2f} cents   (persistence)")
    print(f"directional acc. : {dir_acc:8.1%}   (50% = chance)")
    print(f"corr(forecast, actual) = {np.corrcoef(f, a)[0, 1]:+.3f}")


if __name__ == "__main__":
    main()
