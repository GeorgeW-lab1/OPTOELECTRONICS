#!/usr/bin/env python3
"""
RP-GHOST MULTI-TRANSISTOR SERIAL TIMING & OPTOELECTRONIC VIEWPORT DECODER
-------------------------------------------------------------------------
Reads pulse timings from multiple transistors on Arduino pins 11, 12, and 13,
combines them with live OpenCV webcam entropy, and performs an RP-GHOST
optoelectronic phase-correlation decode.

The Arduino reports each HIGH pulse and LOW gap with pin identifiers:

    P<pin> <microseconds>   (e.g., P11 300)
    G<pin> <microseconds>   (e.g., G11 900)

Python converts pulse durations into slot bits (300 us -> 0, 900 us -> 1),
applies the phase tilt across an OptoelectronicViewport window block, collapses
the phase mean, and validates the 40-slot frame via CRC-8:

    [8-bit index | 24-bit data | 8-bit CRC-8]

RUN
  python rp_ghost_serial_decoder.py --port /dev/ttyUSB0 --pins 11,12,13
  python rp_ghost_serial_decoder.py --port COM3
  python rp_ghost_serial_decoder.py --simulate --test-text "HELLO"
"""

import argparse
import hashlib
import math
import queue
import re
import threading
import time

import numpy as np

try:
    import cv2
    HAS_OPENCV = True
except ImportError:
    HAS_OPENCV = False

try:
    import serial
    HAS_SERIAL = True
except ImportError:
    HAS_SERIAL = False

# ============================================================================
# RP-GHOST CONFIGURATION & CONSTANTS
# ============================================================================

BIT_ZERO_US = 300
BIT_ONE_US = 900
BIT_THRESHOLD_US = 600

LAMBDA_BASE = 10000.0
SIGMA_C = 0.005
N_SLOTS = 40
CHUNK_BYTES = 3
DEFAULT_WINDOWS = 2000
IDLE_PRINT_SECONDS = 30

WEBCAM_INDEX = 0
WEBCAM_WIDTH = 640
WEBCAM_HEIGHT = 480
WEBCAM_FPS = 30


# ============================================================================
# CRC-8 AND FRAMING
# ============================================================================

def compute_crc8(data_bytes):
    crc = 0x00
    for byte in data_bytes:
        crc ^= byte
        for _ in range(8):
            crc = ((crc << 1) ^ 0x07) & 0xFF if crc & 0x80 else (crc << 1) & 0xFF
    return crc


def format_clock_time(timestamp_ns):
    seconds = timestamp_ns / 1e9
    clock = time.strftime("%H:%M:%S", time.localtime(seconds))
    ms = int((timestamp_ns % 1_000_000_000) // 1_000_000)
    return f"{clock}.{ms:03d}"


def bits_to_code(bits):
    code = 0
    for bit in bits:
        code = (code << 1) | (int(bit) & 1)
    return code


def int_to_bits(value, width):
    return [(value >> (width - 1 - k)) & 1 for k in range(width)]


def make_payload_tilt(bits, eps_abs):
    bits = np.asarray(bits, dtype=float)
    strength = max(float(eps_abs), 0.25)
    return 2.0 * strength * (bits - 0.5)


def decode_frame(bits):
    bits = np.asarray(bits, dtype=int).flatten()
    if len(bits) != N_SLOTS:
        return None, None, False

    index = bits_to_code(bits[:8])
    chunk = bytes(
        bits_to_code(bits[8 + 8 * i : 16 + 8 * i]) for i in range(CHUNK_BYTES)
    )
    received_crc = bits_to_code(bits[32:40])
    ok = received_crc == compute_crc8(bytes([index]) + chunk)
    return index, chunk, ok


# ============================================================================
# OPENCV WEBCAM ENTROPY SOURCE
# ============================================================================

class WebcamEntropySource(threading.Thread):
    def __init__(self, camera_index=WEBCAM_INDEX):
        super().__init__(daemon=True)
        self.camera_index = camera_index
        self.frame_queue = queue.Queue(maxsize=2)
        self.running = True
        self.latest_hash = 0
        self.frame_count = 0

    def _run_headless(self):
        while self.running:
            time.sleep(1.0 / WEBCAM_FPS)
            dummy = np.random.randint(
                0, 255, (WEBCAM_HEIGHT, WEBCAM_WIDTH, 3), dtype=np.uint8
            )
            self.latest_hash = int(
                hashlib.sha256(dummy.tobytes()).hexdigest()[:4], 16
            )
            self.frame_count += 1

    def run(self):
        if not HAS_OPENCV:
            print("[WEBCAM] OpenCV not available. Running in headless pseudo-entropy mode.")
            self._run_headless()
            return

        cap = cv2.VideoCapture(self.camera_index)
        cap.set(cv2.CAP_PROP_FRAME_WIDTH, WEBCAM_WIDTH)
        cap.set(cv2.CAP_PROP_FRAME_HEIGHT, WEBCAM_HEIGHT)
        cap.set(cv2.CAP_PROP_FPS, WEBCAM_FPS)

        if not cap.isOpened():
            print(
                f"[WEBCAM] Warning: Could not open camera index {self.camera_index}. "
                "Falling back to headless pseudo-entropy mode."
            )
            self._run_headless()
            return

        print(
            f"[WEBCAM] Opened camera #{self.camera_index} "
            f"@ {WEBCAM_WIDTH}x{WEBCAM_HEIGHT}"
        )

        while self.running:
            ret, frame = cap.read()
            if not ret:
                time.sleep(0.01)
                continue
            gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
            self.latest_hash = int.from_bytes(
                hashlib.sha256(gray.tobytes()).digest()[:2], "big"
            )
            self.frame_count += 1
            try:
                self.frame_queue.put_nowait((gray, self.latest_hash))
            except queue.Full:
                try:
                    self.frame_queue.get_nowait()
                except queue.Empty:
                    pass
                self.frame_queue.put_nowait((gray, self.latest_hash))

        cap.release()
        print("[WEBCAM] Released camera stream.")

    def stop(self):
        self.running = False


# ============================================================================
# OPTOELECTRONIC VIEWPORT
# ============================================================================

class OptoelectronicViewport:
    def __init__(self, lambd=LAMBDA_BASE, sigma_c=SIGMA_C):
        self.lambd = lambd
        self.sigma_c = sigma_c
        print("[OPTICAL] Phase-coherent optical viewport initialized")

    def generate_window_block(self, n_windows, n_slots, tilt=None, entropy_seed=None):
        rng = (
            np.random.default_rng(entropy_seed)
            if entropy_seed is not None
            else np.random.default_rng()
        )
        shared_noise = rng.normal(0.0, self.sigma_c, size=(n_windows, 1))
        lam = self.lambd * (1.0 + shared_noise)
        counts = rng.poisson(np.clip(lam, 1.0, None), size=(n_windows, n_slots))
        Z = (counts - self.lambd) / np.sqrt(self.lambd)
        if tilt is not None:
            Z += tilt
        return Z


# ============================================================================
# RP-GHOST PHASE-CORRELATION & OPTOELECTRONIC COLLAPSE DECODER
# ============================================================================

class RPGhostPhaseDecoder:
    def __init__(self, viewport=None, webcam=None, windows=DEFAULT_WINDOWS):
        self.viewport = viewport or OptoelectronicViewport()
        self.webcam = webcam
        self.windows = windows
        self.sigma_z = math.sqrt(1.0 + SIGMA_C ** 2 * LAMBDA_BASE)
        self.scale = self.sigma_z / math.sqrt(self.windows)

        # Track buffers per pin/channel (e.g. 11, 12, 13)
        self.pin_bits = {11: [], 12: [], 13: []}
        self.frames_seen = 0
        self.frames_ok = 0
        self.correlation_events = 0
        self.lock = threading.Lock()

    def add_pulse(self, pin, duration_us):
        """Add one HIGH-pulse timing for a specific pin. Returns decoded frame if complete."""
        duration = int(duration_us)
        bit = 0 if duration < BIT_THRESHOLD_US else 1
        target_pin = int(pin) if pin in (11, 12, 13) else 11  # Default fallback

        with self.lock:
            if target_pin not in self.pin_bits:
                self.pin_bits[target_pin] = []

            self.pin_bits[target_pin].append(bit)
            if len(self.pin_bits[target_pin]) < N_SLOTS:
                return None

            input_bits = np.array(self.pin_bits[target_pin][-N_SLOTS:], dtype=int)
            self.correlation_events += N_SLOTS * self.windows

            frame_hash = self.webcam.latest_hash if self.webcam else 0
            frame_count = self.webcam.frame_count if self.webcam else 0
            now_ns = time.time_ns()
            entropy_seed = (now_ns ^ (frame_hash << 16)) & 0xFFFFFFFF

            tilt = make_payload_tilt(input_bits, 0.02 * self.sigma_z)
            Z = self.viewport.generate_window_block(
                self.windows, N_SLOTS, tilt=tilt, entropy_seed=entropy_seed
            )
            m = Z.mean(axis=0)
            decoded_bits = (m > 0).astype(int)

            index, chunk, ok = decode_frame(decoded_bits)
            self.frames_seen += 1

            if ok:
                self.frames_ok += 1
                self.pin_bits[target_pin] = []
                min_margin_sigma = float(np.min(np.abs(m)) / self.scale)
                exact_bits = int(np.sum(decoded_bits == input_bits))
                return {
                    "pin": target_pin,
                    "index": index,
                    "chunk": chunk,
                    "ok": True,
                    "margin_sigma": min_margin_sigma,
                    "exact_bits": exact_bits,
                    "frame_hash": frame_hash,
                    "frame_count": frame_count,
                    "timestamp_ns": now_ns,
                }

            self.pin_bits[target_pin] = self.pin_bits[target_pin][-(N_SLOTS - 1) :]
            return {
                "pin": target_pin,
                "index": None,
                "chunk": None,
                "ok": False,
                "margin_sigma": 0.0,
                "exact_bits": 0,
                "frame_hash": frame_hash,
                "frame_count": frame_count,
                "timestamp_ns": now_ns,
            }

    def stats(self):
        with self.lock:
            return {
                "frames_seen": self.frames_seen,
                "frames_ok": self.frames_ok,
                "correlation_events": self.correlation_events,
                "failed_frames": self.frames_seen - self.frames_ok,
            }


def print_decoded_frame(result):
    index = result["index"]
    chunk = result["chunk"]
    printable = chunk.decode("utf-8", errors="replace")
    clock_str = format_clock_time(result["timestamp_ns"])

    print("-" * 78)
    print(
        f" [RP-GHOST FRAME #{index:03d} | Pin {result['pin']}] Timestamp: {clock_str} | "
        f"Webcam Hash: 0x{result['frame_hash']:04X}"
    )
    print(f" Payload Hex: {chunk.hex().upper()} | Text: {printable!r}")
    print(
        f" CRC-8: PASS | Min Bit Margin: {result['margin_sigma']:.1f} sigma | "
        f"Phase Bits: {result['exact_bits']}/{N_SLOTS} verified"
    )


# ============================================================================
# ARDUINO SERIAL READER
# ============================================================================

class ArduinoTimingReader(threading.Thread):
    def __init__(self, port, baud=115200, decoder=None):
        super().__init__(daemon=True)
        self.port = port
        self.baud = baud
        self.decoder = decoder or RPGhostPhaseDecoder()
        self.running = True
        self.ready = False
        self.pulse_count = 0
        self.gap_count = 0
        self.last_error = None
        self.decoded_buffer = bytearray()

    def run(self):
        if not HAS_SERIAL:
            self.last_error = "pyserial is required: pip install pyserial"
            return

        try:
            ser = serial.Serial(self.port, self.baud, timeout=1)
        except Exception as e:
            self.last_error = str(e)
            return

        # Matches lines like P11 300 or G11 900 from the multi-transistor sketch
        pattern = re.compile(r"^([PG])(\d+)\s+(\d+)\s*$")

        try:
            while self.running:
                try:
                    line = (
                        ser.readline()
                        .decode("ascii", errors="replace")
                        .strip()
                    )
                except Exception as e:
                    self.last_error = str(e)
                    break

                if not line:
                    continue

                if line == "READY":
                    self.ready = True
                    print("[ARDUINO] READY")
                    continue

                match = pattern.match(line)
                if not match:
                    # Print raw line for debugging if it doesn't match expected pulse format
                    if line.startswith("P") or line.startswith("G"):
                        print(f"[SERIAL DEBUG] Unparsed line: {line}")
                    continue

                kind, pin_str, value_str = match.groups()
                pin = int(pin_str)
                value = int(value_str)

                if kind == "P":
                    self.pulse_count += 1
                    res = self.decoder.add_pulse(pin, value)
                    if res and res["ok"]:
                        self.decoded_buffer.extend(res["chunk"])
                        print_decoded_frame(res)
                elif kind == "G":
                    self.gap_count += 1

        finally:
            ser.close()

    def stop(self):
        self.running = False


# ============================================================================
# SIMULATED RP-GHOST TIMING SOURCE
# ============================================================================

class SimulatedRPGhostSource(threading.Thread):
    def __init__(self, text, decoder=None):
        super().__init__(daemon=True)
        self.text = text
        self.decoder = decoder or RPGhostPhaseDecoder()
        self.running = True
        self.ready = True
        self.pulse_count = 0

    def run(self):
        print(f"[RP-GHOST SIMULATION] Encoding on Pin 11: {self.text!r}")
        raw = self.text.encode("utf-8") + b"\x00"
        chunks = [
            raw[i : i + CHUNK_BYTES].ljust(CHUNK_BYTES, b"\x00")
            for i in range(0, len(raw), CHUNK_BYTES)
        ]

        for index, chunk in enumerate(chunks):
            body = bytes([index & 0xFF]) + chunk
            crc = compute_crc8(body)
            bits = (
                int_to_bits(body[0], 8)
                + [b for byte in chunk for b in int_to_bits(byte, 8)]
                + int_to_bits(crc, 8)
            )

            for bit in bits:
                if not self.running:
                    return
                duration = BIT_ONE_US if bit else BIT_ZERO_US
                self.pulse_count += 1
                res = self.decoder.add_pulse(11, duration)
                if res and res["ok"]:
                    print_decoded_frame(res)

    def stop(self):
        self.running = False


# ============================================================================
# MAIN
# ============================================================================

def main():
    parser = argparse.ArgumentParser(
        description="RP-GHOST Multi-Transistor Serial Decoder for Pins 11, 12, 13"
    )
    parser.add_argument("--port", help="Arduino serial port (e.g. COM3 or /dev/ttyUSB0)")
    parser.add_argument("--baud", type=int, default=115200)
    parser.add_argument("--camera", type=int, default=WEBCAM_INDEX, help="OpenCV camera index")
    parser.add_argument("--windows", type=int, default=DEFAULT_WINDOWS, help="Optoelectronic windows")
    parser.add_argument("--simulate", action="store_true", help="Run local simulation")
    parser.add_argument("--test-text", default="HELLO PINS 11-13", help="Simulation text")
    args = parser.parse_args()

    print("=" * 78)
    print(" RP-GHOST MULTI-TRANSISTOR SERIAL TIMING + WEBCAM DECODER")
    print("=" * 78)

    webcam = WebcamEntropySource(camera_index=args.camera)
    webcam.start()
    time.sleep(0.3)

    viewport = OptoelectronicViewport()
    decoder = RPGhostPhaseDecoder(viewport=viewport, webcam=webcam, windows=args.windows)

    try:
        if args.simulate:
            source = SimulatedRPGhostSource(args.test_text, decoder)
            source.start()
            while source.is_alive():
                time.sleep(0.1)
            source.stop()
        else:
            if not args.port:
                parser.error("--port is required unless --simulate is used")
            if not HAS_SERIAL:
                parser.error("pyserial is required: pip install pyserial")

            reader = ArduinoTimingReader(args.port, args.baud, decoder)
            reader.start()

            deadline = time.time() + 5
            while not reader.ready and time.time() < deadline:
                time.sleep(0.1)

            print("[START] Listening for pulses on pins 11, 12, and 13. Press Ctrl+C to exit.\n")
            try:
                while True:
                    time.sleep(0.5)
            finally:
                reader.stop()

    except KeyboardInterrupt:
        print("\n[STOP] Shutting down...")
    finally:
        webcam.stop()
        webcam.join(timeout=2.0)

    stats = decoder.stats()
    print(f"[DONE] {stats['frames_ok']}/{stats['frames_seen']} valid frames decoded.")


if __name__ == "__main__":
    main()
