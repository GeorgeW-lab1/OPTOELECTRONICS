#!/usr/bin/env python3
"""
stratum_miner.py - Stratum V1 SHA-256d share miner with a REAL pool mode and a SIMULATED pool mode.

    python stratum_miner.py --mode sim                                   # built-in test pool, fast shares
    python stratum_miner.py --mode real --host POOL --port 3333 --user WALLET.worker
    python stratum_miner.py --mode real --host POOL --port 443 --tls --user WALLET.worker

What it does (same code path in both modes):
  mining.subscribe / authorize / set_difficulty / notify  ->  build coinbase, merkle root, 80-byte header
  -> double SHA-256 over nonces in worker PROCESSES (real parallelism, no GIL limit)
  -> a share is sent with mining.submit ONLY after the header is re-hashed independently and is <= the
     pool target (diff1 / pool difficulty). Nothing else is ever submitted.

Modes:
  sim   starts a local pool on 127.0.0.1 that sends real-format jobs at a LOW difficulty, re-verifies every
        submitted share from scratch, and rejects stale / duplicate / low-difficulty ones. Use it to prove
        the miner works end to end in seconds. Its numbers are not worth anything; no network is touched.
  real  connects to the pool you name. Pure Python is ~0.2-0.5 MH/s per process, so shares only appear on
        pools with a very low or variable minimum difficulty, and there is no meaningful payout.

Only needs the Python standard library.
"""
import argparse, hashlib, json, multiprocessing as mp, queue, random, secrets, socket, ssl
import struct, sys, threading, time

DIFF1 = 0xFFFF << 208
sha256 = hashlib.sha256


def dsha(b: bytes) -> bytes:
    return sha256(sha256(b).digest()).digest()


def swap_words(prevhash_hex: str) -> bytes:
    """Stratum prevhash = 8 words, each byte-reversed relative to the header."""
    raw = bytes.fromhex(prevhash_hex)
    return b"".join(raw[i:i + 4][::-1] for i in range(0, 32, 4))


def merkle_root(coinbase: bytes, branch) -> bytes:
    root = dsha(coinbase)
    for h in branch:
        root = dsha(root + h)
    return root


def header76(job, en1: bytes, en2: bytes) -> bytes:
    cb = job["c1"] + en1 + en2 + job["c2"]
    return job["version"] + job["prev"] + merkle_root(cb, job["branch"]) + job["ntime"] + job["nbits"]


def target_for(diff: float) -> int:
    return min(int(DIFF1 / diff), (1 << 256) - 1)


# ============================================================ worker process
def worker(idx, inq, outq, stop):
    """Hashes nonces for the newest job it was sent. Reports shares and hash counts through outq."""
    msg = None
    while not stop.is_set():
        try:
            msg = inq.get(timeout=0.2) if msg is None else msg
            while True:                                  # keep only the newest message
                msg = inq.get_nowait()
        except queue.Empty:
            pass
        if msg is None:
            continue
        _, seq, job, en1, en2_size, diff = msg
        newest = msg
        target = target_for(diff)
        quick = target < (1 << 224)                      # top 4 bytes of the digest must be zero
        en2 = secrets.token_bytes(en2_size)
        h76 = header76(job, en1, en2)
        mid, tail = sha256(h76[:64]), h76[64:76]
        t0, done = time.perf_counter(), 0
        for nonce in range(1 << 32):
            h = mid.copy()
            h.update(tail + struct.pack("<I", nonce))
            d = sha256(h.digest()).digest()
            if not (quick and d[28:] != b"\0\0\0\0"):
                v = int.from_bytes(d, "little")
                if v <= target:
                    v2 = int.from_bytes(dsha(h76 + struct.pack("<I", nonce)), "little")  # independent re-hash
                    if v2 <= target:
                        outq.put(("share", seq, job["id"], en2.hex(), job["ntime_hex"], nonce, diff, v2))
            done += 1
            if done == 8192:
                outq.put(("hashes", idx, done, time.perf_counter() - t0))
                done, t0 = 0, time.perf_counter()
                try:
                    newest = inq.get_nowait()            # a newer job or difficulty arrived
                    msg = newest
                    break
                except queue.Empty:
                    pass
                if stop.is_set():
                    return
        else:
            msg = newest                                 # nonce space exhausted: same job, new extranonce2


# ============================================================ Stratum client
class Client:
    def __init__(self, host, port, user, pw, procs, tls, suggest, log):
        self.host, self.port, self.user, self.pw = host, port, user, pw
        self.procs, self.tls, self.suggest, self.log = procs, tls, suggest, log
        self.stop = mp.Event()
        self.inqs = [mp.Queue() for _ in range(procs)]
        self.outq = mp.Queue()
        self.workers = []
        self.sock = None
        self.send_lock = threading.Lock()
        self.connected = False
        self.job = None
        self.seq = 0
        self.en1, self.en2_size, self.diff = b"", 4, 1.0
        self.pending = {}
        self._id = 10
        self.accepted = self.rejected = self.submitted = self.dropped = 0
        self.hashes = 0
        self.rate = {}
        self.t_start = time.time()
        self.last_reject = ""
        self.quit = threading.Event()

    # ---- lifecycle
    def start(self):
        for i in range(self.procs):
            p = mp.Process(target=worker, args=(i, self.inqs[i], self.outq, self.stop), daemon=True)
            p.start()
            self.workers.append(p)
        threading.Thread(target=self._conn_loop, daemon=True).start()
        threading.Thread(target=self._pump, daemon=True).start()

    def close(self):
        self.quit.set()
        self.stop.set()
        try:
            if self.sock:
                self.sock.close()
        except OSError:
            pass
        for p in self.workers:
            p.join(timeout=1)
            if p.is_alive():
                p.terminate()

    def hps(self):
        return sum(self.rate.values())

    # ---- network
    def _send(self, obj):
        data = (json.dumps(obj) + "\n").encode()
        with self.send_lock:
            self.sock.sendall(data)

    def _broadcast(self):
        if self.job is None or not self.connected:
            return
        self.seq += 1
        msg = ("job", self.seq, self.job, self.en1, self.en2_size, self.diff)
        for q in self.inqs:
            q.put(msg)

    def _conn_loop(self):
        backoff = 2
        while not self.quit.is_set():
            try:
                s = socket.create_connection((self.host, self.port), timeout=30)
                if self.tls:
                    s = ssl.create_default_context().wrap_socket(s, server_hostname=self.host)
                s.settimeout(180)
                self.sock = s
                self.log(f"# connected to {self.host}:{self.port}{' (TLS)' if self.tls else ''}")
                self._send({"id": 1, "method": "mining.subscribe", "params": ["stratum-miner/2.0"]})
                self._send({"id": 2, "method": "mining.authorize", "params": [self.user, self.pw]})
                if self.suggest:
                    self._send({"id": 3, "method": "mining.suggest_difficulty", "params": [self.suggest]})
                backoff = 2
                for line in s.makefile("r", encoding="utf-8", errors="replace"):
                    if self.quit.is_set():
                        break
                    line = line.strip()
                    if not line:
                        continue
                    try:
                        self._handle(json.loads(line))
                    except OSError:
                        raise
                    except Exception as e:
                        self.log(f"# could not handle message ({type(e).__name__}: {e}): {line[:200]}")
            except (OSError, ValueError, ssl.SSLError) as e:
                self.log(f"# connection problem: {e}")
            self.connected, self.job = False, None
            self.pending.clear()
            if self.quit.is_set():
                return
            self.log(f"# reconnecting in {backoff} s")
            self.quit.wait(backoff)
            backoff = min(backoff * 2, 60)

    def _handle(self, m):
        mid, method = m.get("id"), m.get("method")
        if method == "mining.notify":
            p = m.get("params") or []
            if len(p) < 9 or not isinstance(p[4], list):
                self.log("# unrecognised mining.notify layout, ignored")
                return
            self.job = dict(id=p[0], prev=swap_words(p[1]), c1=bytes.fromhex(p[2]), c2=bytes.fromhex(p[3]),
                            branch=[bytes.fromhex(h) for h in p[4]], version=bytes.fromhex(p[5])[::-1],
                            nbits=bytes.fromhex(p[6])[::-1], ntime=bytes.fromhex(p[7])[::-1],
                            ntime_hex=p[7])
            self._broadcast()
        elif method == "mining.set_difficulty":
            self.diff = float(m["params"][0])
            self.log(f"# difficulty {self.diff:g}  (~{self.diff * 2 ** 32:.3g} hashes per share)")
            self._broadcast()
        elif method == "mining.set_extranonce":
            self.en1, self.en2_size = bytes.fromhex(m["params"][0]), int(m["params"][1])
            self.log(f"# extranonce changed (en1 {self.en1.hex()}, en2 size {self.en2_size})")
            self._broadcast()
        elif method == "client.reconnect":
            raise OSError("pool asked to reconnect")
        elif mid == 1:
            if m.get("result"):
                self.en1, self.en2_size = bytes.fromhex(m["result"][1]), int(m["result"][2])
                self.log(f"# subscribed (extranonce1 {self.en1.hex()}, extranonce2 size {self.en2_size})")
            else:
                self.log(f"# SUBSCRIBE FAILED {m.get('error')}")
        elif mid == 2:
            self.connected = bool(m.get("result"))
            self.log("# authorised" if self.connected else f"# AUTH FAILED {m.get('error')}")
            if self.connected:
                self._broadcast()
        elif mid in self.pending:
            job_id, d, nonce = self.pending.pop(mid)
            if m.get("result"):
                self.accepted += 1
                self.log(f"SHARE ACCEPTED  job {job_id} nonce {nonce:08x} diff {d:g}  ({self.accepted}/{self.submitted})")
            else:
                self.rejected += 1
                self.last_reject = str(m.get("error"))
                self.log(f"SHARE REJECTED  job {job_id} nonce {nonce:08x}: {self.last_reject}")
        elif mid is not None and mid != 3:
            self.log(f"# unmatched reply id {mid}: {json.dumps(m)[:200]}")

    # ---- share path
    def _pump(self):
        while not self.quit.is_set():
            try:
                ev = self.outq.get(timeout=0.3)
            except queue.Empty:
                continue
            if ev[0] == "hashes":
                _, idx, n, dt = ev
                self.hashes += n
                self.rate[idx] = n / max(dt, 1e-9)
            elif ev[0] == "share":
                _, seq, job_id, en2hex, ntime_hex, nonce, diff, v = ev
                if seq != self.seq or not self.job or self.job["id"] != job_id:
                    self.dropped += 1
                    self.log(f"# share for old job {job_id} dropped (stale)")
                    continue
                self._id += 1
                self.pending[self._id] = (job_id, diff, nonce)
                self.submitted += 1
                self.log(f"SHARE FOUND     job {job_id} nonce {nonce:08x} en2 {en2hex} "
                         f"share diff {DIFF1 / max(v, 1):.4g} >= {diff:g}; sending")
                try:
                    self._send({"id": self._id, "method": "mining.submit",
                                "params": [self.user, job_id, en2hex, ntime_hex, f"{nonce:08x}"]})
                except OSError as e:
                    self.log(f"# submit failed: {e}")


# ============================================================ simulated pool
class SimPool:
    """Local Stratum V1 pool: real job format, independent share verification, stale/duplicate/low-diff checks."""

    def __init__(self, diff, job_secs, en2_size=4):
        self.diff, self.job_secs, self.en2_size = diff, job_secs, en2_size
        self.srv = socket.socket()
        self.srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self.srv.bind(("127.0.0.1", 0))
        self.srv.listen(4)
        self.port = self.srv.getsockname()[1]
        self.jobs = {}                      # job id -> job dict (what the pool remembers)
        self.current = None
        self.seen = set()
        self.stats = dict(valid=0, stale=0, duplicate=0, low=0, bad=0)
        self.lock = threading.Lock()
        self.n = 0
        threading.Thread(target=self._accept, daemon=True).start()

    def _new_job(self):
        self.n += 1
        j = dict(id=f"sim{self.n:04x}", prev=secrets.token_hex(32), c1=secrets.token_hex(24) + "00",
                 c2="ffffffff" + secrets.token_hex(8), branch=[secrets.token_hex(32) for _ in range(3)],
                 version="20000000", nbits="1d00ffff", ntime=f"{int(time.time()):08x}")
        with self.lock:
            self.jobs[j["id"]] = j
            self.current = j["id"]
        return j

    def _accept(self):
        while True:
            c, _ = self.srv.accept()
            threading.Thread(target=self._serve, args=(c,), daemon=True).start()

    def _serve(self, c):
        f = c.makefile("rw", encoding="utf-8")
        en1 = secrets.token_hex(4)
        wl = threading.Lock()

        def send(o):
            with wl:
                f.write(json.dumps(o) + "\n")
                f.flush()

        def notify(clean):
            j = self._new_job()
            send({"id": None, "method": "mining.notify",
                  "params": [j["id"], j["prev"], j["c1"], j["c2"], j["branch"], j["version"], j["nbits"],
                             j["ntime"], clean]})

        def ticker():
            try:
                while True:
                    time.sleep(self.job_secs)
                    notify(True)
            except (OSError, ValueError):
                pass

        try:
            for line in f:
                m = json.loads(line)
                meth, mid = m.get("method"), m.get("id")
                if meth == "mining.subscribe":
                    send({"id": mid, "result": [[["mining.notify", "sim"]], en1, self.en2_size], "error": None})
                elif meth == "mining.authorize":
                    send({"id": mid, "result": True, "error": None})
                    send({"id": None, "method": "mining.set_difficulty", "params": [self.diff]})
                    notify(True)
                    threading.Thread(target=ticker, daemon=True).start()
                elif meth == "mining.submit":
                    send({"id": mid, **self._check(en1, m["params"])})
        except (OSError, ValueError):
            pass

    def _check(self, en1_hex, params):
        user, job_id, en2, ntime, nonce = params
        with self.lock:
            job = self.jobs.get(job_id)
            current = self.current
        if job is None or job_id != current:
            self.stats["stale"] += 1
            return {"result": False, "error": [21, "Job not found (stale)", None]}
        key = (job_id, en2, ntime, nonce)
        if key in self.seen:
            self.stats["duplicate"] += 1
            return {"result": False, "error": [22, "Duplicate share", None]}
        try:
            if len(bytes.fromhex(en2)) != self.en2_size or len(nonce) != 8:
                raise ValueError
            cb = bytes.fromhex(job["c1"] + en1_hex + en2 + job["c2"])
            root = merkle_root(cb, [bytes.fromhex(h) for h in job["branch"]])
            hdr = (bytes.fromhex(job["version"])[::-1] + swap_words(job["prev"]) + root +
                   bytes.fromhex(ntime)[::-1] + bytes.fromhex(job["nbits"])[::-1] + bytes.fromhex(nonce)[::-1])
        except ValueError:
            self.stats["bad"] += 1
            return {"result": False, "error": [20, "Malformed share", None]}
        if int.from_bytes(dsha(hdr), "little") > target_for(self.diff):
            self.stats["low"] += 1
            return {"result": False, "error": [23, "Low difficulty share", None]}
        self.seen.add(key)
        self.stats["valid"] += 1
        return {"result": True, "error": None}


# ============================================================ main
def main():
    ap = argparse.ArgumentParser(description="Stratum V1 SHA-256d miner (real or simulated pool).")
    ap.add_argument("--mode", choices=["sim", "real"], required=True)
    ap.add_argument("--host"), ap.add_argument("--port", type=int)
    ap.add_argument("--user", default="", help="WALLET.WORKER (real mode)")
    ap.add_argument("--password", default="x")
    ap.add_argument("--tls", action="store_true", help="wrap the connection in TLS (real mode)")
    ap.add_argument("--procs", type=int, default=max(1, (mp.cpu_count() or 2) - 1), help="hashing processes")
    ap.add_argument("--suggest-diff", type=float, default=None, help="ask the pool for this difficulty (many ignore it)")
    ap.add_argument("--sim-diff", type=float, default=1 / 8192, help="difficulty of the simulated pool")
    ap.add_argument("--sim-job-secs", type=float, default=15.0, help="seconds between simulated jobs")
    ap.add_argument("--stats", type=float, default=10.0, help="seconds between status lines (0 = off)")
    ap.add_argument("--duration", type=float, default=0.0, help="stop after this many seconds (0 = until Ctrl-C)")
    a = ap.parse_args()

    log_lock = threading.Lock()

    def log(s):
        with log_lock:
            print(s, flush=True)

    sim = None
    if a.mode == "sim":
        sim = SimPool(a.sim_diff, a.sim_job_secs)
        host, port, user, tls = "127.0.0.1", sim.port, a.user or "sim.worker", False
        log(f"# SIMULATED pool on 127.0.0.1:{port}  difficulty {a.sim_diff:g}  (nothing leaves this machine)")
    else:
        if not (a.host and a.port and a.user):
            ap.error("real mode needs --host, --port and --user")
        host, port, user, tls = a.host, a.port, a.user, a.tls
        log(f"# REAL pool {host}:{port} as {user}. Only shares that verify locally are submitted.")

    c = Client(host, port, user, a.password, max(1, a.procs), tls, a.suggest_diff, log)
    c.start()
    t_end = time.time() + a.duration if a.duration else None
    last = time.time()
    try:
        while not (t_end and time.time() >= t_end):
            time.sleep(0.25)
            if a.stats and time.time() - last >= a.stats:
                last = time.time()
                log(f"[stats] {c.hps() / 1000:.0f} kH/s  hashes {c.hashes}  shares sent {c.submitted}  "
                    f"accepted {c.accepted}  rejected {c.rejected}  stale-dropped {c.dropped}"
                    + (f"  last reject: {c.last_reject}" if c.last_reject else ""))
    except KeyboardInterrupt:
        log("\n# interrupted")
    finally:
        c.close()
        log(f"# done: {c.hashes} hashes, {c.submitted} shares sent, {c.accepted} accepted, {c.rejected} rejected")
        if sim:
            log(f"# simulated pool's own verification: {sim.stats}")


if __name__ == "__main__":
    mp.freeze_support()
    main()
