#!/usr/bin/env python3
"""Toy mining simulator (educational).

1. Brute-force a toy hash (truncated SHA-256) and show attempts-until-success is
   geometric: mean ~ D, sd ~ D. No nonce is better than another.
2. Compare solo vs pooled income over 30-day months (Monero-style 2-min blocks).

Usage: python mining_sim.py [--D 12] [--trials 2000] [--f 0.0004] [--F 0.05] [--months 2000]
"""
import argparse
import hashlib
import os

import numpy as np


def toy_pow_attempts(difficulty_bits: int, trials: int, rng: np.random.Generator):
    """Attempts until sha256(seed || nonce)[:4] < 2^32 / D, over many random seeds."""
    D = 1 << difficulty_bits
    thr = (1 << 32) // D
    out = []
    for _ in range(trials):
        seed = rng.bytes(8)
        n = 0
        while int.from_bytes(hashlib.sha256(seed + n.to_bytes(8, "big")).digest()[:4], "big") >= thr:
            n += 1
        out.append(n + 1)
    return D, np.array(out)


def income(f: float, F: float, months: int, rng: np.random.Generator, blocks=21600):
    """Per-month income, reward normalised to 1 per block."""
    F = max(F, f * 1.0001)
    solo = rng.poisson(f * blocks, months).astype(float)
    pool = rng.poisson(F * blocks, months) * (f / F)
    return solo, pool


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--D", type=int, default=12, help="difficulty bits for toy PoW")
    ap.add_argument("--trials", type=int, default=2000)
    ap.add_argument("--f", type=float, default=0.0004, help="your hashrate share")
    ap.add_argument("--F", type=float, default=0.05, help="pool hashrate share")
    ap.add_argument("--months", type=int, default=2000)
    ap.add_argument("--seed", type=int, default=1)
    ap.add_argument("--plot", default="mining_sim.png")
    a = ap.parse_args()
    rng = np.random.default_rng(a.seed)

    D, att = toy_pow_attempts(a.D, a.trials, rng)
    print(f"[1] Toy PoW, D = 2^{a.D} = {D}, {a.trials} trials")
    print(f"    mean attempts {att.mean():.1f} (theory {D}), sd {att.std():.1f} (theory ~{D})")
    print(f"    median {np.median(att):.0f} (theory {D*np.log(2):.0f})")

    solo, pool = income(a.f, a.F, a.months, rng)
    print(f"\n[2] f = {a.f:.4%}, pool F = {a.F:.1%}, {a.months} simulated months")
    print(f"    solo: mean {solo.mean():.2f}, sd {solo.std():.2f}, zero-block months {np.mean(solo == 0):.1%}")
    print(f"    pool: mean {pool.mean():.2f}, sd {pool.std():.2f}")
    print(f"    pooling reduces sd by ~{solo.std()/max(pool.std(), 1e-12):.1f}x (same expected income)")

    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt

        fig, ax = plt.subplots(1, 2, figsize=(11, 4))
        ax[0].hist(att, bins=40, density=True, alpha=0.6, label="simulated")
        x = np.linspace(1, att.max(), 300)
        ax[0].plot(x, np.exp(-x / D) / D, "k", label="exponential, mean D")
        ax[0].set(title="Toy PoW: attempts until success", xlabel="attempts")
        ax[0].legend()
        hi = max(solo.max(), pool.max())
        ax[1].hist(solo, bins=np.linspace(0, hi, 40), alpha=0.55, label="solo")
        ax[1].hist(pool, bins=np.linspace(0, hi, 40), alpha=0.55, label="pool")
        ax[1].set(title="Monthly income (blocks)", xlabel="blocks per 30 days")
        ax[1].legend()
        fig.tight_layout()
        fig.savefig(a.plot, dpi=130)
        print(f"\nPlot saved to {os.path.abspath(a.plot)}")
    except ImportError:
        print("\n(matplotlib not installed; skipping plot)")


if __name__ == "__main__":
    main()
