import hashlib

# 1. Your custom 64-character SHA256 hex digest
custom_digest_hex = "1000000000000000000000000000000cafe00000000000000000000000000001"
digest_bytes = bytes.fromhex(custom_digest_hex)

# 2. Convert raw digest bytes to a 256-bit big-endian integer
full_int = int.from_bytes(digest_bytes, "big")
print(f"Full 256-bit integer from digest: {full_int}")

# 3. Apply secret-bits windowing (64 bits) and force the high bit
bits = 64
hidden_number = (full_int >> (256 - bits)) | (1 << (bits - 1))

print(f"Derived Hidden Number          : {hidden_number}")
print(f"Expected Recovery              : 10376293541461622784")
print(f"Match Verified                 : {hidden_number == 10376293541461622784}")
