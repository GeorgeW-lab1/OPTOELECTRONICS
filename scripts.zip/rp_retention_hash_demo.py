#!/usr/bin/env python3
"""Retention proof-of-work hash demo.

Shows the retained challenge, nonce range, individual hash samples,
best partial match, winning nonce/digest, and independent verification.

No Tkinter.

Run:
  python rp_retention_hash_demo.py --difficulty 16 --frames 3 --hashes-per-frame 20000
"""

from __future__ import annotations

import argparse
import hashlib
import json
import time
from dataclasses import dataclass, field

import numpy as np


W, H = 128, 96


def leading_zero_bits(digest: bytes) -> int:
    bits = 0
    for byte in digest:
        if byte:
            bits += (byte ^ (byte - 1)).bit_length() - 1
            return bits
        bits += 8
    return bits


def meets_target(digest: bytes, difficulty: int) -> bool:
    full, remainder = divmod(difficulty, 8)
    if any(digest[:full]):
        return False
    if remainder:
        return digest[full] >> (8 - remainder) == 0
    return True


@dataclass
class Retention:
    active: bool = False
    entropy_sha256: str = ""
    challenge: bytes = b""
    cursor: int = 0
    hashes: int = 0
    frames: int = 0
    best_digest: bytes = b""
    best_nonce: int = -1
    best_bits: int = -1
    samples: list[str] = field(default_factory=list)


class RetentionPow:
    def __init__(self, difficulty: int, hashes_per_frame: int, retention_frames: int, seed: int):
        self.difficulty = difficulty
        self.hashes_per_frame = hashes_per_frame
        self.retention_frames = retention_frames
        self.rng = np.random.default_rng(seed)
        self.state = Retention()
        self.frame_index = 0

    def next_entropy(self) -> bytes:
        gray = np.clip(self.rng.poisson(120, size=(H, W)), 0, 255).astype(np.uint8)
        payload = gray.tobytes() + self.frame_index.to_bytes(8, "big")
        self.frame_index += 1
        return payload

    @staticmethod
    def show(digest: bytes) -> str:
        return digest.hex()

    def mine_frame(self, frame: int) -> dict:
        entropy = self.next_entropy()
        entropy_digest = hashlib.sha256(entropy).digest()

        retained = self.state.active
        cursor_start = self.state.cursor
        hashes_before = self.state.hashes

        if not retained:
            challenge = hashlib.sha256(
                b"RP-RETENTION-HASH-DEMO|" + entropy_digest
            ).digest()
            self.state = Retention(
                active=True,
                entropy_sha256=entropy_digest.hex(),
                challenge=challenge,
                cursor=0,
                hashes=0,
                frames=0,
            )

        challenge = self.state.challenge
        started = time.perf_counter()
        solution_nonce = None
        solution_digest = None
        hashes_this_frame = 0
        samples: list[str] = []

        upper = min(self.state.cursor + self.hashes_per_frame, 2 ** 32 - 1)

        for candidate in range(self.state.cursor, upper):
            digest = hashlib.sha256(challenge + candidate.to_bytes(8, "big")).digest()
            hashes_this_frame += 1

            if len(samples) < 5:
                samples.append({
                    "nonce": candidate,
                    "sha256": digest.hex(),
                    "leading_zero_bits": leading_zero_bits(digest),
                    "meets_target": meets_target(digest, self.difficulty),
                })

            bits = leading_zero_bits(digest)
            if bits > self.state.best_bits:
                self.state.best_bits = bits
                self.state.best_digest = digest
                self.state.best_nonce = candidate

            if meets_target(digest, self.difficulty):
                solution_nonce = candidate
                solution_digest = digest
                break

        elapsed = time.perf_counter() - started
        self.state.cursor = upper
        self.state.hashes += hashes_this_frame
        self.state.frames += 1

        verified = False
        if solution_nonce is not None:
            check = hashlib.sha256(
                challenge + solution_nonce.to_bytes(8, "big")
            ).digest()
            verified = check == solution_digest and meets_target(check, self.difficulty)

        solved = solution_nonce is not None
        expired = False
        if not solved and self.state.frames >= self.retention_frames:
            expired = True
            self.state.active = False
        if solved:
            self.state.active = False

        return {
            "frame": frame,
            "retention_active_before": retained,
            "retention_frame": self.state.frames,
            "retention_window": self.retention_frames,
            "entropy_sha256": self.state.entropy_sha256,
            "challenge_sha256": challenge.hex(),
            "difficulty_bits": self.difficulty,
            "nonce_start": cursor_start,
            "nonce_end": self.state.cursor,
            "hashes_this_frame": hashes_this_frame,
            "hashes_retained_total": self.state.hashes,
            "hashes_before_this_frame": hashes_before,
            "hash_samples": samples,
            "best_partial": {
                "nonce": self.state.best_nonce,
                "leading_zero_bits": self.state.best_bits,
                "sha256": self.state.best_digest.hex() if self.state.best_digest else None,
            },
            "solution": {
                "nonce": solution_nonce,
                "sha256": solution_digest.hex() if solution_digest else None,
                "leading_zero_bits": leading_zero_bits(solution_digest) if solution_digest else None,
                "verified": verified,
            },
            "elapsed_seconds": elapsed,
            "hashes_per_second": hashes_this_frame / elapsed if elapsed else 0.0,
            "solved": solved,
            "retention_expired": expired,
        }


def main() -> int:
    parser = argparse.ArgumentParser(description="Show retention proof-of-work hashes and details")
    parser.add_argument("--difficulty", type=int, default=32)
    parser.add_argument("--frames", type=int, default=30)
    parser.add_argument("--hashes-per-frame", type=int, default=20000)
    parser.add_argument("--retention-frames", type=int, default=3)
    parser.add_argument("--seed", type=int, default=20261110)
    parser.add_argument("--json", default="retention_hash_details.json")
    args = parser.parse_args()

    miner = RetentionPow(args.difficulty, args.hashes_per_frame, args.retention_frames, args.seed)
    results = []

    print(f"RETENTION HASH DEMO | difficulty={args.difficulty} zero bits")
    print(f"Expected hashes per fresh solve: {2 ** args.difficulty:,}")
    print(f"Retention window: {args.retention_frames} frames")
    print(f"Hash budget per frame: {args.hashes_per_frame:,}")
    print("=" * 88)

    for frame in range(args.frames):
        result = miner.mine_frame(frame)
        results.append(result)

        print(f"\nFRAME {frame + 1} / {args.frames}")
        print(f"  retained challenge: {result['retention_active_before']}")
        print(f"  retention frame:    {result['retention_frame']} / {result['retention_window']}")
        print(f"  entropy SHA-256:    {result['entropy_sha256']}")
        print(f"  challenge SHA-256:  {result['challenge_sha256']}")
        print(f"  nonce range:        {result['nonce_start']:,} to {result['nonce_end'] - 1:,}")
        print(f"  hashes this frame:  {result['hashes_this_frame']:,}")
        print(f"  hashes retained:    {result['hashes_retained_total']:,}")
        print(f"  elapsed:            {result['elapsed_seconds']:.4f} s")
        print(f"  hashrate:           {result['hashes_per_second']:,.0f} H/s")

        print("  first hash samples:")
        for sample in result["hash_samples"]:
            print(
                f"    nonce={sample['nonce']:>8}  "
                f"sha256={sample['sha256']}  "
                f"zero_bits={sample['leading_zero_bits']:>2}  "
                f"target={str(sample['meets_target']).lower()}"
            )

        best = result["best_partial"]
        print(
            f"  best partial: nonce={best['nonce']} "
            f"zero_bits={best['leading_zero_bits']} sha256={best['sha256']}"
        )

        solution = result["solution"]
        if solution["nonce"] is not None:
            print(
                f"  SOLUTION: nonce={solution['nonce']} "
                f"sha256={solution['sha256']} "
                f"zero_bits={solution['leading_zero_bits']} verified={solution['verified']}"
            )
        else:
            print("  SOLUTION: none in this frame; challenge retained" if not result["retention_expired"]
                  else "  SOLUTION: none; retention window expired")

    with open(args.json, "w", encoding="utf-8") as handle:
        json.dump({
            "protocol": "RETENTION-HASH-DEMO",
            "difficulty": args.difficulty,
            "retention_frames": args.retention_frames,
            "hashes_per_frame": args.hashes_per_frame,
            "rounds": results,
        }, handle, indent=2)

    print("\nSaved detailed hash log:", args.json)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
