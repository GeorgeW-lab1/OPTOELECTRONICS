"""
Real-USB-camera photonic recovery of the unknown input to a SHA-256 target.

    target = SHA256(known_data || frame_bytes)

frame_bytes is the raw cell pattern the camera sees: a rows x cols grid, row-major,
one byte per cell (0 = dark, 1 = lit). No integer/bit encoding is involved.

Setup: an AND-gated light source (each emitter can only light if its secret bit is
set, and then only randomly per exposure) is aimed at the camera. Every video frame
is one exposure of all cells at once. A cell that flashes even once proves its secret
bit is 1 (cumulative OR). The accumulated frame is hashed only when it gains a new
cell, so total hashing is O(n) for n cells.

Usage:
    python photonic_usb_camera_sha256.py --target <hex> --data "known bytes" --grid 4x8
    python photonic_usb_camera_sha256.py --camera 1 --roi 120,80,400,200 --preview ...
    python photonic_usb_camera_sha256.py --simulate          # no hardware needed
    python photonic_usb_camera_sha256.py --print-target "10110010/01001101/11100001/00110110" --data "..."
"""
import argparse
import hashlib
import sys
import time
from typing import Optional, Tuple

import numpy as np

try:
    import cv2
except ImportError:
    sys.exit("OpenCV is required: pip install opencv-python")


def digest(known_data: bytes, frame: np.ndarray) -> str:
    return hashlib.sha256(known_data + frame.astype(np.uint8).tobytes()).hexdigest()


def parse_pattern(text: str) -> np.ndarray:
    return np.array([[int(c) for c in row] for row in text.split("/")], dtype=np.uint8)


def render(frame: np.ndarray) -> str:
    return "\n".join("        " + "".join("#" if v else "." for v in row) for row in frame)


# ----------------------------------------------------------------------------
# Frame sources
# ----------------------------------------------------------------------------
class UsbCamera:
    """Thin wrapper over cv2.VideoCapture with exposure/gain locked where supported."""

    def __init__(self, index: int = 0, width: int = 640, height: int = 480, fps: int = 30,
                 backend: Optional[int] = None):
        self.cap = cv2.VideoCapture(index, backend) if backend is not None else cv2.VideoCapture(index)
        if not self.cap.isOpened():
            raise RuntimeError(f"cannot open camera index {index} (check device, permissions, other apps using it)")
        self.cap.set(cv2.CAP_PROP_FRAME_WIDTH, width)
        self.cap.set(cv2.CAP_PROP_FRAME_HEIGHT, height)
        self.cap.set(cv2.CAP_PROP_FPS, fps)
        # Lock auto-exposure so a lit cell does not change the global gain.
        # (0.25 = manual on most V4L2/UVC drivers, 1 on some others; device dependent.)
        self.cap.set(cv2.CAP_PROP_AUTO_EXPOSURE, 0.25)
        self.fps = self.cap.get(cv2.CAP_PROP_FPS) or fps

    def read(self):
        return self.cap.read()

    def release(self):
        self.cap.release()


class SimulatedCamera:
    """Stand-in for a USB camera: AND-gated cells flash with probability p per frame."""

    def __init__(self, pattern: np.ndarray, p: float = 0.02, width: int = 640, height: int = 480,
                 fps: float = 30, seed: int = 1):
        self.secret = pattern.astype(bool)
        self.p = p
        self.w, self.h = width, height
        self.fps = fps
        self.rng = np.random.default_rng(seed)

    def read(self):
        rows, cols = self.secret.shape
        img = self.rng.normal(30, 3, (self.h, self.w)).clip(0, 255)
        flash = self.secret & (self.rng.random(self.secret.shape) < self.p)
        ch, cw = self.h // rows, self.w // cols
        for r, c in zip(*np.nonzero(flash)):
            y, x = r * ch + ch // 2, c * cw + cw // 2
            img[y - 8:y + 8, x - 8:x + 8] = 255          # a bright spot inside the cell
        return True, np.dstack([img] * 3).astype(np.uint8)

    def release(self):
        pass


# ----------------------------------------------------------------------------
# Recognizer
# ----------------------------------------------------------------------------
class CameraRecognizer:
    def __init__(self, source, rows: int, cols: int, known_data: bytes, target: str,
                 roi: Optional[Tuple[int, int, int, int]] = None, reduce: str = "max",
                 k_sigma: float = 8.0, min_delta: float = 25.0, calib_frames: int = 60):
        self.src = source
        self.rows, self.cols = rows, cols
        self.n = rows * cols
        self.known_data = known_data
        self.target = target.lower()
        self.roi = roi
        self.reduce = reduce
        self.k_sigma = k_sigma
        self.min_delta = min_delta
        self.calib_frames = calib_frames
        self.threshold = None

    def cells(self, frame: np.ndarray) -> np.ndarray:
        """Camera frame -> (rows, cols) brightness per cell."""
        g = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY) if frame.ndim == 3 else frame
        if self.roi:
            x, y, w, h = self.roi
            g = g[y:y + h, x:x + w]
        s = 8  # sub-samples per cell, so 'max' can catch a small flash inside a cell
        g = cv2.resize(g, (self.cols * s, self.rows * s), interpolation=cv2.INTER_AREA).astype(np.float32)
        blocks = g.reshape(self.rows, s, self.cols, s)
        return blocks.max(axis=(1, 3)) if self.reduce == "max" else blocks.mean(axis=(1, 3))

    def calibrate(self):
        """Learn each cell's dark level and noise with the source in its normal state."""
        stack = []
        for _ in range(self.calib_frames):
            ok, f = self.src.read()
            if ok:
                stack.append(self.cells(f))
        if len(stack) < 10:
            raise RuntimeError("camera returned too few frames during calibration")
        a = np.array(stack)
        # Robust baseline (median + MAD): occasional flashes during calibration do not
        # inflate the threshold, so the source may already be running.
        med = np.median(a, axis=0)
        sigma = 1.4826 * np.median(np.abs(a - med), axis=0)
        self.threshold = med + np.maximum(self.k_sigma * sigma, self.min_delta)
        print(f"[*] Calibrated on {len(stack)} frames; dark level {med.mean():.1f}, "
              f"mean threshold {self.threshold.mean():.1f}")

    def run(self, max_frames: int = 10_000_000, max_seconds: float = 3600, preview: bool = False):
        print(f"[*] USB camera recovery: grid {self.rows}x{self.cols} ({self.n} cells)")
        print(f"[*] Known data : {self.known_data!r}")
        print(f"[*] Target hash: {self.target}")
        self.calibrate()

        lit = np.zeros((self.rows, self.cols), dtype=np.uint8)   # B_m
        hashes, m = 0, 0
        t0 = time.time()

        try:
            while m < max_frames and time.time() - t0 < max_seconds:
                ok, frame = self.src.read()
                if not ok:
                    print("[!] frame grab failed, retrying")
                    continue
                m += 1

                new = (self.cells(frame) > self.threshold) & (lit == 0)    # Level 1
                if new.any():
                    lit[new] = 1
                    hashes += 1                                            # Level 2: one hash per change
                    match = digest(self.known_data, lit) == self.target
                    print(f"    frame m={m:7d} | t={time.time() - t0:7.1f}s | "
                          f"lit={int(lit.sum()):2d}/{self.n} | hashes={hashes}")
                    if match:
                        print(f"\n[+] RECOVERED at frame m={m} after {hashes} hashes (n={self.n})")
                        print(render(lit))
                        print(f"    Digest : {digest(self.known_data, lit)}")
                        print(f"    Matches target: True")
                        return True, lit.copy(), m, hashes

                if preview:
                    view = cv2.resize((lit * 255).astype(np.uint8), (self.cols * 40, self.rows * 40),
                                      interpolation=cv2.INTER_NEAREST)
                    cv2.imshow("accumulated frame B_m", view)
                    cv2.imshow("camera", frame)
                    if cv2.waitKey(1) & 0xFF == ord("q"):
                        break
        finally:
            self.src.release()
            if preview:
                cv2.destroyAllWindows()

        print(f"\n[-] Not recovered after {m} frames / {time.time() - t0:.0f}s ({hashes} hashes).")
        print(render(lit))
        return False, lit.copy(), m, hashes


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--target", help="SHA-256 hex digest of known_data || frame")
    ap.add_argument("--data", default="known_header_data|ts=1789000000", help="known data (utf-8)")
    ap.add_argument("--grid", default="4x8", help="ROWSxCOLS of emitters/cells")
    ap.add_argument("--camera", type=int, default=0, help="USB camera index")
    ap.add_argument("--width", type=int, default=640)
    ap.add_argument("--height", type=int, default=480)
    ap.add_argument("--fps", type=int, default=30)
    ap.add_argument("--roi", help="x,y,w,h crop around the emitter grid")
    ap.add_argument("--reduce", choices=["max", "mean"], default="max")
    ap.add_argument("--k-sigma", type=float, default=8.0)
    ap.add_argument("--min-delta", type=float, default=25.0, help="min brightness rise (0-255) to count as a flash")
    ap.add_argument("--calib-frames", type=int, default=60)
    ap.add_argument("--max-seconds", type=float, default=3600)
    ap.add_argument("--preview", action="store_true", help="show live windows (press q to quit)")
    ap.add_argument("--simulate", action="store_true", help="use a simulated camera instead of hardware")
    ap.add_argument("--sim-p", type=float, default=0.02, help="flash probability per frame in simulation")
    ap.add_argument("--print-target", metavar="PATTERN", help='print the target for a pattern like "1011/0100"')
    a = ap.parse_args()

    known = a.data.encode()
    if a.print_target:
        print(digest(known, parse_pattern(a.print_target)))
        return

    rows, cols = (int(v) for v in a.grid.lower().split("x"))
    roi = tuple(int(v) for v in a.roi.split(",")) if a.roi else None

    if a.simulate:
        pattern = parse_pattern("10110010/01001101/11100001/00110110")
        rows, cols = pattern.shape
        src = SimulatedCamera(pattern, p=a.sim_p, width=a.width, height=a.height)
        target = a.target or digest(known, pattern)
    else:
        if not a.target:
            sys.exit("--target is required with a real camera (or use --simulate)")
        src = UsbCamera(a.camera, a.width, a.height, a.fps)
        target = a.target

    rec = CameraRecognizer(src, rows, cols, known, target, roi, a.reduce,
                           a.k_sigma, a.min_delta, a.calib_frames)
    rec.run(max_seconds=a.max_seconds, preview=a.preview)


if __name__ == "__main__":
    main()
