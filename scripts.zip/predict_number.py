#!/usr/bin/env python3
"""
predict_number.py - infer the hidden "isolated number" from a camera.

Author: George Wagenknecht

What it does
------------
The TimeCodeLatch holds an n-bit number and the 74HC74 flip-flop emits one bit
per clock edge (MSB first) on SELECT. If the SELECT (or Q-bar "observe") output
drives an LED that the camera can see, the number is not guessed, it is
*recovered* from the light:

  1. grab frames and reduce a region of interest (ROI) to one brightness value
  2. binarise with a Schmitt trigger (adaptive threshold, no chatter)
  3. recover the clock frequency and phase from the LED edges
  4. sample one bit in the middle of every clock slot
  5. find the frame boundary with a preamble (Barker-7 by default)
  6. majority-vote the repeated frames, pool the bits into hex

If the number never reaches anything the camera can see, nothing can be
predicted - the program reports low confidence instead of inventing an answer.

Usage
-----
  python predict_number.py --synthetic --secret 0xA5 --nbits 8      # no hardware
  python predict_number.py --cam 0 --nbits 8                        # webcam, auto ROI
  python predict_number.py --cam 0 --nbits 8 --select               # pick ROI with mouse
  python predict_number.py --cam recording.mp4 --nbits 8 --roi 400,220,40,40

Camera mode needs:  pip install opencv-python numpy
Synthetic mode needs only numpy.

Signal format expected from the transmitter (repeated continuously):
  [ preamble bits | nbits data bits, MSB first ]   one bit per clock period
"""
import argparse
import collections
import math
import sys
import time

import numpy as np

PREAMBLE = "1110010"  # Barker-7: sharp autocorrelation, easy to find in a stream


# --------------------------------------------------------------------------
# Transmitter side (used by the synthetic camera)
# --------------------------------------------------------------------------
class TimeCodeLatch:
    """Latch holding the isolated number; outputs one bit (MSB first) per clock"""

    def __init__(self, value, nbits):
        self.value, self.nbits = value, nbits

    def bit(self, slot):
        return (self.value >> (self.nbits - 1 - slot)) & 1


class DFlipFlop74HC74:
    """Rising-edge D flip-flop: Q <- D on CLK, Qbar is the complement"""

    def __init__(self):
        self.q = 0

    @property
    def qbar(self):
        return 1 - self.q

    def clock(self, d):
        self.q = d & 1
        return self.q


class SyntheticLED:
    """Simulates the optical SELECT output seen by a camera.

    Includes: unknown start phase, clock skew between device and camera,
    LED/camera rise time, ambient light, slow drift, sensor noise, dropped
    frames, and optional random bit errors (e.g. gating interference).
    """

    def __init__(self, secret, nbits, clock_hz, preamble, clock_skew, bit_error, seed):
        self.rng = np.random.default_rng(seed)
        self.latch = TimeCodeLatch(secret, nbits)
        self.ff = DFlipFlop74HC74()
        pre = [int(c) for c in preamble]
        self.stream = pre + [self.latch.bit(i) for i in range(nbits)]
        self.L = len(self.stream)
        self.period = 1.0 / (clock_hz * (1.0 + clock_skew))
        self.t0 = self.rng.uniform(0, self.period) + 0.35  # unknown phase
        self.bit_error = bit_error
        self.n_done = -1
        self.level, self.last_t, self.tau = 0.0, 0.0, 0.012
        self.ambient, self.gain, self.noise = 40.0, 110.0, 6.0

    def brightness(self, t):
        n = int(math.floor((t - self.t0) / self.period))
        while self.n_done < n:  # process every clock edge that has passed
            self.n_done += 1
            d = self.stream[self.n_done % self.L]
            if self.rng.random() < self.bit_error:
                d ^= 1
            self.ff.clock(d)
        dt = max(0.0, t - self.last_t)
        self.last_t = max(t, self.last_t)
        self.level += (self.ff.q - self.level) * (1 - math.exp(-dt / self.tau))
        drift = 8.0 * math.sin(2 * math.pi * 0.13 * t)
        v = self.ambient + self.gain * self.level + drift + self.rng.normal(0, self.noise)
        return float(np.clip(v, 0, 255))


# --------------------------------------------------------------------------
# Camera
# --------------------------------------------------------------------------
class Camera:
    """Yields (timestamp_seconds, ROI brightness) per frame.

    source    : camera index ("0"), or a video file path
    synthetic : if True, use SyntheticLED instead of hardware
    """

    def __init__(self, source, synthetic, sim=None, fps=30.0, roi=None, select=False):
        self.synthetic, self.sim, self.fps, self.roi = synthetic, sim, fps, roi
        if synthetic:
            return
        try:
            import cv2
        except ImportError:
            sys.exit("OpenCV is required for camera mode:  pip install opencv-python")
        self.cv2 = cv2
        self.is_file = not str(source).isdigit()
        self.cap = cv2.VideoCapture(source if self.is_file else int(source))
        if not self.cap.isOpened():
            sys.exit(f"Could not open camera/video source: {source}")
        if self.is_file:
            self.fps = self.cap.get(cv2.CAP_PROP_FPS) or fps
        else:
            self.cap.set(cv2.CAP_PROP_FPS, fps)
            self.fps = self.cap.get(cv2.CAP_PROP_FPS) or fps
        if self.roi is None:
            self.roi = self._select_roi() if select else self._auto_roi()
        print(f"[camera] {self.fps:.1f} fps, ROI x,y,w,h = {self.roi}")

    def _select_roi(self):
        ok, frame = self.cap.read()
        if not ok:
            sys.exit("No frame received from camera.")
        r = self.cv2.selectROI("Select the LED, then press ENTER", frame, showCrosshair=True)
        self.cv2.destroyAllWindows()
        if r[2] == 0 or r[3] == 0:
            sys.exit("No ROI selected.")
        self._rewind()
        return tuple(int(x) for x in r)

    def _auto_roi(self, seconds=3.0):
        """The blinking LED is the region with the highest temporal variance."""
        cv2, small = self.cv2, []
        n = int(self.fps * seconds)
        size = None
        for _ in range(n):
            ok, frame = self.cap.read()
            if not ok:
                break
            size = frame.shape[:2]
            g = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
            small.append(cv2.resize(g, (160, 120)).astype(np.float32))
        if len(small) < 10:
            sys.exit("Not enough frames to find the LED automatically; use --roi or --select.")
        std = cv2.GaussianBlur(np.std(np.stack(small), axis=0), (0, 0), 2)
        y, x = np.unravel_index(np.argmax(std), std.shape)
        sx, sy = size[1] / 160.0, size[0] / 120.0
        w = h = int(max(8, 0.05 * size[1]))
        self._rewind()
        return (int(x * sx - w / 2), int(y * sy - h / 2), w, h)

    def _rewind(self):
        if self.is_file:
            self.cap.set(self.cv2.CAP_PROP_POS_FRAMES, 0)

    def frames(self, duration):
        if self.synthetic:
            rng, k = self.sim.rng, 0
            while True:
                t = k / self.fps + rng.normal(0, 0.002)
                k += 1
                if t > duration:
                    return
                if rng.random() < 0.02:  # dropped frame
                    continue
                yield t, self.sim.brightness(max(t, 0.0))
        else:
            cv2, idx, start = self.cv2, 0, time.perf_counter()
            x, y, w, h = self.roi
            while True:
                ok, frame = self.cap.read()
                if not ok:
                    return
                t = idx / self.fps if self.is_file else time.perf_counter() - start
                idx += 1
                if t > duration:
                    return
                g = cv2.cvtColor(frame[max(y, 0):y + h, max(x, 0):x + w], cv2.COLOR_BGR2GRAY)
                yield t, float(g.mean())

    def release(self):
        if not self.synthetic:
            self.cap.release()


# --------------------------------------------------------------------------
# Decoder
# --------------------------------------------------------------------------
def schmitt_edges(t, v, lo, hi):
    """Edge times (linearly interpolated) of a hysteresis-thresholded signal."""
    mid = (lo + hi) / 2
    state = v[0] > mid
    edges = []
    for i in range(1, len(v)):
        new = state
        if state and v[i] < lo:
            new = False
        elif not state and v[i] > hi:
            new = True
        if new != state:
            # interpolate the crossing of the mid level between samples i-1 and i
            frac = np.clip((mid - v[i - 1]) / (v[i] - v[i - 1] + 1e-9), 0, 1)
            edges.append(t[i - 1] + frac * (t[i] - t[i - 1]))
            state = new
    return np.array(edges)


def recover_clock(edges, f0, span=0.03):
    """Find frequency f and phase so edges lie at (k + phase)/f. Returns (f, phase, lock)."""
    def best(freqs):
        scores = [abs(np.exp(2j * np.pi * f * edges).mean()) for f in freqs]
        i = int(np.argmax(scores))
        return freqs[i], scores[i]

    f, _ = best(np.linspace(f0 * (1 - span), f0 * (1 + span), 241))
    step = f0 * 2 * span / 240
    f, lock = best(np.linspace(f - step, f + step, 81))
    phase = (np.angle(np.exp(2j * np.pi * f * edges).mean()) / (2 * np.pi)) % 1.0
    return f, phase, lock


def sample_slots(t, v, f, phase, thr, span):
    """One decision per clock slot, using the central 60% of the slot."""
    T = 1.0 / f
    kmin = int(math.ceil(t[0] * f - phase)) + 1
    kmax = int(math.floor(t[-1] * f - phase)) - 1
    bits, margins = [], []
    for k in range(kmin, kmax):
        b = (k + phase) * T
        i0, i1 = np.searchsorted(t, [b + 0.2 * T, b + 0.8 * T])
        if i1 <= i0:
            bits.append(-1)
            margins.append(0.0)
            continue
        m = v[i0:i1].mean()
        bits.append(int(m > thr))
        margins.append(min(1.0, abs(m - thr) / (span / 2)))
    return np.array(bits), np.array(margins)


def align_and_vote(bits, nbits, preamble):
    """Find frame start with the preamble, majority-vote repeated frames."""
    pre = np.array([int(c) for c in preamble], dtype=int)
    L = len(pre) + nbits
    good = bits >= 0
    idx = np.arange(len(bits))
    cands = []
    for off in range(L):
        pos = (idx + off) % L
        m = np.array([bits[(pos == p) & good].mean() if np.any((pos == p) & good) else 0.5
                      for p in range(L)])
        maj = (m >= 0.5).astype(int)
        if len(pre) and not np.array_equal(maj[:len(pre)], pre):
            continue
        cons = m[len(pre):]
        agree = np.maximum(cons, 1 - cons)
        value = int("".join(map(str, maj[len(pre):])), 2)
        cands.append({"value": value, "bit_conf": agree, "conf": float(agree.mean()),
                      "frames": int(len(bits) // L)})
    cands.sort(key=lambda c: -c["conf"])
    return cands


def decode(t, v, clock, nbits, preamble):
    lo, hi = np.percentile(v, [5, 95])
    span = hi - lo
    info = {"span": float(span)}
    if span < 15:
        info["error"] = (f"No visible modulation (brightness range {span:.1f}). "
                         "Is the ROI on the LED and is the circuit running?")
        return info
    thr = (lo + hi) / 2
    edges = schmitt_edges(t, v, lo + 0.4 * span, lo + 0.6 * span)
    if len(edges) < 6:
        info["error"] = "Too few LED edges detected to recover the clock."
        return info
    f, phase, lock = recover_clock(edges, clock)
    bits, margins = sample_slots(t, v, f, phase, thr, span)
    info.update(clock=f, lock=float(lock), n_slots=int(len(bits)),
                slot_margin=float(margins.mean()), bits=bits)
    cands = align_and_vote(bits, nbits, preamble)
    if not cands:
        info["error"] = ("Preamble not found. Capture longer, adjust --clock, "
                         "or check that the transmitter sends the expected preamble.")
        return info
    info["cands"] = cands
    return info


def fmt_hex(value, nbits):
    return f"0x{value:0{(nbits + 3) // 4}X}"


# --------------------------------------------------------------------------
def parse_int(s):
    return int(s, 0)


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--cam", default="0", help="camera index or video file (default 0)")
    ap.add_argument("--synthetic", action="store_true", help="simulate the circuit, no hardware")
    ap.add_argument("--secret", type=parse_int, default=None, help="synthetic only: the hidden number")
    ap.add_argument("--nbits", type=int, default=8, help="width of the isolated number")
    ap.add_argument("--clock", type=float, default=10.0, help="nominal clock in Hz (default 10)")
    ap.add_argument("--preamble", default=PREAMBLE, help=f"frame preamble bits (default {PREAMBLE})")
    ap.add_argument("--duration", type=float, default=None, help="capture seconds (default: ~8 frames)")
    ap.add_argument("--fps", type=float, default=30.0, help="requested camera fps")
    ap.add_argument("--roi", default=None, help="x,y,w,h of the LED region")
    ap.add_argument("--select", action="store_true", help="choose the ROI with the mouse")
    ap.add_argument("--seed", type=int, default=None)
    ap.add_argument("--clock-skew", type=float, default=0.007, help="synthetic: clock mismatch")
    ap.add_argument("--bit-error", type=float, default=0.02, help="synthetic: per-slot flip probability")
    ap.add_argument("--save-trace", default=None, help="write the brightness trace to CSV")
    args = ap.parse_args()

    L = len(args.preamble) + args.nbits
    duration = args.duration or max(10.0, 8 * L / args.clock)

    sim, secret = None, None
    if args.synthetic:
        rng = np.random.default_rng(args.seed)
        secret = args.secret if args.secret is not None else int(rng.integers(0, 2 ** args.nbits))
        if secret >> args.nbits:
            sys.exit(f"--secret does not fit in {args.nbits} bits")
        sim = SyntheticLED(secret, args.nbits, args.clock, args.preamble,
                           args.clock_skew, args.bit_error, args.seed)
    roi = tuple(int(x) for x in args.roi.split(",")) if args.roi else None

    cam = Camera(args.cam, args.synthetic, sim, args.fps, roi, args.select)
    traces = collections.defaultdict(lambda: collections.deque(maxlen=int(cam.fps * duration) + 64))

    print(f"[capture] {duration:.1f} s ({L} bits per frame, clock {args.clock} Hz)")
    for t, v in cam.frames(duration):
        traces["t"].append(t)
        traces["v"].append(v)
    cam.release()
    t, v = np.array(traces["t"]), np.array(traces["v"])
    print(f"[capture] {len(t)} frames")
    if len(t) < 30:
        sys.exit("Too few frames captured.")

    if args.save_trace:
        np.savetxt(args.save_trace, np.c_[t, v], delimiter=",", header="t_s,brightness", comments="")

    res = decode(t, v, args.clock, args.nbits, args.preamble)
    print(f"[signal]  brightness range {res['span']:.1f}")
    if "clock" in res:
        print(f"[clock]   {res['clock']:.3f} Hz (nominal {args.clock}), lock quality {res['lock']:.2f}")
        print(f"[slots]   {res['n_slots']} decoded, mean decision margin {res['slot_margin']:.2f}")
    if "error" in res:
        print("RESULT:   FAILED -", res["error"])
        sys.exit(1)

    best = res["cands"][0]
    print()
    print(f"PREDICTED NUMBER : {best['value']}  ({fmt_hex(best['value'], args.nbits)}, "
          f"{best['value']:0{args.nbits}b})")
    print(f"CONFIDENCE       : {best['conf']:.1%} bit agreement over ~{best['frames']} frames")
    weak = [i for i, c in enumerate(best["bit_conf"]) if c < 0.8]
    if weak:
        print(f"WEAK BITS (slot, MSB=0): {weak}  - capture longer for more votes")
    if len(res["cands"]) > 1:
        print("AMBIGUOUS FRAMING: the preamble also matches at another offset. Alternatives:")
        for c in res["cands"][1:4]:
            print(f"   {c['value']} ({fmt_hex(c['value'], args.nbits)})  conf {c['conf']:.1%}")
    if args.synthetic:
        ok = best["value"] == secret
        print(f"\n[synthetic ground truth] secret = {secret} ({fmt_hex(secret, args.nbits)})  "
              f"-> {'MATCH' if ok else 'MISMATCH'}")
        sys.exit(0 if ok else 2)


if __name__ == "__main__":
    main()
