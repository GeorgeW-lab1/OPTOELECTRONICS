#!/usr/bin/env python3
"""Two-level factorisation solver.

Level 1: generate candidate factors from simple number-theoretic constraints.
Level 2: verify each candidate exactly with N % d == 0.

Usage:
  python factor_two_level.py 3233
  python factor_two_level.py 9007199254740881
"""
import math, random, sys, time

def small_primes(limit=10000):
    sieve = bytearray([1]) * (limit + 1)
    sieve[0:2] = b"\x00\x00"
    for i in range(2, int(limit ** 0.5) + 1):
        if sieve[i]:
            sieve[i*i::i] = bytearray(len(sieve[i*i::i]))
    return [i for i, v in enumerate(sieve) if v]

def trial_divide(n, primes):
    for p in primes:
        if p * p > n:
            break
        while n % p == 0:
            yield p
            n //= p
    if n > 1:
        yield n

def is_probable_prime(n, rounds=24):
    if n < 2:
        return False
    for p in (2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37):
        if n % p == 0:
            return n == p
    d, s = n - 1, 0
    while d % 2 == 0:
        d //= 2
        s += 1
    for _ in range(rounds):
        a = random.randrange(2, n - 1)
        x = pow(a, d, n)
        if x in (1, n - 1):
            continue
        for _ in range(s - 1):
            x = x * x % n
            if x == n - 1:
                break
        else:
            return False
    return True

def pollard_rho(n):
    if n % 2 == 0:
        return 2
    while True:
        x = random.randrange(2, n)
        y, c, d = x, random.randrange(1, n), 1
        while d == 1:
            x = (x * x + c) % n
            y = (y * y + c) % n
            y = (y * y + c) % n
            d = math.gcd(abs(x - y), n)
        if d != n:
            return d

def factor(n):
    if n <= 1:
        return []
    factors = []
    for p in trial_divide(n, small_primes()):
        factors.append(p)
        n //= p
        while n % p == 0:
            factors.append(p)
            n //= p
    stack = [n] if n > 1 else []
    while stack:
        m = stack.pop()
        if m == 1:
            continue
        if is_probable_prime(m):
            factors.append(m)
            continue
        d = pollard_rho(m)
        stack.extend([d, m // d])
    return sorted(factors)

def verify(n, factors):
    product = 1
    for f in factors:
        product *= f
    return product == n and all(is_probable_prime(f) for f in factors)

if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("usage: python factor_two_level.py <integer>")
        sys.exit(1)
    n = int(sys.argv[1])
    t = time.perf_counter()
    fs = factor(n)
    dt = time.perf_counter() - t
    print(f"N = {n}")
    print(f"factorisation = {' * '.join(map(str, fs))}")
    print(f"verified exactly: {verify(n, fs)}")
    print(f"time: {dt:.6f} s")
