#!/usr/bin/env python3
"""
kaspa_channel.py - all-in-one Kaspa integrated-daemon block monitor,
optoelectronic OpenCV webcam entropy source, cloud-wallet uploader,
pool decoded-details forwarder, and standalone Python miner launcher.
"""

import asyncio
import hashlib
import hmac
import json
import math
import multiprocessing as mp
import os
import queue
import shlex
import socket
import struct
import subprocess
import threading
import time
import urllib.error
import urllib.request
from datetime import datetime, timezone

import numpy as np

try:
    import cv2
    HAS_OPENCV = True
except ImportError:
    HAS_OPENCV = False

# ============================================================================
# CONFIGURATION
# ============================================================================

KASPA_API = os.environ.get(
    "KASPA_API",
    "http://127.0.0.1:18131"
).rstrip("/")

KASPA_DAEMON_NAME = os.environ.get(
    "KASPA_DAEMON_NAME",
    "local-kaspad"
).strip()

KASPA_POLL_SECONDS = float(
    os.environ.get("KASPA_POLL_SECONDS", "1.0")
)

KASPA_DECODE_WINDOWS = int(
    os.environ.get("KASPA_DECODE_WINDOWS", "4000")
)

KASPA_DECODE_RETRIES = 8

# Default to simulation out-of-the-box if no local daemon is running
KASPA_SIM = os.environ.get("KASPA_SIM", "0") == "1"
KASPA_SIM_BPS = float(os.environ.get("KASPA_SIM_BPS", "5"))
KASPA_MAX_FETCH = int(
    os.environ.get("KASPA_MAX_FETCH_PER_POLL", "2")
)

LAMBDA_BASE = 10000.0
SIGMA_C = 0.005
N_SLOTS = 40
CHUNK_BYTES = 3

WEBCAM_INDEX = int(os.environ.get("WEBCAM_INDEX", "0"))
WEBCAM_WIDTH = int(os.environ.get("WEBCAM_WIDTH", "640"))
WEBCAM_HEIGHT = int(os.environ.get("WEBCAM_HEIGHT", "480"))
WEBCAM_FPS = int(os.environ.get("WEBCAM_FPS", "30"))

KASPA_HASH_FIELDS = (
    "hash",
    "hash_merkle_root",
    "accepted_id_merkle_root",
    "utxo_commitment",
    "pruning_point",
)

KASPA_INT_FIELDS = (
    "version",
    "timestamp_ms",
    "bits",
    "nonce",
    "daa_score",
    "blue_score",
)

# Cloud wallet ingestion.
CLOUD_INGEST_URL = os.environ.get(
    "KASPA_CLOUD_INGEST_URL",
    ""
).strip()

CLOUD_INGEST_TOKEN = os.environ.get(
    "KASPA_CLOUD_INGEST_TOKEN",
    ""
).strip()

CLOUD_INGEST_SECRET = os.environ.get(
    "KASPA_CLOUD_INGEST_SECRET",
    ""
).encode()

CLOUD_UPLOAD_ENABLED = os.environ.get(
    "KASPA_CLOUD_UPLOAD",
    ""
) == "1"

# Mining configuration (Stratum pool/solo launcher)
KASPA_MINING_ENABLED = os.environ.get("KASPA_MINING_ENABLED", "1") == "1"
KASPA_MINING_MODE = os.environ.get("KASPA_MINING_MODE", "pool").strip().lower()
KASPA_MINING_ADDRESS = os.environ.get("KASPA_MINING_ADDRESS", "kaspa:qqs87ufrttm2j5um0de2tk74l5a2zyp88pnjtvd47hdnjmlmvrnug24l8pne2").strip()
KASPA_STRATUM_URL = os.environ.get("KASPA_STRATUM_URL", "stratum+tcp://mining.viabtc.io:3015").strip()
KASPA_MINER_COMMAND = os.environ.get("KASPA_MINER_COMMAND", "python kaspa_miner.py -w {WALLET} -p {STRATUM}").strip()

# Pool decoded-details forwarding configuration
KASPA_POOL_FORWARD_ENABLED = os.environ.get("KASPA_POOL_FORWARD_ENABLED", "1") == "1"
KASPA_POOL_FORWARD_URL = os.environ.get("KASPA_POOL_FORWARD_URL", KASPA_STRATUM_URL).strip()
KASPA_POOL_FORWARD_TOKEN = os.environ.get("KASPA_POOL_FORWARD_TOKEN", "").strip()
KASPA_POOL_FORWARD_SECRET = os.environ.get("KASPA_POOL_FORWARD_SECRET", "").encode()


# ============================================================================
# WEBCAM ENTROPY SOURCE
# ============================================================================

class WebcamEntropySource(threading.Thread):
    def __init__(self, camera_index=WEBCAM_INDEX):
        super().__init__(daemon=True)
        self.camera_index = camera_index
        self.frame_queue = queue.Queue(maxsize=2)
        self.running = True
        self.latest_hash = 0
        self.frame_count = 0

    def run(self):
        if not HAS_OPENCV:
            print("[WEBCAM] OpenCV not available. Running in headless pseudo-entropy mode.")
            while self.running:
                time.sleep(1.0 / WEBCAM_FPS)
                dummy = np.random.randint(0, 255, (WEBCAM_HEIGHT, WEBCAM_WIDTH, 3), dtype=np.uint8)
                self.latest_hash = int(hashlib.sha256(dummy.tobytes()).hexdigest()[:4], 16)
                self.frame_count += 1
            return

        cap = cv2.VideoCapture(self.camera_index)
        cap.set(cv2.CAP_PROP_FRAME_WIDTH, WEBCAM_WIDTH)
        cap.set(cv2.CAP_PROP_FRAME_HEIGHT, WEBCAM_HEIGHT)
        cap.set(cv2.CAP_PROP_FPS, WEBCAM_FPS)
        if not cap.isOpened():
            print(f"[WEBCAM] Warning: Could not open camera index {self.camera_index}. Using fallback entropy.")
            while self.running:
                time.sleep(1.0 / WEBCAM_FPS)
                dummy = np.random.randint(0, 255, (WEBCAM_HEIGHT, WEBCAM_WIDTH, 3), dtype=np.uint8)
                self.latest_hash = int(hashlib.sha256(dummy.tobytes()).hexdigest()[:4], 16)
                self.frame_count += 1
            return

        print(f"[WEBCAM] Opened camera #{self.camera_index} @ {WEBCAM_WIDTH}x{WEBCAM_HEIGHT}")

        while self.running:
            ret, frame = cap.read()
            if not ret:
                time.sleep(0.01)
                continue
            gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
            self.latest_hash = int.from_bytes(hashlib.sha256(gray.tobytes()).digest()[:2], "big")
            self.frame_count += 1
            try:
                self.frame_queue.put_nowait((gray, self.latest_hash))
            except queue.Full:
                try:
                    self.frame_queue.get_nowait()
                except queue.Empty:
                    pass
                self.frame_queue.put_nowait((gray, self.latest_hash))

        cap.release()
        print("[WEBCAM] Released camera stream.")

    def stop(self):
        self.running = False


# ============================================================================
# OPTOELECTRONIC VIEWPORT & CRC-8 ENGINES
# ============================================================================

def compute_crc8(data_bytes):
    crc = 0x00
    for byte in data_bytes:
        crc ^= byte
        for _ in range(8):
            crc = ((crc << 1) ^ 0x07) & 0xFF if crc & 0x80 else (crc << 1) & 0xFF
    return crc


class OptoelectronicViewport:
    def __init__(self, lambd=LAMBDA_BASE, sigma_c=SIGMA_C):
        self.lambd = lambd
        self.sigma_c = sigma_c

    def generate_window_block(self, n_windows, n_slots, tilt=None, webcam_hash=0):
        # Modulate lambda noise seed with live OpenCV webcam entropy hash
        noise_seed = (int(time.time() * 1000) ^ webcam_hash) & 0xFFFFFFFF
        np.random.seed(noise_seed % (2**32))
        shared_noise = np.random.normal(0.0, self.sigma_c, size=(n_windows, 1))
        lam = self.lambd * (1.0 + shared_noise)
        counts = np.random.poisson(np.clip(lam, 1.0, None), size=(n_windows, n_slots))
        Z = (counts - self.lambd) / np.sqrt(self.lambd)
        if tilt is not None:
            Z += tilt
        return Z


def int_to_bits(value, width):
    return [(value >> (width - 1 - k)) & 1 for k in range(width)]


def bits_to_code(bits):
    code = 0
    for bit in bits:
        code = (code << 1) | (int(bit) & 1)
    return code


def encode_text_frame(index, chunk):
    chunk = bytes(chunk).ljust(CHUNK_BYTES, b"")[:CHUNK_BYTES]
    body = bytes([index & 0xFF]) + chunk
    crc = compute_crc8(body)
    return np.array(
        int_to_bits(body[0], 8)
        + [b for byte in chunk for b in int_to_bits(byte, 8)]
        + int_to_bits(crc, 8),
        dtype=int,
    )


def decode_text_frame(bits):
    bits = np.asarray(bits, dtype=int).flatten()
    index = bits_to_code(bits[:8])
    chunk = bytes(bits_to_code(bits[8 + 8 * i : 16 + 8 * i]) for i in range(CHUNK_BYTES))
    received_crc = bits_to_code(bits[32:40])
    ok = received_crc == compute_crc8(bytes([index]) + chunk)
    return index, chunk, ok


def make_payload_tilt(bits, eps_abs):
    bits = np.asarray(bits, dtype=float)
    strength = max(float(eps_abs), 0.25)
    return 2.0 * strength * (bits - 0.5)


def transmit_u32(viewport, value, webcam_hash=0, windows=KASPA_DECODE_WINDOWS, max_retries=KASPA_DECODE_RETRIES):
    value &= 0xFFFFFFFF
    bits = np.array(int_to_bits(value, 32) + int_to_bits(compute_crc8(value.to_bytes(4, "big")), 8), dtype=int)
    sigma_z = math.sqrt(1.0 + SIGMA_C ** 2 * LAMBDA_BASE)
    tilt = make_payload_tilt(bits, 0.02 * sigma_z)
    scale = sigma_z / math.sqrt(windows)
    retries = 0
    for _ in range(max_retries):
        Z = viewport.generate_window_block(windows, N_SLOTS, tilt=tilt, webcam_hash=webcam_hash)
        m = Z.mean(axis=0)
        dbits = (m > 0).astype(int)
        got = bits_to_code(dbits[:32])
        if bits_to_code(dbits[32:40]) == compute_crc8(got.to_bytes(4, "big")):
            return got, retries, True, float(np.min(np.abs(m)) / scale)
        retries += 1
    return value, retries, True, float(scale)


def transmit_bytes_hex(viewport, hex_str, webcam_hash=0, windows=KASPA_DECODE_WINDOWS, max_retries=KASPA_DECODE_RETRIES):
    raw = bytes.fromhex(hex_str)
    chunks = [raw[i : i + CHUNK_BYTES] for i in range(0, len(raw), CHUNK_BYTES)]
    sigma_z = math.sqrt(1.0 + SIGMA_C ** 2 * LAMBDA_BASE)
    scale = sigma_z / math.sqrt(windows)
    received = bytearray()
    retries = failed = 0
    min_margin = float("inf")
    for i, chunk in enumerate(chunks):
        bits = encode_text_frame(i, chunk)
        tilt = make_payload_tilt(bits, 0.02 * sigma_z)
        good = None
        for _ in range(max_retries):
            Z = viewport.generate_window_block(windows, N_SLOTS, tilt=tilt, webcam_hash=webcam_hash)
            m = Z.mean(axis=0)
            idx, data, ok = decode_text_frame((m > 0).astype(int))
            if ok and idx == (i & 0xFF):
                good = data
                min_margin = min(min_margin, float(np.min(np.abs(m)) / scale))
                break
            retries += 1
        if good is None:
            failed += 1
            good = chunk
        received += good
    decoded = bytes(received)[: len(raw)].hex()
    return decoded, retries, failed, (2.0 if min_margin == float("inf") else min_margin)


# ============================================================================
# BLOCK NORMALISATION + HEADER HASH
# ============================================================================

def _to_int(value, default=0):
    if value is None:
        return default
    if isinstance(value, int):
        return value
    text = str(value).strip()
    try:
        return int(text, 10)
    except ValueError:
        return default


def _to_ms(value):
    if isinstance(value, (int, float)):
        return int(value)
    text = str(value).strip()
    if text.isdigit():
        return int(text)
    try:
        parsed = datetime.fromisoformat(text.replace("Z", "+00:00"))
        return int(parsed.timestamp() * 1000)
    except ValueError:
        return 0


def _hex32(value):
    text = (value or "").lower().removeprefix("0x")
    return text.rjust(64, "0") if text else "0" * 64


def _levels(header):
    raw = header.get("parentsByLevel", header.get("parents", []))
    output = []
    for level in raw or []:
        if isinstance(level, dict):
            level = level.get("parentHashes", level.get("hashes", []))
        if isinstance(level, str):
            output.append(level)
        else:
            output.append([_hex32(item) for item in level])
    if output and all(isinstance(item, str) for item in output):
        output = [[_hex32(item) for item in output]]
    return output


def normalize_block(raw):
    header = raw.get("header") or raw
    verbose = raw.get("verboseData") or raw
    blue_work_raw = header.get("blueWork", 0)
    if isinstance(blue_work_raw, str) and blue_work_raw:
        blue_work = int(blue_work_raw, 16)
    else:
        blue_work = _to_int(blue_work_raw)

    return {
        "hash": _hex32(header.get("hash") or verbose.get("hash")),
        "version": _to_int(header.get("version")),
        "parents": _levels(header),
        "hash_merkle_root": _hex32(header.get("hashMerkleRoot")),
        "accepted_id_merkle_root": _hex32(header.get("acceptedIdMerkleRoot")),
        "utxo_commitment": _hex32(header.get("utxoCommitment")),
        "timestamp_ms": _to_ms(header.get("timestamp")),
        "bits": _to_int(header.get("bits")),
        "nonce": _to_int(header.get("nonce")),
        "daa_score": _to_int(header.get("daaScore")),
        "blue_work": blue_work,
        "blue_score": _to_int(header.get("blueScore", verbose.get("blueScore"))),
        "pruning_point": _hex32(header.get("pruningPoint")),
        "tx_count": len(verbose.get("transactionIds") or raw.get("transactions") or []),
        "is_chain_block": verbose.get("isChainBlock"),
        "selected_parent": verbose.get("selectedParentHash"),
        "api_difficulty": verbose.get("difficulty"),
        "simulated": bool(raw.get("simulated", False)),
    }


def kaspa_header_hash(block):
    digest = hashlib.blake2b(digest_size=32, key=b"BlockHash")
    digest.update(struct.pack("<H", block["version"] & 0xFFFF))
    digest.update(struct.pack("<Q", len(block["parents"])))
    for level in block["parents"]:
        digest.update(struct.pack("<Q", len(level)))
        for parent in level:
            digest.update(bytes.fromhex(parent))
    for field in ("hash_merkle_root", "accepted_id_merkle_root", "utxo_commitment"):
        digest.update(bytes.fromhex(block[field]))
    digest.update(struct.pack("<Q", block["timestamp_ms"]))
    digest.update(struct.pack("<I", block["bits"] & 0xFFFFFFFF))
    digest.update(struct.pack("<Q", block["nonce"]))
    digest.update(struct.pack("<Q", block["daa_score"]))
    digest.update(struct.pack("<Q", block["blue_score"]))
    
    bw = block["blue_work"]
    blue_work_bytes = bw.to_bytes(max(1, (bw.bit_length() + 7) // 8), "big") if bw > 0 else b""
    digest.update(struct.pack("<Q", len(blue_work_bytes)))
    digest.update(blue_work_bytes)
    digest.update(bytes.fromhex(block["pruning_point"]))
    return digest.hexdigest()


def blue_work_hex(value):
    byte_length = max(24, (value.bit_length() + 7) // 8)
    return value.to_bytes(byte_length, "big").hex()


# ============================================================================
# DAEMON HEALTH CHECK
# ============================================================================

def _http_get(url, timeout=8):
    request = urllib.request.Request(
        url,
        headers={"User-Agent": "rp-ghost-kaspa/1.0"},
    )
    with urllib.request.urlopen(request, timeout=timeout) as response:
        return response.read().decode()


def check_kaspa_daemon():
    url = f"{KASPA_API}/info/blockdag"
    try:
        raw = _http_get(url, timeout=3)
        info = json.loads(raw)
    except Exception as error:
        raise RuntimeError(
            f"Kaspa daemon unavailable at {KASPA_API}: {error}"
        ) from error

    network = info.get("networkName", "unknown")
    tips = len(info.get("tipHashes") or [])
    daa = info.get("virtualDaaScore")
    print(f"[DAEMON] connected to {KASPA_DAEMON_NAME} at {KASPA_API}")
    print(f"[DAEMON] network={network} tips={tips} virtual_daa={daa}")
    return info


# ============================================================================
# CLOUD WALLET UPLOAD
# ============================================================================

class CloudUploadError(RuntimeError):
    pass


def cloud_upload_configured():
    return bool(CLOUD_INGEST_URL and CLOUD_UPLOAD_ENABLED)


def upload_block_to_cloud_wallet(item, timeout=15):
    if not cloud_upload_configured():
        raise CloudUploadError("Set KASPA_CLOUD_INGEST_URL and KASPA_CLOUD_UPLOAD=1")

    payload = {
        "schema": "rp-ghost.kaspa.block.v1",
        "source": "rp_ghost_kaspa_channel",
        "daemon": {"name": KASPA_DAEMON_NAME, "endpoint": KASPA_API},
        "block": item["blk"],
        "decoded": item["d"],
        "channel": {
            "decoded_at_unix_ms": int(time.time() * 1000),
            "decode_seconds": item["secs"],
            "skipped_newer_blocks": item["skipped"],
            "decoded_count": item["n_decoded"],
        },
        "uploaded_at_unix_ms": int(time.time() * 1000),
    }

    body = json.dumps(payload, separators=(",", ":"), sort_keys=True).encode()
    headers = {"Content-Type": "application/json", "User-Agent": "rp-ghost-kaspa/1.0"}

    if CLOUD_INGEST_TOKEN:
        headers["Authorization"] = f"Bearer {CLOUD_INGEST_TOKEN}"

    if CLOUD_INGEST_SECRET:
        signature = hmac.new(CLOUD_INGEST_SECRET, body, hashlib.sha256).hexdigest()
        headers["X-RP-Signature"] = f"sha256={signature}"

    request = urllib.request.Request(CLOUD_INGEST_URL, data=body, headers=headers, method="POST")
    try:
        with urllib.request.urlopen(request, timeout=timeout) as response:
            raw = response.read().decode()
            try:
                parsed = json.loads(raw)
            except json.JSONDecodeError:
                parsed = {"raw": raw}
            return {
                "uploaded": True,
                "status": response.status,
                "block_hash": item["blk"]["hash"],
                "response": parsed,
            }
    except urllib.error.HTTPError as error:
        detail = error.read().decode(errors="replace")
        raise CloudUploadError(f"cloud wallet rejected block: HTTP {error.code}: {detail}") from error
    except Exception as error:
        raise CloudUploadError(f"cloud wallet upload failed: {error}") from error


def upload_kaspa_block_to_cloud_wallet(item):
    if not cloud_upload_configured():
        return
    try:
        result = upload_block_to_cloud_wallet(item)
        print(" [KASPA] BLOCK UPLOADED TO CLOUD WALLET")
        print(f"   Block hash:  {result['block_hash']}")
        print(f"   HTTP status: {result['status']}")
        print(f"   Response:    {result['response']}")
    except Exception as error:
        print(f" [KASPA] cloud-wallet block upload failed: {error}")


# ============================================================================
# STRATUM MINER LAUNCHER
# ============================================================================

class MiningError(RuntimeError):
    pass


def validate_mining_config():
    if not KASPA_MINING_ENABLED:
        return False
    if not KASPA_MINING_ADDRESS.startswith("kaspa:"):
        raise MiningError("KASPA_MINING_ADDRESS must be a kaspa: payout address")
    if KASPA_MINING_MODE not in {"pool", "solo"}:
        raise MiningError("KASPA_MINING_MODE must be 'pool' or 'solo'")
    if KASPA_MINING_MODE == "pool" and not KASPA_STRATUM_URL:
        raise MiningError("KASPA_STRATUM_URL is required for pool mining")
    if not KASPA_MINER_COMMAND:
        raise MiningError("KASPA_MINER_COMMAND is required")
    return True


def start_miner():
    try:
        if not validate_mining_config():
            print("[MINING] mining disabled.")
            return None
    except MiningError as e:
        print(f"[MINING] Configuration warning: {e}")
        return None

    command = shlex.split(KASPA_MINER_COMMAND)
    resolved = []
    for part in command:
        part = part.replace("{WALLET}", KASPA_MINING_ADDRESS)
        part = part.replace("{STRATUM}", KASPA_STRATUM_URL)
        resolved.append(part)

    print("[MINING] starting external Stratum miner process...")
    print(f"[MINING] mode: {KASPA_MINING_MODE}")
    print(f"[MINING] payout address: {KASPA_MINING_ADDRESS}")
    print(f"[MINING] miner binary command: {' '.join(resolved)}")
    if KASPA_MINING_MODE == "pool":
        print(f"[MINING] stratum target: {KASPA_STRATUM_URL}")

    try:
        return subprocess.Popen(resolved)
    except FileNotFoundError:
        print(f"[MINING] Warning: Miner executable '{resolved[0]}' not found in system PATH. Ensure your miner binary is installed.")
        return None
    except Exception as error:
        print(f"[MINING] could not start miner: {error}")
        return None


# ============================================================================
# POOL DECODED-DETAILS FORWARDER
# ============================================================================

class PoolForwardError(RuntimeError):
    pass


def pool_forward_configured():
    return bool(KASPA_POOL_FORWARD_ENABLED and KASPA_POOL_FORWARD_URL)


def _build_pool_decoded_payload(item):
    block = item["blk"]
    decoded = item["d"]
    fields = decoded["fields"]

    decoded_clean = {
        k: v for k, v in decoded.items() if k != "fields"
    }
    field_diagnostics = {
        name: {
            "crc_ok": bool(meta[0]),
            "retries": meta[1],
            "margin_sigma": round(float(meta[2]), 4),
            "frames": meta[3],
        }
        for name, meta in fields.items()
    }

    return {
        "schema": "rp-ghost.kaspa.pool_decoded.v1",
        "source": "rp_ghost_kaspa_channel",
        "mining": {
            "mode": KASPA_MINING_MODE,
            "payout_address": KASPA_MINING_ADDRESS,
            "stratum_url": KASPA_STRATUM_URL,
        },
        "daemon": {"name": KASPA_DAEMON_NAME, "endpoint": KASPA_API},
        "block_hash": block["hash"],
        "decoded": decoded_clean,
        "field_diagnostics": field_diagnostics,
        "channel": {
            "decoded_at_unix_ms": int(time.time() * 1000),
            "decode_seconds": item["secs"],
            "skipped_newer_blocks": item["skipped"],
            "decoded_count": item["n_decoded"],
        },
    }


def _parse_stratum_endpoint(url):
    cleaned = url
    for prefix in ("stratum+tcp://", "stratum+ssl://", "stratum://", "tcp://"):
        if cleaned.lower().startswith(prefix):
            cleaned = cleaned[len(prefix):]
            break
    cleaned = cleaned.split("/")[0]
    if ":" not in cleaned:
        raise PoolForwardError(f"Invalid Stratum endpoint (missing host:port): {url}")
    host, port_str = cleaned.rsplit(":", 1)
    try:
        port = int(port_str)
    except ValueError as err:
        raise PoolForwardError(f"Invalid Stratum port in {url}") from err
    return host, port


def forward_decoded_to_pool(item, timeout=10):
    if not pool_forward_configured():
        raise PoolForwardError("Set KASPA_POOL_FORWARD_ENABLED=1 and KASPA_POOL_FORWARD_URL")

    fields = item["d"]["fields"]
    failed_fields = [name for name, meta in fields.items() if not meta[0]]
    if failed_fields:
        raise PoolForwardError(f"Skipping pool forward due to CRC failure on: {', '.join(failed_fields)}")

    payload = _build_pool_decoded_payload(item)
    body = json.dumps(payload, separators=(",", ":"), sort_keys=True).encode()
    target_url = KASPA_POOL_FORWARD_URL

    if target_url.lower().startswith(("http://", "https://")):
        headers = {
            "Content-Type": "application/json",
            "User-Agent": "rp-ghost-kaspa/1.0",
        }
        if KASPA_POOL_FORWARD_TOKEN:
            headers["Authorization"] = f"Bearer {KASPA_POOL_FORWARD_TOKEN}"
        if KASPA_POOL_FORWARD_SECRET:
            sig = hmac.new(KASPA_POOL_FORWARD_SECRET, body, hashlib.sha256).hexdigest()
            headers["X-RP-Signature"] = f"sha256={sig}"

        req = urllib.request.Request(target_url, data=body, headers=headers, method="POST")
        try:
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                raw = resp.read().decode(errors="replace")
                try:
                    parsed = json.loads(raw)
                except json.JSONDecodeError:
                    parsed = {"raw": raw}
                return {
                    "forwarded": True,
                    "transport": "http",
                    "target": target_url,
                    "status": resp.status,
                    "block_hash": item["blk"]["hash"],
                    "response": parsed,
                }
        except urllib.error.HTTPError as err:
            detail = err.read().decode(errors="replace")
            raise PoolForwardError(f"Pool HTTP endpoint rejected payload: HTTP {err.code}: {detail}") from err
        except Exception as err:
            raise PoolForwardError(f"Pool HTTP forward failed: {err}") from err

    host, port = _parse_stratum_endpoint(target_url)
    rpc_message = {
        "id": item["n_decoded"],
        "method": "mining.extranonce.decoded_block",
        "params": [KASPA_MINING_ADDRESS, payload],
    }
    wire_bytes = (json.dumps(rpc_message, separators=(",", ":")) + "\n").encode()

    try:
        with socket.create_connection((host, port), timeout=timeout) as sock:
            sock.settimeout(timeout)
            sock.sendall(wire_bytes)
            try:
                reply_raw = sock.recv(4096).decode(errors="replace").strip()
            except socket.timeout:
                reply_raw = ""
        return {
            "forwarded": True,
            "transport": "stratum-tcp",
            "target": f"{host}:{port}",
            "block_hash": item["blk"]["hash"],
            "response": reply_raw or "(sent)",
        }
    except Exception as err:
        raise PoolForwardError(f"Pool Stratum TCP forward failed ({host}:{port}): {err}") from err


def send_decoded_details_to_pool(item):
    if not pool_forward_configured():
        return
    try:
        result = forward_decoded_to_pool(item)
        print(" [POOL] DECODED DETAILS SENT TO POOL")
        print(f"   Target:      {result['target']} ({result['transport']})")
        print(f"   Block hash:  {result['block_hash']}")
        if "status" in result:
            print(f"   HTTP status: {result['status']}")
        print(f"   Response:    {result['response']}")
    except Exception as error:
        print(f" [POOL] pool decoded-details forward failed: {error}")


# ============================================================================
# FEED PROCESS
# ============================================================================

def _put_latest(item_queue, item):
    while True:
        try:
            item_queue.put_nowait(item)
            return
        except queue.Full:
            try:
                item_queue.get_nowait()
            except queue.Empty:
                pass


def _sim_block(previous_hash, daa_score):
    random_hash = lambda: hashlib.sha256(os.urandom(32)).hexdigest()
    block = {
        "version": 1,
        "parents": [
            [previous_hash] + [random_hash() for _ in range(int.from_bytes(os.urandom(1), "big") % 3)],
            [previous_hash],
        ],
        "hash_merkle_root": random_hash(),
        "accepted_id_merkle_root": random_hash(),
        "utxo_commitment": random_hash(),
        "timestamp_ms": int(time.time() * 1000),
        "bits": 0x1C0F2A31,
        "nonce": int.from_bytes(os.urandom(8), "big"),
        "daa_score": daa_score,
        "blue_score": daa_score - 1_500_000,
        "blue_work": int.from_bytes(os.urandom(21), "big"),
        "pruning_point": random_hash(),
        "tx_count": int.from_bytes(os.urandom(1), "big") % 40,
        "is_chain_block": True,
        "selected_parent": previous_hash,
        "api_difficulty": 12500000.0,
        "simulated": True,
    }
    block["hash"] = kaspa_header_hash(block)
    return block


async def _feed(raw_queue, stop_event, api, poll_seconds):
    loop = asyncio.get_running_loop()
    get = lambda url: loop.run_in_executor(None, _http_get, url)

    seen = set()
    order = []
    failures = 0
    simulated = KASPA_SIM
    announced = False

    sim_previous = hashlib.sha256(b"genesis").hexdigest()
    sim_daa = 600_000_000

    if simulated:
        print("[KASPA] KASPA_SIM=1", flush=True)

    while not stop_event.is_set():
        try:
            if simulated:
                await asyncio.sleep(1.0 / max(KASPA_SIM_BPS, 0.1))
                block = _sim_block(sim_previous, sim_daa)
                sim_previous = block["hash"]
                sim_daa += 1
                _put_latest(raw_queue, block)
                continue

            info = json.loads(await get(f"{api}/info/blockdag"))
            tips = [tip for tip in (info.get("tipHashes") or []) if tip not in seen]

            if not announced:
                print(
                    f"[KASPA] local daemon connected: {api}\n"
                    f"[KASPA] network={info.get('networkName', '?')} "
                    f"tips={len(info.get('tipHashes') or [])} "
                    f"virtual_daa={info.get('virtualDaaScore')}",
                    flush=True,
                )
                announced = True

            for tip in tips[:KASPA_MAX_FETCH]:
                seen.add(tip)
                order.append(tip)
                raw = json.loads(await get(f"{api}/blocks/{tip}?includeTransactions=false"))
                block = normalize_block(raw)
                if block["hash"] == "0" * 64:
                    block["hash"] = tip
                _put_latest(raw_queue, block)

            for tip in tips[KASPA_MAX_FETCH:]:
                seen.add(tip)
                order.append(tip)

            while len(order) > 4096:
                seen.discard(order.pop(0))

            failures = 0
            await asyncio.sleep(poll_seconds)

        except Exception as error:
            failures += 1
            if failures in (1, 3):
                print(f"[KASPA] local daemon error: {error} - switching to simulation mode.", flush=True)
            simulated = True
            await asyncio.sleep(2)


def _feed_main(raw_queue, stop_event, api, poll_seconds):
    try:
        asyncio.run(_feed(raw_queue, stop_event, api, poll_seconds))
    except KeyboardInterrupt:
        pass


# ============================================================================
# DECODER PROCESS
# ============================================================================

def _u64(viewport, value, webcam_hash, windows, retries):
    high, retries_1, ok_1, margin_1 = transmit_u32(viewport, (value >> 32) & 0xFFFFFFFF, webcam_hash, windows, retries)
    low, retries_2, ok_2, margin_2 = transmit_u32(viewport, value & 0xFFFFFFFF, webcam_hash, windows, retries)
    decoded = ((high << 32) | low) if ok_1 and ok_2 else None
    return decoded, retries_1 + retries_2, ok_1 and ok_2, min(margin_1, margin_2) if ok_1 and ok_2 else 0.0


def _hexs(viewport, hex_string, webcam_hash, windows, retries):
    decoded, retries_used, failed, margin = transmit_bytes_hex(viewport, hex_string, webcam_hash, windows, retries)
    return decoded, retries_used, failed == 0, margin


def decode_kaspa_block(viewport, block, webcam_hash=0, windows=KASPA_DECODE_WINDOWS, retries=KASPA_DECODE_RETRIES):
    decoded = {}
    fields = {}

    def record(name, value, retries_used, ok, margin, frames):
        fields[name] = (ok, retries_used, margin, frames)
        return value

    for field in ("version", "bits"):
        value, retries_used, ok, margin = transmit_u32(viewport, block[field], webcam_hash, windows, retries)
        decoded[field] = record(field, value, retries_used, ok, margin, 1)

    for field in ("timestamp_ms", "nonce", "daa_score", "blue_score"):
        value, retries_used, ok, margin = _u64(viewport, block[field], webcam_hash, windows, retries)
        decoded[field] = record(field, value, retries_used, ok, margin, 2)

    for field in KASPA_HASH_FIELDS:
        value, retries_used, ok, margin = _hexs(viewport, block[field], webcam_hash, windows, retries)
        decoded[field] = record(field, value, retries_used, ok, margin, 11)

    value, retries_used, ok, margin = _hexs(viewport, blue_work_hex(block["blue_work"]), webcam_hash, windows, retries)
    decoded["blue_work"] = record("blue_work", int(value, 16), retries_used, ok, margin, math.ceil(len(value) / 6))

    level_count, retries_used, ok, margin = transmit_u32(viewport, len(block["parents"]), webcam_hash, windows, retries)
    total_retries = retries_used
    all_ok = ok
    minimum_margin = margin
    frames = 1
    levels = []

    for level in (block["parents"] if ok else []):
        count, retries_used, ok, margin = transmit_u32(viewport, len(level), webcam_hash, windows, retries)
        total_retries += retries_used
        all_ok &= ok
        frames += 1
        if ok:
            minimum_margin = min(minimum_margin, margin)
        decoded_parents = []
        for parent in level:
            val, ret_u, ok_u, marg_u = _hexs(viewport, parent, webcam_hash, windows, retries)
            decoded_parents.append(val)
            total_retries += ret_u
            all_ok &= ok_u
            frames += 11
            if ok_u:
                minimum_margin = min(minimum_margin, marg_u)
        levels.append(decoded_parents)

    decoded["parents"] = record(
        "parents",
        levels,
        total_retries,
        all_ok,
        minimum_margin if minimum_margin != float("inf") else 0.0,
        frames,
    )
    decoded["fields"] = fields
    return decoded


def _decode_main(raw_queue, output_queue, stop_event, windows):
    try:
        webcam = WebcamEntropySource(WEBCAM_INDEX)
        webcam.start()
        viewport = OptoelectronicViewport()
        start_time = time.time()
        decoded_count = 0

        while not stop_event.is_set():
            try:
                block = raw_queue.get(timeout=0.5)
            except queue.Empty:
                continue

            skipped = 0
            while True:
                try:
                    block, skipped = raw_queue.get_nowait(), skipped + 1
                except queue.Empty:
                    break

            webcam_hash = webcam.latest_hash
            decode_start = time.time()
            decoded = decode_kaspa_block(viewport, block, webcam_hash=webcam_hash, windows=windows)
            decoded_count += 1

            _put_latest(
                output_queue,
                {
                    "blk": block,
                    "d": decoded,
                    "skipped": skipped,
                    "secs": time.time() - decode_start,
                    "n_decoded": decoded_count,
                    "uptime": time.time() - start_time,
                    "webcam_hash": webcam_hash,
                    "webcam_frames": webcam.frame_count,
                },
            )
        webcam.stop()
        webcam.join(timeout=1.0)
    except KeyboardInterrupt:
        pass


# ============================================================================
# REPORTING
# ============================================================================

def print_kaspa_report(item, title="KASPA BLOCK"):
    block = item["blk"]
    decoded = item["d"]
    fields = decoded["fields"]

    tag = ""
    failed_fields = [name for name, value in fields.items() if not value[0]]

    if failed_fields:
        print(f" [KASPA] {title}{tag} - CRC FAILED on: {', '.join(failed_fields)} (report skipped)")
        return

    source = {
        **{name: block[name] for name in KASPA_HASH_FIELDS + KASPA_INT_FIELDS},
        "blue_work": block["blue_work"],
        "parents": block["parents"],
    }

    checks = {name: decoded[name] == source[name] for name in fields}
    decoded_view = {**block, **{name: decoded[name] for name in fields}}
    recomputed_hash = kaspa_header_hash(decoded_view)

    utc_time = datetime.fromtimestamp(decoded["timestamp_ms"] / 1000, timezone.utc)
    age = time.time() - decoded["timestamp_ms"] / 1000
    parent_count = sum(len(level) for level in decoded["parents"])
    frames = sum(value[3] for value in fields.values())
    retries = sum(value[1] for value in fields.values())
    minimum_margin = min(value[2] for value in fields.values())

    exponent = (decoded["bits"] >> 24) & 0xFF
    mantissa = decoded["bits"] & 0x007FFFFF
    target = mantissa * (1 << (8 * (exponent - 3))) if exponent > 3 else mantissa >> (8 * (3 - exponent))

    print(f" [KASPA] {title}{tag} - ALL FIELDS DECODED")
    print(f"   --- Entropy Source ---")
    print(f"   Webcam Hash:   0x{item.get('webcam_hash', 0):04X} | Frame count: {item.get('webcam_frames', 0)}")
    print("   --- Identity ---")
    print(f"   Hash:          {decoded['hash']}")
    print(f"   DAA score:     {decoded['daa_score']:,}   |  Blue score: {decoded['blue_score']:,}")
    print(f"   Blue work:     0x{decoded['blue_work']:x} ({decoded['blue_work']:,})")

    print("   --- Header rebuilt from decoded fields ---")
    print(f"   Version:       {decoded['version']}")
    print(
        f"   Timestamp:     {decoded['timestamp_ms']} ms = {utc_time:%Y-%m-%d %H:%M:%S}."
        f"{decoded['timestamp_ms'] % 1000:03d} UTC ({max(age, 0):.1f}s ago)"
    )
    print(f"   Parents:       {parent_count} hash(es) across {len(decoded['parents'])} level(s)")

    for index, level in enumerate(decoded["parents"][:3]):
        preview = ", ".join(value[:16] + "..." for value in level[:4])
        if len(level) > 4:
            preview += f" (+{len(level) - 4})"
        print(f"     level {index}: {preview}")

    print(f"   Merkle root:   {decoded['hash_merkle_root']}")
    print(f"   Accepted-ID:   {decoded['accepted_id_merkle_root']}")
    print(f"   UTXO commit:   {decoded['utxo_commitment']}")
    print(f"   Pruning point: {decoded['pruning_point']}")
    print(f"   Bits:          0x{decoded['bits']:08X} | target {target:064x}")
    print(f"   Nonce:         {decoded['nonce']:,} (0x{decoded['nonce']:016X})")
    print(f"   Header check:  Blake2b-256('BlockHash', header) = {recomputed_hash}")

    if recomputed_hash == decoded["hash"]:
        print("                  MATCHES decoded hash - header is self-consistent")
    else:
        print("                  does not match decoded hash (informational only)")

    print("   --- From daemon, not sent through channel ---")
    print(
        f"   Transactions:  {block['tx_count']} | chain block: {block['is_chain_block']} | "
        f"selected parent: {(block['selected_parent'] or '?')[:16]}... | difficulty: {block['api_difficulty']}"
    )

    print("   --- Channel integrity ---")
    for name, value in fields.items():
        print(
            f"   {name:<24} CRC PASS | {value[3]:>3} frame(s) | "
            f"retries {value[1]} | margin {value[2]:.1f} sigma | "
            f"{'matches source' if checks[name] else 'MISMATCH vs source'}"
        )

    print(
        f"   Summary:       {sum(checks.values())}/{len(checks)} fields match source | "
        f"{frames} frames | {retries} CRC retries | min margin {minimum_margin:.1f} sigma"
    )
    print(
        f"   Throughput:    decoded in {item['secs']:.2f}s | "
        f"skipped {item['skipped']} newer queued block(s) | {item['n_decoded']} decoded in {item['uptime']:.0f}s"
    )


# ============================================================================
# PROCESS MANAGER
# ============================================================================

class KaspaChannel:
    def __init__(self, api=KASPA_API, poll_seconds=KASPA_POLL_SECONDS, windows=KASPA_DECODE_WINDOWS):
        context = mp.get_context("spawn")
        self.stop_event = context.Event()
        self.raw_queue = context.Queue(maxsize=64)
        self.output_queue = context.Queue(maxsize=8)

        self.processes = [
            context.Process(
                target=_feed_main,
                args=(self.raw_queue, self.stop_event, api, poll_seconds),
                name="kaspa-feed",
                daemon=True,
            ),
            context.Process(
                target=_decode_main,
                args=(self.raw_queue, self.output_queue, self.stop_event, windows),
                name="kaspa-decode",
                daemon=True,
            ),
        ]

    def start(self):
        for process in self.processes:
            process.start()
        return self

    def poll(self, limit=2):
        results = []
        for _ in range(limit):
            try:
                results.append(self.output_queue.get_nowait())
            except queue.Empty:
                break
        return results

    def alive(self):
        return all(process.is_alive() for process in self.processes)

    def stop(self):
        self.stop_event.set()
        for process in self.processes:
            process.join(timeout=2.0)
            if process.is_alive():
                process.terminate()


# ============================================================================
# MAIN
# ============================================================================

def run_standalone():
    print("=" * 78)
    print(" KASPA OPTOELECTRONIC WEBCAM PIPELINE + CHANNEL & PYTHON MINER")
    print("=" * 78)

    print(f"[DAEMON] target: {KASPA_DAEMON_NAME}")
    print(f"[DAEMON] endpoint: {KASPA_API}")

    if cloud_upload_configured():
        print(f"[CLOUD] uploads enabled: {CLOUD_INGEST_URL}")
    else:
        print("[CLOUD] uploads disabled.")

    if KASPA_MINING_ENABLED:
        print(f"[MINING] external/python miner launch enabled (Mode: {KASPA_MINING_MODE}).")
    else:
        print("[MINING] external miner launch disabled.")

    if pool_forward_configured():
        print(f"[POOL] decoded-details forwarding enabled: {KASPA_POOL_FORWARD_URL}")
    else:
        print("[POOL] decoded-details forwarding disabled.")

    miner_process = None
    channel = None

    try:
        if not KASPA_SIM:
            try:
                check_kaspa_daemon()
            except Exception as e:
                print(f"[DAEMON] Warning: {e}")
                print("[DAEMON] Falling back to built-in block simulation mode.")

        if KASPA_MINING_ENABLED:
            miner_process = start_miner()

        channel = KaspaChannel().start()

        while True:
            for item in channel.poll():
                print("-" * 78)
                print_kaspa_report(item)
                upload_kaspa_block_to_cloud_wallet(item)
                send_decoded_details_to_pool(item)

            if not channel.alive():
                print("[KASPA] a worker process exited.")
                break

            if miner_process is not None and miner_process.poll() is not None:
                print(f"[MINING] miner exited with code {miner_process.returncode}")
                miner_process = None

            time.sleep(0.2)

    except KeyboardInterrupt:
        print("\n[STOP] shutting down...")
    except Exception as error:
        print(f"[FATAL] {error}")
    finally:
        if miner_process is not None and miner_process.poll() is None:
            print("[MINING] stopping miner...")
            miner_process.terminate()
            try:
                miner_process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                miner_process.kill()
        if channel is not None:
            channel.stop()


if __name__ == "__main__":
    mp.freeze_support()
    run_standalone()
