"""
Bit-Pooling Oracle 10-Bit Lab + Hex-Format Revealed Status
(Tkinter / OpenCV Framework with Visual Bit Registers & Auto-Revealing Oracle)
"""

import asyncio
import queue
import random
import re
import sys
import threading
import time
import tkinter as tk
from tkinter import ttk, messagebox

import numpy as np

try:
    import cv2
except ImportError:
    cv2 = None

try:
    import serial
    import serial.tools.list_ports
except ImportError:
    serial = None


# ==============================================================================
# BIT-POOLING HIGHER-LOWER ORACLE CLASS (10-Bit / 0-1023 Target)
# ==============================================================================
class BitPoolingOracle:
    def __init__(self, bit_depth=360, target=None):
        self.bit_depth = bit_depth
        self.max_val = (1 << bit_depth) - 1  # 1023 for 10-bit
        self._target = int(np.clip(target, 0, self.max_val)) if target is not None else random.randint(0, self.max_val)
        
        self.kernel_size = 4
        self.stride = 2
        self.pool_op = "POPCOUNT"
        self.schmitt_trigger = 0.5
        
        self.pooled_bits = 0
        self.pooled_count = 0
        self.is_done = False

    def reveal(self):
        if not self.is_done:
            return 0
        return self._target

    def query_bit(self, trial_val):
        if self.is_done:
            return 0
        bit = 1 if self._target >= trial_val else 0
        return bit

    def pool_step(self, val):
        bits = [(val >> i) & 1 for i in range(self.bit_depth)]
        
        pooled_out = []
        for i in range(0, len(bits), self.stride):
            block = bits[i : i + self.kernel_size]
            if not block:
                break
                
            if self.pool_op == "POPCOUNT":
                res = sum(block) / len(block)
                res_bit = 1 if res >= self.schmitt_trigger else 0
            elif self.pool_op == "AND":
                res_bit = 1 if all(b == 1 for b in block) else 0
            elif self.pool_op == "OR":
                res_bit = 1 if any(b == 1 for b in block) else 0
            elif self.pool_op == "XOR":
                res_bit = sum(block) % 2
            elif self.pool_op == "MAJORITY":
                res_bit = 1 if sum(block) > (len(block) / 2.0) else 0
            else:
                res_bit = block[0]
                
            pooled_out.append(res_bit)

        out_val = 0
        for idx, b in enumerate(pooled_out):
            out_val |= (b << idx)
        return out_val

    @property
    def target(self):
        if not self.is_done:
            raise PermissionError("SECURITY VIOLATION: Oracle target is classified until fully pooled!")
        return self._target


# ==============================================================================
# BIT-POOLING SEARCH ENGINE
# ==============================================================================
class BitPoolingSearchEngine:
    def __init__(self, bit_depth=360):
        self.bit_depth = bit_depth
        self.max_val = (1 << bit_depth) - 1
        
        self.oracle = BitPoolingOracle(self.bit_depth)
        self.current_guess = 0
        self.step_count = 0
        self.history = []
        self.converged = False
        self.last_status = "INITIALIZED"

        self.kernel_size = 4
        self.stride = 2
        self.pool_op = "POPCOUNT"
        self.schmitt_trigger = 0.5
        
        self.guess_reg = 0
        self.target_reg = 0
        self.pooled_register = 0
        
        self._update_registers()

    def reset(self, new_target=None):
        self.oracle = BitPoolingOracle(self.bit_depth, new_target)
        self.current_guess = 0
        self.step_count = 0
        self.history = [self.current_guess]
        self.converged = False
        self.last_status = f"READY (Target: 0x{self.oracle._target:03X})"
        self._update_registers()

    def step(self):
        if self.converged or self.step_count >= self.bit_depth:
            return

        self.step_count += 1
        shift = self.bit_depth - self.step_count
        trial_val = self.oracle.pooled_bits | (1 << shift)
        
        bit = self.oracle.query_bit(trial_val)
        self.oracle.pooled_bits |= (bit << shift)
        self.current_guess = self.oracle.pooled_bits
        
        self.history.append(self.current_guess)
        self._update_registers()

        if self.step_count >= self.bit_depth:
            if self.current_guess == self.oracle._target:
                self.oracle.is_done = True  # Automatically unlocks oracle access[cite: 1]
                self.converged = True
                hex_str = f"0x{self.current_guess:03X}"
                self.last_status = f"LOCKED & REVEALED AT {hex_str} ({self.current_guess})"
            else:
                self.last_status = "POOL MISMATCH"

    def _update_registers(self):
        self.guess_reg = self.current_guess
        try:
            self.target_reg = self.oracle.target
        except PermissionError:
            self.target_reg = 0
            
        self.pooled_register = self.oracle.pool_step(self.current_guess)


# ==============================================================================
# CAMERA SOURCE HANDLING
# ==============================================================================
class Source:
    def __init__(self, index: int):
        if cv2 is None:
            raise RuntimeError("OpenCV is not installed. Run: pip install opencv-python")
        backend = cv2.CAP_DSHOW if sys.platform == "win32" else cv2.CAP_ANY
        cap = cv2.VideoCapture(index, backend)
        cap.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
        cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)
        if not (cap.isOpened() and cap.read()[0]):
            cap.release()
            raise RuntimeError(f"Cannot open camera {index}.")
        self.cap = cap
        self.rgb = None

    def read(self):
        ok, bgr = self.cap.read()
        if not ok:
            return None
        self.rgb = cv2.cvtColor(bgr, cv2.COLOR_BGR2RGB)
        return cv2.cvtColor(bgr, cv2.COLOR_BGR2GRAY)

    def close(self):
        self.cap.release()


def ppm_photo(rgb: np.ndarray) -> tk.PhotoImage:
    h, w, _ = rgb.shape
    data = b"P6 %d %d 255\n" % (w, h) + np.ascontiguousarray(rgb, np.uint8).tobytes()
    return tk.PhotoImage(data=data, format="PPM")


# ==============================================================================
# SERIAL RECEIVER BACKGROUND THREAD
# ==============================================================================
class SerialReceiverThread(threading.Thread):
    def __init__(self, port, baudrate, ctl_dict, out_queue):
        super().__init__(daemon=True)
        self.port = port
        self.baudrate = baudrate
        self.ctl = ctl_dict
        self.q = out_queue

    def run(self):
        if serial is None:
            self.q.put(("error", "pyserial is not installed. Run: pip install pyserial"))
            return

        try:
            ser = serial.Serial(self.port, self.baudrate, timeout=0.1)
            self.q.put(("info", f"Connected to serial port {self.port} at {self.baudrate} baud"))
        except Exception as e:
            self.q.put(("error", f"Failed to open serial port: {e}"))
            return

        try:
            while not self.ctl.get("stop_serial", False):
                if ser.in_waiting > 0:
                    line = ser.readline().decode("utf-8", errors="ignore").strip()
                    if line:
                        match = re.search(r'(?:target|val|t)?[\s:=]*(\d+)', line, re.IGNORECASE)
                        if match:
                            val = int(match.group(1))
                            if 0 <= val <= 1023:
                                self.q.put(("serial_target", val))
                        self.q.put(("serial_data", line))
                else:
                    time.sleep(0.01)
        finally:
            if ser.is_open:
                ser.close()
            self.q.put(("info", "Serial connection closed."))


# ==============================================================================
# BACKGROUND SIMULATION & CAMERA THREAD
# ==============================================================================
class SimThread(threading.Thread):
    def __init__(self, cam_index, ctl, out, engine):
        super().__init__(daemon=True)
        self.cam_index = cam_index
        self.ctl = ctl
        self.out = out
        self.engine = engine

    def run(self):
        asyncio.run(self._run())

    async def _run(self):
        ctl, out, engine = self.ctl, self.out, self.engine
        try:
            src = Source(self.cam_index)
        except RuntimeError as e:
            out.put(("error", str(e)))
            out.put(("done", None))
            return
        out.put(("info", f"USB camera {self.cam_index} opened"))

        t_prev = time.perf_counter()
        idx = 0
        prev_even = False
        try:
            while not ctl["stop"]:
                gray = await asyncio.to_thread(src.read)
                if gray is None:
                    out.put(("info", "camera stopped delivering frames"))
                    break
                now = time.perf_counter()
                dt = min(max(now - t_prev, 1e-3), 0.25)
                t_prev = now

                small = cv2.resize(gray, (128, 96), interpolation=cv2.INTER_AREA)
                motion_detected = idx > 5 and np.std(small) > 5.0
                x = int(np.std(small) * 10) if motion_detected else 0

                even_now = x > 0 and x % 2 == 0
                even_state = even_now and prev_even
                prev_even = even_now

                if even_state and ctl.get("auto_step", True) and not engine.converged:
                    engine.step()

                rgb = src.rgb if src.rgb is not None else np.stack([gray] * 3, axis=-1)
                pw, ph = 320, 240
                h_img, w_img = rgb.shape[:2]
                preview = rgb[np.arange(ph) * h_img // ph][:, np.arange(pw) * w_img // pw].copy()
                
                if ctl.get("ir_heatmap", False):
                    preview[:, :, 0] = np.clip(preview[:, :, 0].astype(int) + 80, 0, 255)
                    preview[:, :, 2] = np.clip(preview[:, :, 2].astype(int) - 50, 0, 255)

                exposed_target = engine.oracle._target if (engine.converged or ctl.get("force_reveal", False)) else 0

                out.put(("frame", dict(
                    preview=preview, idx=idx, dt=dt, target=exposed_target,
                    guess=engine.current_guess, pooled=engine.pooled_register,
                    status=engine.last_status, steps=engine.step_count,
                    history=list(engine.history), converged=engine.converged
                )))
                idx += 1
                await asyncio.sleep(0.03)
        finally:
            src.close()
            out.put(("done", None))


# ==============================================================================
# MAIN GUI APPLICATION
# ==============================================================================
class App:
    def __init__(self, window):
        self.window = window
        self.window.title("Bit-Pooling Oracle 10-Bit Lab + Hex Revealed Status")
        self.q = queue.Queue()
        self.ctl = dict(stop=False, stop_serial=False, ir_heatmap=False, auto_step=True, force_reveal=False)
        self.engine = BitPoolingSearchEngine(bit_depth=360)
        self.sim_thread = None
        self.serial_thread = None

        self._build_ui()
        self.window.protocol("WM_DELETE_WINDOW", self._close)
        self.window.after(15, self._poll)

    def _build_ui(self):
        main_frame = ttk.Frame(self.window, padding=10)
        main_frame.pack(fill="both", expand=True)

        ctrl_frame = ttk.LabelFrame(main_frame, text="Laboratory Controls")
        ctrl_frame.pack(fill="x", padx=5, pady=5)

        ttk.Button(ctrl_frame, text="Start Lab", command=self.start_lab).pack(side="left", padx=5, pady=5)
        ttk.Button(ctrl_frame, text="Stop Lab", command=self.stop_lab).pack(side="left", padx=5, pady=5)
        ttk.Button(ctrl_frame, text="Step Bit Pool", command=self.step_search).pack(side="left", padx=5, pady=5)
        ttk.Button(ctrl_frame, text="Reset Pool", command=self.reset_search).pack(side="left", padx=5, pady=5)

        self.v_ir = tk.BooleanVar(value=False)
        ttk.Checkbutton(ctrl_frame, text="IR Thermal Heatmap", variable=self.v_ir,
                        command=lambda: self.ctl.update(ir_heatmap=self.v_ir.get())).pack(side="left", padx=10)

        target_frame = ttk.LabelFrame(main_frame, text="10-Bit Target Management (0-1023)")
        target_frame.pack(fill="x", padx=5, pady=5)

        ttk.Label(target_frame, text="Target (0-1023):").pack(side="left", padx=5, pady=5)
        self.v_custom_target = tk.StringVar(value="[SECURE]")
        self.e_custom_target = ttk.Entry(target_frame, width=8, textvariable=self.v_custom_target)
        self.e_custom_target.pack(side="left", padx=5, pady=5)

        ttk.Button(target_frame, text="Set Custom", command=self.set_custom_target).pack(side="left", padx=2, pady=5)
        ttk.Button(target_frame, text="Randomize Target", command=self.randomize_target).pack(side="left", padx=5, pady=5)

        self.v_reveal = tk.BooleanVar(value=False)
        self.chk_reveal = ttk.Checkbutton(target_frame, text="Force Reveal Target", variable=self.v_reveal,
                                          command=lambda: self.ctl.update(force_reveal=self.v_reveal.get()))
        self.chk_reveal.pack(side="left", padx=15, pady=5)

        serial_frame = ttk.LabelFrame(main_frame, text="Serial Hardware Ingest (Updates Target at End of Oracle Run)")
        serial_frame.pack(fill="x", padx=5, pady=5)

        ttk.Label(serial_frame, text="Port:").pack(side="left", padx=5, pady=5)
        self.v_port = tk.StringVar(value="COM3" if sys.platform == "win32" else "/dev/ttyUSB0")
        self.e_port = ttk.Entry(serial_frame, width=12, textvariable=self.v_port)
        self.e_port.pack(side="left", padx=5, pady=5)

        ttk.Button(serial_frame, text="Connect Serial", command=self.start_serial).pack(side="left", padx=5, pady=5)
        ttk.Button(serial_frame, text="Disconnect Serial", command=self.stop_serial).pack(side="left", padx=5, pady=5)

        display_frame = ttk.Frame(main_frame)
        display_frame.pack(fill="both", expand=True, padx=5, pady=5)

        cam_frame = ttk.LabelFrame(display_frame, text="Optoelectronic Circuit Camera Viewport")
        cam_frame.pack(side="left", padx=5, pady=5)
        self.cam_canvas = tk.Canvas(cam_frame, width=320, height=240, bg="black")
        self.cam_canvas.pack(padx=5, pady=5)
        self.cam_img_id = self.cam_canvas.create_image(0, 0, anchor="nw")

        right_panel = ttk.Frame(display_frame)
        right_panel.pack(side="right", fill="both", expand=True, padx=5, pady=5)

        reg_frame = ttk.LabelFrame(right_panel, text="10-Bit Hardware Registers")
        reg_frame.pack(fill="x", padx=5, pady=5)

        self.reg_canvas = tk.Canvas(reg_frame, width=580, height=140, bg="#121414", highlightthickness=0)
        self.reg_canvas.pack(padx=5, pady=5)

        # Status label copyable via standard Tkinter text selection / double-click copy if desired
        self.lbl_status = ttk.Label(reg_frame, text="Status: IDLE", font=("Consolas", 11), foreground="#00e5ff")
        self.lbl_status.pack(anchor="w", padx=10, pady=5)

        log_frame = ttk.LabelFrame(right_panel, text="Serial Stream Log")
        log_frame.pack(fill="both", expand=True, padx=5, pady=5)

        self.text_log = tk.Text(log_frame, height=5, width=60, bg="#121414", fg="#00e5ff", insertbackground="white")
        self.text_log.pack(side="left", fill="both", expand=True, padx=5, pady=5)
        
        scrollbar = ttk.Scrollbar(log_frame, orient="vertical", command=self.text_log.yview)
        scrollbar.pack(side="right", fill="y")
        self.text_log.configure(yscrollcommand=scrollbar.set)

        set_frame = ttk.LabelFrame(right_panel, text="Pooling & Algorithm Settings")
        set_frame.pack(fill="x", padx=5, pady=5)

        ttk.Label(set_frame, text="Pooling Operator:").grid(row=0, column=0, sticky="w", padx=5, pady=5)
        self.op_combo = ttk.Combobox(set_frame, values=["POPCOUNT", "AND", "OR", "XOR", "MAJORITY"], state="readonly")
        self.op_combo.set("POPCOUNT")
        self.op_combo.grid(row=0, column=1, padx=5, pady=5)
        self.op_combo.bind("<<ComboboxSelected>>", self._update_pool_op)

        ttk.Label(set_frame, text="Kernel Size:").grid(row=1, column=0, sticky="w", padx=5, pady=5)
        self.kernel_spin = ttk.Spinbox(set_frame, from_=2, to=8, increment=2, width=5, command=self._update_kernel)
        self.kernel_spin.set(4)
        self.kernel_spin.grid(row=1, column=1, sticky="w", padx=5, pady=5)

    def start_lab(self):
        self.ctl["stop"] = False
        self.sim_thread = SimThread(0, self.ctl, self.q, self.engine)
        self.sim_thread.start()

    def stop_lab(self):
        self.ctl["stop"] = True

    def start_serial(self):
        if self.serial_thread and self.serial_thread.is_alive():
            return
        self.ctl["stop_serial"] = False
        port_name = self.v_port.get()
        self.serial_thread = SerialReceiverThread(port=port_name, baudrate=115200, ctl_dict=self.ctl, out_queue=self.q)
        self.serial_thread.start()

    def stop_serial(self):
        self.ctl["stop_serial"] = True

    def step_search(self):
        self.engine.step()

    def reset_search(self):
        self.engine.reset()
        self.v_custom_target.set("[SECURE]")

    def set_custom_target(self):
        try:
            val = int(self.v_custom_target.get())
            if 0 <= val <= self.engine.max_val:
                self.engine.reset(val)
                messagebox.showinfo("Target Set", f"New 10-bit custom target ({val}) configured.")
            else:
                messagebox.showerror("Invalid Range", f"Target must be between 0 and {self.engine.max_val}.")
        except ValueError:
            messagebox.showerror("Invalid Input", "Please enter a valid integer for the custom target.")

    def randomize_target(self):
        self.engine.reset()
        self.v_custom_target.set("[SECURE]")

    def _update_pool_op(self, event):
        op = self.op_combo.get()
        self.engine.pool_op = op
        self.engine.oracle.pool_op = op

    def _update_kernel(self):
        try:
            k = int(self.kernel_spin.get())
            self.engine.kernel_size = k
            self.engine.oracle.kernel_size = k
        except ValueError:
            pass

    def _draw_bit_rows(self, target_val, guess_val, pooled_val, revealed):
        self.reg_canvas.delete("all")
        bit_depth = self.engine.bit_depth
        
        is_exposed = revealed or self.engine.converged
        active_target = target_val if is_exposed else 0

        rows = [
            ("TARGET", active_target, "#00e676", not is_exposed),
            ("GUESS ", guess_val, "#ffb300", False),
            ("POOLED", pooled_val, "#b388ff", False)
        ]

        y_offset = 10
        for label, val, color, hidden in rows:
            self.reg_canvas.create_text(10, y_offset + 10, text=label, fill="#88a0c0", anchor="w", font=("Consolas", 10, "bold"))
            
            bx = 90
            for b in range(bit_depth - 1, -1, -1):
                bit_state = (val >> b) & 1
                self.reg_canvas.create_rectangle(
                    bx, y_offset, bx + 22, y_offset + 22, 
                    fill=color if (bit_state and not hidden) else "#1e2430", 
                    outline="#38445c"
                )
                txt_val = "?" if hidden else str(bit_state)
                txt_color = "#000000" if (bit_state and not hidden) else "#708090"
                self.reg_canvas.create_text(bx + 11, y_offset + 11, text=txt_val, fill=txt_color, font=("Consolas", 9, "bold"))
                bx += 26
            
            num_str = "[HIDDEN]" if hidden else f"[0x{val:03X}]"
            self.reg_canvas.create_text(bx + 5, y_offset + 11, text=num_str, fill="#d2e0f0", anchor="w", font=("Consolas", 9))
            y_offset += 40

    def _poll(self):
        try:
            for _ in range(100):
                ev = self.q.get_nowait()
                if ev[0] == "frame":
                    d = ev[1]
                    self.photo = ppm_photo(d["preview"])
                    self.cam_canvas.itemconfig(self.cam_img_id, image=self.photo)
                    self._draw_bit_rows(d["target"], d["guess"], d["pooled"], self.v_reveal.get())
                    self.lbl_status.config(text=f"Status: {d['status']} | Bit Step: {d['steps']}/{self.engine.bit_depth}")
                elif ev[0] == "serial_target":
                    target_val = ev[1]
                    if self.engine.converged or self.engine.step_count == 0:
                        self.engine.reset(target_val)
                        self.v_custom_target.set(str(target_val))
                        self.text_log.insert(tk.END, f"[ORACLE] End of run reached. Next target set via Serial: 0x{target_val:03X} ({target_val})\n")
                    else:
                        self.text_log.insert(tk.END, f"[SERIAL] Received target {target_val}, but oracle search is active.\n")
                    self.text_log.see(tk.END)
                elif ev[0] == "serial_data":
                    self.text_log.insert(tk.END, f"{ev[1]}\n")
                    self.text_log.see(tk.END)
                elif ev[0] == "info":
                    self.text_log.insert(tk.END, f"[INFO] {ev[1]}\n")
                    self.text_log.see(tk.END)
                elif ev[0] == "error":
                    messagebox.showerror("Lab Error", ev[1])
        except queue.Empty:
            pass
        self.window.after(30, self._poll)

    def _close(self):
        self.ctl["stop"] = True
        self.ctl["stop_serial"] = True
        self.window.destroy()


if __name__ == "__main__":
    root = tk.Tk()
    app = App(root)
    root.geometry("920x680")
    root.mainloop()
