#!/usr/bin/env python3
"""
FAA TAKEOFF (DEPARTURE) STATUS DECODER
--------------------------------------
Polls the FAA NAS status feed and decodes, through the phase channel, every
record that affects takeoffs:
  * departure delays   (Arrival_Departure Type="Departure")
  * airport closures   (no takeoffs at all)
  * optional: ground stops / ground delay programs (these hold flights headed TO
    the airport, so they are off by default):   export FAA_INCLUDE_PROGRAMS=1

Each record is flattened to one short text line, split into 3-byte chunks,
framed as [8-bit index | 24-bit data | 8-bit CRC-8] (40 slots), sent through the
optoelectronic channel, decoded, CRC-checked, retried on failure and printed.

Feed (no key): https://nasstatus.faa.gov/api/airport-status-information
Filter airports:  export FAA_AIRPORTS="JFK,ORD,LAX"      (default = all)
Coverage: US airports only.
"""

import math
import os
import threading
import time
import urllib.request
import xml.etree.ElementTree as ET
from datetime import datetime, timezone

import numpy as np

# ============================================================================
# CONFIG
# ============================================================================

LAMBDA_BASE = 10000.0
SIGMA_C = 0.005
N_SLOTS = 40
CHUNK_BYTES = 3
MAX_BYTES = 96                # max record length sent over the channel
WINDOWS = 2000
MAX_RETRIES = 4

FAA_API = "https://nasstatus.faa.gov/api/airport-status-information"
POLL_SECONDS = 60
MAX_RECORDS = 15              # records decoded per feed update
IDLE_PRINT_SECONDS = 30       # heartbeat line when nothing changed
WATCH = {a.strip().upper() for a in os.environ.get("FAA_AIRPORTS", "").split(",") if a.strip()}
INCLUDE_PROGRAMS = os.environ.get("FAA_INCLUDE_PROGRAMS", "") not in ("", "0", "false", "False")

SAMPLE_XML = """<AIRPORT_STATUS_INFORMATION>
<Update_Time>Tue Nov 17 14:05:00 2026 GMT</Update_Time>
<Delay_type><Name>Ground Stop Programs</Name><Ground_Stop_List>
<Program><ARPT>EWR</ARPT><Reason>thunderstorms</Reason><End_Time>3:00 pm EST</End_Time></Program>
</Ground_Stop_List></Delay_type>
<Delay_type><Name>Arrival/Departure Delay Info</Name><Arrival_Departure_Delay_List>
<Delay><ARPT>ORD</ARPT><Reason>volume</Reason><Arrival_Departure Type="Departure"><Min>16 minutes</Min><Max>30 minutes</Max><Trend>Increasing</Trend></Arrival_Departure></Delay>
<Delay><ARPT>JFK</ARPT><Reason>weather</Reason><Arrival_Departure Type="Arrival"><Min>20 minutes</Min><Max>45 minutes</Max><Trend>Stable</Trend></Arrival_Departure><Arrival_Departure Type="Departure"><Min>31 minutes</Min><Max>45 minutes</Max><Trend>Decreasing</Trend></Arrival_Departure></Delay>
<Delay><ARPT>SEA</ARPT><Reason>low visibility</Reason><Arrival_Departure Type="Arrival"><Min>15 minutes</Min><Max>29 minutes</Max><Trend>Stable</Trend></Arrival_Departure></Delay>
</Arrival_Departure_Delay_List></Delay_type>
<Delay_type><Name>Airport Closures</Name><Airport_Closure_List>
<Airport><ARPT>PHL</ARPT><Reason>runway repair</Reason><Start>Nov 17 at 06:00 UTC.</Start><Reopen>Nov 18 at 11:00 UTC.</Reopen></Airport>
</Airport_Closure_List></Delay_type>
</AIRPORT_STATUS_INFORMATION>"""

# ============================================================================
# CRC-8 + FRAMING
# ============================================================================


def crc8(data):
    crc = 0
    for byte in data:
        crc ^= byte
        for _ in range(8):
            crc = ((crc << 1) ^ 0x07) & 0xFF if crc & 0x80 else (crc << 1) & 0xFF
    return crc


def int_to_bits(value, width):
    return [(value >> (width - 1 - k)) & 1 for k in range(width)]


def bits_to_code(bits):
    code = 0
    for bit in bits:
        code = (code << 1) | (int(bit) & 1)
    return code


def encode_frame(index, chunk):
    """40 bits: 8-bit index | 24-bit data | 8-bit CRC-8 over index+data."""
    chunk = bytes(chunk).ljust(CHUNK_BYTES, b"\x00")[:CHUNK_BYTES]
    body = bytes([index & 0xFF]) + chunk
    return np.array(int_to_bits(body[0], 8) + [b for by in chunk for b in int_to_bits(by, 8)]
                    + int_to_bits(crc8(body), 8), dtype=int)


def decode_frame(bits):
    bits = np.asarray(bits, dtype=int).flatten()
    index = bits_to_code(bits[:8])
    chunk = bytes(bits_to_code(bits[8 + 8 * i: 16 + 8 * i]) for i in range(CHUNK_BYTES))
    return index, chunk, bits_to_code(bits[32:40]) == crc8(bytes([index]) + chunk)


def make_tilt(bits, eps_abs):
    return 2.0 * max(float(eps_abs), 0.25) * (np.asarray(bits, dtype=float) - 0.5)


# ============================================================================
# OPTICAL VIEWPORT (simulated phase channel)
# ============================================================================


class OptoelectronicViewport:
    def __init__(self, lambd=LAMBDA_BASE, sigma_c=SIGMA_C):
        self.lambd = lambd
        self.sigma_c = sigma_c
        print("[OPTICAL] Phase-coherent optical viewport initialized")

    def generate_window_block(self, n_windows, n_slots, tilt=None):
        shared = np.random.normal(0.0, self.sigma_c, size=(n_windows, 1))
        lam = self.lambd * (1.0 + shared)
        counts = np.random.poisson(np.clip(lam, 1.0, None), size=(n_windows, n_slots))
        Z = (counts - self.lambd) / np.sqrt(self.lambd)
        if tilt is not None:
            Z += tilt
        return Z


def _sigma_z():
    return math.sqrt(1.0 + SIGMA_C ** 2 * LAMBDA_BASE)


def transmit_text(viewport, text, windows=WINDOWS, max_retries=MAX_RETRIES):
    """Returns (decoded_text, frames, retries, failed, min_margin_sigma)."""
    raw = text.encode("utf-8")[:MAX_BYTES] + b"\x00"
    chunks = [raw[i:i + CHUNK_BYTES] for i in range(0, len(raw), CHUNK_BYTES)]
    sz = _sigma_z()
    scale = sz / math.sqrt(windows)
    received = bytearray()
    retries = failed = 0
    min_margin = float("inf")
    for i, chunk in enumerate(chunks):
        tilt = make_tilt(encode_frame(i, chunk), 0.02 * sz)
        good = None
        for _ in range(max_retries):
            m = viewport.generate_window_block(windows, N_SLOTS, tilt=tilt).mean(axis=0)
            idx, data, ok = decode_frame((m > 0).astype(int))
            if ok and idx == (i & 0xFF):
                good = data
                min_margin = min(min_margin, float(np.min(np.abs(m)) / scale))
                break
            retries += 1
        if good is None:
            failed += 1
            good = b"?" * CHUNK_BYTES
        received += good
    out = bytes(received).split(b"\x00", 1)[0].decode("utf-8", errors="replace")
    return out, len(chunks), retries, failed, (0.0 if min_margin == float("inf") else min_margin)


def transmit_u32(viewport, value, windows=WINDOWS, max_retries=MAX_RETRIES):
    """Returns (decoded_value or None, ok)."""
    value &= 0xFFFFFFFF
    bits = np.array(int_to_bits(value, 32) + int_to_bits(crc8(value.to_bytes(4, "big")), 8), dtype=int)
    tilt = make_tilt(bits, 0.02 * _sigma_z())
    for _ in range(max_retries):
        m = viewport.generate_window_block(windows, N_SLOTS, tilt=tilt).mean(axis=0)
        d = (m > 0).astype(int)
        got = bits_to_code(d[:32])
        if bits_to_code(d[32:40]) == crc8(got.to_bytes(4, "big")):
            return got, True
    return None, False


# ============================================================================
# FAA FEED PARSING (takeoff-relevant records only)
# ============================================================================


def format_age(age_sec):
    s = max(0, int(age_sec))
    d, rem = divmod(s, 86400)
    h, rem = divmod(rem, 3600)
    m, sec = divmod(rem, 60)
    if d:
        return f"{d}d {h}h"
    if h:
        return f"{h}h {m}m"
    return f"{m}m {sec}s" if m else f"{sec}s"


def parse_update_time(text):
    """'Fri Sep 15 12:04:41 2023 GMT' -> unix seconds (UTC) or None."""
    try:
        dt = datetime.strptime(text.strip().replace(" GMT", ""), "%a %b %d %H:%M:%S %Y")
        return int(dt.replace(tzinfo=timezone.utc).timestamp())
    except Exception:
        return None


def _clean(el, tag):
    v = (el.findtext(tag) or "").strip().rstrip(".")
    return v


def parse_takeoff_records(xml_text):
    """Returns (update_time_text, records). Record = {airport, kind, rank, line}."""
    root = ET.fromstring(xml_text)
    update_time = (root.findtext("Update_Time") or "").strip()
    records = []

    def add(airport, kind, rank, parts):
        airport = airport.upper()
        if not airport or (WATCH and airport not in WATCH):
            return
        line = "|".join([airport, kind] + [p for p in parts if p])
        records.append({"airport": airport, "kind": kind, "rank": rank, "line": line})

    for dtype in root.iter("Delay_type"):
        name = (dtype.findtext("Name") or "").lower()
        for lst in dtype:
            if lst.tag == "Name":
                continue
            for rec in lst:
                arpt = _clean(rec, "ARPT")
                reason = _clean(rec, "Reason")
                if "closure" in name:                                    # no takeoffs at all
                    add(arpt, "CLOSED", 0, [reason, "from " + _clean(rec, "Start") if _clean(rec, "Start") else "",
                                            "reopen " + _clean(rec, "Reopen") if _clean(rec, "Reopen") else ""])
                elif "arrival" in name or "departure" in name:           # Arrival/Departure Delay Info
                    for ad in rec.findall("Arrival_Departure"):
                        if ad.attrib.get("Type", "").lower() != "departure":
                            continue                                     # arrivals don't affect takeoffs
                        mn, mx, tr = _clean(ad, "Min"), _clean(ad, "Max"), _clean(ad, "Trend")
                        add(arpt, "DEP DELAY", 1, [reason, "min " + mn if mn else "",
                                                   "max " + mx if mx else "", tr])
                elif INCLUDE_PROGRAMS and "ground stop" in name:
                    add(arpt, "GROUND STOP (inbound held)", 2, [reason,
                        "until " + _clean(rec, "End_Time") if _clean(rec, "End_Time") else ""])
                elif INCLUDE_PROGRAMS and "ground delay" in name:
                    avg, mx = _clean(rec, "Avg"), _clean(rec, "Max")
                    add(arpt, "GDP (inbound held)", 3, [reason, "avg " + avg if avg else "",
                                                        "max " + mx if mx else ""])
    records.sort(key=lambda r: (r["rank"], r["airport"]))
    return update_time, records


class FAAFetcher(threading.Thread):
    """Polls the feed; queues a snapshot only when takeoff-relevant content changes.
    Falls back to a clearly-labelled SAMPLE feed if the API is unreachable at startup."""

    def __init__(self, url=FAA_API, poll_seconds=POLL_SECONDS):
        super().__init__(daemon=True)
        self.url = url
        self.poll_seconds = poll_seconds
        self.pending = None
        self.last_sig = None
        self.have_live = False
        self.lock = threading.Lock()
        self.running = True

    def _fetch_xml(self):
        req = urllib.request.Request(self.url, headers={"User-Agent": "faa-takeoffs/1.0",
                                                        "Accept": "application/xml"})
        with urllib.request.urlopen(req, timeout=10) as resp:
            return resp.read().decode("utf-8", errors="replace")

    def ingest(self, xml_text, simulated):
        update_time, records = parse_takeoff_records(xml_text)
        sig = (update_time, tuple(r["line"] for r in records))
        with self.lock:
            if sig == self.last_sig:
                return
            self.last_sig = sig
            self.pending = {"update_time": update_time, "records": records, "simulated": simulated}

    def run(self):
        fails = 0
        while self.running:
            try:
                self.ingest(self._fetch_xml(), simulated=False)
                self.have_live = True
                fails = 0
            except Exception as e:
                fails += 1
                print(f"[FAA] Fetch failed: {e}")
                if not self.have_live and fails >= 3 and self.last_sig is None:
                    print("[FAA] Feed unreachable - using SAMPLE data (not real conditions).")
                    self.ingest(SAMPLE_XML, simulated=True)
            for _ in range(self.poll_seconds):
                if not self.running:
                    break
                time.sleep(1)

    def pop_update(self):
        with self.lock:
            snap, self.pending = self.pending, None
            return snap

    def stop(self):
        self.running = False


# ============================================================================
# DECODE + DISPLAY
# ============================================================================


def decode_snapshot(viewport, snap):
    ut = parse_update_time(snap["update_time"])
    dec_ut, ok_ut = transmit_u32(viewport, ut) if ut is not None else (None, False)
    results = []
    for rec in snap["records"][:MAX_RECORDS]:
        text, frames, retries, failed, margin = transmit_text(viewport, rec["line"])
        sent = rec["line"].encode("utf-8")[:MAX_BYTES].decode("utf-8", errors="replace")
        results.append({"text": text, "kind": rec["kind"], "frames": frames, "retries": retries,
                        "failed": failed, "margin": margin, "match": failed == 0 and text == sent})
    return dec_ut, ok_ut, results


def print_snapshot(snap, dec_ut, ok_ut, results):
    tag = " (SAMPLE DATA)" if snap["simulated"] else ""
    total = len(snap["records"])
    scope = f" for {','.join(sorted(WATCH))}" if WATCH else ""
    closed = sum(1 for r in snap["records"] if r["kind"] == "CLOSED")
    delays = sum(1 for r in snap["records"] if r["kind"] == "DEP DELAY")
    print("-" * 78)
    print(f" [FAA TAKEOFFS] UPDATE{tag} | {total} record(s){scope} | {closed} closed, {delays} departure delay(s)")
    if ok_ut:
        print(f"   Feed time (decoded): {time.strftime('%Y-%m-%d %H:%M:%S', time.gmtime(dec_ut))} UTC "
              f"({format_age(time.time() - dec_ut)} ago) (CRC PASS)")
    else:
        print(f"   Feed time: {snap['update_time'] or 'unknown'} (channel decode unavailable / CRC FAIL)")
    if not results:
        print("   No departure delays or closures reported - takeoffs normal at all listed airports.")
    for n, r in enumerate(results, 1):
        integrity = "" if r["failed"] == 0 else f" | {r['failed']} frame(s) unrecoverable"
        print(f"   [{n:02d}] {r['text']}")
        print(f"        {r['frames']} frames | CRC retries {r['retries']} | min bit margin "
              f"{r['margin']:.1f} sigma | {'MATCHES feed' if r['match'] else 'MISMATCH'}{integrity}")
    if total > len(results):
        print(f"   ... {total - len(results)} more record(s) not decoded (MAX_RECORDS={MAX_RECORDS})")
    print("-" * 78)


def main():
    print("=" * 78)
    print(" FAA TAKEOFF STATUS DECODER (departure delays + closures)")
    print("=" * 78)
    viewport = OptoelectronicViewport()
    faa = FAAFetcher()
    faa.start()
    print("[START] Polling FAA feed. Press Ctrl+C to exit.\n")
    last_print = time.time()
    try:
        while True:
            snap = faa.pop_update()
            if snap:
                print_snapshot(snap, *decode_snapshot(viewport, snap))
                last_print = time.time()
            elif time.time() - last_print >= IDLE_PRINT_SECONDS:
                print(f" [FAA TAKEOFFS] no change since last update ({time.strftime('%H:%M:%S')})")
                last_print = time.time()
            time.sleep(1.0)
    except KeyboardInterrupt:
        print("\n[STOP] Shutting down...")
    finally:
        faa.stop()
        faa.join(timeout=2.0)
        print("[DONE] Terminated.")


if __name__ == "__main__":
    main()
