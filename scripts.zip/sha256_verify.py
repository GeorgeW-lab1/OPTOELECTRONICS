#!/usr/bin/env python3
"""
sha256_verify.py - compute SHA-256 of some data and check it against an
expected hash.

Usage
  python sha256_verify.py --text "hello world" --hash b94d27b9934d3e08...
  python sha256_verify.py --file notes.txt     --hash 1f09d30c707d53f3...
  cat notes.txt | python sha256_verify.py --hash 1f09d30c707d53f3...
  python sha256_verify.py --text "hello world"          # no --hash: just prints the digest
"""
import argparse
import hashlib
import hmac
import sys


def sha256_hex(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def main():
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    src = ap.add_mutually_exclusive_group()
    src.add_argument("--text", help="verify this literal string")
    src.add_argument("--file", help="verify the contents of this file")
    ap.add_argument("--hash", dest="expected", metavar="HEXDIGEST",
                    help="expected SHA-256 hex digest (64 chars). "
                         "If omitted, just prints the computed digest.")
    args = ap.parse_args()

    if args.text is not None:
        data = args.text.encode("utf-8")
        source = "text"
    elif args.file is not None:
        try:
            with open(args.file, "rb") as f:
                data = f.read()
        except OSError as e:
            sys.exit(f"could not read {args.file}: {e}")
        source = args.file
    elif not sys.stdin.isatty():
        data = sys.stdin.buffer.read()
        source = "stdin"
    else:
        sys.exit("give --text, --file, or pipe data on stdin")

    digest = sha256_hex(data)
    print(f"source : {source} ({len(data)} bytes)")
    print(f"sha256 : {digest}")

    if args.expected:
        expected = args.expected.strip().lower()
        if len(expected) != 64 or any(c not in "0123456789abcdef" for c in expected):
            sys.exit("--hash must be a 64-character hex SHA-256 digest")
        match = hmac.compare_digest(digest, expected)
        print(f"match  : {match}")
        sys.exit(0 if match else 1)


if __name__ == "__main__":
    main()
