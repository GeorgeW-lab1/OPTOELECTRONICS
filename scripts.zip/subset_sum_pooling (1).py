#!/usr/bin/env python3
"""
Subset-sum solver built on the architecture of
"Parallel Optical Bit Pooling with Commit-Only Hidden-Number Recovery".

Mapping from the paper to subset sum
------------------------------------
hidden integer N / bit vector b      -> hidden selection vector x in {0,1}^n
published commitment (salt, hash)    -> instance (weights a, target T); verifier V(x): a.x == T
camera frame (noisy bit readout)     -> one randomised heuristic run (noisy estimate of x)
majority vote, sufficient stat D_i   -> weighted vote D_i = sum_t w_t * (+1 / -1)
Chase decoder over L least-reliable  -> bounded flip search over the L lowest-|D_i| items
hash check                           -> exact sum check (here the verifier also gives a
                                        residual T - a.x_hat, so the flip search can be
                                        replaced by a meet-in-the-middle on the L positions)

Honest caveat: subset sum is NP-complete. This does not change that. The method works
when the randomised heuristic is a *biased* estimator of some solution (many solutions,
high density, or planted structure). It is a heuristic with an exact verifier: it never
returns a wrong answer, but it may return None.
"""
import itertools
import math
import random
import time
from typing import List, Optional, Sequence


def verify(a: Sequence[int], T: int, x: Sequence[int]) -> bool:
    return sum(ai for ai, xi in zip(a, x) if xi) == T


# --------------------------------------------------------------------------
# One "exposure": randomised greedy + local search -> noisy estimate of a solution
# --------------------------------------------------------------------------
def exposure(a: List[int], T: int, rng: random.Random, jitter: float = 0.5):
    n = len(a)
    # noisy ordering: largest-first with multiplicative jitter (the "sensor noise")
    order = sorted(range(n), key=lambda i: -a[i] * (1 + jitter * rng.random()))
    x = [0] * n
    s = 0
    for i in order:
        if s + a[i] <= T:
            x[i] = 1
            s += a[i]
    # local search: 1-flip and 1-swap moves that reduce |s - T|
    improved = True
    while improved and s != T:
        improved = False
        idx = list(range(n))
        rng.shuffle(idx)
        for i in idx:                      # single flip
            ns = s - a[i] if x[i] else s + a[i]
            if abs(ns - T) < abs(s - T):
                x[i] ^= 1
                s = ns
                improved = True
                if s == T:
                    break
        if s == T:
            break
        ones = [i for i in range(n) if x[i]]
        zeros = [i for i in range(n) if not x[i]]
        rng.shuffle(ones)
        rng.shuffle(zeros)
        done = False
        for i in ones:                     # swap
            for j in zeros:
                ns = s - a[i] + a[j]
                if abs(ns - T) < abs(s - T):
                    x[i], x[j] = 0, 1
                    s = ns
                    improved = done = True
                    break
            if done or s == T:
                break
    return x, s


# --------------------------------------------------------------------------
# Chase-type list decoding on the least-reliable positions
# --------------------------------------------------------------------------
def chase_search(a, T, xhat, margins, L=16, t=4, budget=200_000):
    """Paper-faithful: flip <= t bits among the L least-reliable positions."""
    n = len(a)
    L = min(L, n)
    U = sorted(range(n), key=lambda i: margins[i])[:L]
    s0 = sum(ai for ai, xi in zip(a, xhat) if xi)
    if s0 == T:
        return list(xhat), 1
    tested = 1
    for k in range(1, min(t, L) + 1):
        for S in itertools.combinations(U, k):
            tested += 1
            if tested > budget:
                return None, tested
            d = sum(-a[i] if xhat[i] else a[i] for i in S)
            if s0 + d == T:
                y = list(xhat)
                for i in S:
                    y[i] ^= 1
                return y, tested
    return None, tested


def mitm_flip_search(a, T, xhat, margins, L=24):
    """
    Upgrade over Chase: because the verifier exposes the residual, we need a subset
    of the L uncertain positions whose signed flip effects sum to T - s0. Solved
    exactly by meet-in-the-middle in O(2^(L/2)) instead of enumerating Hamming balls.
    """
    n = len(a)
    L = min(L, n)
    U = sorted(range(n), key=lambda i: margins[i])[:L]
    s0 = sum(ai for ai, xi in zip(a, xhat) if xi)
    need = T - s0
    delta = [(-a[i] if xhat[i] else a[i]) for i in U]
    h = L // 2
    left, right = delta[:h], delta[h:]
    table = {}
    for mask in range(1 << len(left)):
        v = sum(left[j] for j in range(len(left)) if mask >> j & 1)
        table.setdefault(v, mask)
    for mask in range(1 << len(right)):
        v = sum(right[j] for j in range(len(right)) if mask >> j & 1)
        if need - v in table:
            lm = table[need - v]
            y = list(xhat)
            for j in range(len(left)):
                if lm >> j & 1:
                    y[U[j]] ^= 1
            for j in range(len(right)):
                if mask >> j & 1:
                    y[U[h + j]] ^= 1
            return y
    return None


# --------------------------------------------------------------------------
# Top-level solver
# --------------------------------------------------------------------------
def solve(a: List[int], T: int, max_cycles: int = 800, L: int = 16, t: int = 4,
          use_mitm: bool = True, mitm_L: int = 24, seed: Optional[int] = None,
          verbose: bool = False):
    rng = random.Random(seed)
    n = len(a)
    scale = max(1.0, sum(a) / n)
    D = [0.0] * n                       # weighted vote difference (sufficient statistic)
    seen = [False] * n                  # kept for cover-time diagnostics
    cover_cycle = None
    for cycle in range(1, max_cycles + 1):
        x, s = exposure(a, T, rng)
        if s == T:
            return x, {"cycles": cycle, "how": "direct hit"}
        w = math.exp(-abs(s - T) / scale)   # closer-to-target runs carry more weight
        for i in range(n):
            D[i] += w if x[i] else -w
            seen[i] = True
        if cover_cycle is None and all(seen):
            cover_cycle = cycle
        xhat = [1 if D[i] > 0 else 0 for i in range(n)]     # ties -> 0, as in the paper
        margins = [abs(d) for d in D]
        if verbose and cycle % 10 == 0:
            print(f"  cycle {cycle}: |gap of majority| = "
                  f"{abs(sum(ai for ai, xi in zip(a, xhat) if xi) - T)}")
        y, tested = chase_search(a, T, xhat, margins, L=L, t=t)
        if y is not None and verify(a, T, y):
            return y, {"cycles": cycle, "how": f"chase ({tested} candidates)"}
        if use_mitm:
            y = mitm_flip_search(a, T, xhat, margins, L=mitm_L)
            if y is not None and verify(a, T, y):
                return y, {"cycles": cycle, "how": f"meet-in-the-middle on {mitm_L} weakest bits"}
    return None, {"cycles": max_cycles, "how": "failed"}


def brute_mitm(a, T):
    """Exact baseline, O(2^(n/2)); only for small n."""
    n = len(a)
    h = n // 2
    left, right = a[:h], a[h:]
    table = {}
    for mask in range(1 << len(left)):
        v = sum(left[j] for j in range(len(left)) if mask >> j & 1)
        table.setdefault(v, mask)
    for mask in range(1 << len(right)):
        v = sum(right[j] for j in range(len(right)) if mask >> j & 1)
        if T - v in table:
            lm = table[T - v]
            return [(lm >> j & 1) for j in range(h)] + [(mask >> j & 1) for j in range(len(right))]
    return None


def planted_instance(n: int, bits: int, seed: int):
    rng = random.Random(seed)
    a = [rng.getrandbits(bits) + 1 for _ in range(n)]
    x = [rng.random() < 0.5 for _ in range(n)]
    return a, sum(ai for ai, xi in zip(a, x) if xi), [int(v) for v in x]


if __name__ == "__main__":
    for n, bits in [(30, 20), (40, 24), (50, 32), (56, 40)]:
        a, T, _ = planted_instance(n, bits, seed=n)
        t0 = time.time()
        sol, info = solve(a, T, seed=1)
        dt = time.time() - t0
        ok = sol is not None and verify(a, T, sol)
        print(f"n={n:3d} bits={bits:2d} density={n/bits:4.2f}  "
              f"solved={ok}  {info['cycles']:3d} cycles  via {info['how']}  ({dt:.2f}s)")
