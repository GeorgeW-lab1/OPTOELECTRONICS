import ngrok
import time

# Forward your local proxy port using the TCP protocol
listener = ngrok.forward("localhost:3333", authtoken_from_env=True, proto="tcp")

print(f"Ingress established at: {listener.url()}")

# Keep the script running to maintain the tunnel
try:
    while True:
        time.sleep(1)
except KeyboardInterrupt:
    pass
