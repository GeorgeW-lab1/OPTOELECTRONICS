#!/usr/bin/env python3
"""
rp_camera_sim.py - RP-style optoelectronic decision circuit, driven by raw camera frames.

Signal chain (follows the supplied diagrams / RP-GHOST appendices):

  camera frame (96x128 gray, "raw" as far as the driver allows)
    -> detector A = right ROI mean, detector B = left ROI mean   (the delta-intensity pair)
    -> motion-energy mask E = |frame_t - frame_t-1| > thr, count x_t, digest d_t = SHA-256(E)
    -> instance x_n (odd 32-bit number built from the digest; 50% are forced prime)
    -> Driver A (randomized): r = 2 + SHA256(E, detA, detB) mod (x-3); A = 1 iff r is a
                              Miller-Rabin witness of compositeness   (A = 0 always on primes)
    -> Driver B (deterministic): c(x) = [x >= 4] charges RC node (tau) -> NPN emitter follower
                              VB = max(0, VC - 0.7); B = 1 iff VB >= 3.5 V (74HC logic HIGH)
    -> AND(a,b) -> 150 ms delay -> and_dly ;  OR(a,b) = leak/time-code path
    -> Y = time-code latch bit (isolated number, MSB first, one bit per clock)
    -> D = and_dly OR Y   ("leak" mode, as in the drawing)   or   D = Y   ("isolated" mode)
    -> 74HC74: Q <= D on each clock edge. SELECT = Q, observe = not Q
    -> SELECT bits are pooled into hex words and compared with the isolated number
  Independent probe: AND(a,b) with flip noise p, runs for half the duration (main runs 2x longer).
  H-instrumentation (A.9): nonce picked AFTER the digest from os.urandom, SHA-256d vs 2^-k target.

Usage:
  python rp_camera_sim.py --list
  python rp_camera_sim.py --device 0 --ticks 600
  python rp_camera_sim.py --synthetic --ticks 2000 --y-mode isolated
  python rp_camera_sim.py --device 0 --dark      # cover the lens: pure sensor noise
Needs: numpy (+ opencv-python for a real camera).
"""
import argparse, csv, hashlib, math, os, random, struct, sys, time
import numpy as np

try:
    import cv2
except ImportError:
    cv2 = None

H, W = 96, 128          # 12,288 pixels, as in RP-GHOST Appendix A/D
VS, VBE, VIH = 5.0, 0.7, 3.5


# ----------------------------------------------------------------------------- camera
class RawCamera:
    """OpenCV capture with RGB conversion disabled where the driver allows it."""

    def __init__(self, device=0, width=640, height=480, fourcc=None, fps=30):
        if cv2 is None:
            sys.exit("opencv-python is not installed (pip install opencv-python), or use --synthetic")
        backend = cv2.CAP_V4L2 if sys.platform.startswith("linux") else cv2.CAP_ANY
        self.cap = cv2.VideoCapture(device, backend)
        if not self.cap.isOpened():
            sys.exit(f"cannot open camera {device}")
        if fourcc:
            self.cap.set(cv2.CAP_PROP_FOURCC, cv2.VideoWriter_fourcc(*fourcc))
        self.cap.set(cv2.CAP_PROP_FRAME_WIDTH, width)
        self.cap.set(cv2.CAP_PROP_FRAME_HEIGHT, height)
        self.cap.set(cv2.CAP_PROP_FPS, fps)
        self.cap.set(cv2.CAP_PROP_CONVERT_RGB, 0)       # ask for unconverted frames
        # try to freeze auto controls so the noise floor is the sensor's, not the ISP's
        for prop, val in ((cv2.CAP_PROP_AUTO_EXPOSURE, 1), (cv2.CAP_PROP_AUTOFOCUS, 0),
                          (cv2.CAP_PROP_AUTO_WB, 0)):
            self.cap.set(prop, val)
        ok, f = self.cap.read()
        if not ok:
            sys.exit("camera opened but returned no frame")
        print(f"[camera] frame shape={f.shape} dtype={f.dtype} "
              f"fourcc={int(self.cap.get(cv2.CAP_PROP_FOURCC)):#x}")

    @staticmethod
    def to_gray(f):
        if f.dtype == np.uint16:                        # 10/12/16-bit raw: keep top 8 bits
            f = (f >> 8).astype(np.uint8) if f.max() > 4095 else (f >> 2).astype(np.uint8)
        if f.ndim == 3 and f.shape[2] == 2:             # YUYV packed: Y is channel 0
            return f[:, :, 0]
        if f.ndim == 3 and f.shape[2] == 3:
            return (0.114 * f[:, :, 0] + 0.587 * f[:, :, 1] + 0.299 * f[:, :, 2]).astype(np.uint8)
        if f.ndim == 1 or (f.ndim == 2 and f.shape[0] == 1):  # flat raw buffer, best effort
            f = f.reshape(-1)
            return np.resize(f, (H, W)).astype(np.uint8)
        return f

    def read(self):
        ok, f = self.cap.read()
        if not ok:
            raise RuntimeError("camera read failed")
        g = self.to_gray(f)
        return cv2.resize(g, (W, H), interpolation=cv2.INTER_AREA)

    def close(self):
        self.cap.release()


class SyntheticSensor:
    """Poisson (shot-noise-limited) sensor, 1 e-/DN, with an optional moving blob."""

    def __init__(self, dark=False, seed=None):
        self.rng = np.random.default_rng(seed)
        self.t = 0
        self.dark = dark
        yy, xx = np.mgrid[0:H, 0:W]
        self.yy, self.xx = yy, xx

    def read(self):
        self.t += 1
        mean = 100.0 + 0.0 * self.xx
        if not self.dark:
            cx = W / 2 + 40 * math.sin(self.t / 9.0)
            cy = H / 2 + 25 * math.cos(self.t / 13.0)
            mean = mean + 80 * np.exp(-((self.xx - cx) ** 2 + (self.yy - cy) ** 2) / 60.0)
        return np.clip(self.rng.poisson(mean), 0, 255).astype(np.uint8)

    def close(self):
        pass


# ----------------------------------------------------------------------------- number theory
SMALL_PRIMES = (2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37)


def is_prime(n):
    if n < 2:
        return False
    for p in SMALL_PRIMES:
        if n % p == 0:
            return n == p
    d, s = n - 1, 0
    while d % 2 == 0:
        d //= 2
        s += 1
    for a in SMALL_PRIMES:                       # deterministic for n < 3.3e24
        if is_witness(a, n, d, s):
            return False
    return True


def is_witness(a, n, d=None, s=None):
    """True iff a proves n composite (Miller-Rabin). Never true for a prime n."""
    if d is None:
        d, s = n - 1, 0
        while d % 2 == 0:
            d //= 2
            s += 1
    y = pow(a, d, n)
    if y in (1, n - 1):
        return False
    for _ in range(s - 1):
        y = y * y % n
        if y == n - 1:
            return False
    return True


def next_prime(n):
    n |= 1
    while not is_prime(n):
        n += 2
    return n


# ----------------------------------------------------------------------------- circuit blocks
class TimeCodeLatch:
    """Isolated number, one bit per clock slot, MSB first."""

    def __init__(self, value, nbits):
        self.value, self.nbits = value & ((1 << nbits) - 1), nbits

    def bit(self, slot):
        return (self.value >> (self.nbits - 1 - (slot % self.nbits))) & 1


class DFlipFlop74HC74:
    def __init__(self):
        self.q = 0

    def clock(self, d):
        self.q = int(d)
        return self.q

    @property
    def qbar(self):
        return 1 - self.q


class DriverB:
    """c(x) charges C through R; NPN emitter follower; HIGH once VB >= 3.5 V."""

    def __init__(self, tau_ms, noise=True):
        self.tau = tau_ms / 1000.0
        self.noise = noise

    def run(self, x, t_charge_s):
        c = 1 if x >= 4 else 0
        vc = VS * (1 - math.exp(-t_charge_s / self.tau)) * c      # C is discharged before each trial
        if self.noise:
            vc += random.gauss(0, math.sqrt(1.38e-23 * 300 / 1e-6))  # kT/C for 1 uF (negligible)
        vb = max(0.0, vc - VBE)
        return int(vb >= VIH), vc, vb


class Delay:
    def __init__(self, ticks):
        self.buf = [0] * max(0, ticks)

    def step(self, v):
        if not self.buf:
            return v
        self.buf.append(v)
        return self.buf.pop(0)


# ----------------------------------------------------------------------------- main
def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--device", type=int, default=0)
    ap.add_argument("--list", action="store_true", help="probe camera indices 0-5 and exit")
    ap.add_argument("--synthetic", action="store_true", help="simulated Poisson sensor, no camera")
    ap.add_argument("--dark", action="store_true", help="no scene motion (cover lens / flat field)")
    ap.add_argument("--fourcc", default=None, help="e.g. GREY, Y800, YUYV, MJPG")
    ap.add_argument("--ticks", type=int, default=400, help="probe length; main circuit runs 2x")
    ap.add_argument("--clock-ms", type=float, default=100.0)
    ap.add_argument("--tau-ms", type=float, default=50.0, help="RC node tau (diagram: 50 ms)")
    ap.add_argument("--delay-ms", type=float, default=150.0)
    ap.add_argument("--thr", type=int, default=6, help="motion threshold in DN")
    ap.add_argument("--y-mode", choices=("leak", "isolated"), default="leak")
    ap.add_argument("--number", type=lambda s: int(s, 0), default=0xA5C3)
    ap.add_argument("--nbits", type=int, default=16)
    ap.add_argument("--probe-err", type=float, default=0.01)
    ap.add_argument("--target-bits", type=int, default=8, help="k for SHA-256d H-probe")
    ap.add_argument("--realtime", action="store_true", help="pace to the clock (synthetic only)")
    ap.add_argument("--log", default=None, help="CSV log path")
    ap.add_argument("--seed", type=int, default=None)
    a = ap.parse_args()

    if a.list:
        if cv2 is None:
            sys.exit("opencv-python not installed")
        for i in range(6):
            c = cv2.VideoCapture(i)
            print(f"index {i}: {'OK' if c.isOpened() else '-'}")
            c.release()
        return

    random.seed(a.seed)
    src = SyntheticSensor(a.dark, a.seed) if a.synthetic else RawCamera(a.device, fourcc=a.fourcc)
    T = a.clock_ms / 1000.0
    latch = TimeCodeLatch(a.number, a.nbits)
    ff = DFlipFlop74HC74()
    drvB = DriverB(a.tau_ms)
    delay = Delay(math.ceil(a.delay_ms / a.clock_ms))
    acc = 1                                            # accumulator: running AND of and_dly

    n_main = 2 * a.ticks
    prev = src.read().astype(np.int16)
    s1 = np.zeros((H, W)); s2 = np.zeros((H, W)); nf = 0     # Welford-free running sums (Fano)
    log = []
    sel_bits = []
    st = dict(prime_acc=0, prime_n=0, comp_acc=0, comp_n=0, b_hi=0, probe_n=0, probe_bad=0,
              hits=0, hit_and_acc=0, acc_n=0)
    trial_hist = []                                    # (in_L, and)
    t0 = time.time()

    for n in range(n_main):
        tick0 = time.time()
        raw = src.read()
        f = raw.astype(np.int16)
        s1 += raw; s2 += raw.astype(np.float64) ** 2; nf += 1

        # detectors: right ROI = A, left ROI = B
        det_a, det_b = float(raw[:, W // 2:].mean()), float(raw[:, :W // 2].mean())
        E = (np.abs(f - prev) > a.thr).astype(np.uint8)
        prev = f
        digest = hashlib.sha256(E.tobytes()).digest()
        xcount = int(E.sum())

        # instance x_n: odd 32-bit from digest; half of the frames forced prime
        x = (int.from_bytes(digest[8:12], "big") | 1 | (1 << 31))
        if digest[12] & 1:
            x = next_prime(x)
        in_L = not is_prime(x)

        # Driver A (randomized witness): r from the same frame (shared cause) + ROI signals
        h_r = hashlib.sha256(E.tobytes() + struct.pack("<dd", round(det_a, 3), round(det_b, 3))).digest()
        r = 2 + int.from_bytes(h_r, "big") % (x - 3)
        A = int(is_witness(r, x))

        # Driver B + IF/THEN link
        B, vc, vb = drvB.run(x, T)

        and_ab = A & B
        or_ab = A | B
        and_dly = delay.step(and_ab)
        acc &= and_dly

        Y = latch.bit(n)
        D = (and_dly | Y) if a.y_mode == "leak" else Y
        Q = ff.clock(D)
        sel_bits.append(Q)

        # H-instrumentation: nonce is drawn AFTER the digest from an independent source
        nonce = os.urandom(8)
        hh = hashlib.sha256(hashlib.sha256(digest + nonce).digest()).digest()
        hit = int.from_bytes(hh, "big") < (1 << (256 - a.target_bits))
        st["hits"] += hit
        st["acc_n"] += 1
        st["hit_and_acc"] += hit * and_ab

        # statistics
        if n < a.ticks:                                # independent probe stops at duration
            meas = and_ab ^ (random.random() < a.probe_err)
            st["probe_n"] += 1
            st["probe_bad"] += int(meas != and_ab)
        st["b_hi"] += B
        if in_L:
            st["comp_n"] += 1; st["comp_acc"] += and_ab
        else:
            st["prime_n"] += 1; st["prime_acc"] += and_ab
        trial_hist.append((in_L, and_ab))
        log.append((n, digest.hex()[:16], xcount, round(det_a, 2), round(det_b, 2), x, int(in_L),
                    r, A, B, round(vc, 3), round(vb, 3), and_ab, or_ab, and_dly, Y, Q, ff.qbar,
                    nonce.hex(), int(hit)))

        if n % 100 == 0:
            print(f"t={n:5d} x={x:<11d} L={int(in_L)} A={A} B={B} VB={vb:4.2f}V Y={Y} "
                  f"Q={Q} (count={xcount}, dA-dB={det_a - det_b:+.2f})")

        if a.realtime and a.synthetic:
            time.sleep(max(0, T - (time.time() - tick0)))

    src.close()

    # ------------------------------------------------------------------ report
    print("\n=== RESULTS ===")
    print(f"ticks: main {n_main}, probe {a.ticks}; wall {time.time() - t0:.1f}s; y-mode={a.y_mode}")
    print(f"Driver B reached logic HIGH: {st['b_hi'] / n_main:.1%} of trials "
          f"(tau={a.tau_ms} ms, clock={a.clock_ms} ms; need t >= 1.83*tau)")
    if st["prime_n"]:
        print(f"Soundness   : accepts on primes = {st['prime_acc']}/{st['prime_n']} (must be 0)")
    if st["comp_n"]:
        p = st["comp_acc"] / st["comp_n"]
        print(f"Completeness: p-hat on composites = {p:.3f} (RP needs >= 0.5; MR gives >= 0.75 when B=1)")
        comp = [acc_ for in_l, acc_ in trial_hist if in_l]
        for k in (1, 2, 5):
            fails = sum(1 for i in range(0, len(comp) - k + 1, k) if not any(comp[i:i + k]))
            groups = max(1, (len(comp) - k + 1 + k - 1) // k)
            print(f"   k={k}: empirical false-reject {fails / groups:.4f}   (bound (1-p)^k = {(1 - p) ** k:.4f})")
    print(f"Probe       : {st['probe_bad']}/{st['probe_n']} flipped readings "
          f"({st['probe_bad'] / max(1, st['probe_n']):.3%}, set p={a.probe_err})")

    # hex pooling of SELECT and reconstruction of the isolated number
    words = [sel_bits[i:i + a.nbits] for i in range(0, len(sel_bits) - a.nbits + 1, a.nbits)]
    hexs = ["".join(f"{int(''.join(map(str, w[i:i+4])), 2):X}" for i in range(0, a.nbits - a.nbits % 4, 4))
            for w in words]
    target = f"{a.number & ((1 << a.nbits) - 1):0{a.nbits // 4}X}"
    ok = sum(h == target for h in hexs)
    bit_err = sum(sel_bits[i] != latch.bit(i) for i in range(len(sel_bits)))
    print(f"Time code   : isolated number 0x{target}; SELECT pooled words matching = {ok}/{len(hexs)}; "
          f"bit errors {bit_err}/{len(sel_bits)}")
    print(f"   first words from SELECT: {' '.join(hexs[:6])}")
    if a.y_mode == "leak" and ok < len(hexs):
        print("   -> in 'leak' mode the delayed AND path ORs into D, so SELECT cannot reconstruct the "
              "number. Use --y-mode isolated to see exact reconstruction.")

    # H-instrumentation
    n = st["acc_n"]; p0 = 2.0 ** -a.target_bits
    z = (st["hits"] - n * p0) / math.sqrt(n * p0 * (1 - p0))
    print(f"H-probe     : SHA-256d below 2^-{a.target_bits}: {st['hits']}/{n} "
          f"(chance {n * p0:.1f}), z={z:+.2f}  [nonce chosen after the frame digest]")

    # per-pixel Fano estimate (D.8 estimator), DN-domain
    if nf > 2:
        mean = s1 / nf
        var = (s2 - s1 ** 2 / nf) / (nf - 1)
        m = (mean > 50) & (mean < 230)
        if m.any():
            print(f"Fano (var/mean, DN domain) over {int(m.sum())} pixels: {np.mean(var[m] / mean[m]):.3f} "
                  f"(Poisson sensor at 1 e-/DN gives ~1; real cameras need the photon-transfer gain)")

    if a.log:
        with open(a.log, "w", newline="") as fh:
            w = csv.writer(fh)
            w.writerow("tick digest16 count detA detB x in_L r A B VC VB and or and_dly Y Q Qbar nonce hit".split())
            w.writerows(log)
        print(f"log written to {a.log}")


if __name__ == "__main__":
    main()
