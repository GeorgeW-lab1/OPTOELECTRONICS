#!/usr/bin/env python3
"""Integer factorisation CLI. Standard library only; Python 3.9+.
Primality is deterministic below 2**64 and probabilistic above it.
"""
import argparse
import collections
import json
import math
import random
import time

SMALL = (2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47)
BASES64 = (2, 325, 9375, 28178, 450775, 9780504, 1795265022)

class BudgetExpired(Exception):
    pass

def check(deadline):
    if time.monotonic() >= deadline:
        raise BudgetExpired()

def is_prime(n, rounds=32, rng=None, deadline=float('inf')):
    """True means proven prime below 2**64, probable prime otherwise."""
    if n < 2:
        return False
    for p in SMALL:
        if n % p == 0:
            return n == p
    d, s = n - 1, 0
    while d % 2 == 0:
        d //= 2
        s += 1
    rng = rng or random.SystemRandom()
    bases = BASES64 if n < 2**64 else (rng.randrange(2, n-1) for _ in range(rounds))
    for a in bases:
        check(deadline)
        a %= n
        if a < 2:
            continue
        x = pow(a, d, n)
        if x in (1, n-1):
            continue
        for _ in range(s-1):
            check(deadline)
            x = x*x % n
            if x == n-1:
                break
        else:
            return False
    return True

def rho(n, rng, deadline):
    """Brent's batched-GCD variant of Pollard rho."""
    for p in SMALL:
        if n % p == 0:
            return p
    while True:
        check(deadline)
        y, c = rng.randrange(1, n), rng.randrange(1, n)
        g, r, batch = 1, 1, 128
        while g == 1:
            x = y
            for i in range(r):
                if i % 128 == 0:
                    check(deadline)
                y = (y*y+c) % n
            k = 0
            while k < r and g == 1:
                check(deadline)
                ys, q = y, 1
                for _ in range(min(batch, r-k)):
                    y = (y*y+c) % n
                    q = q * abs(x-y) % n
                g = math.gcd(q, n)
                k += batch
            r *= 2
        if g == n:
            while True:
                check(deadline)
                ys = (ys*ys+c) % n
                g = math.gcd(abs(x-ys), n)
                if g > 1:
                    break
        if g != n:
            return g

def factor(n, timeout=10.0, rounds=32):
    """Return JSON-compatible result; timeout is a cooperative time budget.
    Unresolved cofactors always remain separate from accepted prime factors.
    """
    if not isinstance(n, int) or isinstance(n, bool):
        raise TypeError('n must be an integer')
    if n == 0:
        raise ValueError('zero has no finite prime factorisation')
    if not math.isfinite(timeout) or timeout <= 0:
        raise ValueError('timeout must be finite and positive')
    if rounds < 1:
        raise ValueError('rounds must be positive')
    start = time.monotonic()
    deadline = start + timeout
    rng = random.SystemRandom()
    accepted, pending = [], []
    remainder = abs(n)
    for p in SMALL:
        while remainder % p == 0:
            accepted.append(p)
            remainder //= p
    if remainder > 1:
        pending.append(remainder)
    while pending:
        current = pending.pop()
        try:
            check(deadline)
            if is_prime(current, rounds, rng, deadline):
                accepted.append(current)
                continue
            root = math.isqrt(current)
            if root*root == current:
                pending.extend((root, root))
                continue
            divisor = rho(current, rng, deadline)
            pending.extend((divisor, current//divisor))
        except BudgetExpired:
            pending.append(current)
            break
    counts = collections.Counter(accepted)
    factors = [dict(value=str(p), exponent=e,
                    primality='proven' if p < 2**64 else 'probable')
               for p, e in sorted(counts.items())]
    complete = not pending
    proven = complete and all(p < 2**64 for p in accepted)
    reconstructed = (-1 if n < 0 else 1)
    for p in accepted:
        reconstructed *= p
    for c in pending:
        reconstructed *= c
    assert reconstructed == n
    return dict(input=str(n), sign=-1 if n < 0 else 1,
                status='complete_proven' if proven else
                       'complete_probable' if complete else 'partial',
                factors=factors, unresolved_cofactors=[str(c) for c in sorted(pending)],
                product_verified=True, elapsed_seconds=time.monotonic()-start,
                primality_rounds=rounds)

def format_result(result):
    terms = ['-1'] if result['sign'] < 0 else []
    for f in result['factors']:
        term = f['value'] + (('^'+str(f['exponent'])) if f['exponent'] > 1 else '')
        if f['primality'] == 'probable':
            term += ' (probable prime)'
        terms.append(term)
    terms.extend('['+c+' unresolved]' for c in result['unresolved_cofactors'])
    return (result['input']+' = '+' * '.join(terms or ['1'])+
            '\nstatus: '+result['status']+
            '\nelapsed: '+format(result['elapsed_seconds'], '.6f')+' s')

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('integers', nargs='+', help='decimal integers, or 0x / 0o / 0b literals')
    parser.add_argument('--timeout', type=float, default=10.0, help='seconds per integer (default: 10)')
    parser.add_argument('--rounds', type=int, default=32, help='Miller-Rabin rounds above 64 bits')
    parser.add_argument('--json', action='store_true', help='emit a JSON array')
    args = parser.parse_args()
    results = []
    for text in args.integers:
        try:
            t = text.strip().replace('_', '')
            n = int(t, 0) if t.lstrip('+-').lower().startswith(('0x','0o','0b')) else int(t, 10)
            results.append(factor(n, args.timeout, args.rounds))
        except (ValueError, TypeError) as exc:
            parser.error(str(exc))
    if args.json:
        print(json.dumps(results, indent=2))
    else:
        print('\n\n'.join(format_result(r) for r in results))

if __name__ == '__main__':
    main()
