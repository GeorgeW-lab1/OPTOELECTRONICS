#!/usr/bin/env python3
"""RP Proof-of-Work demo — camera/synthetic entropy, SHA-256 mining, verification.

This is a demonstration of proof-of-work, not a cryptocurrency implementation.

Each mining round:
1. Collects entropy from a USB camera frame or a reproducible synthetic frame.
2. Derives a challenge and miner nonce range from that entropy.
3. Searches for a nonce whose SHA-256(challenge || nonce) has at least
   `difficulty` leading zero bits.
4. Verifies the winning solution independently.
5. Records hashes tried, elapsed time, hashrate, and verification result.

No Tkinter is used.

Examples:
  python rp_pow_demo.py --synthetic --difficulty 16 --rounds 5
  python rp_pow_demo.py --device 0 --difficulty 18 --rounds 3
  python rp_pow_demo.py --synthetic --difficulty 20 --rounds 1 --json pow.json
"""

from __future__ import annotations
import sys
import argparse
import hashlib
import json
import math
import secrets
import statistics
import time
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Iterator

import numpy as np

try:
    import cv2
except ImportError:
    cv2 = None

W, H = 128, 96


def leading_zero_bits(digest: bytes) -> int:
    """Count leading zero bits in a SHA-256 digest."""
    bits = 0
    for byte in digest:
        if byte:
            bits += (byte ^ (byte - 1)).bit_length() - 1
            return bits
        bits += 8
    return bits


def meets_target(digest: bytes, difficulty: int) -> bool:
    if difficulty <= 0:
        return True
    full, remainder = divmod(difficulty, 8)
    if any(digest[:full]):
        return False
    if remainder:
        return digest[full] >> (8 - remainder) == 0
    return True


def expected_hashes(difficulty: int) -> float:
    return float(2 ** difficulty)


@dataclass
class PowResult:
    round_index: int
    entropy_source: str
    challenge: str
    difficulty: int
    nonce: int | None
    digest: str | None
    hashes_tried: int
    elapsed_seconds: float
    hashes_per_second: float
    expected_hashes: float
    luck_ratio: float
    verified: bool
    entropy_sha256: str


class EntropySource:
    def frames(self) -> Iterator[bytes]:
        raise NotImplementedError


class SyntheticEntropy(EntropySource):
    """Deterministic synthetic photon frames; useful for repeatable demos."""

    def __init__(self, seed: int = 20261110, level: float = 120.0):
        self.rng = np.random.default_rng(seed)
        self.level = level
        self.index = 0

    def frames(self) -> Iterator[bytes]:
        while True:
            gray = np.clip(
                self.rng.poisson(self.level, size=(H, W)), 0, 255
            ).astype(np.uint8)
            yield gray.tobytes() + self.index.to_bytes(8, "big")
            self.index += 1


class CameraEntropy(EntropySource):
    """Live USB-camera entropy. Camera images are entropy input, not trusted randomness."""

    def __init__(self, device: int = 0, warmup: int = 8):
        if cv2 is None:
            raise RuntimeError("Install OpenCV for camera entropy: pip install opencv-python")
        backend = cv2.CAP_DSHOW if sys.platform == "win32" else cv2.CAP_ANY
        self.cap = cv2.VideoCapture(device, backend)
        if not self.cap.isOpened():
            raise RuntimeError(f"Cannot open camera device {device}")
        for _ in range(warmup):
            self.cap.read()
        self.index = 0

    def frames(self) -> Iterator[bytes]:
        while True:
            ok, frame = self.cap.read()
            if not ok or frame is None:
                raise RuntimeError("Camera stopped delivering frames")
            gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
            gray = cv2.resize(gray, (W, H), interpolation=cv2.INTER_AREA)
            yield gray.tobytes() + self.index.to_bytes(8, "big")
            self.index += 1

    def close(self) -> None:
        if self.cap is not None and self.cap.isOpened():
            self.cap.release()


class ProofOfWorkDemo:
    def __init__(self, source: EntropySource, difficulty: int, max_hashes: int):
        if difficulty < 1 or difficulty > 32:
            raise ValueError("difficulty must be between 1 and 32 leading zero bits")
        if max_hashes < 1:
            raise ValueError("max-hashes must be positive")
        self.source = source
        self.difficulty = difficulty
        self.max_hashes = max_hashes

    def mine_round(self, round_index: int, entropy: bytes) -> PowResult:
        entropy_digest = hashlib.sha256(entropy).digest()
        challenge = hashlib.sha256(b"RP-PoW-demo|" + entropy_digest).digest()

        # The nonce search space is bounded so a demo always terminates.
        nonce_limit = min(self.max_hashes, 2 ** 32 - 1)
        start = time.perf_counter()
        nonce = None
        winning_digest = None
        hashes_tried = 0

        for candidate in range(nonce_limit):
            payload = challenge + candidate.to_bytes(8, "big")
            digest = hashlib.sha256(payload).digest()
            hashes_tried += 1
            if meets_target(digest, self.difficulty):
                nonce = candidate
                winning_digest = digest
                break

        elapsed = time.perf_counter() - start
        rate = hashes_tried / elapsed if elapsed > 0 else 0.0
        expected = expected_hashes(self.difficulty)
        verified = False

        if nonce is not None:
            payload = challenge + nonce.to_bytes(8, "big")
            verified = hashlib.sha256(payload).digest() == winning_digest and \
                meets_target(winning_digest, self.difficulty)

        return PowResult(
            round_index=round_index,
            entropy_source="camera" if isinstance(self.source, CameraEntropy) else "synthetic",
            challenge=challenge.hex(),
            difficulty=self.difficulty,
            nonce=nonce,
            digest=winning_digest.hex() if winning_digest else None,
            hashes_tried=hashes_tried,
            elapsed_seconds=elapsed,
            hashes_per_second=rate,
            expected_hashes=expected,
            luck_ratio=expected / hashes_tried if hashes_tried else 0.0,
            verified=verified,
            entropy_sha256=entropy_digest.hex(),
        )

    def run(self, rounds: int) -> list[PowResult]:
        results = []
        frames = self.source.frames()
        for index in range(rounds):
            entropy = next(frames)
            result = self.mine_round(index, entropy)
            results.append(result)
            status = "SOLVED" if result.nonce is not None else "NO SOLUTION IN LIMIT"
            print(
                f"round {index + 1}/{rounds}: {status} | "
                f"{result.hashes_tried:,} hashes | {result.elapsed_seconds:.3f} s | "
                f"{result.hashes_per_second:,.0f} H/s | verified={result.verified}"
            )
        return results


def summarise(results: list[PowResult]) -> dict:
    solved = [r for r in results if r.nonce is not None]
    hashes = [r.hashes_tried for r in results]
    times = [r.elapsed_seconds for r in results]
    rates = [r.hashes_per_second for r in results]
    return {
        "rounds": len(results),
        "solved_rounds": len(solved),
        "solve_rate": len(solved) / len(results) if results else 0.0,
        "total_hashes": sum(hashes),
        "total_time_seconds": sum(times),
        "mean_hashes_per_round": statistics.mean(hashes) if hashes else 0.0,
        "median_hashes_per_round": statistics.median(hashes) if hashes else 0.0,
        "mean_hashrate": statistics.mean(rates) if rates else 0.0,
        "mean_luck_ratio": statistics.mean(r.luck_ratio for r in solved) if solved else None,
        "all_solutions_verified": all(r.verified for r in solved),
        "difficulty_bits": results[0].difficulty if results else None,
        "theoretical_expected_hashes_per_solve": expected_hashes(results[0].difficulty) if results else None,
    }


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Camera-entropy SHA-256 proof-of-work demo")
    source = parser.add_mutually_exclusive_group(required=True)
    source.add_argument("--synthetic", action="store_true", help="use deterministic synthetic frames")
    source.add_argument("--device", type=int, help="OpenCV camera index")
    parser.add_argument("--difficulty", type=int, default=16, help="required leading zero bits")
    parser.add_argument("--rounds", type=int, default=3, help="number of mining rounds")
    parser.add_argument("--max-hashes", type=int, default=2_000_000, help="per-round search limit")
    parser.add_argument("--seed", type=int, default=20261110, help="synthetic entropy seed")
    parser.add_argument("--json", default="rp_pow_results.json", help="JSON output path")
    return parser


def main() -> int:
    args = build_parser().parse_args()
    if args.rounds < 1:
        raise SystemExit("--rounds must be positive")

    source = SyntheticEntropy(seed=args.seed) if args.synthetic else CameraEntropy(args.device)
    demo = ProofOfWorkDemo(source, args.difficulty, args.max_hashes)

    print(f"RP proof-of-work demo | difficulty: {args.difficulty} leading zero bits")
    print(f"Expected hashes per solve: {expected_hashes(args.difficulty):,.0f}")
    print(f"Per-round nonce limit: {args.max_hashes:,}")

    results: list[PowResult] = []
    try:
        results = demo.run(args.rounds)
    except KeyboardInterrupt:
        print("\nStopped by user.")
    finally:
        if isinstance(source, CameraEntropy):
            source.close()

    if not results:
        return 1

    summary = summarise(results)
    output = {
        "protocol": "RP-PROOF-OF-WORK-DEMO",
        "created_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "difficulty_bits": args.difficulty,
        "rounds_requested": args.rounds,
        "entropy_source": "synthetic" if args.synthetic else f"camera:{args.device}",
        "summary": summary,
        "rounds": [asdict(result) for result in results],
    }

    output_path = Path(args.json)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(json.dumps(output, indent=2), encoding="utf-8")

    print("\nSummary")
    for key, value in summary.items():
        if isinstance(value, float):
            print(f"{key}: {value:,.4f}")
        else:
            print(f"{key}: {value}")
    print(f"Saved results: {output_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
