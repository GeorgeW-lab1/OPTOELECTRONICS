
#!/usr/bin/env python3
"""
WEBCAM-DRIVEN OPTOELECTRONIC BTC PREDICTION

Circuit:
    Webcam -> Detector A / Detector B
    Detector A -> stochastic photon detector
    Detector B -> RC/NPN response
    AND -> 150ms delay -> accumulator
    OR  -> 74HC74-style 10Hz leak latch

Prediction:
    Positive circuit output = HIGHER
    Negative circuit output = LOWER

Keyboard:
    Shift+W = HIGHER
    Shift+S = LOWER

BTC:
    Coinbase BTC-USD spot reference.
    60-second prediction horizon.

IMPORTANT:
    BTC price is never used to calculate the circuit prediction.
    It is only used to establish the starting price and evaluate
    the prediction 60 seconds later.

This is a webcam-driven software model of the circuit.
For physical circuit measurements, replace the detector model
with actual ADC measurements.
"""

import cv2
import numpy as np
import pyautogui
import hashlib
import urllib.request
import json
import csv
import os
import time
import math

from collections import deque
from datetime import datetime, timezone


# ============================================================
# CONFIGURATION
# ============================================================

CAMERA_INDEX = 0

BTC_ENDPOINT = (
    "https://api.coinbase.com/v2/prices/BTC-USD/spot"
)

PREDICTION_HORIZON = 60.0

MAIN_DELAY = 0.150
POST_CIRCUIT_WAIT = 1.0

CAMERA_SAMPLE_TIME = 0.35

RC_TIME_CONSTANT = 0.15

FLIP_FLOP_FREQUENCY = 10.0

PHOTON_SCALE = 100.0
DETECTOR_A_THRESHOLD = 5

DETECTOR_B_THRESHOLD = 0.02

ACCUMULATOR_GAIN = 10.0
ACCUMULATOR_DECAY = 0.015
LEAK_STRENGTH = 0.05

MAX_SIGNAL = 1.0

INJECT_KEYS = True

KEY_HIGHER = "w"
KEY_LOWER = "s"

SHOW_CAMERA = False

CSV_FILE = "btc_circuit_predictions.csv"

CAMERA_WIDTH = 640
CAMERA_HEIGHT = 480

# Automatic detector regions.
# Right = A, Left = B.

ROI_B = (0.05, 0.20, 0.40, 0.60)
ROI_A = (0.55, 0.20, 0.40, 0.60)


# ============================================================
# BTC PRICE REFERENCE
# ============================================================

def get_btc_price():

    request = urllib.request.Request(
        BTC_ENDPOINT,
        headers={"User-Agent": "PhotonicCircuitBTC/1.0"}
    )

    with urllib.request.urlopen(
        request,
        timeout=8
    ) as response:

        result = json.loads(response.read().decode())

    return float(result["data"]["amount"])


# ============================================================
# CSV LOGGING
# ============================================================

def log_event(event, prediction="", price=0.0,
              signal=0.0, outcome="", correct=""):

    exists = os.path.exists(CSV_FILE)

    with open(CSV_FILE, "a", newline="", encoding="utf-8") as file:

        writer = csv.writer(file)

        if not exists:
            writer.writerow([
                "timestamp",
                "event",
                "prediction",
                "btc_price",
                "circuit_signal",
                "outcome",
                "correct"
            ])

        writer.writerow([
            datetime.now(timezone.utc).isoformat(),
            event,
            prediction,
            price,
            signal,
            outcome,
            correct
        ])


# ============================================================
# OPTOELECTRONIC CIRCUIT
# ============================================================

class OptoelectronicCircuit:

    def __init__(self):

        self.rng = np.random.default_rng()

        self.rc_state = 0.0

        self.accumulator = 0.0

        self.flip_flop = 0

        self.last_clock = time.perf_counter()

        self.last_frame_time = time.perf_counter()

        self.last_a = 0.0
        self.last_b = 0.0

        self.main_output = 0
        self.leak_output = 0

        self.signal = 0.0

    def process(self, frame):

        now = time.perf_counter()

        dt = max(
            0.0001,
            min(now - self.last_frame_time, 0.1)
        )

        self.last_frame_time = now

        height, width = frame.shape[:2]

        # ----------------------------------------------------
        # Detector regions
        # ----------------------------------------------------

        bx, by, bw, bh = ROI_B
        ax, ay, aw, ah = ROI_A

        left = frame[
            int(by*height):int((by+bh)*height),
            int(bx*width):int((bx+bw)*width)
        ]

        right = frame[
            int(ay*height):int((ay+ah)*height),
            int(ax*width):int((ax+aw)*width)
        ]

        b_intensity = (
            float(np.mean(cv2.cvtColor(
                left, cv2.COLOR_BGR2GRAY
            ))) / 255.0
        )

        a_intensity = (
            float(np.mean(cv2.cvtColor(
                right, cv2.COLOR_BGR2GRAY
            ))) / 255.0
        )

        self.last_a = a_intensity
        self.last_b = b_intensity

        # ----------------------------------------------------
        # Detector A: stochastic photon response
        # ----------------------------------------------------

        expected_photons = max(
            0.0,
            a_intensity * PHOTON_SCALE
        )

        photon_count = self.rng.poisson(
            expected_photons
        )

        detector_a = int(
            photon_count >= DETECTOR_A_THRESHOLD
        )

        # ----------------------------------------------------
        # Detector B: deterministic RC/NPN response
        # ----------------------------------------------------

        alpha = 1.0 - math.exp(
            -dt / RC_TIME_CONSTANT
        )

        self.rc_state += alpha * (
            b_intensity - self.rc_state
        )

        detector_b = int(
            self.rc_state >= DETECTOR_B_THRESHOLD
        )

        # ----------------------------------------------------
        # Main circuit: AND
        # ----------------------------------------------------

        self.main_output = int(
            detector_a and detector_b
        )

        # Signed differential drive.
        differential = (
            a_intensity - self.rc_state
        )

        # ----------------------------------------------------
        # Main delay: 150ms
        # ----------------------------------------------------

        if self.main_output:

            drive = (
                differential *
                ACCUMULATOR_GAIN *
                dt
            )

        else:

            drive = 0.0

        # ----------------------------------------------------
        # Leak circuit: OR
        # ----------------------------------------------------

        self.leak_output = int(
            detector_a or detector_b
        )

        # 74HC74-style 10Hz clock.
        clock_period = 1.0 / FLIP_FLOP_FREQUENCY

        if now - self.last_clock >= clock_period:

            self.flip_flop = self.leak_output

            self.last_clock = now

        # ----------------------------------------------------
        # Accumulator
        # ----------------------------------------------------

        decay = math.exp(
            -ACCUMULATOR_DECAY * dt
        )

        self.accumulator *= decay

        self.accumulator += drive

        # Leak feedback.
        if self.flip_flop:

            self.accumulator -= (
                self.accumulator *
                LEAK_STRENGTH *
                dt
            )

        # ----------------------------------------------------
        # Bounded signed output
        # ----------------------------------------------------

        self.signal = math.tanh(
            self.accumulator
        )

        self.signal = float(np.clip(
            self.signal,
            -MAX_SIGNAL,
            MAX_SIGNAL
        ))

        return self.signal

    def reset(self):

        self.accumulator = 0.0
        self.rc_state = 0.0
        self.signal = 0.0


# ============================================================
# WEBCAM
# ============================================================

class CircuitCamera:

    def __init__(self):

        self.cap = cv2.VideoCapture(CAMERA_INDEX)

        if not self.cap.isOpened():
            raise RuntimeError("Cannot open webcam.")

        self.cap.set(
            cv2.CAP_PROP_FRAME_WIDTH,
            CAMERA_WIDTH
        )

        self.cap.set(
            cv2.CAP_PROP_FRAME_HEIGHT,
            CAMERA_HEIGHT
        )

        self.circuit = OptoelectronicCircuit()

    def acquire(self):

        values = []

        start = time.perf_counter()

        while time.perf_counter() - start < CAMERA_SAMPLE_TIME:

            ok, frame = self.cap.read()

            if not ok:
                continue

            signal = self.circuit.process(frame)

            values.append(signal)

            if SHOW_CAMERA:

                self.display(frame, signal)

        if not values:
            raise RuntimeError("No camera measurements.")

        # Use the circuit's temporal output, not BTC data.
        return float(np.mean(values))

    def display(self, frame, signal):

        h, w = frame.shape[:2]

        for roi, label, color in [
            (ROI_A, "DETECTOR A", (0, 255, 0)),
            (ROI_B, "DETECTOR B", (255, 180, 0))
        ]:

            x, y, rw, rh = roi

            x = int(x*w)
            y = int(y*h)
            rw = int(rw*w)
            rh = int(rh*h)

            cv2.rectangle(
                frame,
                (x, y),
                (x+rw, y+rh),
                color,
                2
            )

            cv2.putText(
                frame,
                label,
                (x, max(20, y-8)),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.5,
                color,
                1
            )

        cv2.putText(
            frame,
            f"CIRCUIT SIGNAL: {signal:+.5f}",
            (15, 30),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.7,
            (255, 255, 255),
            2
        )

        cv2.putText(
            frame,
            f"AND: {self.circuit.main_output} "
            f"OR: {self.circuit.leak_output} "
            f"FF: {self.circuit.flip_flop}",
            (15, 60),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.55,
            (0, 255, 255),
            2
        )

        cv2.imshow("BTC Photonic Circuit", frame)

        if cv2.waitKey(1) & 0xFF == ord("q"):
            raise KeyboardInterrupt


# ============================================================
# CIRCUIT PREDICTION
# ============================================================

def circuit_prediction(signal):

    # Prediction comes exclusively from the circuit.
    if signal >= 0:
        return "HIGHER"

    return "LOWER"


# ============================================================
# KEYBOARD OUTPUT
# ============================================================

def inject_prediction(prediction):

    if not INJECT_KEYS:
        return

    key = (
        KEY_HIGHER
        if prediction == "HIGHER"
        else KEY_LOWER
    )

    # The circuit-control application must have keyboard focus.
    pyautogui.hotkey("shift", key)


# ============================================================
# PREDICTION TRACKER
# ============================================================

class PredictionTracker:

    def __init__(self):

        self.pending = deque()

        self.total = 0
        self.correct = 0

    def add(self, prediction, price, signal):

        record = {
            "prediction": prediction,
            "price": price,
            "signal": signal,
            "created": time.perf_counter(),
            "due": time.perf_counter() + PREDICTION_HORIZON
        }

        self.pending.append(record)

        self.total += 1

        log_event(
            "PREDICTION",
            prediction,
            price,
            signal
        )

    def settle(self, current_price):

        now = time.perf_counter()

        while self.pending and self.pending[0]["due"] <= now:

            record = self.pending.popleft()

            starting_price = record["price"]

            prediction = record["prediction"]

            if current_price > starting_price:
                outcome = "HIGHER"

            elif current_price < starting_price:
                outcome = "LOWER"

            else:
                outcome = "FLAT"

            correct = prediction == outcome

            if correct:
                self.correct += 1

            accuracy = (
                100.0 * self.correct / self.total_settled
                if self.total_settled > 0
                else 0.0
            )

            print("\n=== BTC PREDICTION SETTLED ===")

            print(f"Prediction: {prediction}")
            print(f"Starting BTC: ${starting_price:,.2f}")
            print(f"Ending BTC:   ${current_price:,.2f}")
            print(f"Actual: {outcome}")
            print(f"Correct: {correct}")

            log_event(
                "SETTLED",
                prediction,
                current_price,
                record["signal"],
                outcome,
                correct
            )

            self.settled += 1

            accuracy = (
                100.0 * self.correct / self.settled
            )

            print(f"Settled predictions: {self.settled}")
            print(f"Correct predictions: {self.correct}")
            print(f"Accuracy: {accuracy:.2f}%")

    @property
    def total_settled(self):
        return self.settled

    def initialize(self):
        self.settled = 0


# ============================================================
# MAIN LOOP
# ============================================================

def main():

    print("\n========================================")
    print(" WEBCAM OPTOELECTRONIC BTC PREDICTOR")
    print("========================================")

    print("Camera: webcam")
    print("Detector A: right ROI")
    print("Detector B: left ROI")
    print("Main circuit: AND")
    print("Leak circuit: OR / 10Hz")
    print("Prediction horizon: 60 seconds")
    print("HIGHER: Shift+W")
    print("LOWER: Shift+S")
    print("Price source: Coinbase BTC-USD")

    camera = CircuitCamera()

    tracker = PredictionTracker()
    tracker.initialize()

    try:

        while True:

            print("\n[*] Sampling optical circuit...")

            # ------------------------------------------------
            # 1. Camera drives the circuit.
            # ------------------------------------------------

            signal = camera.acquire()

            # ------------------------------------------------
            # 2. Main circuit delay.
            # ------------------------------------------------

            time.sleep(MAIN_DELAY)

            # ------------------------------------------------
            # 3. Circuit decides direction.
            # ------------------------------------------------

            prediction = circuit_prediction(signal)

            # ------------------------------------------------
            # 4. Fetch BTC price independently.
            # ------------------------------------------------

            try:

                price = get_btc_price()

            except Exception as error:

                print("[BTC API ERROR]", error)
                print("[*] Retrying in 2 seconds.")

                time.sleep(2)
                continue

            # ------------------------------------------------
            # 5. Settle matured predictions.
            # ------------------------------------------------

            tracker.settle(price)

            # ------------------------------------------------
            # 6. Inject circuit prediction.
            # ------------------------------------------------

            inject_prediction(prediction)

            # ------------------------------------------------
            # 7. Record prediction.
            # ------------------------------------------------

            tracker.add(
                prediction,
                price,
                signal
            )

            print("\n=== NEW BTC PREDICTION ===")

            print(
                "Time:",
                datetime.now().strftime("%H:%M:%S")
            )

            print(f"BTC spot: ${price:,.2f}")

            print(f"Circuit signal: {signal:+.6f}")

            print(f"Prediction: {prediction}")

            print(
                f"Evaluation: {PREDICTION_HORIZON:.0f} seconds"
            )

            print(
                f"Pending predictions: {len(tracker.pending)}"
            )

            print(
                f"Settled: {tracker.settled} | "
                f"Correct: {tracker.correct}"
            )

            # ------------------------------------------------
            # 8. Independent post-circuit wait.
            # ------------------------------------------------

            time.sleep(POST_CIRCUIT_WAIT)

    except KeyboardInterrupt:

        print("\n\n[*] BTC circuit stopped.")

    finally:

        camera.cap.release()

        cv2.destroyAllWindows()

        pyautogui.keyUp("shift")
        pyautogui.keyUp("w")
        pyautogui.keyUp("s")

        print("\n=== FINAL STATISTICS ===")

        print("Predictions:", tracker.total)
        print("Settled:", tracker.settled)
        print("Correct:", tracker.correct)

        if tracker.settled:

            print(
                "Accuracy:",
                f"{100 * tracker.correct / tracker.settled:.2f}%"
            )

        print("Log:", CSV_FILE)


if __name__ == "__main__":
    main()
