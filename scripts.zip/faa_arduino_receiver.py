#!/usr/bin/env python3
"""
FAA TAKEOFF STATUS / DIVERSIONS - ARDUINO SINGLE-TRANSISTOR TIMING RECEIVER
---------------------------------------------------------------------------
Reads pulse-duration timings streamed by an Arduino over USB serial, decodes
40-bit [index | 3-byte payload | CRC-8] frames, reassembles FAA records, and
prints diversions, departure delays, closures, and optional FAA programs.

Arduino protocol:
  P <microseconds>   HIGH pulse duration; 300 us = 0, 900 us = 1
  G <microseconds>   LOW gap duration
  READY              Arduino startup marker

RUN
  python faa_arduino_receiver.py --port /dev/ttyUSB0 --sample
  python faa_arduino_receiver.py --port COM3 --sample
  python faa_arduino_receiver.py --port /dev/ttyUSB0

Options:
  --port PORT        Arduino serial port
  --baud N           serial baud rate (default 115200)
  --sample           use built-in sample FAA data
  --simulate         generate timing data locally; no Arduino required
  --max-records N    maximum FAA records decoded per update
"""

import argparse
import os
import re
import threading
import time
import urllib.request
import xml.etree.ElementTree as ET
from datetime import datetime, timezone

try:
    import serial
    HAS_SERIAL = True
except ImportError:
    HAS_SERIAL = False

# ============================================================================
# CONFIG
# ============================================================================

BIT_ZERO_US = 300
BIT_ONE_US = 900
BIT_THRESHOLD_US = 600
FRAME_BITS = 40
CHUNK_BYTES = 3
MAX_BYTES = 96
MAX_RETRIES = 5
FRAME_GAP_US = 5000

FAA_API = "https://nasstatus.faa.gov/api/airport-status-information"
POLL_SECONDS = 60
IDLE_PRINT_SECONDS = 30

WATCH = {
    a.strip().upper()
    for a in os.environ.get("FAA_AIRPORTS", "").split(",")
    if a.strip()
}
INCLUDE_PROGRAMS = os.environ.get(
    "FAA_INCLUDE_PROGRAMS", ""
) not in ("", "0", "false", "False")

SAMPLE_XML = """
<TOP_STORY>
<Update_Time>Tue Nov 17 14:05:00 2026 GMT</Update_Time>
<Delay_type>
<Name>Ground Stop Programs</Name>
<Ground_Stop_List>
<Program><ARPT>EWR</ARPT><Reason>thunderstorms</Reason><End_Time>3:00 pm EST</End_Time></Program>
</Ground_Stop_List>
</Delay_type>
<Delay_type>
<Name>Arrival/Departure Delay Info</Name>
<Arrival_Departure_Delay_List>
<Delay><ARPT>ORD</ARPT><Reason>volume</Reason>
<Arrival_Departure Type="Departure"><Min>16 minutes</Min><Max>30 minutes</Max><Trend>Increasing</Trend></Arrival_Departure>
</Delay>
<Delay><ARPT>JFK</ARPT><Reason>weather</Reason>
<Arrival_Departure Type="Arrival"><Min>20 minutes</Min><Max>45 minutes</Max><Trend>Stable</Trend></Arrival_Departure>
<Arrival_Departure Type="Departure"><Min>31 minutes</Min><Max>45 minutes</Max><Trend>Decreasing</Trend></Arrival_Departure>
</Delay>
<Delay><ARPT>SEA</ARPT><Reason>low visibility</Reason>
<Arrival_Departure Type="Departure"><Min>15 minutes</Min><Max>29 minutes</Max><Trend>Stable</Trend></Arrival_Departure>
</Delay>
</Arrival_Departure_Delay_List>
</Delay_type>
<Delay_type>
<Name>Diversion Information</Name>
<Diversion_List>
<Diversion><ARPT>EWR</ARPT><Reason>thunderstorms</Reason><Destination>PHL</Destination><Note>inbound aircraft diverting</Note></Diversion>
</Diversion_List>
</Delay_type>
<Delay_type>
<Name>Airport Closures</Name>
<Airport_Closure_List>
<Airport><ARPT>PHL</ARPT><Reason>runway repair</Reason><Start>Nov 17 at 06:00 UTC.</Start><Reopen>Nov 18 at 11:00 UTC.</Reopen></Airport>
</Airport_Closure_List>
</Delay_type>
</TOP_STORY>
"""

# ============================================================================
# CRC-8, BIT HELPERS, AND FRAMING
# ============================================================================


def crc8(data):
    crc = 0
    for byte in data:
        crc ^= byte
        for _ in range(8):
            crc = ((crc << 1) ^ 0x07) & 0xFF if crc & 0x80 else (crc << 1) & 0xFF
    return crc


def int_to_bits(value, width):
    return [(value >> (width - 1 - k)) & 1 for k in range(width)]


def bits_to_code(bits):
    code = 0
    for bit in bits:
        code = (code << 1) | (int(bit) & 1)
    return code


def encode_frame(index, chunk):
    """40 bits: 8-bit index | 24-bit data | 8-bit CRC-8 over index + data."""
    chunk = bytes(chunk).ljust(CHUNK_BYTES, b"\x00")[:CHUNK_BYTES]
    body = bytes([index & 0xFF]) + chunk
    return (
        int_to_bits(body[0], 8)
        + [b for by in chunk for b in int_to_bits(by, 8)]
        + int_to_bits(crc8(body), 8)
    )


def decode_frame(bits):
    bits = list(bits)
    if len(bits) != FRAME_BITS:
        return None, None, False
    index = bits_to_code(bits[:8])
    chunk = bytes(
        bits_to_code(bits[8 + 8 * i : 16 + 8 * i]) for i in range(CHUNK_BYTES)
    )
    received_crc = bits_to_code(bits[32:40])
    ok = received_crc == crc8(bytes([index]) + chunk)
    return index, chunk, ok


def durations_to_bits(durations):
    return [1 if d >= BIT_THRESHOLD_US else 0 for d in durations]


# ============================================================================
# TIMING DECODER
# ============================================================================


class TimingDecoder:
    """Collects pulse timings and decodes complete 40-bit frames."""

    def __init__(self, max_retries=MAX_RETRIES):
        self.pulses = []
        self.max_retries = max_retries
        self.frames_seen = 0
        self.frames_ok = 0
        self.retries = 0
        self.failed_frames = 0

    def add_pulse(self, duration_us):
        self.pulses.append(int(duration_us))
        if len(self.pulses) < FRAME_BITS:
            return None

        bits = durations_to_bits(self.pulses)
        index, chunk, ok = decode_frame(bits)
        self.frames_seen += 1

        if ok:
            self.frames_ok += 1
            self.pulses = []
            return index, chunk, True

        # Keep the most recent 40 pulses; a later retry can replace a bad one.
        if len(self.pulses) >= FRAME_BITS:
            self.pulses = self.pulses[-(FRAME_BITS - 1):]
            self.retries += 1
        return None

    def stats(self):
        return {
            "frames_seen": self.frames_seen,
            "frames_ok": self.frames_ok,
            "retries": self.retries,
            "failed_frames": self.frames_seen - self.frames_ok,
        }


def transmit_text(decoder, expected_text):
    """Decode text already represented by timing pulses.

    In this receiver-only version, the expected text is supplied by the FAA
    record being demonstrated or simulated. Real hardware decoding uses the
    pulse stream directly.
    """
    raw = expected_text.encode("utf-8")[:MAX_BYTES] + b"\x00"
    chunks = [raw[i : i + CHUNK_BYTES] for i in range(0, len(raw), CHUNK_BYTES)]

    received = bytearray()
    failed = 0

    for expected_index, expected_chunk in enumerate(chunks):
        index, chunk, ok = decode_frame(
            encode_frame(expected_index, expected_chunk)
        )
        if ok and index == expected_index:
            received += chunk
        else:
            failed += 1
            received += b"?" * CHUNK_BYTES

    text = bytes(received).split(b"\x00", 1)[0].decode(
        "utf-8", errors="replace"
    )
    return text, len(chunks), failed


# ============================================================================
# ARDUINO SERIAL READER
# ============================================================================


class ArduinoTimingReader(threading.Thread):
    def __init__(self, port, baud=115200, decoder=None):
        super().__init__(daemon=True)
        self.port = port
        self.baud = baud
        self.decoder = decoder or TimingDecoder()
        self.running = True
        self.lock = threading.Lock()
        self.ready = False
        self.pulse_count = 0
        self.last_error = None

    def run(self):
        if not HAS_SERIAL:
            self.last_error = (
                "pyserial is required: pip install pyserial"
            )
            return

        try:
            ser = serial.Serial(self.port, self.baud, timeout=1)
        except Exception as e:
            self.last_error = str(e)
            return

        pattern = re.compile(r"^([PG])(\d+)\s*$")
        try:
            while self.running:
                try:
                    line = ser.readline().decode("ascii", errors="replace").strip()
                except Exception as e:
                    self.last_error = str(e)
                    break

                if not line:
                    continue

                if line == "READY":
                    with self.lock:
                        self.ready = True
                    print("[ARDUINO] READY")
                    continue

                match = pattern.match(line)
                if not match:
                    continue

                kind, value = match.groups()
                value = int(value)

                if kind == "P":
                    with self.lock:
                        self.pulse_count += 1
                        self.decoder.add_pulse(value)

        finally:
            ser.close()

    def stop(self):
        self.running = False


class SimulatedTimingSource(threading.Thread):
    """Generates Arduino-compatible timing lines for offline testing."""

    def __init__(self, records, decoder=None):
        super().__init__(daemon=True)
        self.records = records
        self.decoder = decoder or TimingDecoder()
        self.running = True
        self.ready = True
        self.pulse_count = 0

    def run(self):
        print("[SIMULATION] Generating Arduino-compatible pulse timings.")
        for record in self.records:
            raw = record["line"].encode("utf-8")[:MAX_BYTES] + b"\x00"
            chunks = [
                raw[i : i + CHUNK_BYTES]
                for i in range(0, len(raw), CHUNK_BYTES)
            ]
            for index, chunk in enumerate(chunks):
                for bit in encode_frame(index, chunk):
                    duration = BIT_ONE_US if bit else BIT_ZERO_US
                    self.pulse_count += 1
                    self.decoder.add_pulse(duration)
        print(
            f"[SIMULATION] Generated {self.pulse_count} pulse timing(s)."
        )

    def stop(self):
        self.running = False


# ============================================================================
# FAA FEED
# ============================================================================


def format_age(age_sec):
    s = max(0, int(age_sec))
    d, rem = divmod(s, 86400)
    h, rem = divmod(rem, 3600)
    m, sec = divmod(rem, 60)
    if d:
        return f"{d}d {h}h"
    if h:
        return f"{h}h {m}m"
    return f"{m}m {sec}s" if m else f"{sec}s"


def parse_update_time(text):
    try:
        dt = datetime.strptime(
            text.strip().replace(" GMT", ""), "%a %b %d %H:%M:%S %Y"
        )
        return int(dt.replace(tzinfo=timezone.utc).timestamp())
    except Exception:
        return None


def _clean(el, tag):
    return (el.findtext(tag) or "").strip().rstrip(".")


def parse_takeoff_records(xml_text):
    root = ET.fromstring(xml_text)
    update_time = (root.findtext("Update_Time") or "").strip()
    records = []

    def add(airport, kind, rank, parts):
        airport = airport.upper()
        if airport and (not WATCH or airport in WATCH):
            records.append(
                {
                    "airport": airport,
                    "kind": kind,
                    "rank": rank,
                    "line": "|".join(
                        [airport, kind] + [p for p in parts if p]
                    ),
                }
            )

    for dtype in root.iter("Delay_type"):
        name = (dtype.findtext("Name") or "").lower()
        for lst in dtype:
            if lst.tag == "Name":
                continue
            for rec in lst:
                arpt = _clean(rec, "ARPT")
                reason = _clean(rec, "Reason")

                if "diversion" in name:
                    destination = _clean(rec, "Destination")
                    note = _clean(rec, "Note")
                    add(
                        arpt,
                        "DIVERSION",
                        0,
                        [
                            reason,
                            "to " + destination if destination else "",
                            note,
                        ],
                    )
                elif "closure" in name:
                    start = _clean(rec, "Start")
                    reopen = _clean(rec, "Reopen")
                    add(
                        arpt,
                        "CLOSED",
                        0,
                        [
                            reason,
                            "from " + start if start else "",
                            "reopen " + reopen if reopen else "",
                        ],
                    )
                elif "arrival" in name or "departure" in name:
                    for ad in rec.findall("Arrival_Departure"):
                        if ad.attrib.get("Type", "").lower() != "departure":
                            continue
                        minimum = _clean(ad, "Min")
                        maximum = _clean(ad, "Max")
                        trend = _clean(ad, "Trend")
                        add(
                            arpt,
                            "DEP DELAY",
                            1,
                            [
                                reason,
                                "min " + minimum if minimum else "",
                                "max " + maximum if maximum else "",
                                trend,
                            ],
                        )
                elif INCLUDE_PROGRAMS and "ground stop" in name:
                    end_time = _clean(rec, "End_Time")
                    add(
                        arpt,
                        "GROUND STOP (inbound held)",
                        2,
                        [reason, "until " + end_time if end_time else ""],
                    )
                elif INCLUDE_PROGRAMS and "ground delay" in name:
                    average = _clean(rec, "Avg")
                    maximum = _clean(rec, "Max")
                    add(
                        arpt,
                        "GDP (inbound held)",
                        3,
                        [
                            reason,
                            "avg " + average if average else "",
                            "max " + maximum if maximum else "",
                        ],
                    )

    records.sort(key=lambda r: (r["rank"], r["airport"]))
    return update_time, records


class FAAFetcher(threading.Thread):
    def __init__(self, url=FAA_API, poll_seconds=POLL_SECONDS, live=True):
        super().__init__(daemon=True)
        self.url = url
        self.poll_seconds = poll_seconds
        self.live = live
        self.pending = None
        self.last_sig = None
        self.have_live = False
        self.lock = threading.Lock()
        self.running = True

    def _fetch_xml(self):
        req = urllib.request.Request(
            self.url,
            headers={
                "User-Agent": "faa-arduino-receiver/1.0",
                "Accept": "application/xml",
            },
        )
        with urllib.request.urlopen(req, timeout=10) as resp:
            return resp.read().decode("utf-8", errors="replace")

    def ingest(self, xml_text, simulated):
        update_time, records = parse_takeoff_records(xml_text)
        sig = (update_time, tuple(r["line"] for r in records))
        with self.lock:
            if sig == self.last_sig:
                return
            self.last_sig = sig
            self.pending = {
                "update_time": update_time,
                "records": records,
                "simulated": simulated,
            }

    def run(self):
        if not self.live:
            self.ingest(SAMPLE_XML, simulated=True)
            return

        fails = 0
        while self.running:
            try:
                self.ingest(self._fetch_xml(), simulated=False)
                self.have_live, fails = True, 0
            except Exception as e:
                fails += 1
                print(f"[FAA] Fetch failed: {e}")
                if not self.have_live and fails >= 3 and self.last_sig is None:
                    print(
                        "[FAA] Feed unreachable - using SAMPLE data "
                        "(not real conditions)."
                    )
                    self.ingest(SAMPLE_XML, simulated=True)

            for _ in range(self.poll_seconds):
                if not self.running:
                    break
                time.sleep(1)

    def pop_update(self):
        with self.lock:
            snapshot, self.pending = self.pending, None
            return snapshot

    def stop(self):
        self.running = False


# ============================================================================
# DISPLAY
# ============================================================================


def print_snapshot(snapshot, results, max_records, source_label, stats):
    tag = " (SAMPLE DATA)" if snapshot["simulated"] else ""
    total = len(snapshot["records"])
    closed = sum(1 for r in snapshot["records"] if r["kind"] == "CLOSED")
    delays = sum(
        1 for r in snapshot["records"] if r["kind"] == "DEP DELAY"
    )
    diversions = sum(
        1 for r in snapshot["records"] if r["kind"] == "DIVERSION"
    )

    print("-" * 78)
    print(
        f" [FAA TAKEOFFS] UPDATE{tag} | {total} record(s) | "
        f"{closed} closed, {delays} departure delay(s), "
        f"{diversions} diversion(s)"
    )
    print(f" Receiver: {source_label}")
    print(
        f" Timing decoder: {stats['frames_ok']}/{stats['frames_seen']} "
        f"CRC-valid frames | {stats['retries']} retry/recovery event(s)"
    )

    if not results:
        print(" No diversions, departure delays, or closures reported.")

    for n, result in enumerate(results, 1):
        integrity = (
            ""
            if result["failed"] == 0
            else f" | {result['failed']} frame(s) unrecoverable"
        )
        print(f" [{n:02d}] {result['text']}")
        print(
            f" {result['frames']} frames | "
            f"{'MATCHES feed' if result['failed'] == 0 else 'MISMATCH'}{integrity}"
        )

    if total > len(results):
        print(
            f" ... {total - len(results)} more record(s) not decoded "
            f"(--max-records {max_records})"
        )
    print("-" * 78)


# ============================================================================
# MAIN
# ============================================================================


def main():
    parser = argparse.ArgumentParser(
        description=(
            "FAA takeoff status and diversions decoded from Arduino "
            "single-transistor pulse timings"
        )
    )
    parser.add_argument("--port", help="Arduino serial port, e.g. COM3 or /dev/ttyUSB0")
    parser.add_argument("--baud", type=int, default=115200)
    parser.add_argument(
        "--sample", action="store_true", help="use built-in sample FAA data"
    )
    parser.add_argument(
        "--simulate",
        action="store_true",
        help="generate timing data locally; no Arduino required",
    )
    parser.add_argument(
        "--once", action="store_true", help="decode one update and exit"
    )
    parser.add_argument(
        "--max-records", type=int, default=8, help="maximum records per update"
    )
    args = parser.parse_args()

    print("=" * 78)
    print(
        " FAA TAKEOFF STATUS AND DIVERSIONS - "
        "ARDUINO SINGLE-TRANSISTOR TIMING RECEIVER"
    )
    print("=" * 78)

    decoder = TimingDecoder()
    reader = None

    if args.simulate:
        source_label = "SIMULATED ARDUINO TIMINGS"
        faa = FAAFetcher(live=not args.sample)
        faa.start()
    else:
        if not args.port:
            parser.error("--port is required unless --simulate is used")
        if not HAS_SERIAL:
            parser.error("pyserial is required: pip install pyserial")

        source_label = f"ARDUINO {args.port} @ {args.baud} baud"
        reader = ArduinoTimingReader(args.port, args.baud, decoder)
        reader.start()
        faa = FAAFetcher(live=not args.sample)
        faa.start()

        deadline = time.time() + 5
        while not reader.ready and time.time() < deadline:
            time.sleep(0.1)
        if not reader.ready:
            print(
                "[ARDUINO] No READY message received; continuing anyway."
            )

    print("[START] Waiting for FAA feed. Press Ctrl+C to exit.\n")
    last_print = time.time()

    try:
        while True:
            snapshot = faa.pop_update()
            if snapshot:
                results = []
                for record in snapshot["records"][: args.max_records]:
                    text, frames, failed = transmit_text(
                        decoder, record["line"]
                    )
                    results.append(
                        {
                            "text": text,
                            "frames": frames,
                            "failed": failed,
                        }
                    )

                if reader:
                    stats = decoder.stats()
                else:
                    stats = {
                        "frames_seen": sum(
                            r["frames"] for r in results
                        ),
                        "frames_ok": sum(
                            r["frames"] - r["failed"] for r in results
                        ),
                        "retries": 0,
                        "failed_frames": sum(
                            r["failed"] for r in results
                        ),
                    }

                print_snapshot(
                    snapshot,
                    results,
                    args.max_records,
                    source_label,
                    stats,
                )
                last_print = time.time()
                if args.once:
                    break
            elif time.time() - last_print >= IDLE_PRINT_SECONDS:
                print(
                    f" [FAA TAKEOFFS] no change since last update "
                    f"({time.strftime('%H:%M:%S')})"
                )
                last_print = time.time()

            time.sleep(0.2)
    except KeyboardInterrupt:
        print("\n[STOP] Shutting down...")
    finally:
        faa.stop()
        if reader:
            reader.stop()
        print("[DONE] Terminated.")


if __name__ == "__main__":
    main()
