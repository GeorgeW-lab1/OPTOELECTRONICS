#!/usr/bin/env python3
"""
apply_circuit_needle.py - patches rp_camera_sim.py so the CIRCUIT does the needle search.

  python apply_circuit_needle.py rp_camera_sim.py          -> writes rp_camera_sim_needle.py
  python rp_camera_sim_needle.py --synthetic --ticks 100 --target-bits 10 --search --log run.csv
  python rp_camera_sim_needle.py --verify run.csv --target-bits 10      # replays every hit through the circuit

What changes
  * per frame, every trial nonce is ONE clock of the real chain:
        Driver A (r from digest + detA/detB + nonce)  ->  Driver B (RC node + NPN)  ->
        AND3(A, B, H)  ->  150 ms delay  ->  74HC74 D-input  ->  Q
    H is the k-bit SHA-256d comparator (the haystack) acting as a third AND input.
  * needle = the nonce whose AND3 pulse emerges from the delay line and sets Q = 1
  * composite x -> Q fires after ~2^k clocks;  prime x -> A = 0 always, Q never fires (budget runs out)
  * CSV now carries the FULL digest, the found nonce, hit and clocks used, so --verify can replay it
"""
import sys

BLOCK = r'''# ----------------------------------------------------------------------------- circuit needle search
def _instance(digest):
    x = (int.from_bytes(digest[8:12], "big") | 1 | (1 << 31))
    return next_prime(x) if digest[12] & 1 else x


def _driver_a(digest, det_a, det_b, nonce, x):
    h = hashlib.sha256(digest + struct.pack("<dd", round(det_a, 2), round(det_b, 2)) + nonce).digest()
    return int(is_witness(2 + int.from_bytes(h, "big") % (x - 3), x))


def _pow_bit(digest, nonce, k):
    d2 = hashlib.sha256(hashlib.sha256(digest + nonce).digest()).digest()
    return int(int.from_bytes(d2, "big") < (1 << (256 - k)))


def circuit_search(digest, det_a, det_b, x, drvB, T, delay_ticks, k, budget, start=0):
    """
    The circuit is the verifier. One trial nonce = one clock of the chain:
        A = Driver A(nonce), B = Driver B (RC link), H = SHA-256d < 2^-k comparator
        and3 = A & B & H -> delay line -> D flip-flop -> Q
    Returns (nonce, clocks) when Q rises, else (None, budget).  The nonce is recovered from the
    clock index minus the delay-line latency.  H is evaluated first only as a speed shortcut;
    the gate value is identical to evaluating A and B on every clock.
    """
    dly, ff = Delay(delay_ticks), DFlipFlop74HC74()
    for ctr in range(budget + delay_ticks):         # extra clocks flush the delay line
        and3 = 0
        if ctr < budget:
            nonce = (start + ctr).to_bytes(8, "big")
            if _pow_bit(digest, nonce, k):
                A = _driver_a(digest, det_a, det_b, nonce, x)
                B, _, _ = drvB.run(x, T)
                and3 = A & B
        if ff.clock(dly.step(and3)):
            i = ctr - delay_ticks
            return (start + i).to_bytes(8, "big"), i + 1
    return None, budget


def verify_csv(a):
    rows = list(csv.DictReader(open(a.verify)))
    if not rows or len(rows[0]["digest16"]) < 64:
        sys.exit("CSV needs the full digest column (run with the patched simulator)")
    drvB = DriverB(a.tau_ms, noise=False)
    T, dt = a.clock_ms / 1000.0, math.ceil(a.delay_ms / a.clock_ms)
    ok = bad = bad_x = prime_hits = 0
    for r in rows:
        d = bytes.fromhex(r["digest16"])
        x = _instance(d)
        if int(r["x"]) != x:
            bad_x += 1
            continue
        if not int(r["hit"]):
            continue
        n = bytes.fromhex(r["nonce"])
        got, _ = circuit_search(d, float(r["detA"]), float(r["detB"]), x, drvB, T, dt,
                                a.target_bits, 1, start=int.from_bytes(n, "big"))
        if got is None:
            bad += 1
        else:
            ok += 1
            prime_hits += int(is_prime(x))
    print(f"replayed through the circuit: {ok} certificates verified, {bad} rejected, "
          f"{bad_x} rows with mismatching x; hits on primes: {prime_hits} (must be 0)")


'''

SUMMARY = r'''    if a.search:
        cn = sum(1 for l, h, t in needles if l); cf = sum(1 for l, h, t in needles if l and h)
        pn = sum(1 for l, h, t in needles if not l); pf = sum(1 for l, h, t in needles if (not l) and h)
        tr = [t for l, h, t in needles if h]
        print(f"Circuit needle search: k={a.target_bits}, budget {int(a.search_mult * 2 ** a.target_bits)} clocks/frame")
        print(f"   composites certified {cf}/{cn}; primes certified {pf}/{pn} (soundness, must be 0)")
        if tr:
            print(f"   mean clocks until Q=1: {sum(tr) / len(tr):.0f}  (theory <= {2 ** a.target_bits * 4 / 3:.0f})")
    # H-instrumentation
    n = st["acc_n"]; p0 = 2.0 ** -a.target_bits'''

OLD_NONCE = '''        # H-instrumentation: nonce is drawn AFTER the digest from an independent source
        nonce = os.urandom(8)
        hh = hashlib.sha256(hashlib.sha256(digest + nonce).digest()).digest()
        hit = int.from_bytes(hh, "big") < (1 << (256 - a.target_bits))
'''
NEW_NONCE = '''        # H-instrumentation
        if a.search:
            # the CIRCUIT is the verifier: each trial nonce is one clock of A, B, AND3, delay, 74HC74
            found, trials = circuit_search(digest, det_a, det_b, x, drvB, T, len(delay.buf),
                                           a.target_bits, int(a.search_mult * 2 ** a.target_bits))
            hit = found is not None
            nonce = found if hit else bytes(8)
        else:
            # nonce is drawn AFTER the digest from an independent source
            nonce = os.urandom(8)
            hh = hashlib.sha256(hashlib.sha256(digest + nonce).digest()).digest()
            hit = int.from_bytes(hh, "big") < (1 << (256 - a.target_bits))
            trials = 0
        needles.append((in_L, hit, trials))
'''

OLD_PRINT = '''    print(f"H-probe     : SHA-256d below 2^-{a.target_bits}: {st['hits']}/{n} "
          f"(chance {n * p0:.1f}), z={z:+.2f}  [nonce chosen after the frame digest]")'''
NEW_PRINT = '''    if not a.search:
        print(f"H-probe     : SHA-256d below 2^-{a.target_bits}: {st['hits']}/{n} "
              f"(chance {n * p0:.1f}), z={z:+.2f}  [nonce chosen after the frame digest]")'''

EDITS = [
    ("# ----------------------------------------------------------------------------- noise decoder",
     BLOCK + "# ----------------------------------------------------------------------------- noise decoder"),
    ('    ap.add_argument("--seed", type=int, default=None)\n    a = ap.parse_args()\n',
     '    ap.add_argument("--seed", type=int, default=None)\n'
     '    ap.add_argument("--search", action="store_true",\n'
     '                    help="needle search: every trial nonce is one clock of the circuit")\n'
     '    ap.add_argument("--search-mult", type=float, default=20.0, help="budget = mult * 2^k clocks per frame")\n'
     '    ap.add_argument("--verify", default=None, help="replay hits of a CSV through the circuit and exit")\n'
     '    a = ap.parse_args()\n'
     '    if a.verify:\n        verify_csv(a)\n        return\n'),
    ("    trial_hist = []", "    needles = []\n    trial_hist = []"),
    (OLD_NONCE, NEW_NONCE),
    ("digest.hex()[:16]", "digest.hex()"),
    ("nonce.hex(), int(hit)))", "nonce.hex(), int(hit), trials))"),
    ('Q Qbar nonce hit".split()', 'Q Qbar nonce hit trials".split()'),
    ('    # H-instrumentation\n    n = st["acc_n"]; p0 = 2.0 ** -a.target_bits', SUMMARY),
    (OLD_PRINT, NEW_PRINT),
]


def main():
    src = sys.argv[1] if len(sys.argv) > 1 else "rp_camera_sim.py"
    text = open(src).read()
    for old, new in EDITS:
        c = text.count(old)
        if c != 1:
            sys.exit(f"anchor found {c} times (need exactly 1):\n{old[:120]}")
        text = text.replace(old, new)
    out = src.replace(".py", "_needle.py")
    open(out, "w").write(text)
    print(f"wrote {out}")


if __name__ == "__main__":
    main()
