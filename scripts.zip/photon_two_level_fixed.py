#!/usr/bin/env python3
"""Fixed, runnable two-level photon-statistics decoder."""
import argparse, hashlib, itertools, secrets
import numpy as np

VCC, V_BE = 5.0, 0.7
TAU = 10e3 * 15e-6
CLK = 0.100
FRAME_DT = 0.005

def commit(salt, v, nbits):
    return hashlib.sha256(f"{salt}:{v:0{nbits // 4}X}".encode()).hexdigest()

class PhotonCircuit:
    def __init__(self, secret, nbits, rng, mean_photons=40.0, thr=0.45):
        self.secret, self.nbits, self.rng = secret, nbits, rng
        self.lam = mean_photons
        self.thr, self.hyst = thr, 0.03
        self.state, self.vc, self.t = False, 0.0, 0.0

    def _b_out(self, intensity):
        if self.state and intensity < self.thr - self.hyst:
            self.state = False
        elif not self.state and intensity > self.thr + self.hyst:
            self.state = True
        drive = VCC if self.state else 0.0
        self.vc += (drive - self.vc) * (1 - np.exp(-FRAME_DT / TAU))
        return self.vc > V_BE

    def word(self):
        bits = 0
        frames = int(round(CLK / FRAME_DT))
        for slot in range(self.nbits):
            d = 0
            for _ in range(frames):
                self.t += FRAME_DT
                nB = self.rng.poisson(self.lam * (1 + 0.8 * np.sin(2*np.pi*0.4*self.t)))
                nA = self.rng.poisson(self.lam * (1 + 0.8 * np.sin(2*np.pi*0.7*self.t + 1)))
                a = bool(nA & 1)
                b = self._b_out(nB / (2*self.lam))
                d = a and b
            y = (self.secret >> (self.nbits-1-slot)) & 1
            bits = (bits << 1) | int(bool(y) or d)
        return bits

class PhotonStatistics:
    def __init__(self, nbits):
        self.nbits, self.n = nbits, 0
        self.zeros = np.zeros(nbits, int)

    def update(self, word):
        self.n += 1
        for i in range(self.nbits):
            if not (word >> (self.nbits-1-i)) & 1:
                self.zeros[i] += 1

    def proven_zero(self):
        return self.zeros > 0

    def noise_rate(self):
        z = self.proven_zero()
        if not z.any() or self.n == 0:
            return 0.5
        p = 1.0 - self.zeros[z].sum() / (self.n * z.sum())
        return float(np.clip(p, 0.01, 0.97))

    def posterior_one(self):
        p = self.noise_rate()
        post = np.zeros(self.nbits)
        z = self.proven_zero()
        post[~z] = 1.0 / (1.0 + p ** self.n)
        return post

def list_decode(stats, commitment, salt, nbits, max_ambiguous=14, thr=0.999):
    post = stats.posterior_one()
    base = 0
    for i in range(nbits):
        if post[i] >= 0.5:
            base |= 1 << (nbits-1-i)
    amb = [i for i in range(nbits) if 0 < post[i] < thr]
    if len(amb) > max_ambiguous:
        return None, len(amb), 0
    tries = 0
    for k in range(len(amb)+1):
        for flip in itertools.combinations(amb, k):
            cand = base
            for i in flip:
                cand &= ~(1 << (nbits-1-i))
            tries += 1
            if commit(salt, cand, nbits) == commitment:
                return cand, len(amb), tries
    return None, len(amb), tries

def attack(nbits, seed, max_words=200):
    rng = np.random.default_rng(seed)
    secret = int(rng.integers(0, 1 << nbits))
    salt = secrets.token_hex(8)
    commitment = commit(salt, secret, nbits)
    circ = PhotonCircuit(secret, nbits, rng)
    stats = PhotonStatistics(nbits)
    for w in range(1, max_words+1):
        stats.update(circ.word())
        cand, n_amb, tries = list_decode(stats, commitment, salt, nbits)
        if cand is not None:
            return dict(ok=cand == secret, words=w, amb=n_amb, tries=tries,
                        p=stats.noise_rate(), secret=secret, guess=cand)
    return dict(ok=False, words=max_words, amb=-1, tries=0,
                p=stats.noise_rate(), secret=secret, guess=None)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--bits', type=int, default=16)
    ap.add_argument('--trials', type=int, default=10)
    ap.add_argument('--reveal', action='store_true')
    a = ap.parse_args()
    n = a.bits - a.bits % 4
    res = [attack(n, s) for s in range(a.trials)]
    okr = np.mean([r['ok'] for r in res])
    print(f'bits={n} success={okr:.0%} '
          f'words mean={np.mean([r["words"] for r in res]):.1f} '
          f'max={max(r["words"] for r in res)} '
          f'hash checks mean={np.mean([r["tries"] for r in res]):.1f} '
          f'p_hat={np.mean([r["p"] for r in res]):.2f}')
    if a.reveal:
        r = res[0]
        print(f'example secret={r["secret"]:0{n//4}X} guess={r["guess"]:0{n//4}X}')

if __name__ == '__main__':
    main()
