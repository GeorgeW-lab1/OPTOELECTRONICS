"""
Online next-tick forecasting for the optoelectronic circuit.

Each stream (detector A, detector B, probe truth = a AND b) gets a
StreamForecaster. At every clock tick it:
  1. scores the forecast it made one tick ago against the bit that actually arrived,
  2. learns from that bit (order-k Markov model over recent bits),
  3. forecasts the next tick.

Scoring is honest: accuracy is compared with "same as last tick" (persistence)
and with a binomial test against pure chance, so you can see whether the
forecaster beats luck or just copies the last value.
"""

from collections import defaultdict, deque
from math import comb


def binom_tail(hits, n, p=0.5):
    """P(X >= hits) for X ~ Binomial(n, p)."""
    if n == 0:
        return 1.0
    return sum(comb(n, k) * p**k * (1 - p) ** (n - k) for k in range(hits, n + 1))


class MarkovPredictor:
    """Order-k Markov model with Laplace smoothing; falls back to lower orders."""

    def __init__(self, order=3):
        self.order = order
        self.counts = [defaultdict(lambda: [0, 0]) for _ in range(order + 1)]
        self.hist = deque(maxlen=order)

    def prob_one(self):
        """Probability the next bit is 1, using the longest context seen so far."""
        h = tuple(self.hist)
        for k in range(min(len(h), self.order), -1, -1):
            n0, n1 = self.counts[k][h[len(h) - k:]]
            if n0 + n1 > 0:
                return (n1 + 1) / (n0 + n1 + 2)
        return 0.5

    def update(self, bit):
        h = tuple(self.hist)
        for k in range(min(len(h), self.order) + 1):
            self.counts[k][h[len(h) - k:]][bit] += 1
        self.hist.append(bit)


class StreamForecaster:
    def __init__(self, name, order=3):
        self.name = name
        self.model = MarkovPredictor(order)
        self.p1 = 0.5                  # current forecast: P(next bit = 1)
        self.last = None
        self.n = self.hits = self.persist_hits = 0
        self.ready = False             # True once a forecast exists to be scored

    @property
    def forecast(self):
        return int(self.p1 >= 0.5)

    def observe(self, bit):
        if self.ready:
            self.n += 1
            self.hits += int(self.forecast == bit)
            self.persist_hits += int(self.last == bit)
        self.model.update(bit)
        self.last = bit
        self.p1 = self.model.prob_one()   # forecast for the NEXT tick
        self.ready = True

    def summary(self):
        if self.n == 0:
            return f"{self.name}: no scored forecasts yet"
        acc = self.hits / self.n
        pers = self.persist_hits / self.n
        p = binom_tail(self.hits, self.n)
        verdict = "better than chance" if p < 0.05 else "indistinguishable from chance"
        return (f"{self.name:<10} n={self.n:4d}  forecaster={acc:5.1%}  "
                f"persistence={pers:5.1%}  p(vs chance)={p:.3f}  -> {verdict}")
