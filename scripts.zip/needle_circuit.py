#!/usr/bin/env python3
"""
needle_circuit.py - the RP circuit IS the verifier of a needle-in-a-haystack problem.

Per frame (full digest d from the CSV):
  x      = instance from d            (same rule as rp_camera_sim: odd 32-bit, 50% forced prime)
  needle = nonce n such that ALL of
     1. Driver A : r = 2 + SHA256("r"||d||n) mod (x-3) is a Miller-Rabin witness   (A = 1)
     2. Driver B : RC node charges, NPN emitter follower reaches logic HIGH          (B = 1)
     3. AND(A,B) is clocked through the 150 ms delay and the 74HC74, Q = 1          (SELECT)
     4. PoW gate : SHA256d(d||n) < 2^(256-k)                                         (haystack)

  composite x : needles exist, density ~ 2^-k * P(A=1) >= 0.75 * 2^-k  -> found in ~2^k trials
  prime x     : NO needle exists (A = 0 always) -> search exhausts its budget (one-sided error)
So the search doubles as an RP decision procedure: found => composite (certificate = nonce, 1 check),
budget exhausted => "prime" with error ~ exp(-budget / (1.34 * 2^k)).

Needs the FULL digest in the CSV (log digest.hex(), not [:16]) and rp_camera_sim.py in the same folder.
  python needle_circuit.py run.csv --k 12 --rows 40
"""
import argparse, csv, hashlib, math, time
from rp_camera_sim import is_prime, is_witness, next_prime, DriverB, DFlipFlop74HC74, Delay


def sha256d(b):
    return hashlib.sha256(hashlib.sha256(b).digest()).digest()


def instance(d):
    x = int.from_bytes(d[8:12], "big") | 1 | (1 << 31)
    return next_prime(x) if d[12] & 1 else x


def pow_ok(d, n, k):
    return int.from_bytes(sha256d(d + n), "big") < (1 << (256 - k))


def driver_A(d, n, x):
    r = 2 + int.from_bytes(hashlib.sha256(b"r" + d + n).digest(), "big") % (x - 3)
    return int(is_witness(r, x))


def clock_through(and_ab, clock_ms, delay_ms):
    """AND -> delay line -> D flip-flop; returns Q after the delayed bit has been clocked in."""
    dl = Delay(math.ceil(delay_ms / clock_ms))
    ff = DFlipFlop74HC74()
    q = 0
    for _ in range(len(dl.buf) + 1):
        q = ff.clock(dl.step(and_ab))
    return q


def verify(d, n, k, tau_ms=50.0, clock_ms=100.0, delay_ms=150.0):
    """The whole certificate check: one run of the circuit plus one double hash."""
    x = instance(d)
    A = driver_A(d, n, x)
    B, _, _ = DriverB(tau_ms, noise=False).run(x, clock_ms / 1000.0)
    return clock_through(A & B, clock_ms, delay_ms) == 1 and pow_ok(d, n, k)


def search(d, k, budget, **kw):
    """Brute force. PoW gate is tested first (cheap); the circuit confirms survivors."""
    ctr = 0
    while ctr < budget:
        n = ctr.to_bytes(8, "big")
        ctr += 1
        if pow_ok(d, n, k) and verify(d, n, k, **kw):
            return n, ctr
    return None, ctr


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("csv")
    ap.add_argument("--k", type=int, default=12, help="PoW bits; ~2^k trials per composite frame")
    ap.add_argument("--rows", type=int, default=40)
    ap.add_argument("--budget-mult", type=float, default=20.0, help="budget = mult * 2^k trials")
    ap.add_argument("--tau-ms", type=float, default=50.0)
    ap.add_argument("--clock-ms", type=float, default=100.0)
    ap.add_argument("--delay-ms", type=float, default=150.0)
    ap.add_argument("--out", default=None, help="write found certificates to CSV")
    a = ap.parse_args()
    kw = dict(tau_ms=a.tau_ms, clock_ms=a.clock_ms, delay_ms=a.delay_ms)

    rows = list(csv.DictReader(open(a.csv)))[:a.rows]
    if len(rows[0]["digest16"]) < 64:
        raise SystemExit("CSV holds truncated digests: log digest.hex() in full.")
    budget = int(a.budget_mult * 2 ** a.k)
    print(f"k={a.k}  budget={budget}  expected trials per composite frame <= {2 ** a.k * 4 / 3:.0f}\n")

    comp = prime = comp_found = prime_found = 0
    trials, certs = [], []
    t0 = time.time()
    for r in rows:
        d = bytes.fromhex(r["digest16"])
        x = instance(d)
        is_comp = not is_prime(x)
        if "x" in r and int(r["x"]) != x:
            print(f"  tick {r['tick']}: CSV x differs from recomputed x, skipping")
            continue
        n, used = search(d, a.k, budget, **kw)
        if is_comp:
            comp += 1
            comp_found += n is not None
        else:
            prime += 1
            prime_found += n is not None
        if n is not None:
            trials.append(used)
            assert verify(d, n, a.k, **kw)
            certs.append((r["tick"], x, n.hex(), used))
        verdict = "composite (certificate found)" if n else "prime (budget exhausted)"
        print(f"  tick {r['tick']:>5} x={x:<11d} truth={'composite' if is_comp else 'prime    '} "
              f"-> {verdict}  trials={used}")

    print("\n=== SUMMARY ===")
    print(f"composites: {comp_found}/{comp} certified   (completeness; miss prob ~ "
          f"{math.exp(-a.budget_mult / (4 / 3)):.1e} each)")
    print(f"primes    : {prime_found}/{prime} certified   (soundness, must be 0: A=0 on every prime)")
    if trials:
        print(f"mean trials to certificate {sum(trials) / len(trials):.0f} "
              f"(theory <= {2 ** a.k * 4 / 3:.0f}); verifying one costs 1 circuit pass + 2 hashes")
    print(f"wall {time.time() - t0:.1f}s")
    if a.out and certs:
        with open(a.out, "w", newline="") as fh:
            w = csv.writer(fh)
            w.writerow(["tick", "x", "nonce", "trials"])
            w.writerows(certs)
        print(f"certificates written to {a.out}")


if __name__ == "__main__":
    main()
