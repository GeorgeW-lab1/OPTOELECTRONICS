"""cutcheck.py - random code-cut checker: does removing this code change the generated text?

  python cutcheck.py tg.py [--n 150] [--seed 0] [--all] [--include-unexecuted] [--jobs N] [--json out.json]

How it works
  1. Baseline: run a fixed probe (seeded generations over both pipelines, several option sets) in a
     subprocess, recording the texts, a few metrics, and which source lines were executed.
  2. Cuts (AST level):  delete a simple statement | unwrap an `if` (treat as always true) |
     drop an `if` (treat as always false) | take one side of `a if c else b` | drop one operand of
     `and`/`or` | drop one comprehension filter.
  3. Each sampled cut is written to a temp file and the probe re-run. Outcome:
       KILLED-TEXT     generated text changed        -> the code matters (to the probe)
       KILLED-CRASH/TIMEOUT                           -> the code is needed to run
       METRICS-ONLY    text identical, metrics differ -> affects diagnostics, not output
       SURVIVED        nothing observable changed     -> redundant, dead, or probe too weak
  Survivors on EXECUTED lines are the interesting ones. Survival is evidence, not proof.
Target must expose Engine(text, sources, order=, alpha=, warm=) and Engine.generate(prompt, **opts)."""
import argparse, ast, importlib.util, json, os, random, subprocess, sys, tempfile, time
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

PROBE_TEXT = """The process begins with a simple observation of local flows. As patterns emerge, structural constraints shape the boundary conditions. Non-isomorphic transformations map states across mismatched dimensions. Causal ascent drives the system toward higher informational complexity. Through adiabatic continuation, the generator balances exploration and selective focus. A state machine reads a symbol, writes a symbol, moves its head, and changes state. The tape preserves the history of every emitted token. Transitions are explicit, inspectable, and reproducible. Observation becomes description, description becomes relation, and relation becomes abstraction. Synthesis gathers prior evidence, while reflection consolidates the generated sequence. Let x = i + 1 and y = x * 2 in the model. We set i = 3 and then compare x with y. The protocol I, II, III, and O recycles every output into the next identity. A machine doesn't forget what it has written, but it can't read what it hasn't seen. The value 3.14 appears twice, and 42 appears once. Each stage keeps its own memory, and synthesis composes those memories into a single state. Verification asks whether the next state stays close to the last one. When the distance is small, the transition is accepted; when it is large, the gate relaxes. Reflection compares the synthesized process with the tape that was actually produced. Small differences are tolerated, because continuity matters more than novelty. Structural constraints narrow the field of possible tokens, while association widens it again. Patterns repeat, patterns drift, and patterns return in altered form. Every symbol on the tape was once a candidate among many. The ledger remembers which fragments followed which fragments. Abstraction removes detail, relation connects detail, and description preserves detail. The generator ascends from observation toward synthesis, then reflects and halts. A new segment begins where the last one ended. Complexity grows when simple rules interact over long sequences. The head moves, the state changes, and the tape grows by one symbol."""
CONFIGS = [
    ("A process", dict(seed=1, tokens=220, pipeline="forward")),
    ("A process", dict(seed=2, tokens=220, pipeline="reverse")),
    ("The tape", dict(seed=3, tokens=160, temp=0, pipeline="forward")),
    ("Observation becomes", dict(seed=4, tokens=160, temp=1.2, pipeline="reverse")),
    ("Let x", dict(seed=5, tokens=140, pipeline="forward", eps=.2)),
    ("The system", dict(seed=6, tokens=140, pipeline="reverse", tau=.5, keep_learning=False)),
    ("Causal ascent", dict(seed=7, tokens=140, atoms=["ngram", "rank_prior", "repetition", "ledger"], masks=9, state="DESCRIBE")),
    ("A state machine", dict(seed=8, tokens=140, masks=40, levels=5, ledger_w=.3, beam=4)),
    ("II", dict(seed=9, tokens=100, pipeline="forward")),
    ("Synthesis", dict(seed=10, tokens=180, pipeline="reverse", state="ABSTRACT", eps=.1, engine=dict(order=3, warm=0))),
    ("Reflection", dict(seed=11, tokens=120, pipeline="forward", state="REFLECT", engine=dict(order=2))),
    ("", dict(seed=12, tokens=90)),
]

# ---------------------------------------------------------------- probe (subprocess side)
def probe(path, cover):
    target, lines = os.path.abspath(path), set()
    if cover:
        if hasattr(sys, "monitoring"):
            mon = sys.monitoring; mon.use_tool_id(3, "cut")
            def cb(code, line):
                if code.co_filename == target: lines.add(line)
                return mon.DISABLE
            mon.register_callback(3, mon.events.LINE, cb); mon.set_events(3, mon.events.LINE)
        else:
            def tr(frame, ev, arg):
                if frame.f_code.co_filename != target: return None
                def local(f, e, a):
                    if e == "line": lines.add(f.f_lineno)
                    return local
                return local
            sys.settrace(tr)
    spec = importlib.util.spec_from_file_location("target", target); m = importlib.util.module_from_spec(spec)
    sys.modules["target"] = m; spec.loader.exec_module(m)
    engines, out = {}, []
    for prompt, kw in CONFIGS:
        kw = dict(kw); ek = tuple(sorted(kw.pop("engine", {}).items()))
        if ek not in engines: engines[ek] = m.Engine(PROBE_TEXT, ["<probe>"], **dict(ek))
        r = engines[ek].generate(prompt, **kw)
        ag = r["mean_agreement"]
        out.append(dict(text=r["text"], m=[r["relaxations"], r["fallbacks"], r["n_segments"],
                        None if ag is None else round(ag, 9), round(float(r["mean_natural_rate"]), 9)]))
    print("@@" + json.dumps(dict(out=out, lines=sorted(lines))))

def run_probe(path, timeout, cover=False):
    cmd = [sys.executable, os.path.abspath(__file__), "--_probe", path] + (["--cover"] if cover else [])
    env = dict(os.environ, OMP_NUM_THREADS="1", OPENBLAS_NUM_THREADS="1", MKL_NUM_THREADS="1")
    try: p = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout, env=env)
    except subprocess.TimeoutExpired: return "timeout", None
    if p.returncode: return "crash", (p.stderr.strip().splitlines() or ["?"])[-1][:100]
    return "ok", json.loads([l for l in p.stdout.splitlines() if l.startswith("@@")][-1][2:])

# ---------------------------------------------------------------- cuts
SIMPLE = (ast.Assign, ast.AugAssign, ast.AnnAssign, ast.Expr, ast.Return, ast.Raise, ast.Break, ast.Continue, ast.Delete)
def find_sites(tree):
    out = []
    for i, n in enumerate(ast.walk(tree)):
        if isinstance(n, SIMPLE) and not (isinstance(n, ast.Expr) and isinstance(n.value, ast.Constant)): out.append((i, "delete"))
        elif isinstance(n, ast.If):
            if isinstance(n.test, ast.Compare) and isinstance(n.test.left, ast.Name) and n.test.left.id == "__name__": continue
            out += [(i, "unwrap_if"), (i, "drop_if")]
        elif isinstance(n, ast.IfExp): out += [(i, "ifexp_then"), (i, "ifexp_else")]
        elif isinstance(n, ast.BoolOp): out += [(i, f"drop_operand{j}") for j in range(len(n.values))]
        elif isinstance(n, ast.comprehension): out += [(i, f"drop_filter{j}") for j in range(len(n.ifs))]
    return out

def mutate(src, idx, kind):
    tree = ast.parse(src); nodes = list(ast.walk(tree)); node = nodes[idx]; parent = field = None
    for p in nodes:
        for f, v in ast.iter_fields(p):
            if v is node or (isinstance(v, list) and any(x is node for x in v)): parent, field = p, f
    def put(new):
        v = getattr(parent, field)
        if isinstance(v, list):
            k = next(k for k, x in enumerate(v) if x is node); v[k:k + 1] = new if isinstance(new, list) else [new]
        else: setattr(parent, field, new)
    if kind == "delete": put(ast.Pass())
    elif kind == "unwrap_if": put(node.body)
    elif kind == "drop_if": put(node.orelse or [ast.Pass()])
    elif kind == "ifexp_then": put(node.body)
    elif kind == "ifexp_else": put(node.orelse)
    elif kind.startswith("drop_operand"):
        j = int(kind[12:]); vals = [v for k, v in enumerate(node.values) if k != j]
        put(vals[0] if len(vals) == 1 else ast.BoolOp(node.op, vals))
    elif kind.startswith("drop_filter"): del node.ifs[int(kind[11:])]
    return ast.unparse(ast.fix_missing_locations(tree))

# ---------------------------------------------------------------- driver
def main():
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    ap.add_argument("target"); ap.add_argument("--n", type=int, default=150); ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--all", action="store_true"); ap.add_argument("--include-unexecuted", action="store_true")
    ap.add_argument("--timeout", type=float, default=90); ap.add_argument("--jobs", type=int, default=os.cpu_count() or 2)
    ap.add_argument("--json"); ap.add_argument("--_probe"); ap.add_argument("--cover", action="store_true")
    a = ap.parse_args()
    if a._probe: return probe(a._probe, a.cover)

    t0 = time.time(); src = Path(a.target).read_text("utf-8")
    st, base = run_probe(a.target, a.timeout, cover=True)
    if st != "ok": sys.exit(f"baseline failed: {st} {base}")
    st2, base2 = run_probe(a.target, a.timeout)
    if st2 != "ok" or base2["out"] != base["out"]: sys.exit("probe is not deterministic; cannot compare cuts")
    executed, ref = set(base["lines"]), base["out"]
    print(f"baseline ok: {len(ref)} generations, {sum(len(x['text']) for x in ref):,} chars, {len(executed)} lines executed ({time.time()-t0:.0f}s)")

    tree = ast.parse(src); nodes = list(ast.walk(tree)); sites = find_sites(tree)
    live = [s for s in sites if a.include_unexecuted or nodes[s[0]].lineno in executed]
    pick = live if a.all else random.Random(a.seed).sample(live, min(a.n, len(live)))
    print(f"{len(sites)} possible cuts, {len(live)} on executed lines; testing {len(pick)} (jobs={a.jobs})")

    tmp = tempfile.mkdtemp(prefix="cutcheck_")
    def trial(k, site):
        idx, kind = site; p = os.path.join(tmp, f"m{k}.py")
        try: Path(p).write_text(mutate(src, idx, kind), "utf-8")
        except Exception as ex: return k, "SKIP", f"unparse failed: {ex}"
        st, res = run_probe(p, a.timeout); os.remove(p)
        if st == "timeout": return k, "KILLED-TIMEOUT", ""
        if st == "crash": return k, "KILLED-CRASH", res
        if [r["text"] for r in res["out"]] != [r["text"] for r in ref]:
            n = sum(x["text"] != y["text"] for x, y in zip(res["out"], ref)); return k, "KILLED-TEXT", f"{n}/{len(ref)} generations differ"
        if [r["m"] for r in res["out"]] != [r["m"] for r in ref]: return k, "METRICS-ONLY", ""
        return k, "SURVIVED", ""
    with ThreadPoolExecutor(a.jobs) as ex: results = list(ex.map(lambda t: trial(*t), enumerate(pick)))

    from collections import Counter
    cnt = Counter(r[1] for r in results); tested = len(results) - cnt["SKIP"]
    killed = sum(v for k, v in cnt.items() if k.startswith("KILLED"))
    def desc(site):
        n = nodes[site[0]]; seg = (ast.get_source_segment(src, n) or "").split("\n")[0]
        return n.lineno, " ".join(seg.split())[:90]
    rows = []
    for k, status, note in results:
        ln, seg = desc(pick[k]); rows.append(dict(line=ln, kind=pick[k][1], status=status, code=seg, note=note))
    print("\n" + "  ".join(f"{k}={v}" for k, v in sorted(cnt.items())))
    print(f"mutation score: {killed}/{tested} = {100 * killed / max(1, tested):.0f}% of tested cuts changed behaviour")
    for label in ("SURVIVED", "METRICS-ONLY"):
        sel = sorted((r for r in rows if r["status"] == label), key=lambda r: (r["line"], r["kind"]))
        if sel: print(f"\n== {label}: {len(sel)} ==")
        for r in sel: print(f"  L{r['line']:<4} {r['kind']:<14} {r['code']}")
    if a.json: Path(a.json).write_text(json.dumps(rows, indent=1)); print(f"\nwrote {a.json}")
    print(f"\ndone in {time.time() - t0:.0f}s")

if __name__ == "__main__": main()
