import random
import sys
import time
from math import gcd

SMALL_PRIMES = [2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47, 53, 59, 61, 67, 71]


def is_prime(n):
    """Miller-Rabin (deterministic for n < 3.3e24, probabilistic and very reliable above)."""
    if n < 2:
        return False
    for p in SMALL_PRIMES:
        if n % p == 0:
            return n == p
    d, s = n - 1, 0
    while d % 2 == 0:
        d //= 2
        s += 1
    for a in SMALL_PRIMES[:12] + [random.randrange(2, n - 1) for _ in range(8)]:
        x = pow(a, d, n)
        if x in (1, n - 1):
            continue
        for _ in range(s - 1):
            x = x * x % n
            if x == n - 1:
                break
        else:
            return False
    return True


def brent_rho(n):
    """Return a nontrivial factor of composite n."""
    if n % 2 == 0:
        return 2
    while True:
        y, c, m = random.randrange(1, n), random.randrange(1, n), 128
        g = r = q = 1
        while g == 1:
            x = y
            for _ in range(r):
                y = (y * y + c) % n
            k = 0
            while k < r and g == 1:
                ys = y
                for _ in range(min(m, r - k)):
                    y = (y * y + c) % n
                    q = q * abs(x - y) % n
                g = gcd(q, n)
                k += m
            r *= 2
        if g == n:
            g = 1
            while g == 1:
                ys = (ys * ys + c) % n
                g = gcd(abs(x - ys), n)
        if g != n:
            return g


def factor(n):
    """Full factorization of n as {prime: exponent}. Takes only n."""
    factors = {}

    def add(p):
        factors[p] = factors.get(p, 0) + 1

    # strip small primes
    for p in SMALL_PRIMES:
        while n % p == 0:
            add(p)
            n //= p

    stack = [n] if n > 1 else []
    while stack:
        m = stack.pop()
        if m == 1:
            continue
        if is_prime(m):
            add(m)
            continue
        d = brent_rho(m)
        stack += [d, m // d]
    return dict(sorted(factors.items()))


if __name__ == "__main__":
    N = int(sys.argv[1]) if len(sys.argv) > 1 else 1000003 * 999983 * 2**5
    t0 = time.time()
    print(f"N = {N}")
    print(f"factors = {factor(N)}")
    print(f"time = {time.time() - t0:.3f}s")
