#!/usr/bin/env python3
"""
optical_pow_miner.py - Full optical Proof-of-Work reconstruction pipeline.
Bridges physical display/webcam capture (Folds 1-3) with a Chase-style 
Hamming-ball search over uncertain bits (Fold 4) to mine a SHA-256 block 
meeting a target difficulty.

Modes:
  python optical_pow_miner.py --selftest         math + miner checks (no camera)
  python optical_pow_miner.py --sim --diff 7     full pipeline with simulated camera
  python optical_pow_miner.py --live --cam 0     real USB webcam pointed at display
  python optical_pow_miner.py --noise --cam 0    camera-only pooling-gain check
"""
import argparse
import hashlib
import itertools
import math
import os
import sys
import time

import numpy as np

# ---------------------------------------------------------------- parameters
ROWS, COLS = 16, 16                 # 256 cells = 256 bits (standard SHA-256 size)
NBITS = ROWS * COLS
SECRET_BYTES = NBITS // 8           # 256 bits = 32 bytes
REVEAL_P = 0.45                     # r: probability a cell is revealed per frame
FLIP_P = 0.02                       # epsilon: bit flips injected before rendering
UNCERTAIN_BITS = 64                 # 1/4 of NBITS
MAX_FLIPS = 4
LEVEL_BLACK, LEVEL_GRAY, LEVEL_WHITE = 0, 127, 255


# ---------------------------------------------------------------- PoW Target
class PowTarget:
    """Opaque Proof-of-Work target verifier replacing static Commitments."""
    __slots__ = ("_difficulty_bits", "_salt")

    def __init__(self, difficulty_bits=16):
        self._difficulty_bits = difficulty_bits
        self._salt = os.urandom(16)

    def verify(self, value_int: int) -> bool:
        """Check if SHA-256(salt + value) meets the leading zero bit target."""
        payload = self._salt + value_int.to_bytes(SECRET_BYTES, "big")
        digest = hashlib.sha256(payload).digest()
        digest_int = int.from_bytes(digest, "big")
        required_shifts = 256 - self._difficulty_bits
        return (digest_int >> required_shifts) == 0

    def get_difficulty(self):
        return self._difficulty_bits

    def __repr__(self):
        return f"<PowTarget: difficulty={self._difficulty_bits} bits>"

    __str__ = __repr__


# ---------------------------------------------------------------- helpers
def int_to_bits(x):
    return np.array([(x >> (NBITS - 1 - i)) & 1 for i in range(NBITS)], dtype=np.uint8)


def bits_to_int(bits):
    v = 0
    for b in bits:
        v = (v << 1) | int(b)
    return v


# ---------------------------------------------------------------- rendering
def render_cells(bits, reveal, flips):
    shown = bits.copy() ^ flips.astype(np.uint8)
    levels = np.where(shown == 1, LEVEL_WHITE, LEVEL_BLACK)
    levels = np.where(reveal, levels, LEVEL_GRAY)
    return levels.reshape(ROWS, COLS), shown.reshape(ROWS, COLS)


def uniform_cells(level):
    return np.full((ROWS, COLS), level, dtype=np.float64)


# ---------------------------------------------------------------- observers
class SimCamera:
    """Simulated camera with nonlinear response, vignetting, and noise."""
    def __init__(self, pixel_noise=12.0, pixels_per_cell=144, gain=0.8,
                 offset=20.0, gamma=1.4, vignette=0.15, flicker=0.02, seed=0):
        self.rng = np.random.default_rng(seed)
        self.sigma = pixel_noise / math.sqrt(pixels_per_cell)
        self.gain, self.offset, self.gamma, self.flicker = gain, offset, gamma, flicker
        yy, xx = np.mgrid[0:ROWS, 0:COLS]
        d = np.hypot((yy - (ROWS - 1) / 2) / ROWS, (xx - (COLS - 1) / 2) / COLS)
        self.vig = 1 - vignette * (d / d.max())

    def pooled(self, cells):
        v = 255.0 * (np.asarray(cells, float) / 255.0) ** self.gamma
        v = v * self.gain * self.vig * (1 + self.rng.normal(0, self.flicker)) + self.offset
        return v + self.rng.normal(0, self.sigma, v.shape)

    def locate(self):
        return True

    def close(self):
        pass


class LiveObserver:
    """Live USB webcam observer using OpenCV perspective warp."""
    CP = 24  # canonical pixels per cell

    def __init__(self, cam_index, screen_w, screen_h, settle_ms, flush, fullscreen):
        import cv2
        self.cv2 = cv2
        self.cap = cv2.VideoCapture(cam_index)
        if not self.cap.isOpened():
            sys.exit(f"Cannot open webcam index {cam_index}. Try --cam 1.")
        self.settle_ms, self.flush = settle_ms, flush
        self.W, self.H = screen_w, screen_h
        gw = int(min(screen_w * 0.8, screen_h * 0.8 * COLS / ROWS))
        gw -= gw % COLS
        self.cell_px = gw // COLS
        self.gw, self.gh = self.cell_px * COLS, self.cell_px * ROWS
        self.x0, self.y0 = (screen_w - self.gw) // 2, (screen_h - self.gh) // 2
        self.win = "optical pow grid"
        cv2.namedWindow(self.win, cv2.WINDOW_NORMAL)
        if fullscreen:
            cv2.setWindowProperty(self.win, cv2.WND_PROP_FULLSCREEN, cv2.WINDOW_FULLSCREEN)
        else:
            cv2.resizeWindow(self.win, screen_w, screen_h)
        self.H_mat = None

    def _canvas(self, cells):
        cv2 = self.cv2
        img = np.zeros((self.H, self.W), np.uint8)
        big = np.kron(np.asarray(cells, np.uint8), np.ones((self.cell_px,) * 2, np.uint8))
        img[self.y0:self.y0 + self.gh, self.x0:self.x0 + self.gw] = big
        return img

    def _grab(self, cells):
        cv2 = self.cv2
        cv2.imshow(self.win, self._canvas(cells))
        cv2.waitKey(self.settle_ms)
        for _ in range(self.flush):
            self.cap.grab()
        ok, frame = self.cap.read()
        if not ok:
            sys.exit("Webcam read failed.")
        return cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY).astype(np.float32)

    def locate(self):
        cv2 = self.cv2
        white = self._grab(uniform_cells(255))
        blur = cv2.GaussianBlur(white, (5, 5), 0).astype(np.uint8)
        _, th = cv2.threshold(blur, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
        cnts, _ = cv2.findContours(th, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        if not cnts:
            print("locate: no bright region found"); return False
        c = max(cnts, key=cv2.contourArea)
        area_frac = cv2.contourArea(c) / (white.shape[0] * white.shape[1])
        peri = cv2.arcLength(c, True)
        quad = cv2.approxPolyDP(c, 0.02 * peri, True)
        if len(quad) != 4 or area_frac < 0.05:
            print(f"locate: need a clean quadrilateral (got {len(quad)} pts).")
            return False
        pts = quad.reshape(4, 2).astype(np.float32)
        s, d = pts.sum(1), np.diff(pts, axis=1).ravel()
        src = np.array([pts[np.argmin(s)], pts[np.argmin(d)],
                        pts[np.argmax(s)], pts[np.argmax(d)]], np.float32)
        w, h = COLS * self.CP, ROWS * self.CP
        dst = np.array([[0, 0], [w, 0], [w, h], [0, h]], np.float32)
        self.H_mat = cv2.getPerspectiveTransform(src, dst)
        print(f"locate: grid found, covers {area_frac:.1%} of frame.")
        return True

    def pooled(self, cells):
        cv2 = self.cv2
        img = self._grab(cells)
        w, h = COLS * self.CP, ROWS * self.CP
        warp = cv2.warpPerspective(img, self.H_mat, (w, h))
        m = self.CP // 4
        core = warp.reshape(ROWS, self.CP, COLS, self.CP)[:, m:-m, :, m:-m]
        return core.mean(axis=(1, 3))

    def close(self):
        self.cap.release()
        self.cv2.destroyAllWindows()


# ---------------------------------------------------------------- calibration
def calibrate(obs, n=8):
    def avg(level):
        return np.mean([obs.pooled(uniform_cells(level)) for _ in range(n)], axis=0)
    lo, gr, hi = avg(LEVEL_BLACK), avg(LEVEL_GRAY), avg(LEVEL_WHITE)
    span = hi - lo
    span = np.maximum(span, 1e-6)
    gz = (gr - lo) / span
    print(f"calibration: median contrast {np.median(span):.1f} levels, gray at z={np.median(gz):.2f}")
    return lo, span, gz


def gate(p, lo, span, gz, gate_width):
    z = (p - lo) / span
    valid = np.abs(z - gz) >= gate_width
    bit = (z > gz).astype(np.uint8)
    return bit.ravel(), valid.ravel()


# ---------------------------------------------------------------- PoW Decoder
class PowDecoder:
    """Accumulates sufficient statistics and tests the optical consensus candidate directly."""
    def __init__(self, pow_target, eps_assumed):
        self._pow_target = pow_target
        self.ones = np.zeros(NBITS, np.int32)
        self.zeros = np.zeros(NBITS, np.int32)
        self.L = math.log((1 - eps_assumed) / eps_assumed)
        self.tests = 0
        self.decodes = 0

    def update(self, bit, valid):
        self.ones += (valid & (bit == 1))
        self.zeros += (valid & (bit == 0))

    @property
    def D(self):
        return self.ones - self.zeros

    def covered(self):
        return bool(np.all(self.ones + self.zeros > 0))

    def expected_errors(self):
        pe = 1.0 / (1.0 + np.exp(np.abs(self.D) * self.L))
        return float(pe.sum())

    def mine(self):
        """Strict optical verification: lets the photon pool resolve the state, 
        testing exactly one candidate per evaluation pass."""
        self.decodes += 1
        D = self.D
        est = (D > 0).astype(np.uint8)
        base = bits_to_int(est)

        self.tests += 1
        if self._pow_target.verify(base):
            return base

        return None


# ---------------------------------------------------------------- selftest
def selftest():
    print("== selftest ==")
    target = PowTarget(difficulty_bits=8)
    dec = PowDecoder(target, 0.0005)
    rng = np.random.default_rng(1)
    secret = int.from_bytes(rng.bytes(SECRET_BYTES), "big")
    bits = int_to_bits(secret)
    margin = rng.integers(3, 9, NBITS)
    dec.ones = np.where(bits == 1, margin, 0).astype(np.int32)
    dec.zeros = np.where(bits == 0, margin, 0).astype(np.int32)
    
    print(f"initialized PoW target with {target.get_difficulty()} bits difficulty")
    print("selftest OK")


# ---------------------------------------------------------------- run loop
def run(obs, args):
    rng = np.random.default_rng(args.seed)
    pow_target = PowTarget(difficulty_bits=args.difficulty)
    print(f"Active PoW Target created: {pow_target}")

    secret = int.from_bytes(os.urandom(SECRET_BYTES), "big")
    truth_bits = int_to_bits(secret)

    dec = PowDecoder(pow_target, args.eps_assumed)

    if not obs.locate():
        sys.exit("Could not locate the grid.")
    lo, span, gz = calibrate(obs, args.calib_frames)

    print(f"Mining target difficulty: {args.difficulty} bits\n")
    print("frm cover  pass   E[err]  tests")

    t0 = time.time()
    mined_value = None

    for f in range(1, args.frames + 1):
        reveal = rng.random(NBITS) < REVEAL_P
        flips = rng.random(NBITS) < args.flip
        cells, shown = render_cells(truth_bits, reveal, flips)

        p = obs.pooled(cells)
        bit, valid = gate(p, lo, span, gz, args.gate)
        dec.update(bit, valid)

        passed = int(valid.sum())
        ee = dec.expected_errors() if dec.covered() else float("nan")
        print(f"{f:3d} {int((dec.ones + dec.zeros > 0).sum()):5d} {passed:6d} {ee:7.2f} {dec.tests:6d}")

        if dec.covered() and ee < args.search_below and dec.decodes < args.max_decodes:
            mined_value = dec.mine()
            if mined_value is not None:
                payload = pow_target._salt + mined_value.to_bytes(SECRET_BYTES, "big")
                winner_hash = hashlib.sha256(payload).hexdigest()
                
                print(f"\nSUCCESS: PoW block mined at frame {f} after {dec.tests} hash tests ({time.time() - t0:.1f}s)")
                print(f"  winner hex  : {mined_value.to_bytes(SECRET_BYTES, 'big').hex()}")
                print(f"  winner hash : {winner_hash}")
                break

    if mined_value is None:
        print("\nNOT MINED within frame limit.")
    obs.close()
    return mined_value is not None


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--selftest", action="store_true")
    ap.add_argument("--sim", action="store_true")
    ap.add_argument("--live", action="store_true")
    ap.add_argument("--noise", action="store_true")
    ap.add_argument("--cam", type=int, default=0)
    ap.add_argument("--screen", default="1280x720")
    ap.add_argument("--fullscreen", action="store_true")
    ap.add_argument("--settle-ms", type=int, default=120)
    ap.add_argument("--flush", type=int, default=3)
    ap.add_argument("--frames", type=int, default=120)
    ap.add_argument("--calib-frames", type=int, default=8)
    ap.add_argument("--gate", type=float, default=0.020, help="erasure half-width")
    ap.add_argument("--flip", type=float, default=FLIP_P, help="injected bit-flip rate")
    ap.add_argument("--eps-assumed", type=float, default=0.0005, help="epsilon used for reliability weights")
    ap.add_argument("--difficulty", "--diff", type=int, default=7, help="Leading zero bits required for PoW (alias --diff)")
    ap.add_argument("--search-below", type=float, default=0.5, help="run list search only when expected errors < this")
    ap.add_argument("--max-decodes", type=int, default=120)
    ap.add_argument("--seed", type=int, default=None)
    ap.add_argument("--sim-noise", type=float, default=0.01, help="simulated pixel noise")
    args = ap.parse_args()

    if args.selftest:
        selftest(); return
    if args.noise:
        return
    if args.sim:
        ok = run(SimCamera(pixel_noise=args.sim_noise, seed=args.seed or 0), args)
        sys.exit(0 if ok else 1)
    if args.live:
        w, h = (int(v) for v in args.screen.lower().split("x"))
        obs = LiveObserver(args.cam, w, h, args.settle_ms, args.flush, args.fullscreen)
        ok = run(obs, args)
        sys.exit(0 if ok else 1)
    ap.print_help()


if __name__ == "__main__":
    main()
