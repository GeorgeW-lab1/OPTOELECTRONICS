#!/usr/bin/env python3
"""
Extreme-scale subset solver.

Modes:
  1. Stream all subsets (memory-safe).
  2. Find all subsets with an exact sum.
  3. Find subsets matching a custom Python predicate.
  4. Fast exact-sum search using meet-in-the-middle.

Examples:
  python subset_solver.py --items 1,2,3,4 --mode stream
  python subset_solver.py --items 1,2,3,4,5 --mode sum --target 7
  python subset_solver.py --items-file numbers.txt --mode sum --target 100 \
      --output matches.txt --workers 8
  python subset_solver.py --items-file numbers.txt --mode meet --target 100
"""

from __future__ import annotations

import argparse
import itertools
import json
import os
import sys
import time
from concurrent.futures import ProcessPoolExecutor, as_completed
from dataclasses import dataclass
from pathlib import Path
from typing import Callable, Iterable, Iterator, Sequence


@dataclass(frozen=True)
class SubsetResult:
    indices: tuple[int, ...]
    values: tuple[int | float, ...]
    total: int | float


def parse_numbers(text: str) -> list[int | float]:
    """Parse comma-, space-, newline-, or semicolon-separated numbers."""
    tokens = text.replace(";", ",").replace("\n", ",").split(",")
    values: list[int | float] = []

    for token in tokens:
        token = token.strip()
        if not token:
            continue

        try:
            values.append(int(token))
        except ValueError:
            values.append(float(token))

    return values


def load_items(args: argparse.Namespace) -> list[int | float]:
    if args.items_file:
        path = Path(args.items_file)
        if not path.exists():
            raise FileNotFoundError(f"Items file not found: {path}")

        text = path.read_text(encoding="utf-8")
        return parse_numbers(text)

    if args.items is None:
        raise ValueError("Provide either --items or --items-file.")

    return parse_numbers(args.items)


def stream_subsets(
    values: Sequence[int | float],
    *,
    include_empty: bool = True,
) -> Iterator[SubsetResult]:
    """
    Yield every subset one at a time.

    Memory use is O(n), not O(2^n), because subsets are never accumulated.
    """
    n = len(values)
    start = 0 if include_empty else 1

    for mask in range(start, 1 << n):
        indices = tuple(i for i in range(n) if mask & (1 << i))
        chosen = tuple(values[i] for i in indices)
        yield SubsetResult(
            indices=indices,
            values=chosen,
            total=sum(chosen),
        )


def subset_sum_stream(
    values: Sequence[int | float],
    target: int | float,
    *,
    include_empty: bool = False,
) -> Iterator[SubsetResult]:
    """Stream only subsets whose sum equals target."""
    for result in stream_subsets(values, include_empty=include_empty):
        if result.total == target:
            yield result


def make_worker(
    values: tuple[int | float, ...],
    target: int | float | None,
    predicate_source: str | None,
    include_empty: bool,
):
    """
    Create a standalone worker function for multiprocessing.

    A custom predicate receives:
      indices, values, total
    and must return True or False.
    """
    predicate: Callable[[tuple[int, ...], tuple[int | float, ...], int | float], bool] | None

    if predicate_source:
        namespace: dict[str, object] = {}
        exec(predicate_source, namespace)
        predicate = namespace.get("predicate")

        if not callable(predicate):
            raise ValueError(
                "Custom predicate code must define: def predicate(indices, values, total): ..."
            )
    else:
        predicate = None

    def worker(start_mask: int, end_mask: int) -> list[SubsetResult]:
        matches: list[SubsetResult] = []
        n = len(values)

        for mask in range(start_mask, end_mask):
            indices = tuple(i for i in range(n) if mask & (1 << i))
            chosen = tuple(values[i] for i in indices)
            total = sum(chosen)

            if target is not None and total != target:
                continue

            if predicate is not None and not predicate(indices, chosen, total):
                continue

            matches.append(
                SubsetResult(
                    indices=indices,
                    values=chosen,
                    total=total,
                )
            )

        return matches

    return worker


def parallel_subset_search(
    values: Sequence[int | float],
    *,
    target: int | float | None = None,
    predicate_source: str | None = None,
    workers: int = os.cpu_count() or 4,
    chunk_size: int = 1_000_000,
    include_empty: bool = False,
) -> Iterator[SubsetResult]:
    """
    Search a subset space in parallel.

    This still examines up to 2^n masks, but distributes that work across CPUs.
    Results are yielded as soon as each worker chunk completes.
    """
    n = len(values)
    total_masks = 1 << n
    start = 0 if include_empty else 1

    if workers <= 1:
        worker = make_worker(
            tuple(values), target, predicate_source, include_empty
        )

        for result in worker(start, total_masks):
            yield result

        return

    ranges = [
        (begin, min(begin + chunk_size, total_masks))
        for begin in range(start, total_masks, chunk_size)
    ]

    with ProcessPoolExecutor(max_workers=workers) as pool:
        futures = [
            pool.submit(
                make_worker(
                    tuple(values), target, predicate_source, include_empty
                ),
                begin,
                end,
            )
            for begin, end in ranges
        ]

        for future in as_completed(futures):
            for result in future.result():
                yield result


def meet_in_the_middle(
    values: Sequence[int | float],
    target: int | float,
) -> Iterator[SubsetResult]:
    """
    Find subsets with an exact target sum much faster than brute force.

    Complexity:
      Time:  O(2^(n/2))
      Memory: O(2^(n/2))

    For 40 items, this examines about one million partial subsets per half,
    rather than about 1.1 trillion full subsets.
    """
    n = len(values)
    half = n // 2
    left = values[:half]
    right = values[half:]

    left_options: dict[int | float, list[tuple[int, ...]]] = {}

    for mask in range(1 << len(left)):
        indices = tuple(i for i in range(len(left)) if mask & (1 << i))
        chosen = tuple(left[i] for i in indices)
        total = sum(chosen)
        left_options.setdefault(total, []).append(indices)

    for mask in range(1 << len(right)):
        right_indices = tuple(
            half + i for i in range(len(right)) if mask & (1 << i)
        )
        right_values = tuple(right[i] for i in range(len(right)) if mask & (1 << i))
        right_total = sum(right_values)
        needed = target - right_total

        for left_indices in left_options.get(needed, []):
            indices = tuple(sorted(left_indices + right_indices))
            chosen = tuple(values[i] for i in indices)
            yield SubsetResult(
                indices=indices,
                values=chosen,
                total=target,
            )


def format_result(result: SubsetResult, *, show_indices: bool) -> str:
    if show_indices:
        return (
            f"indices={list(result.indices)} "
            f"values={list(result.values)} total={result.total}"
        )

    return f"values={list(result.values)} total={result.total}"


def write_results(
    results: Iterable[SubsetResult],
    output: Path | None,
    *,
    show_indices: bool,
    limit: int | None,
) -> int:
    count = 0

    handle = output.open("w", encoding="utf-8") if output else sys.stdout

    try:
        for result in results:
            handle.write(format_result(result, show_indices=show_indices) + "\n")
            count += 1

            if limit is not None and count >= limit:
                break
    finally:
        if output:
            handle.close()

    return count


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Solve extremely large subset-enumeration problems."
    )

    parser.add_argument(
        "--items",
        help="Comma-separated input values, e.g. 1,2,3,4",
    )

    parser.add_argument(
        "--items-file",
        help="Text file containing numbers separated by commas, spaces, or newlines",
    )

    parser.add_argument(
        "--mode",
        choices=["stream", "sum", "custom", "meet"],
        default="stream",
        help=(
            "stream: enumerate every subset; "
            "sum: exact subset-sum search; "
            "custom: user predicate; "
            "meet: fast exact-sum meet-in-the-middle"
        ),
    )

    parser.add_argument(
        "--target",
        type=float,
        help="Target sum for --mode sum or --mode meet",
    )

    parser.add_argument(
        "--predicate-file",
        help="Python file defining predicate(indices, values, total)",
    )

    parser.add_argument(
        "--workers",
        type=int,
        default=os.cpu_count() or 4,
        help="Number of CPU workers for stream, sum, or custom modes",
    )

    parser.add_argument(
        "--chunk-size",
        type=int,
        default=1_000_000,
        help="Number of subset masks sent to each worker per batch",
    )

    parser.add_argument(
        "--include-empty",
        action="store_true",
        help="Include the empty subset",
    )

    parser.add_argument(
        "--output",
        type=Path,
        help="Write results to this file instead of stdout",
    )

    parser.add_argument(
        "--limit",
        type=int,
        help="Stop after this many matching subsets",
    )

    parser.add_argument(
        "--show-indices",
        action="store_true",
        help="Include original item indices in output",
    )

    parser.add_argument(
        "--stats",
        action="store_true",
        help="Print timing and search-space statistics",
    )

    return parser


def main() -> int:
    parser = build_parser()
    args = parser.parse_args()

    values = load_items(args)
    n = len(values)
    total_subsets = 1 << n

    if args.mode in {"sum", "meet"} and args.target is None:
        parser.error("--target is required for --mode sum or --mode meet")

    if args.mode == "custom" and not args.predicate_file:
        parser.error("--predicate-file is required for --mode custom")

    predicate_source = None

    if args.predicate_file:
        path = Path(args.predicate_file)

        if not path.exists():
            raise FileNotFoundError(f"Predicate file not found: {path}")

        predicate_source = path.read_text(encoding="utf-8")

    started = time.perf_counter()

    if args.mode == "stream":
        results = stream_subsets(
            values,
            include_empty=args.include_empty,
        )

    elif args.mode == "sum":
        results = parallel_subset_search(
            values,
            target=args.target,
            workers=args.workers,
            chunk_size=args.chunk_size,
            include_empty=args.include_empty,
        )

    elif args.mode == "custom":
        results = parallel_subset_search(
            values,
            target=None,
            predicate_source=predicate_source,
            workers=args.workers,
            chunk_size=args.chunk_size,
            include_empty=args.include_empty,
        )

    else:
        results = meet_in_the_middle(values, args.target)

    count = write_results(
        results,
        args.output,
        show_indices=args.show_indices,
        limit=args.limit,
    )

    elapsed = time.perf_counter() - started

    if args.stats:
        stats = {
            "items": n,
            "possible_subsets": total_subsets,
            "reported_results": count,
            "elapsed_seconds": round(elapsed, 6),
            "mode": args.mode,
            "workers": args.workers if args.mode != "meet" else 1,
        }

        print(json.dumps(stats, indent=2), file=sys.stderr)

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
