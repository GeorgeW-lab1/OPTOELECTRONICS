#!/usr/bin/env python3
"""RP-SCIENCE v2 + Proof-of-Work — Tkinter-free scientific PoW demonstration.

This integrates proof-of-work into the RP-SCIENCE v2 technology:
- The same preregistration, nonce-commitment, synthetic/camera frame pipeline.
- Each mining round derives its SHA-256 challenge from a frame.
- It mines for a nonce whose digest has at least `difficulty` leading zero bits.
- Every accepted solution is independently verified.
- Results are analysed with Wilson/Clopper-Pearson intervals, exact binomial
  tests, Benjamini-Hochberg FDR control, effect sizes, and lag diagnostics.
- Outputs CSV and JSON; no Tkinter.

Examples:
  python rp_science_v2_pow.py --synthetic --frames 20 --difficulty 16
  python rp_science_v2_pow.py --device 0 --frames 10 --difficulty 18
  python rp_science_v2_pow.py --synthetic --frames 30 --difficulty 20 --out science_pow
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import secrets
import statistics
import sys
import time
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Iterable

import numpy as np

try:
    import cv2
except ImportError:
    cv2 = None

W, H = 128, 96
PROTOCOL = "RP-SCIENCE-V2-POW"


# ---------------------------------------------------------------------------
# Statistics
# ---------------------------------------------------------------------------

def wilson_interval(successes: int, n: int, alpha: float = 0.05) -> tuple[float, float]:
    if n <= 0:
        return (0.0, 1.0)
    z = _z_from_alpha(alpha)
    p = successes / n
    denom = 1 + z * z / n
    centre = (p + z * z / (2 * n)) / denom
    half = z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / denom
    return max(0.0, centre - half), min(1.0, centre + half)


def clopper_pearson_interval(successes: int, n: int, alpha: float = 0.05) -> tuple[float, float]:
    if n == 0:
        return (0.0, 1.0)
    lower = 0.0 if successes == 0 else _beta_quantile(alpha / 2, successes, n - successes + 1)
    upper = 1.0 if successes == n else _beta_quantile(1 - alpha / 2, successes + 1, n - successes)
    return lower, upper


def _z_from_alpha(alpha: float) -> float:
    if not 0 < alpha < 1:
        raise ValueError("alpha must lie between 0 and 1")
    p = 1 - alpha / 2
    a = [-3.969683028665376e+01, 2.209460984245205e+02, -2.759285104469687e+02,
         1.383577518672690e+02, -3.066479806614716e+01, 2.506628277459239e+00]
    b = [-5.447609879822406e+01, 1.615858368580409e+02, -1.556989798598866e+02,
         6.680131188771972e+01, -1.328068155288572e+01]
    c = [-7.784894002430293e-03, -3.223964580411365e-01, -2.400758277161838e+00,
         -2.549732539343734e+00, 4.374664141464968e+00, 2.938163982698783e+00]
    d = [7.784695709041462e-03, 3.224671290700398e-01, 2.445134137142996e+00,
         3.754408661907416e+00]
    plow, phigh = 0.02425, 1 - 0.02425
    if p < plow:
        q = math.sqrt(-2 * math.log(p))
        z = (((((c[0] * q + c[1]) * q + c[2]) * q + c[3]) * q + c[4]) * q + c[5]) / \
            ((((d[0] * q + d[1]) * q + d[2]) * q + d[3]) * q + 1)
    elif p <= phigh:
        q = p - 0.5
        r = q * q
        z = (((((a[0] * r + a[1]) * r + a[2]) * r + a[3]) * r + a[4]) * r + a[5]) * q / \
            (((((b[0] * r + b[1]) * r + b[2]) * r + b[3]) * r + b[4]) * r + 1)
    else:
        q = math.sqrt(-2 * math.log(1 - p))
        z = -(((((c[0] * q + c[1]) * q + c[2]) * q + c[3]) * q + c[4]) * q + c[5]) / \
             ((((d[0] * q + d[1]) * q + d[2]) * q + d[3]) * q + 1)
    for _ in range(2):
        e = 0.5 * math.erfc(-z / math.sqrt(2)) - p
        u = e * math.sqrt(2 * math.pi) * math.exp(z * z / 2)
        z -= u / (1 + z * u / 2)
    return z


def _beta_quantile(p: float, a: float, b: float) -> float:
    if p <= 0:
        return 0.0
    if p >= 1:
        return 1.0
    lo, hi = 0.0, 1.0
    for _ in range(200):
        mid = (lo + hi) / 2
        if _beta_cdf(mid, a, b) < p:
            lo = mid
        else:
            hi = mid
    return (lo + hi) / 2


def _beta_cdf(x: float, a: float, b: float) -> float:
    if x <= 0:
        return 0.0
    if x >= 1:
        return 1.0
    return _regularized_beta(x, a, b)


def _regularized_beta(x: float, a: float, b: float) -> float:
    lbeta = math.lgamma(a) + math.lgamma(b) - math.lgamma(a + b)
    if x < (a + 1) / (a + b + 2):
        front = math.exp(-lbeta + a * math.log(x) + b * math.log1p(-x))
        return front * _betacf(x, a, b) / a
    front = math.exp(-lbeta + (a + 1) * math.log(x) + (b - 1) * math.log1p(-x))
    return 1 - front * _betacf(1 - x, b, a) / b


def _betacf(x: float, a: float, b: float, max_iter: int = 300, eps: float = 3e-12) -> float:
    qab, qap, qam = a + b, a + 1, a - 1
    c, d = 1.0, 1 - qab * x / qap
    if abs(d) < 1e-300:
        d = 1e-300
    d = 1 / d
    h = d
    for m in range(1, max_iter + 1):
        m2 = 2 * m
        aa = m * (b - m) * x / ((qam + m2) * (a + m2))
        d = 1 + aa * d
        if abs(d) < 1e-300:
            d = 1e-300
        c = 1 + aa / c
        if abs(c) < 1e-300:
            c = 1e-300
        d = 1 / d
        h *= d * c
        aa = -(a + m) * (qab + m) * x / ((a + m2) * (qap + m2))
        d = 1 + aa * d
        if abs(d) < 1e-300:
            d = 1e-300
        c = 1 + aa / c
        if abs(c) < 1e-300:
            c = 1e-300
        d = 1 / d
        delta = d * c
        h *= delta
        if abs(delta - 1) < eps:
            break
    return h


def exact_binomial_p_two_sided(successes: int, n: int, p0: float) -> float:
    if n <= 0:
        return 1.0
    if not 0 <= p0 <= 1:
        raise ValueError("p0 must be in [0, 1]")
    def pmf(k):
        return math.comb(n, k) * (p0 ** k) * ((1 - p0) ** (n - k))
    target = pmf(successes) * (1 + 1e-12)
    return min(1.0, sum(pmf(k) for k in range(n + 1) if pmf(k) <= target))


def benjamini_hochberg(pvals: Iterable[float], alpha: float = 0.05) -> tuple[list[bool], float]:
    p = sorted((float(v), i) for i, v in enumerate(pvals))
    m = len(p)
    if m == 0:
        return [], alpha
    reject = [False] * m
    threshold = alpha
    for rank in range(m, 0, -1):
        value, original_index = p[rank - 1]
        cutoff = alpha * rank / m
        if value <= cutoff:
            threshold = cutoff
            break
    for value, original_index in p:
        reject[original_index] = value <= threshold
    return reject, threshold


def lag_autocorrelation(values: list[float], lag: int = 1) -> float:
    if len(values) <= lag:
        return 0.0
    a = np.asarray(values[:-lag], dtype=float)
    b = np.asarray(values[lag:], dtype=float)
    if np.std(a) == 0 or np.std(b) == 0:
        return 0.0
    return float(np.corrcoef(a, b)[0, 1])


# ---------------------------------------------------------------------------
# RP-SCIENCE v2 frame pipeline
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class Preregistration:
    frames: int
    difficulty: int
    max_hashes: int
    alpha: float
    source: str
    created_utc: str

    @property
    def digest(self) -> str:
        payload = json.dumps(asdict(self) | {"protocol": PROTOCOL}, sort_keys=True).encode()
        return hashlib.sha256(payload).hexdigest()


class NonceSource:
    """Pre-committed cryptographically random nonces for reproducible auditability."""

    def __init__(self, count: int):
        self.nonces = [secrets.token_hex(16) for _ in range(count)]
        self.commitment = hashlib.sha256("".join(self.nonces).encode()).hexdigest()

    def get(self, index: int) -> str:
        return self.nonces[index % len(self.nonces)]


class FrameSource:
    def __init__(self, seed: int = 20261110, level: float = 120.0):
        self.rng = np.random.default_rng(seed)
        self.level = level
        self.index = 0

    def next_frame(self) -> bytes:
        gray = np.clip(self.rng.poisson(self.level, size=(H, W)), 0, 255).astype(np.uint8)
        payload = gray.tobytes() + self.index.to_bytes(8, "big")
        self.index += 1
        return payload

    def close(self) -> None:
        pass


class CameraFrameSource(FrameSource):
    def __init__(self, device: int, warmup: int = 8):
        super().__init__()
        if cv2 is None:
            raise RuntimeError("Install OpenCV for camera capture: pip install opencv-python")
        backend = cv2.CAP_DSHOW if sys.platform == "win32" else cv2.CAP_ANY
        self.cap = cv2.VideoCapture(device, backend)
        if not self.cap.isOpened():
            raise RuntimeError(f"Cannot open camera device {device}")
        for _ in range(warmup):
            self.cap.read()
        self.device = device

    def next_frame(self) -> bytes:
        ok, frame = self.cap.read()
        if not ok or frame is None:
            raise RuntimeError("Camera stopped delivering frames")
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        gray = cv2.resize(gray, (W, H), interpolation=cv2.INTER_AREA)
        payload = gray.tobytes() + self.index.to_bytes(8, "big")
        self.index += 1
        return payload

    def close(self) -> None:
        if self.cap is not None and self.cap.isOpened():
            self.cap.release()


# ---------------------------------------------------------------------------
# Proof of work
# ---------------------------------------------------------------------------

@dataclass
class PowRecord:
    frame: int
    nonce: str
    entropy_sha256: str
    challenge: str
    difficulty_bits: int
    solution_nonce: int | None
    solution_digest: str | None
    hashes_tried: int
    elapsed_seconds: float
    hashes_per_second: float
    expected_hashes: float
    luck_ratio: float | None
    verified: bool
    solved: bool


class SciencePow:
    def __init__(self, source: FrameSource, difficulty: int, max_hashes: int):
        if not 1 <= difficulty <= 32:
            raise ValueError("difficulty must be between 1 and 32 leading zero bits")
        if max_hashes < 1:
            raise ValueError("max-hashes must be positive")
        self.source = source
        self.difficulty = difficulty
        self.max_hashes = max_hashes

    @staticmethod
    def meets_target(digest: bytes, difficulty: int) -> bool:
        full, remainder = divmod(difficulty, 8)
        if any(digest[:full]):
            return False
        if remainder:
            return digest[full] >> (8 - remainder) == 0
        return True

    def mine(self, index: int, nonce: str) -> PowRecord:
        entropy = self.source.next_frame()
        entropy_digest = hashlib.sha256(entropy).digest()
        challenge = hashlib.sha256(
            b"RP-SCIENCE-V2-POW|" + entropy_digest + nonce.encode()
        ).digest()

        started = time.perf_counter()
        solution_nonce = None
        solution_digest = None
        hashes = 0

        for candidate in range(self.max_hashes):
            digest = hashlib.sha256(challenge + candidate.to_bytes(8, "big")).digest()
            hashes += 1
            if self.meets_target(digest, self.difficulty):
                solution_nonce = candidate
                solution_digest = digest
                break

        elapsed = time.perf_counter() - started
        verified = False
        if solution_nonce is not None:
            check = hashlib.sha256(
                challenge + solution_nonce.to_bytes(8, "big")
            ).digest()
            verified = check == solution_digest and self.meets_target(check, self.difficulty)

        expected = float(2 ** self.difficulty)
        return PowRecord(
            frame=index,
            nonce=nonce,
            entropy_sha256=entropy_digest.hex(),
            challenge=challenge.hex(),
            difficulty_bits=self.difficulty,
            solution_nonce=solution_nonce,
            solution_digest=solution_digest.hex() if solution_digest else None,
            hashes_tried=hashes,
            elapsed_seconds=elapsed,
            hashes_per_second=hashes / elapsed if elapsed > 0 else 0.0,
            expected_hashes=expected,
            luck_ratio=expected / hashes if hashes else None,
            verified=verified,
            solved=solution_nonce is not None,
        )


# ---------------------------------------------------------------------------
# Analysis
# ---------------------------------------------------------------------------

def analyse(records: list[PowRecord], prereg: Preregistration) -> dict:
    n = len(records)
    if n == 0:
        raise ValueError("No PoW records to analyse")

    solved = [r for r in records if r.solved]
    verified = [r for r in solved if r.verified]
    hashes = [float(r.hashes_tried) for r in records]
    times = [r.elapsed_seconds for r in records]
    rates = [r.hashes_per_second for r in records]
    difficulty = prereg.difficulty
    expected = float(2 ** difficulty)

    solve_hits = len(solved)
    verify_hits = len(verified)
    solve_rate = solve_hits / n
    verify_rate = verify_hits / n if solved else 0.0

    geometric_mean = math.exp(sum(math.log(r.hashes_tried) for r in solved) / len(solved)) \
        if solved else None

    p_solve = exact_binomial_p_two_sided(solve_hits, n, 0.5)  # illustrative null: 50% solve rate
    p_verify = exact_binomial_p_two_sided(verify_hits, len(solved), 1.0) if solved else 1.0

    pvals = [
        p_solve,
        p_verify,
        1.0,  # H3: no negative-luck bias; retained unless future test specifies an alternative
        1.0,  # H4: no serial dependence; assessed descriptively below
    ]
    decisions, fdr_threshold = benjamini_hochberg(pvals, prereg.alpha)

    return {
        "protocol": PROTOCOL,
        "preregistration_digest": prereg.digest,
        "n_rounds": n,
        "alpha": prereg.alpha,
        "fdr_threshold": fdr_threshold,
        "difficulty_bits": difficulty,
        "theoretical_expected_hashes": expected,
        "counts": {
            "solved": solve_hits,
            "unsolved": n - solve_hits,
            "verified": verify_hits,
            "verification_failures": len(solved) - verify_hits,
        },
        "H1_solve_rate": {
            "observed": solve_rate,
            "wilson_ci": wilson_interval(solve_hits, n, prereg.alpha),
            "clopper_pearson_ci": clopper_pearson_interval(solve_hits, n, prereg.alpha),
            "exact_p": p_solve,
            "rejected": decisions[0],
        },
        "H2_verification_rate": {
            "observed": verify_rate,
            "wilson_ci": wilson_interval(verify_hits, len(solved), prereg.alpha) if solved else (0.0, 1.0),
            "clopper_pearson_ci": clopper_pearson_interval(verify_hits, len(solved), prereg.alpha) if solved else (0.0, 1.0),
            "exact_p": p_verify,
            "rejected": decisions[1],
        },
        "H3_no_negative_luck_bias": {
            "mean_luck_ratio": statistics.mean(r.luck_ratio for r in solved) if solved else None,
            "median_luck_ratio": statistics.median(r.luck_ratio for r in solved) if solved else None,
            "rejected": decisions[2],
        },
        "H4_no_serial_dependence": {
            "lag1_hashes": lag_autocorrelation(hashes, 1),
            "lag1_time": lag_autocorrelation(times, 1),
            "lag1_hashrate": lag_autocorrelation(rates, 1),
            "rejected": decisions[3],
        },
        "work_statistics": {
            "total_hashes": int(sum(hashes)),
            "total_time_seconds": sum(times),
            "mean_hashes": statistics.mean(hashes),
            "median_hashes": statistics.median(hashes),
            "geometric_mean_hashes_solved": geometric_mean,
            "mean_hashrate": statistics.mean(rates),
            "median_hashrate": statistics.median(rates),
        },
    }


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="RP-SCIENCE v2 proof-of-work demonstration")
    source = parser.add_mutually_exclusive_group(required=True)
    source.add_argument("--synthetic", action="store_true", help="reproducible synthetic frames")
    source.add_argument("--device", type=int, help="OpenCV camera index")
    parser.add_argument("--frames", type=int, default=10, help="number of PoW rounds")
    parser.add_argument("--difficulty", type=int, default=16, help="leading zero bits required")
    parser.add_argument("--max-hashes", type=int, default=2_000_000, help="per-round nonce limit")
    parser.add_argument("--seed", type=int, default=20261110, help="synthetic entropy seed")
    parser.add_argument("--alpha", type=float, default=0.05, help="significance level")
    parser.add_argument("--out", default="rp_science_v2_pow", help="output basename")
    return parser


def main() -> int:
    args = build_parser().parse_args()
    if args.frames < 1:
        raise SystemExit("--frames must be positive")
    if not 0 < args.alpha < 1:
        raise SystemExit("--alpha must be between 0 and 1")

    prereg = Preregistration(
        frames=args.frames,
        difficulty=args.difficulty,
        max_hashes=args.max_hashes,
        alpha=args.alpha,
        source="synthetic" if args.synthetic else f"device:{args.device}",
        created_utc=time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
    )
    nonce_source = NonceSource(args.frames)
    source = SyntheticEntropy = FrameSource(seed=args.seed) if args.synthetic else CameraFrameSource(args.device)
    miner = SciencePow(source, args.difficulty, args.max_hashes)

    print(f"{PROTOCOL}")
    print(f"Preregistration SHA-256: {prereg.digest}")
    print(f"Nonce commitment SHA-256: {nonce_source.commitment}")
    print(f"Difficulty: {args.difficulty} leading zero bits")
    print(f"Expected hashes per solve: {2 ** args.difficulty:,}")

    records: list[PowRecord] = []
    started = time.perf_counter()
    try:
        for index in range(args.frames):
            record = miner.mine(index, nonce_source.get(index))
            records.append(record)
            state = "SOLVED" if record.solved else "LIMIT REACHED"
            print(
                f"round {index + 1}/{args.frames}: {state} | "
                f"{record.hashes_tried:,} hashes | {record.elapsed_seconds:.3f} s | "
                f"{record.hashes_per_second:,.0f} H/s | verified={record.verified}"
            )
    except KeyboardInterrupt:
        print("\nStopped by user.")
    finally:
        source.close()
    elapsed = time.perf_counter() - started

    if not records:
        return 1

    out_base = Path(args.out)
    out_base.parent.mkdir(parents=True, exist_ok=True)
    csv_path = out_base.with_suffix(".csv")
    json_path = out_base.with_suffix(".json")

    fields = list(asdict(records[0]).keys())
    with csv_path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(asdict(record) for record in records)

    result = analyse(records, prereg)
    result["wall_clock_seconds"] = elapsed
    result["nonce_commitment"] = nonce_source.commitment
    result["output_csv"] = str(csv_path)

    with json_path.open("w", encoding="utf-8") as handle:
        json.dump(result, handle, indent=2, sort_keys=True)

    print("\nScientific analysis")
    for key, value in result.items():
        if key in {"protocol", "preregistration_digest", "output_csv"}:
            continue
        if isinstance(value, dict):
            print(f"{key}:")
            for subkey, subvalue in value.items():
                print(f"  {subkey}: {subvalue}")
        else:
            print(f"{key}: {value}")
    print(f"Saved CSV: {csv_path}")
    print(f"Saved JSON: {json_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
