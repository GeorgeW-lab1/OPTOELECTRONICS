#!/usr/bin/env python3
"""Hotfix: validate mining.notify and keep the pool thread alive on bad messages.
    python fix_notify.py rp_circuit_camera_cli_pool.py        (edits the file in place, keeps a .bak)
"""
import shutil, sys

EDITS = [
 ('            p = m["params"]\n            self.job = dict(',
  '            p = m.get("params") or []\n'
  '            if (len(p) < 9 or not all(isinstance(p[i], str) for i in (0, 1, 2, 3, 5, 6, 7))\n'
  '                    or not isinstance(p[4], list)):\n'
  '                self.log("# pool: unrecognised mining.notify layout, ignored: " + json.dumps(m)[:400])\n'
  '                return\n'
  '            self.job = dict('),
 ('                    if line:\n                        self._handle(json.loads(line))\n',
  '                    if line:\n'
  '                        try:\n'
  '                            self._handle(json.loads(line))\n'
  '                        except OSError:\n'
  '                            raise\n'
  '                        except Exception as e:      # a bad message must not kill the pool thread\n'
  '                            self.log(f"# pool: could not handle message ({type(e).__name__}: {e}): {line[:300]}")\n'),
]

if len(sys.argv) != 2:
    sys.exit(__doc__)
t = open(sys.argv[1], encoding="utf-8").read()
for i, (a, b) in enumerate(EDITS, 1):
    if t.count(a) != 1:
        sys.exit(f"edit {i}: anchor found {t.count(a)} times (need 1)")
    t = t.replace(a, b, 1)
shutil.copy(sys.argv[1], sys.argv[1] + ".bak")
open(sys.argv[1], "w", encoding="utf-8").write(t)
print("fixed; backup at", sys.argv[1] + ".bak")
