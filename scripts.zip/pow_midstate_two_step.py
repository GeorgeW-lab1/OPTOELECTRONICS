"""
Simulation: recover the SHA-256 midstate of a PoW header from NOISY SIMULATED LEAKAGE.
Real PoW midstates are public; here the leak channel is synthetic, as in
midstate_leak_decoder.py. Verification = finish the double-SHA256 from the candidate
midstate and compare with the known block hash.
"""
import struct, itertools, time, string, hashlib
import numpy as np
from midstate_leak_decoder import compress, IV, state_to_bits, bits_to_state

def pad80():
    return b"\x80" + b"\x00" * 39 + struct.pack(">Q", 640)

def pow_hash_from_midstate(midstate, tail12, nonce):
    st = compress(midstate, tail12 + struct.pack("<I", nonce) + pad80())
    inner = struct.pack(">8I", *st)
    return compress(IV, inner + b"\x80" + b"\x00" * 23 + struct.pack(">Q", 256))

def run(difficulty_bits=12):
    seed = 42
    rng = np.random.default_rng(seed)
    m = 256

    # --- Build a solved toy block: header prefix + nonce meeting low difficulty
    version = struct.pack("<I", 0x20000000)
    prev_hash = rng.bytes(32)                       # known/public
    hidden = "".join(rng.choice(list(string.ascii_lowercase), 3))   # unknown to attacker
    merkle = hashlib.sha256(hashlib.sha256(b"tx-" + hidden.encode()).digest()).digest()
    prefix76 = version + prev_hash + merkle + struct.pack("<II", 1700000000, 0x1d00ffff)
    secret_state = compress(IV, prefix76[:64])      # the midstate to "recover"
    secret_bits = state_to_bits(secret_state)
    tail12 = prefix76[64:76]
    target = 1 << (256 - difficulty_bits)
    nonce = 0
    while True:
        d = pow_hash_from_midstate(secret_state, tail12, nonce)
        if int.from_bytes(struct.pack(">8I", *d)[::-1], "big") < target:
            break
        nonce += 1
    block_hash = d

    def verify(bits):
        return pow_hash_from_midstate(bits_to_state(bits), tail12, nonce) == block_hash

    print("=" * 78)
    print(" PoW MIDSTATE RECOVERY FROM NOISY SIMULATED LEAKAGE")
    print("=" * 78)
    print(f"  Block hash : {struct.pack('>8I', *block_hash)[::-1].hex()}")
    print(f"  Nonce      : {nonce}   Midstate bits: {m}\n")
    print(f"{'Cycle':<6} | {'Seen':<6} | {'Unseen':<7} | Status")
    print("-" * 78)

    ch = np.random.default_rng(seed + 1)
    tau, c0, pooled_std = 127.0, 25.0, 40.0 / 16
    flip_eps, reveal_rate = 0.02, 0.45
    ones = np.zeros(m, np.int32); zeros = np.zeros(m, np.int32)
    seen = np.zeros(m, bool)
    checks, found = 0, None
    t0 = time.perf_counter()

    for cycle in range(1, 60):
        pooled = secret_bits * 255.0 + ch.normal(0, pooled_std, m)
        dec = np.full(m, -1, np.int8)
        dec[pooled > tau + c0] = 1
        dec[pooled < tau - c0] = 0
        valid = dec != -1
        dec[valid & (ch.random(m) < flip_eps)] ^= 1
        obs = np.where(valid & (ch.random(m) < reveal_rate), dec, -1)
        ones += (obs == 1); zeros += (obs == 0)
        seen |= (obs != -1)
        n_seen = int(seen.sum())
        if n_seen < m:
            print(f"{cycle:<6} | {n_seen:<6} | {m-n_seen:<7} | collecting frames...")
            continue

        guess = (ones > zeros).astype(np.uint8)
        checks += 1
        if verify(guess):
            found = guess
            print(f"{cycle:<6} | {n_seen:<6} | 0       | SUCCESS: 0-flip majority guess verified")
            break
        uncertain = np.argsort(np.abs(ones - zeros))[:16]
        for k in range(1, 5):
            for subset in itertools.combinations(uncertain, k):
                checks += 1
                cand = guess.copy(); cand[list(subset)] ^= 1
                if verify(cand):
                    found = cand; break
            if found is not None:
                print(f"{cycle:<6} | {n_seen:<6} | 0       | SUCCESS: Chase decode, k={k} flips")
                break
        if found is not None:
            break
        print(f"{cycle:<6} | {n_seen:<6} | 0       | list decoding failed ({checks:,} checks)")

    ms = (time.perf_counter() - t0) * 1000
    print("\n" + "=" * 78)
    if found is not None:
        words = bits_to_state(found)
        print(f"  Recovered midstate : {''.join(f'{x:08x}' for x in words)}")
        print(f"  Matches secret     : {words == secret_state}")
        print(f"  Candidates checked : {checks:,}   Time: {ms:.1f} ms")

        # ---------- EXTRA STEP: recover the hidden data behind the midstate ----------
        print("\n[STEP 3] Recovering hidden input from recovered midstate (low-entropy search)")
        t1, tries, recovered = time.perf_counter(), 0, None
        for combo in itertools.product(string.ascii_lowercase, repeat=3):
            tries += 1
            m_c = hashlib.sha256(hashlib.sha256(b"tx-" + "".join(combo).encode()).digest()).digest()
            if compress(IV, version + prev_hash + m_c[:28]) == words:
                recovered = "".join(combo); break
        if recovered:
            print(f"  Recovered hidden tx string : tx-{recovered}  ({tries:,} tries, "
                  f"{(time.perf_counter()-t1)*1000:.0f} ms)")
            print(f"  Matches ground truth       : {recovered == hidden}")
        else:
            print("  Hidden input not found in the assumed keyspace.")
    else:
        print("  Failed to recover midstate within budget.")

if __name__ == "__main__":
    run()
