#!/usr/bin/env python3
"""
Commit-reveal and permutation validation test applied to the 
Tryptophan Photonic Device (Ensemble & Enantiomer Stages A & B).
"""

import argparse
import hashlib
import json
import math
import os
import numpy as np

# ============================================================================
# PREREGISTERED CONFIGURATION (Tryptophan Photonic Device)
# ============================================================================

SIGMA_THRESH = 5.0         # 5-sigma detection threshold
N_RUNS = 10000             # Number of measurement windows
N_PERMS = 200              # Permutations for empirical null distribution
EPS_POSITIVE = 0.03        # Positive-control chiral tilt in sigma units

def code_hash_of_this_file():
    with open(__file__, "rb") as f:
        return hashlib.sha256(f.read()).hexdigest()

def zscore(a):
    a = np.asarray(a, dtype=np.float64)
    s = a.std()
    return (a - a.mean()) / s if s > 0 else np.zeros_like(a)

# ============================================================================
# SIMULATED / EXPERIMENTAL DATA PIPELINE
# ============================================================================

def simulate_tryp_experiment(enantiomer_type, n_runs, eps, seed):
    """
    Simulates UV-induced photocurrent measurements under Left/Right 
    circular polarization switching for L-Trp, D-Trp, or Racemic Trp.
    """
    rng = np.random.default_rng(seed)
    
    # Polarization sequence: 0 = Left circular, 1 = Right circular
    polarization = rng.integers(0, 2, size=n_runs)
    pol_sign = np.where(polarization == 0, 1.0, -1.0)
    
    # Baseline detector noise (Gaussian shot noise + thermal/laser flicker)
    base_noise = rng.normal(0.0, 1.0, size=n_runs)
    
    signal = np.zeros(n_runs)
    if enantiomer_type == "L-Trp":
        # True chiral signal expected to correlate with polarization sign
        signal = base_noise + eps * pol_sign
    elif enantiomer_type == "D-Trp":
        # Enantiomer mirror image: signal flips sign
        signal = base_noise - eps * pol_sign
    elif enantiomer_type == "Racemic":
        # Racemic mixture: zero chiral asymmetry
        signal = base_noise
    elif enantiomer_type == "Control_Bare":
        # Bare electrodes: zero chiral signal, potential heating artifact if uncompensated
        signal = base_noise + 0.002 * pol_sign  # small instrumental asymmetry
        
    return polarization, signal

def permutation_null_test(polarization, signal, n_perms):
    """Shuffles polarization assignment across runs to compute observed vs null z-score."""
    obs_diff = float(np.mean(signal[polarization == 0]) - np.mean(signal[polarization == 1]))
    
    null_diffs = np.empty(n_perms)
    rng = np.random.default_rng(42)
    
    for p in range(n_perms):
        shuffled_pol = rng.permutation(polarization)
        null_diffs[p] = float(np.mean(signal[shuffled_pol == 0]) - np.mean(signal[shuffled_pol == 1]))
        
    mean0 = float(null_diffs.mean())
    sd0 = float(null_diffs.std(ddof=1))
    z_score = (obs_diff - mean0) / sd0 if sd0 > 0 else 0.0
    
    return {"obs": obs_diff, "mean_null": mean0, "sd_null": sd0, "z": z_score}

def evaluate_tryp_pipeline(args):
    seed = args.seed if args.seed is not None else int.from_bytes(os.urandom(8), "big")
    
    prereg = {
        "runs": args.runs,
        "permutations": args.perms,
        "threshold_sigma": SIGMA_THRESH,
        "code_sha256": code_hash_of_this_file()
    }
    print("=" * 78)
    print(f" TRYPTOPHAN PHOTONIC DEVICE: Validation Pipeline (Seed: {seed})")
    print("=" * 78)
    print(f"[PREREG HASH] {hashlib.sha256(json.dumps(prereg, sort_keys=True).encode()).hexdigest()}")
    
    # 1. Positive Control Test (L-Trp with known chiral expectation)
    pol_pc, sig_pc = simulate_tryp_experiment("L-Trp", args.runs, EPS_POSITIVE, seed)
    res_pc = permutation_null_test(pol_pc, sig_pc, args.perms)
    pc_ok = res_pc["z"] >= SIGMA_THRESH
    print(f"\n[POSITIVE CONTROL] L-Trp Z-score = {res_pc['z']:+.2f} -> {'RECOVERED' if pc_ok else 'MISSED'}")
    
    if not pc_ok:
        print("PIPELINE TOO WEAK: Positive control failed. Increase integration time or reduce noise.")
        return

    # 2. Enantiomer & Control Sweep (Stages A & B)
    test_cases = ["L-Trp", "D-Trp", "Racemic", "Control_Bare"]
    results = {}
    
    print("\n[STAGES A & B] Enantiomer and Control Results:")
    print("  Sample Type  |  Observed L-R Diff  |  Null SD  |  Z-Score  |  Status")
    print("-" * 65)
    
    for case in test_cases:
        pol, sig = simulate_tryp_experiment(case, args.runs, EPS_POSITIVE, seed + hash(case) % 1000)
        res = permutation_null_test(pol, sig, args.perms)
        results[case] = res
        
        status = "PASS (Chiral Signal)" if case == "L-Trp" and res["z"] >= SIGMA_THRESH else \
                 "PASS (Inverted Sign)" if case == "D-Trp" and res["z"] <= -SIGMA_THRESH else \
                 "PASS (Null Confirmed)" if abs(res["z"]) < SIGMA_THRESH and case in ["Racemic", "Control_Bare"] else \
                 "FLAGGED (Artifact / Anomaly)"
                 
        print(f"  {case:<12} | {res['obs']:+18.5f} | {res['sd_null']:9.5f} | {res['z']:+9.2f} | {status}")

    # 3. Decision Verdict
    print("\n" + "=" * 78)
    print(" EXPERIMENTAL DECISION VERDICT:")
    if results["L-Trp"]["z"] >= SIGMA_THRESH and results["D-Trp"]["z"] <= -SIGMA_THRESH and abs(results["Racemic"]["z"]) < SIGMA_THRESH:
        print(" -> SUCCESS: Chiral photoconductance confirmed. Enantiomeric sign flip verified. Proceed to Stage C (Single-Molecule Break Junction).")
    elif abs(results["Control_Bare"]["z"]) >= SIGMA_THRESH or abs(results["Racemic"]["z"]) >= SIGMA_THRESH:
        print(" -> ARTIFACT DETECTED: Non-chiral signal present in bare electrodes or racemic mix. Rule out heating, polarization-induced power fluctuations, or electrode asymmetry.")
    else:
        print(" -> NULL RESULT: No statistically significant polarization-dependent chiral conductance above threshold.")
    print("=" * 78)

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--runs", type=int, default=N_RUNS)
    ap.add_argument("--perms", type=int, default=N_PERMS)
    ap.add_argument("--seed", type=int, default=None)
    args = ap.parse_args()
    evaluate_tryp_pipeline(args)
