#!/usr/bin/env python3
"""
rp_hidden_number_commit_only.py

Software bench for: "Parallel Optical Bit Pooling with Commit-Only
Hidden-Number Recovery".

Roles
  Oracle     holds N, a random 128-bit salt and c = SHA-256(salt || N_bytes).
             Publishes only (salt, c). Releases N and its factors only after
             a candidate is verified against the commitment.
  Channel    renders the bits of N as a rows x cols black/white grid
             (16x16 px per cell) and produces frames (synthetic or camera).
  Recogniser pools each frame in ONE vectorised call, classifies with a
             confidence gate, accumulates votes, majority-decodes, then runs a
             Chase-type bounded bit-flip search verified by the hash.

NOT factoring: the recogniser never factors N. The 8-qubit GHZ circuit is a
classically simulated execution diagnostic whose result is discarded.

Usage
  python rp_hidden_number_commit_only.py run                  # synthetic run
  python rp_hidden_number_commit_only.py run --pixel-sigma 40 # Gaussian pixel noise
  python rp_hidden_number_commit_only.py run --camera 0       # real camera (needs opencv)
  python rp_hidden_number_commit_only.py theory               # paper's predictions
  python rp_hidden_number_commit_only.py mc --trials 200      # Monte-Carlo vs theory
Requires: numpy. Optional: sympy (factoring in oracle), opencv-python (camera).
"""
from __future__ import annotations

import argparse
import hashlib
import itertools
import math
import os
import time
from dataclasses import dataclass, field
from typing import List, Optional, Tuple

import numpy as np

CELL = 16  # pixels per cell edge
DEFAULT_N = 9_999_999_999_999_999  # 10**16 - 1


# --------------------------------------------------------------------------
# Helpers
# --------------------------------------------------------------------------
def grid_shape(m: int) -> Tuple[int, int]:
    """Near-square rows x cols with rows*cols == m (56 -> 8 x 7)."""
    best = (m, 1)
    for c in range(1, int(math.isqrt(m)) + 1):
        if m % c == 0:
            best = (m // c, c)  # rows >= cols
    return best


def bits_of(n: int, m: int) -> np.ndarray:
    """b_i = floor(n / 2^i) mod 2, i = 0..m-1 (LSB first)."""
    return np.array([(n >> i) & 1 for i in range(m)], dtype=np.uint8)


def int_of(bits: np.ndarray) -> int:
    return sum(int(b) << i for i, b in enumerate(bits))


def trial_factor(n: int) -> List[int]:
    f, d = [], 2
    while d * d <= n and d < 10_000_000:
        while n % d == 0:
            f.append(d)
            n //= d
        d += 1 if d == 2 else 2
    if n > 1:
        f.append(n)
    return f


def factorise(n: int) -> List[int]:
    try:
        import sympy
        out: List[int] = []
        for p, e in sympy.factorint(n).items():
            out += [int(p)] * e
        return sorted(out)
    except Exception:
        return trial_factor(n)


def H2(x: float) -> float:
    if x <= 0 or x >= 1:
        return 0.0
    return -x * math.log2(x) - (1 - x) * math.log2(1 - x)


def Qfun(x: float) -> float:
    return 0.5 * math.erfc(x / math.sqrt(2))


# --------------------------------------------------------------------------
# Oracle
# --------------------------------------------------------------------------
class Oracle:
    def __init__(self, n: int = DEFAULT_N, seed: Optional[int] = None):
        self.n = n
        self.nbytes = (n.bit_length() + 7) // 8
        self.m = 8 * self.nbytes  # byte-aligned bit count
        self.rows, self.cols = grid_shape(self.m)
        self._salt = (np.random.default_rng(seed).bytes(16)
                      if seed is not None else os.urandom(16))
        self.commitment = self._hash(n)
        self._factors = factorise(n)  # held privately

    def _hash(self, x: int) -> bytes:
        return hashlib.sha256(self._salt + x.to_bytes(self.nbytes, "big")).digest()

    # published values
    @property
    def public(self) -> Tuple[bytes, bytes]:
        return self._salt, self.commitment

    def verify(self, x: int) -> bool:
        if x < 0 or x.bit_length() > self.m:
            return False
        try:
            return self._hash(x) == self.commitment
        except OverflowError:
            return False

    def reveal_if_proven(self, x: int):
        if self.verify(x):
            return self.n, list(self._factors)
        return None

    # the "display"
    def true_bits(self) -> np.ndarray:
        return bits_of(self.n, self.m)

    def render(self) -> np.ndarray:
        """Grayscale frame (16R x 16C): bit 1 -> white (255), 0 -> black (0)."""
        cells = (self.true_bits().reshape(self.rows, self.cols) * 255).astype(np.float64)
        return np.kron(cells, np.ones((CELL, CELL)))


# --------------------------------------------------------------------------
# Optical front end
# --------------------------------------------------------------------------
def pool(frame: np.ndarray, rows: int, cols: int) -> np.ndarray:
    """Parallel spatial pooling = (A_R (x) A_C) vec(G): one tensor mean."""
    return frame.reshape(rows, CELL, cols, CELL).mean(axis=(1, 3))


def classify(pooled: np.ndarray, tau: float = 127, c0: float = 25):
    """Return (bit, valid). |p - tau| < c0 -> erased (invalid)."""
    valid = np.abs(pooled - tau) >= c0
    bit = (pooled > tau).astype(np.uint8)
    return bit.ravel(), valid.ravel()


class SyntheticSource:
    """Frames from the oracle display, optional Gaussian pixel noise."""

    def __init__(self, oracle: Oracle, pixel_sigma: float = 0.0, rng=None):
        self.o, self.sigma = oracle, pixel_sigma
        self.rng = rng or np.random.default_rng()
        self.base = oracle.render()

    def frame(self) -> np.ndarray:
        if self.sigma > 0:
            return np.clip(self.base + self.rng.normal(0, self.sigma, self.base.shape), 0, 255)
        return self.base


class CameraSource:
    def __init__(self, index: int, rows: int, cols: int):
        import cv2  # optional dependency
        self.cv2, self.rows, self.cols = cv2, rows, cols
        self.cap = cv2.VideoCapture(index)
        if not self.cap.isOpened():
            raise RuntimeError(f"cannot open camera {index}")

    def frame(self) -> np.ndarray:
        ok, img = self.cap.read()
        if not ok:
            raise RuntimeError("camera read failed")
        g = self.cv2.cvtColor(img, self.cv2.COLOR_BGR2GRAY)
        g = self.cv2.resize(g, (CELL * self.cols, CELL * self.rows),
                            interpolation=self.cv2.INTER_AREA)
        return g.astype(np.float64)


# --------------------------------------------------------------------------
# Recogniser
# --------------------------------------------------------------------------
@dataclass
class DecodeStats:
    cycles: int = 0
    cover_cycle: Optional[int] = None
    candidates: int = 0
    success: bool = False
    result: Optional[int] = None
    factors: List[int] = field(default_factory=list)


class Recogniser:
    def __init__(self, oracle: Oracle, L: int = 16, t: int = 4,
                 q_max: int = 200_000, rng=None):
        self.o = oracle
        self.m = oracle.m
        self.L, self.t = min(L, self.m), min(t, min(L, self.m))
        self.q_max = q_max
        self.rng = rng or np.random.default_rng()
        self.ones = np.zeros(self.m, dtype=np.int64)
        self.zeros = np.zeros(self.m, dtype=np.int64)
        self.tested = 0

    def accumulate(self, bit: np.ndarray, valid: np.ndarray):
        self.ones += (bit == 1) & valid
        self.zeros += (bit == 0) & valid

    def covered(self) -> bool:
        return bool(np.all(self.ones + self.zeros > 0))

    def _check(self, bits: np.ndarray) -> bool:
        self.tested += 1
        return self.o.verify(int_of(bits))

    def decode(self) -> Optional[int]:
        """Majority vote (ties -> 0) then Chase-type search; None on failure."""
        if not self.covered():
            return None
        bhat = (self.ones > self.zeros).astype(np.uint8)
        if self._check(bhat):  # zero-flip test is always performed
            return int_of(bhat)
        D = np.abs(self.ones - self.zeros)
        # least-reliable first; random tie-break (removes low-index bias)
        order = np.lexsort((self.rng.random(self.m), D))
        U = order[: self.L]
        for k in range(1, self.t + 1):
            for S in itertools.combinations(U, k):
                if self.tested >= self.q_max:
                    return None
                cand = bhat.copy()
                cand[list(S)] ^= 1
                if self._check(cand):
                    return int_of(cand)
        return None


# --------------------------------------------------------------------------
# GHZ diagnostic (classical 8-qubit statevector; result discarded)
# --------------------------------------------------------------------------
def ghz_diagnostic(n_qubits: int = 8, shots: int = 64, rng=None) -> dict:
    rng = rng or np.random.default_rng()
    dim = 1 << n_qubits
    psi = np.zeros(dim, dtype=complex)
    psi[0] = 1.0
    # H on qubit 0
    new = np.zeros_like(psi)
    for i in range(dim):
        if i & 1 == 0:
            new[i] += psi[i] / math.sqrt(2)
            new[i | 1] += psi[i] / math.sqrt(2)
        else:
            new[i & ~1] += psi[i] / math.sqrt(2)
            new[i] -= psi[i] / math.sqrt(2)
    psi = new
    # CNOT chain (q, q+1)
    for q in range(n_qubits - 1):
        new = psi.copy()
        for i in range(dim):
            if (i >> q) & 1:
                new[i] = psi[i ^ (1 << (q + 1))]
        psi = new
    probs = np.abs(psi) ** 2
    probs /= probs.sum()
    draws = rng.choice(dim, size=shots, p=probs)
    counts: dict = {}
    for d in draws:
        key = format(int(d), f"0{n_qubits}b")
        counts[key] = counts.get(key, 0) + 1
    return counts


# --------------------------------------------------------------------------
# Theory (Sections 3-5, 8)
# --------------------------------------------------------------------------
def theory(m=56, r=0.45, eps=0.02, t=4, L=16, q_max=200_000, delta=(1e-2, 1e-6)):
    Z = 2 * math.sqrt(eps * (1 - eps))
    base = 1 - r * (1 - Z)
    expo = -math.log(base)
    C = r * (1 - H2(eps))
    lam = -math.log(1 - r)
    gamma = 0.5772156649
    V = sum(math.comb(L, k) for k in range(t + 1))
    rows = [
        ("Bhattacharyya Z", Z),
        ("Per-cycle error base", base),
        ("Per-cycle exponent (nats)", expo),
        ("Capacity C (bits/cell/frame)", C),
        ("Shannon lower bound on T", 1 / C),
        ("Mean cover time", (math.log(m) + gamma) / lam),
        ("Cover-time s.d.", math.pi / (math.sqrt(6) * lam)),
    ]
    for d in delta:
        rows.append((f"T for union bound <= {d:g}", math.log(m / d) / expo))
    rows += [
        ("Hamming-ball size V(L,t)", V),
        ("Cycles until Q_max", math.ceil(q_max / V)),
        ("False-accept bound", q_max * 2.0 ** -256),
    ]
    return rows


def print_theory(**kw):
    for name, val in theory(**kw):
        print(f"{name:<34s} {val:.6g}")


def camera_channel(sigma: float, c0: float = 25, tau: float = 127,
                   mu0: float = 0, mu1: float = 255):
    """Section 2.3: effective (eps_eff, rho) after pooling + confidence gate."""
    s = sigma / CELL
    d1 = mu1 - tau
    if s == 0:
        return 0.0, 0.0
    eps_eff = Qfun((d1 + c0) / s)
    rho = Qfun((d1 - c0) / s) - eps_eff
    return eps_eff, rho


# --------------------------------------------------------------------------
# Runs
# --------------------------------------------------------------------------
def run_once(oracle: Oracle, source, r: float, eps: float, max_cycles: int,
             L: int, t: int, q_max: int, rng, synthetic_bitflips: bool,
             verbose: bool = False, diagnostic: bool = False) -> DecodeStats:
    rec = Recogniser(oracle, L=L, t=t, q_max=q_max, rng=rng)
    st = DecodeStats()
    for cyc in range(1, max_cycles + 1):
        st.cycles = cyc
        pooled = pool(source.frame(), oracle.rows, oracle.cols)
        bit, valid = classify(pooled)
        if synthetic_bitflips:
            bit = bit ^ (rng.random(oracle.m) < eps).astype(np.uint8)
            valid = valid & (rng.random(oracle.m) < r)
        rec.accumulate(bit, valid)
        if diagnostic:
            _ = ghz_diagnostic(rng=rng)  # discarded by design
        if st.cover_cycle is None and rec.covered():
            st.cover_cycle = cyc
        cand = rec.decode()
        if verbose and cand is None and rec.covered():
            print(f"  cycle {cyc}: tested {rec.tested} candidates, no match")
        if cand is not None:
            proof = oracle.reveal_if_proven(cand)
            if proof:
                st.success, (st.result, st.factors) = True, proof
                break
        if rec.tested >= q_max:
            break
    st.candidates = rec.tested
    return st


def cmd_run(a):
    rng = np.random.default_rng(a.seed)
    oracle = Oracle(a.n, seed=a.seed)
    salt, c = oracle.public
    print(f"m={oracle.m} bits, grid {oracle.rows}x{oracle.cols}")
    print(f"salt={salt.hex()}\ncommit={c.hex()}")
    if a.camera is not None:
        src, flips = CameraSource(a.camera, oracle.rows, oracle.cols), False
    else:
        src = SyntheticSource(oracle, a.pixel_sigma, rng)
        flips = a.pixel_sigma == 0  # bit-level channel unless pixel noise used
        if a.pixel_sigma > 0:
            e, rho = camera_channel(a.pixel_sigma)
            print(f"pixel sigma={a.pixel_sigma}: eps_eff={e:.3g}, erasure rho={rho:.3g}")
    t0 = time.time()
    st = run_once(oracle, src, a.r, a.eps, a.max_cycles, a.L, a.t, a.q_max,
                  rng, flips, verbose=a.verbose, diagnostic=a.ghz)
    dt = time.time() - t0
    if st.success:
        print(f"RECOVERED N={st.result} after {st.cycles} cycles "
              f"(cover at {st.cover_cycle}, {st.candidates} hashes, {dt:.2f}s)")
        print(f"factors (released by oracle after proof): {st.factors}")
    else:
        print(f"FAILED after {st.cycles} cycles, {st.candidates} hashes")


def cmd_mc(a):
    rng = np.random.default_rng(a.seed)
    cyc, cov, ok = [], [], 0
    for k in range(a.trials):
        oracle = Oracle(a.n, seed=int(rng.integers(1 << 31)))
        src = SyntheticSource(oracle)
        st = run_once(oracle, src, a.r, a.eps, a.max_cycles, a.L, a.t,
                      a.q_max, rng, True)
        if st.success:
            ok += 1
            cyc.append(st.cycles)
            cov.append(st.cover_cycle)
    print(f"success {ok}/{a.trials}")
    if cyc:
        print(f"mean cycles to recover: {np.mean(cyc):.2f} (sd {np.std(cyc):.2f})")
        print(f"mean cover cycle      : {np.mean(cov):.2f} (sd {np.std(cov):.2f})")
    print("--- theory ---")
    print_theory(m=Oracle(a.n).m, r=a.r, eps=a.eps, t=a.t, L=a.L, q_max=a.q_max)


def main():
    p = argparse.ArgumentParser(description=__doc__,
                                formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = p.add_subparsers(dest="cmd", required=True)

    def common(sp):
        sp.add_argument("--n", type=int, default=DEFAULT_N)
        sp.add_argument("--r", type=float, default=0.45, help="reveal rate")
        sp.add_argument("--eps", type=float, default=0.02, help="bit-flip prob")
        sp.add_argument("--L", type=int, default=16)
        sp.add_argument("--t", type=int, default=4)
        sp.add_argument("--q-max", type=int, default=200_000)
        sp.add_argument("--max-cycles", type=int, default=800)
        sp.add_argument("--seed", type=int, default=None)

    sr = sub.add_parser("run"); common(sr)
    sr.add_argument("--pixel-sigma", type=float, default=0.0)
    sr.add_argument("--camera", type=int, default=None)
    sr.add_argument("--ghz", action="store_true", help="run GHZ diagnostic each cycle")
    sr.add_argument("--verbose", action="store_true")
    sr.set_defaults(fn=cmd_run)

    sm = sub.add_parser("mc"); common(sm)
    sm.add_argument("--trials", type=int, default=1000)
    sm.set_defaults(fn=cmd_mc)

    st = sub.add_parser("theory")
    st.set_defaults(fn=lambda a: print_theory())

    a = p.parse_args()
    a.fn(a)


if __name__ == "__main__":
    main()
