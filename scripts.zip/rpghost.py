#!/usr/bin/env python3
"""
rpghost.py - calculators and test harness for RP-GHOST Appendices A-D.

Status convention follows the document: [E] established, [C] calculated, [T] test.

Sections
  1. Sample-size calculators (A.9 table, C.4, D.8)          [C]
  2. Information / locality / self-reference (B.10)          [C]
  3. CMOS sensor chain (D.2-D.7)                             [C]
  4. A.9 harness: frame records, post-frame nonce, SHA256d   [T]
  5. Estimators (i)-(vi) with preregistered thresholds       [T]
  6. Null simulation: checks the estimators do NOT fire      [T]

Run:  python rpghost.py            -> prints tables and runs the null self-test
Needs: numpy (scipy optional, not required)
"""
from __future__ import annotations

import csv
import hashlib
import json
import math
import os
import time
from dataclasses import dataclass, asdict, field
from typing import Callable, Iterable, Optional, Protocol

import numpy as np

# ----------------------------------------------------------------------------
# Constants
# ----------------------------------------------------------------------------
K_B = 1.380649e-23
Q_E = 1.602176634e-19
H_PLANCK = 6.62607015e-34
C_LIGHT = 299_792_458.0
EPS0 = 8.8541878128e-12
FPS = 30.0
HASHRATE = 500e3  # R, hashes/s
SIGMA5 = 5.0


def fmt_time(s: float) -> str:
    if s < 120:
        return f"{s:.1f} s"
    if s < 7200:
        return f"{s/60:.1f} min"
    if s < 172800:
        return f"{s/3600:.1f} h"
    return f"{s/86400:.1f} d"


# ----------------------------------------------------------------------------
# 1. Sample-size calculators
# ----------------------------------------------------------------------------
def n_hidden_number(m: int, sigma: float = SIGMA5) -> int:
    """Trials to see hit rate 2*2^-m vs chance 2^-m at `sigma` (doc: 25*2^m)."""
    return int(round(sigma**2 * 2**m))


def n_tts_solutions(speedup: float = 2.0, sigma: float = 3.0) -> int:
    """Solutions needed so ln(speedup) > sigma/sqrt(m)  (exponential TTS)."""
    return math.ceil((sigma / math.log(speedup)) ** 2)


def tts_time(k: int, rate: float = HASHRATE, solutions: Optional[int] = None) -> float:
    solutions = solutions or n_tts_solutions()
    return solutions * 2**k / rate


def n_bit_bias(eps: float, sigma: float = SIGMA5) -> float:
    return (sigma**2 / 4) / eps**2  # doc: 6.25/eps^2


def n_correlation(rho: float, sigma: float = SIGMA5) -> float:
    return sigma**2 / rho**2


def n_p_distinguish(p0: float, p1: float, sigma: float = SIGMA5) -> float:
    """C.4: frames with x in L to separate p1 from p0 (doc uses p0(1-p0)=0.1875)."""
    return sigma**2 * p0 * (1 - p0) / (p1 - p0) ** 2


def n_fano(delta: float, sigma: float = SIGMA5) -> float:
    """D.8: samples for fractional Fano shift delta (variance rel. err sqrt(2/(n-1)))."""
    return 2 * sigma**2 / delta**2


def sample_size_table() -> str:
    rows = []
    for m in (8, 12, 16):
        n = n_hidden_number(m)
        rows.append(("hidden number", f"m={m}", n, n / FPS))
    for k in (20, 24, 28, 32):
        rows.append(("SHA256d TTS", f"k={k}", n_tts_solutions(), tts_time(k)))
    for e in (1e-3, 1e-4, 1e-6):
        n = n_bit_bias(e)
        rows.append(("hash-bit bias", f"eps={e:g}", n, n / HASHRATE))
    for r in (0.1, 0.01, 0.001):
        n = n_correlation(r)
        rows.append(("correlation", f"rho={r:g}", n, n / FPS))
    for d in (1e-2, 1e-3):
        n = n_fano(d)
        rows.append(("Fano shift", f"delta={d:g}", n, n / (12288 * FPS)))
    out = [f"{'probe':<15}{'setting':<12}{'trials':>14}  time"]
    for name, s, n, t in rows:
        out.append(f"{name:<15}{s:<12}{n:>14,.0f}  {fmt_time(t)}")
    return "\n".join(out)


# ----------------------------------------------------------------------------
# 2. Information, locality, self-reference (B.10)
# ----------------------------------------------------------------------------
def info_required(k: int, q: float = 1.0) -> float:
    """B.10.1: bits needed to raise success from 2^-k to q."""
    return k + math.log2(q)


def frame_bits(w: int = 128, h: int = 96) -> float:
    return math.log2(w * h)


def implied_speedup_bits(k: int, frames: int, bits_per_frame: float = 4.0, rate=HASHRATE):
    search_s = 2**k / rate
    t = frames / FPS
    return math.log2(search_s / t)


def boundary_bits_per_block(difficulty: float) -> float:
    return math.log2(difficulty) + 32  # B.10.2


def light_radius_m(dt: float) -> float:
    return C_LIGHT * dt  # B.10.3


def self_reference_iterations(eps: float, start_dev: float = 0.5, target_dev: float = 1e-3):
    """B.10.4: |p_n - 1/2| = |-(1-2eps)|^n |p0 - 1/2|; clocks until below target."""
    return math.log(start_dev / target_dev) / -math.log(1 - 2 * eps)


def self_reference_trace(p0: float, eps: float, n: int) -> np.ndarray:
    p = np.empty(n + 1)
    p[0] = p0
    for i in range(n):
        p[i + 1] = 0.5 + (-(1 - 2 * eps)) * (p[i] - 0.5)
    return p


# ----------------------------------------------------------------------------
# 3. CMOS sensor chain (D.2-D.7)
# ----------------------------------------------------------------------------
@dataclass
class Sensor:
    T: float = 300.0
    eps_si: float = 11.7 * EPS0
    n_i: float = 1.0e10 * 1e6          # m^-3
    N_A: float = 1e15 * 1e6
    N_D: float = 1e18 * 1e6
    V_rev: float = 2.8
    C_fd: float = 1.6e-15
    C_col: float = 1e-12
    I_bias: float = 10e-6
    W_over_L: float = 4.0
    mu_eff: float = 400e-4             # m^2/Vs
    C_ox: float = 6.9e-3               # F/m^2
    full_well: float = 1e4
    read_noise_e: float = 2.0
    t_int: float = 1 / 30
    J_dark_e: float = 10.0             # e-/s
    vdd: float = 3.3

    @property
    def kT(self):
        return K_B * self.T

    @property
    def vt(self):
        return self.kT / Q_E

    def bandgap_ev(self):
        return 1.170 - 4.73e-4 * self.T**2 / (self.T + 636)

    def cutoff_nm(self):
        return 1239.8 / self.bandgap_ev()

    def iqe(self, alpha_cm: float, W_um: float = 3.0):
        return 1 - math.exp(-alpha_cm * W_um * 1e-4)

    def responsivity(self, eta: float, wl_nm: float):
        return eta * wl_nm * 1e-3 / 1.2398

    def junction(self):
        vbi = self.vt * math.log(self.N_A * self.N_D / self.n_i**2)
        W = math.sqrt(2 * self.eps_si * (vbi + self.V_rev) / (Q_E * self.N_A))
        Cj_per_area = self.eps_si / W
        Emax = Q_E * self.N_A * W / self.eps_si
        return dict(Vbi=vbi, W_um=W * 1e6, Cj_fF_um2=Cj_per_area * 1e3,
                    Emax_kV_cm=Emax * 1e-5, transit_ps=W / 1e5 * 1e12)

    def cv_gain(self):
        return Q_E / self.C_fd  # V per electron

    def noise_budget(self, N: float):
        reset = math.sqrt(self.kT * self.C_fd) / Q_E  # e- rms (removed by CDS)
        dark = math.sqrt(self.J_dark_e * self.t_int)
        var = N + self.read_noise_e**2 + dark**2
        return dict(shot=math.sqrt(N), reset_e=reset, dark_e=dark,
                    total_e=math.sqrt(var), snr_db=20 * math.log10(N / math.sqrt(var)))

    def dark_doubling_K(self):
        dlnJ = self.bandgap_ev() * Q_E / (2 * self.kT * self.T) + 2 / self.T
        return math.log(2) / dlnJ, dlnJ

    def follower(self):
        gm = math.sqrt(2 * self.mu_eff * self.C_ox * self.W_over_L * 10e-6)
        gmb = 0.2 * gm
        A = gm / (gm + gmb)
        Rout = 1 / (gm + gmb)
        tau = Rout * self.C_col
        return dict(gm_uS=gm * 1e6, A=A, Rout_kohm=Rout * 1e-3, tau_ns=tau * 1e9,
                    settle_ns=6.91 * tau * 1e9,
                    slew_ns_for_0p8V=0.8 * self.C_col / self.I_bias * 1e9,
                    ktc_col_uV=math.sqrt(self.kT / self.C_col) * 1e6)

    def p_one(self, mu_e: float, sigma_e: float, v_th: float):
        """D.6: P(1) = Phi((muV - Vth)/sigmaV)."""
        A = self.follower()["A"]
        g = A * self.cv_gain()
        z = (mu_e * g - v_th) / (sigma_e * g)
        return 0.5 * math.erfc(-z / math.sqrt(2))

    def read_energy(self, pixels=12288, fps=FPS):
        e_read = self.C_col * self.vdd**2
        landauer = self.kT * math.log(2)
        return dict(E_read_pJ=e_read * 1e12, power_uW=e_read * pixels * fps * 1e6,
                    landauer_J=landauer, ratio=e_read / landauer)


# ----------------------------------------------------------------------------
# 4. A.9 harness
# ----------------------------------------------------------------------------
def sha256d(b: bytes) -> bytes:
    return hashlib.sha256(hashlib.sha256(b).digest()).digest()


def hash_below_target(h: bytes, k: int) -> bool:
    """Treat hash as big-endian integer; success if top k bits are zero."""
    return int.from_bytes(h, "big") >> (256 - k) == 0


@dataclass
class FrameRecord:
    t: int
    t_frame: float          # monotonic time frame digest was fixed
    t_nonce: float          # monotonic time nonce was drawn
    frame_digest: str       # d_t (hex)
    count_x: int            # x_t
    witness_r: int          # r_t
    Q: int                  # Q_t
    nonce: int              # n_t, drawn AFTER d_t from independent source
    header_hash: str        # h_t (hex)
    below_target: int
    hidden_m: int = 0       # bits of hidden target (0 = unused)
    hidden_guess: int = -1
    hidden_target: int = -1
    in_L: int = 0           # x in L (for p-hat)
    feature: float = 0.0    # frame feature for rho


class NonceSource(Protocol):
    def next(self) -> int: ...


class OSRandomNonce:
    """Stand-in for 'separate quantum RNG'. Replace with a hardware QRNG."""
    def next(self) -> int:
        return int.from_bytes(os.urandom(8), "big")


class PrecommittedNonce:
    """Precommitted list: publish `commitment` BEFORE the run; reveal list after."""
    def __init__(self, nonces: list[int]):
        self._n = list(nonces)
        self._i = 0
        blob = json.dumps(self._n).encode()
        self.commitment = hashlib.sha256(blob).hexdigest()

    def next(self) -> int:
        v = self._n[self._i]
        self._i += 1
        return v

    def verify(self, revealed: list[int]) -> bool:
        return hashlib.sha256(json.dumps(revealed).encode()).hexdigest() == self.commitment


@dataclass
class Prereg:
    """Freeze BEFORE the run. Hash of this object is stored in the log header."""
    sigma: float = 5.0
    hidden_m: int = 12
    tts_k: int = 24
    tts_speedup_sigma: float = 3.0
    bit_bias_eps: float = 1e-4
    rho_target: float = 0.01
    p_null: float = 0.75
    L_member_min: int = 208
    n_frames: int = 102_400

    def digest(self) -> str:
        return hashlib.sha256(json.dumps(asdict(self), sort_keys=True).encode()).hexdigest()


class Harness:
    """Drives frames through a user-supplied device and logs every record.

    frame_source() -> (frame_bytes, count_x, witness_r, Q, in_L, feature, hidden_guess)
    The harness (not the device) fixes the digest, THEN draws the nonce, and
    refuses to record a row where t_nonce <= t_frame (validity rule, A.9).
    """

    def __init__(self, frame_source: Callable[[int], tuple], nonce_source: NonceSource,
                 prereg: Prereg, hidden_target_source: Optional[NonceSource] = None):
        self.frame_source = frame_source
        self.nonce_source = nonce_source
        self.hidden_source = hidden_target_source or OSRandomNonce()
        self.prereg = prereg
        self.records: list[FrameRecord] = []

    def run(self, n: int, header_prefix: bytes = b"RPGHOST") -> None:
        m = self.prereg.hidden_m
        for t in range(n):
            frame, x, r, Q, in_L, feat, guess = self.frame_source(t)
            d = hashlib.sha256(frame).hexdigest()
            t_frame = time.monotonic_ns()
            nonce = self.nonce_source.next()               # AFTER digest
            t_nonce = time.monotonic_ns()
            if t_nonce <= t_frame:
                raise RuntimeError("invalid run: nonce not strictly after frame")
            header = header_prefix + bytes.fromhex(d) + nonce.to_bytes(8, "big")
            h = sha256d(header)
            ok = int(hash_below_target(h, self.prereg.tts_k))
            target = self.hidden_source.next() & ((1 << m) - 1) if m else -1
            self.records.append(FrameRecord(
                t, t_frame * 1e-9, t_nonce * 1e-9, d, int(x), int(r), int(Q),
                nonce, h.hex(), ok, m, int(guess), int(target), int(in_L), float(feat)))

    def save(self, path: str) -> None:
        with open(path, "w", newline="") as f:
            f.write(f"# prereg_sha256={self.prereg.digest()}\n")
            w = csv.DictWriter(f, fieldnames=list(asdict(self.records[0]).keys()))
            w.writeheader()
            for r in self.records:
                w.writerow(asdict(r))


# ----------------------------------------------------------------------------
# 5. Estimators (return z-scores or effect sizes; all one-sided where noted)
# ----------------------------------------------------------------------------
def est_hidden_number(recs: Iterable[FrameRecord]) -> dict:
    """(i) hit rate vs 2^-m. Binomial z."""
    rs = [r for r in recs if r.hidden_m > 0 and r.hidden_guess >= 0]
    n = len(rs)
    if n == 0:
        return dict(n=0)
    m = rs[0].hidden_m
    p0 = 2.0**-m
    hits = sum(r.hidden_guess == r.hidden_target for r in rs)
    z = (hits - n * p0) / math.sqrt(n * p0 * (1 - p0))
    return dict(n=n, hits=hits, expected=n * p0, rate=hits / n, chance=p0, z=z)


def est_tts(recs: Iterable[FrameRecord], k: int, rate: float = HASHRATE) -> dict:
    """(ii) Header-level solutions per hash vs 2^-k.

    Under the null each hash succeeds with p=2^-k; the count of solutions in N
    hashes is Poisson(N 2^-k).  One-sided z for excess (speed-up) solutions.
    """
    rs = list(recs)
    N = len(rs)
    lam = N * 2.0**-k
    s = sum(r.below_target for r in rs)
    z = (s - lam) / math.sqrt(max(lam, 1e-12))
    return dict(hashes=N, solutions=s, expected=lam, z=z,
                speedup=(s / lam) if lam > 0 else float("nan"))


def est_bit_bias(recs: Iterable[FrameRecord]) -> dict:
    """(iii) Per-bit bias over all 256 header-hash bits; max |z| with Bonferroni."""
    rs = list(recs)
    n = len(rs)
    arr = np.frombuffer(b"".join(bytes.fromhex(r.header_hash) for r in rs), dtype=np.uint8)
    bits = np.unpackbits(arr.reshape(n, 32), axis=1)
    mean = bits.mean(axis=0)
    z = (mean - 0.5) / (0.5 / math.sqrt(n))
    i = int(np.argmax(np.abs(z)))
    p_single = math.erfc(abs(z[i]) / math.sqrt(2))
    p_adj = min(1.0, 256 * p_single)
    return dict(n=n, worst_bit=i, bias=float(mean[i] - 0.5), z=float(z[i]),
                p_bonferroni=p_adj, sd_floor=0.5 / math.sqrt(n))


def est_correlation(recs: Iterable[FrameRecord]) -> dict:
    """(iv) Pearson rho between frame feature and outcome; z = rho*sqrt(n)."""
    rs = list(recs)
    x = np.array([r.feature for r in rs])
    y = np.array([r.below_target for r in rs], dtype=float)
    if x.std() == 0 or y.std() == 0:
        return dict(n=len(rs), rho=0.0, z=0.0)
    rho = float(np.corrcoef(x, y)[0, 1])
    return dict(n=len(rs), rho=rho, z=rho * math.sqrt(len(rs)))


def est_correlation_vs_lag(recs: list[FrameRecord], lags: list[int]) -> dict:
    """(iv)/B.10.3: rho(tau) using nonce shifted by `lag` frames (tau = lag/fps).

    A feature at frame t is correlated with the outcome at frame t+lag. Under H,
    rho above chance with a locality-dependent profile; under the null all ~0.
    """
    out = {}
    for L in lags:
        if L >= len(recs) - 10:
            continue
        a = np.array([r.feature for r in recs[: len(recs) - L]])
        b = np.array([r.below_target for r in recs[L:]], dtype=float)
        n = len(a)
        rho = float(np.corrcoef(a, b)[0, 1]) if a.std() and b.std() else 0.0
        out[L] = dict(tau_s=L / FPS, rho=rho, z=rho * math.sqrt(n))
    return out


def est_witness(recs: Iterable[FrameRecord], p_null: float = 0.75) -> dict:
    """(v) witness success rate on x in L vs p_null (one-sided, z)."""
    rs = [r for r in recs if r.in_L]
    n = len(rs)
    if n == 0:
        return dict(n=0)
    s = sum(r.Q for r in rs)
    p_hat = s / n
    z = (s - n * p_null) / math.sqrt(n * p_null * (1 - p_null))
    return dict(n=n, p_hat=p_hat, z=z)


def est_fano(stack: np.ndarray, F0: float = 1.0, read_var: float = 4.0) -> dict:
    """(vi) per-pixel temporal variance/mean on a flat field.

    stack: (frames, pixels) electron-equivalent counts. Returns F-hat and the
    fractional shift delta vs F0, with z using relative error sqrt(2/(n-1)).
    """
    n = stack.shape[0]
    mean = stack.mean(axis=0)
    var = stack.var(axis=0, ddof=1)
    good = mean > 10 * read_var
    F = float(np.mean((var[good] - read_var) / mean[good]))
    rel_err = math.sqrt(2.0 / (n - 1)) / math.sqrt(good.sum())
    delta = F / F0 - 1
    return dict(frames=n, pixels=int(good.sum()), F_hat=F, delta=delta, z=delta / rel_err)


def decide(results: dict, prereg: Prereg) -> dict:
    """Apply the preregistered threshold; 'evidence' only if z >= sigma."""
    s = prereg.sigma
    verdict = {}
    for name, key in (("P1 hidden-number", "hidden"), ("P2 TTS", "tts"),
                      ("P4 correlation", "corr"), ("P5 witness", "witness")):
        z = results.get(key, {}).get("z")
        verdict[name] = ("EVIDENCE" if z is not None and z >= s else "null") if z is not None else "n/a"
    bb = results.get("bias", {})
    if bb:
        verdict["P3 bit bias"] = "EVIDENCE" if abs(bb["z"]) >= s and bb["p_bonferroni"] < 5.7e-7 else "null"
    return verdict


def analyse(recs: list[FrameRecord], prereg: Prereg) -> dict:
    res = dict(
        hidden=est_hidden_number(recs),
        tts=est_tts(recs, prereg.tts_k),
        bias=est_bit_bias(recs),
        corr=est_correlation(recs),
        witness=est_witness(recs, prereg.p_null),
    )
    res["verdict"] = decide(res, prereg)
    return res


# ----------------------------------------------------------------------------
# 6. Null simulation: a classical frame source with NO link to the nonce
# ----------------------------------------------------------------------------
def null_frame_source(rng: np.random.Generator, m: int):
    """Classical camera stand-in. Guess is a deterministic function of the frame."""
    def src(t: int):
        frame = rng.integers(0, 256, size=128 * 96, dtype=np.uint8)
        x = int(frame.sum() % 2)               # stand-in count / witness inputs
        r = int(frame[: 64].sum() % 2)
        Q = int(rng.random() < 0.75)           # witness succeeds 3/4 under independence
        in_L = int(rng.random() < 0.5)
        feature = float(frame.mean())
        guess = int.from_bytes(hashlib.sha256(frame.tobytes()).digest()[:4], "big") & ((1 << m) - 1)
        return frame.tobytes(), x, r, Q, in_L, feature, guess
    return src


def self_test(n_frames: int = 20_000, seed: int = 1) -> dict:
    # Small k so the null run has solutions to count; m reduced for same reason.
    pre = Prereg(hidden_m=8, tts_k=8, n_frames=n_frames)
    rng = np.random.default_rng(seed)
    h = Harness(null_frame_source(rng, pre.hidden_m), OSRandomNonce(), pre)
    h.run(n_frames)
    return analyse(h.records, pre)


def injected_signal_test(n_frames: int = 20_000, seed: int = 2, leak: float = 0.5) -> dict:
    """Sanity check of POWER: make the hidden target equal the guess with extra
    probability `leak`. The hidden-number estimator must fire; the others not."""
    pre = Prereg(hidden_m=8, tts_k=8, n_frames=n_frames)
    rng = np.random.default_rng(seed)
    src = null_frame_source(rng, pre.hidden_m)
    holder = {}

    def wrapped(t):
        out = src(t)
        holder["guess"] = out[-1]
        return out

    class LeakyTarget:
        def next(self_inner):
            if rng.random() < leak:
                return holder["guess"]
            return int.from_bytes(os.urandom(8), "big")

    h = Harness(wrapped, OSRandomNonce(), pre, hidden_target_source=LeakyTarget())
    h.run(n_frames)
    return analyse(h.records, pre)


# ----------------------------------------------------------------------------
# Demo
# ----------------------------------------------------------------------------
def main():
    print("=== A.9 sample sizes (5 sigma, 30 fps, R = 500 kHz) ===")
    print(sample_size_table())
    print(f"\nC.4  p=0.75 vs 0.9: n = {n_p_distinguish(0.75, 0.9):.0f} frames in L")

    print("\n=== B.10 ===")
    print(f"frame bits           : {frame_bits():.1f}")
    for k, fr in ((20, 5), (32, 8), (48, 12), (64, 16)):
        print(f"k={k:<3} search {fmt_time(2**k/HASHRATE):>10}   bits {info_required(k):.0f}   "
              f"frames {fr}   t {fr/FPS:.2f} s")
    sp = implied_speedup_bits(48, 12)
    print(f"k=48 implied speed-up: 2^{sp:.1f}")
    print(f"D=1e14 boundary bits : {boundary_bits_per_block(1e14):.1f}  "
          f"({boundary_bits_per_block(1e14)/600:.2f} bit/s)")
    print(f"light radius / frame : {light_radius_m(1/FPS):.3e} m")
    print(f"self-ref clocks eps=.01: {self_reference_iterations(0.01):.0f}")

    print("\n=== D sensor chain ===")
    s = Sensor()
    print(f"Eg {s.bandgap_ev():.3f} eV, cutoff {s.cutoff_nm():.0f} nm")
    print("noise @N=1e4 :", {k: round(v, 3) for k, v in s.noise_budget(1e4).items()})
    print("follower     :", {k: round(v, 3) for k, v in s.follower().items()})
    print("dark doubling: %.1f K" % s.dark_doubling_K()[0])
    print("energy       :", {k: float(f"{v:.3g}") for k, v in s.read_energy().items()})
    print("P(1) at mu=Vth: %.2f" % s.p_one(5000, 100, 5000 * s.cv_gain() * s.follower()['A']))

    print("\n=== Null self-test (estimators must stay below 5 sigma) ===")
    res = self_test()
    for k in ("hidden", "tts", "bias", "corr", "witness"):
        print(k, {a: (round(b, 4) if isinstance(b, float) else b) for a, b in res[k].items()})
    print("verdict:", res["verdict"])

    print("\n=== Power check: injected leak (hidden-number must fire) ===")
    res = injected_signal_test()
    print("hidden:", {a: (round(b, 4) if isinstance(b, float) else b) for a, b in res["hidden"].items()})
    print("verdict:", res["verdict"])


if __name__ == "__main__":
    main()
