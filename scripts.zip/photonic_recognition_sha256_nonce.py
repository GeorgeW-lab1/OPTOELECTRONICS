import numpy as np
import hashlib
import itertools
import math
from typing import List, Tuple, Set


class PhotonicNonceRecoverySimulation:
    """
    Two-Level Photonic Recognition and Temporally Directed Secret Recovery,
    applied to a SHA-256 target with KNOWN data and an UNKNOWN nonce.

        target = SHA256(known_data || nonce_bytes)

    The solver is given only `known_data` and `target`. The nonce is the photonic
    source's secret K; it is an arbitrary chosen value (nothing is mined). The
    solver learns it only through the AND-gated photon stream X(t) = K AND R(t),
    and accepts a candidate only if it reproduces the target digest.
    """

    def __init__(self, nonce_bits: List[int], known_data: bytes, p: float = 0.5):
        self.secret = np.array(nonce_bits, dtype=int)       # physical source only
        self.n = len(self.secret)
        self.p = p
        self.known_data = known_data
        self.nonce_len = (self.n + 7) // 8
        self.target = self._digest(self.secret)             # the only public output

    def _digest(self, K: np.ndarray) -> str:
        """SHA256(known_data || nonce) with the nonce as a big-endian integer."""
        nonce = int(''.join(map(str, K)), 2)
        return hashlib.sha256(self.known_data + nonce.to_bytes(self.nonce_len, "big")).hexdigest()

    def generate_single_observation(self) -> np.ndarray:
        """X(t) = K AND R(t), R_i(t) ~ Bernoulli(p)."""
        R = np.random.choice([0, 1], size=self.n, p=[1.0 - self.p, self.p])
        return np.bitwise_and(self.secret, R)

    def apply_noise_cancellation(self, X: np.ndarray) -> np.ndarray:
        """Simulates S_c(t) = S(t) - N_hat(t) across accumulated observations."""
        noise = np.random.normal(0, 0.08, size=X.shape)
        S = X.astype(float) + noise
        n_hat = np.mean(noise, axis=0, keepdims=True)
        return ((S - n_hat) > 0.5).astype(int)

    def level_one_recognition(self, X: np.ndarray) -> Tuple[Set[int], np.ndarray]:
        """
        Cumulative-OR rule. Since K_i = 0 always yields X_i = 0, a single observed
        '1' proves K_i = 1. U_m = positions proven to be 1; B_m is their indicator.
        """
        ones_count = np.sum(X == 1, axis=0)
        u_set = {i for i in range(self.n) if ones_count[i] > 0}
        b_m = np.zeros(self.n, dtype=int)
        for i in u_set:
            b_m[i] = 1
        return u_set, b_m

    def level_two_recognition(self, b_m: np.ndarray, max_budget: int) -> Tuple[bool, np.ndarray, int]:
        """
        Hamming-weight recognition: B_m's ones are certain, so the missing ones can
        only be on never-seen positions. Try adding k extra ones there, in
        increasing k, and accept the candidate that reproduces the target hash.
        """
        unseen = [i for i in range(self.n) if b_m[i] == 0]
        u = len(unseen)
        total_hashes = 0

        for k in range(u + 1):
            if total_hashes + math.comb(u, k) > max_budget:
                return False, np.array([]), total_hashes
            for combo in itertools.combinations(unseen, k):
                total_hashes += 1
                k_hat = b_m.copy()
                for idx in combo:
                    k_hat[idx] = 1
                if self._digest(k_hat) == self.target:
                    return True, k_hat, total_hashes
        return False, np.array([]), total_hashes

    def run_sequential_recovery(self, max_observations: int = 82, max_budget_per_stage: int = 1_000_000):
        """Stage-by-stage (m = 1, 2, ..., M) recovery; stops as soon as the target matches."""
        print(f"[*] Photonic SHA-256 nonce recovery (n={self.n} bits, p={self.p}, max_m={max_observations})")
        print(f"[*] Known data : {self.known_data!r}")
        print(f"[*] Target hash: {self.target}")

        observations = []
        cumulative_hashes = 0

        for m in range(1, max_observations + 1):
            observations.append(self.generate_single_observation())
            X_clean = self.apply_noise_cancellation(np.array(observations))

            u_set, b_m = self.level_one_recognition(X_clean)
            success, k_hat, stage_hashes = self.level_two_recognition(b_m, max_budget_per_stage)
            cumulative_hashes += stage_hashes

            print(f"    Stage m={m:2d} | |U_m|={len(u_set):2d} | B_m={''.join(map(str, b_m))} | Stage Hashes={stage_hashes}")

            if success:
                nonce = int(''.join(map(str, k_hat)), 2)
                print(f"\n[+] NONCE RECOVERED at observation stage m={m}!")
                print(f"    Nonce (bits) : {''.join(map(str, k_hat))}")
                print(f"    Nonce (int)  : {nonce} (0x{nonce:0{self.nonce_len * 2}x})")
                print(f"    Digest       : {self._digest(k_hat)}")
                print(f"    Matches target: {self._digest(k_hat) == self.target}")
                print(f"    Cumulative hashes: {cumulative_hashes}")
                return True, k_hat, m, cumulative_hashes

        print(f"\n[-] Not recovered within {max_observations} observations (total hashes: {cumulative_hashes}).")
        return False, np.array([]), max_observations, cumulative_hashes


if __name__ == "__main__":
    np.random.seed(42)
    # Arbitrary chosen nonce (0xBEEF); the solver only ever sees the target hash.
    nonce_bits = [int(b) for b in format(0xBEEF, "032b")]
    sim = PhotonicNonceRecoverySimulation(nonce_bits, known_data=b"known_header_data|ts=1789000000", p=0.00006)
    sim.run_sequential_recovery(max_observations=82, max_budget_per_stage=10**9)
