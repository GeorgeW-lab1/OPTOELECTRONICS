"""
Real-camera version of the optoelectronic circuit (optoelectronics_v2.png).

No laser is needed: the camera plus ambient light replace IR laser + reflector
+ IR detectors.
  right half of the frame = detector A (right ROI)
  left  half of the frame = detector B (left ROI)
A detector bit is 1 when its ROI brightness departs from a slowly adapting
baseline by more than `--margin` (the "delta intensity"). Cover or shade one
half of the lens/scene with your hand, or shine a torch on it, to trigger it.
Because the baseline adapts (`--adapt` seconds), slow room-light drift is
ignored and only quick changes count.

Everything downstream (drivers, RC node, NPN, delay, accumulator, flip-flop,
independent probe) is reused from optoelectronics_sim.py, which must sit in the
same folder.

Usage:
    pip install opencv-python numpy
    python optoelectronics_camera.py                  # default webcam, 10 s probe
    python optoelectronics_camera.py --camera 1 --duration 5000 --margin 20 --mode dark
    python optoelectronics_camera.py --camera clip.mp4 --no-preview

Press 'q' in the preview window to stop early.
"""

import argparse
import random
import threading
import time

import cv2
import numpy as np

from optoelectronics_sim import (
    DT_MS, CLOCK_PERIOD_MS, DELAY_MS,
    DriverA, DriverB, RCNode, NPN, DelayLine, Accumulator,
    DFlipFlop74HC74, Clock, Probe,
)
from optoelectronics_predict import StreamForecaster


class CameraBench:
    """Grabs frames in a background thread and exposes two ROI brightness values."""

    def __init__(self, source=0, margin=15.0, mirror=False, mode="either",
                 adapt_s=5.0, lock_exposure=False):
        src = int(source) if str(source).isdigit() else source
        self.is_file = not isinstance(src, int)
        self.cap = cv2.VideoCapture(src)
        if not self.cap.isOpened():
            raise RuntimeError(f"Could not open camera/source: {source!r}")
        self.margin = margin
        self.mirror = mirror
        self.mode = mode                         # dark | bright | either
        self.alpha = (DT_MS / 1000.0) / adapt_s  # baseline EMA step per 1 ms tick
        if lock_exposure:                        # best effort; driver dependent
            self.cap.set(cv2.CAP_PROP_AUTO_EXPOSURE, 0.25)
        self.baseline_a = self.baseline_b = None
        self.level_a = self.level_b = 0.0
        self.frame = None
        self._lock = threading.Lock()
        self._running = False

    # -- capture thread ------------------------------------------------------
    def start(self):
        self._running = True
        self._thread = threading.Thread(target=self._loop, daemon=True)
        self._thread.start()
        t0 = time.time()
        while self.frame is None:                # wait for the first frame
            if time.time() - t0 > 5:
                raise RuntimeError("Camera produced no frames")
            time.sleep(0.01)

    def stop(self):
        self._running = False
        self._thread.join(timeout=1)
        self.cap.release()

    def _loop(self):
        while self._running:
            ok, frame = self.cap.read()
            if not ok:
                if self.is_file:                 # loop video files
                    self.cap.set(cv2.CAP_PROP_POS_FRAMES, 0)
                    continue
                time.sleep(0.01)
                continue
            if self.mirror:
                frame = cv2.flip(frame, 1)
            gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
            h, w = gray.shape
            left_b = float(np.mean(gray[:, : w // 2]))     # detector B
            right_a = float(np.mean(gray[:, w // 2:]))     # detector A
            with self._lock:
                self.level_a, self.level_b, self.frame = right_a, left_b, frame

    # -- detectors -----------------------------------------------------------
    def calibrate(self, seconds=1.5):
        """Average ROI brightness in the resting scene to set the baseline."""
        a_vals, b_vals = [], []
        t0 = time.time()
        while time.time() - t0 < seconds:
            with self._lock:
                a_vals.append(self.level_a)
                b_vals.append(self.level_b)
            time.sleep(0.02)
        self.baseline_a, self.baseline_b = float(np.mean(a_vals)), float(np.mean(b_vals))
        print(f"Baseline  A (right): {self.baseline_a:.1f}   B (left): {self.baseline_b:.1f}")

    def read_bits(self):
        with self._lock:
            a, b = self.level_a, self.level_b
        bit_a = self._detect(a - self.baseline_a)
        bit_b = self._detect(b - self.baseline_b)
        # slowly track ambient drift so only quick changes trigger
        self.baseline_a += self.alpha * (a - self.baseline_a)
        self.baseline_b += self.alpha * (b - self.baseline_b)
        return bit_a, bit_b

    def _detect(self, delta):
        if self.mode == "dark":
            return int(delta < -self.margin)
        if self.mode == "bright":
            return int(delta > self.margin)
        return int(abs(delta) > self.margin)

    def preview(self, bit_a, bit_b, status=""):
        with self._lock:
            frame = None if self.frame is None else self.frame.copy()
        if frame is None:
            return True
        h, w = frame.shape[:2]
        col = lambda bit: (0, 255, 0) if bit else (0, 0, 255)
        cv2.rectangle(frame, (w // 2, 0), (w - 1, h - 1), col(bit_a), 3)   # A
        cv2.rectangle(frame, (0, 0), (w // 2 - 1, h - 1), col(bit_b), 3)   # B
        cv2.putText(frame, f"B={bit_b}", (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.9, col(bit_b), 2)
        cv2.putText(frame, f"A={bit_a}", (w // 2 + 10, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.9, col(bit_a), 2)
        cv2.putText(frame, status, (10, h - 12), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 2)
        cv2.imshow("optoelectronics", frame)
        return (cv2.waitKey(1) & 0xFF) != ord("q")


def run(args):
    rng = random.Random(args.seed)
    bench = CameraBench(args.camera, margin=args.margin, mirror=args.mirror,
                        mode=args.mode, adapt_s=args.adapt,
                        lock_exposure=args.lock_exposure)
    bench.start()
    print("Calibrating baseline - leave the scene still ...")
    bench.calibrate()
    print("Running - cover/shade or light up one half of the view to trigger a detector.")

    drv_a, drv_b = DriverA(rng), DriverB()
    rc, npn = RCNode(), NPN()
    delay, acc, ff, clock = DelayLine(), Accumulator(), DFlipFlop74HC74(), Clock()
    probe = Probe(args.probe_err, rng)
    fc = {k: StreamForecaster(k, args.order) for k in ("det_a", "det_b", "truth")}

    main_duration = 2 * args.duration            # main circuit runs 2x longer
    trace = []
    start = time.perf_counter()
    last_preview = 0.0
    keep_going = True

    try:
        t = 0
        while t < main_duration and keep_going:
            # pace the loop to wall-clock time (1 ms logical ticks)
            while time.perf_counter() - start < t / 1000.0:
                time.sleep(0.0002)

            # camera -> detectors
            bit_a, bit_b = bench.read_bits()

            # parallel drivers
            a = drv_a.drive(args.x, bit_a)
            v_c = rc.step(drv_b.drive(args.x, bit_b))
            b = npn.out(v_c)

            # main circuit
            and_dly = delay.step(a & b)
            y = a | b                              # time code, forces HIGH
            d = and_dly | y                        # leak path
            select, observe = ff.step(d, clock.level(t))
            acc_val = acc.update(and_dly) if t >= DELAY_MS else 1

            # independent probe (stops at duration)
            if t < args.duration and t % CLOCK_PERIOD_MS == 0:
                probe.sample(t, a, b)

            trace.append(dict(t=t, det_a=bit_a, det_b=bit_b, a=a, b=b, v_c=v_c,
                              and_dly=and_dly, y=y, d=d,
                              select=select, observe=observe, acc=acc_val))

            # forecasting: score last tick's forecast, learn, forecast the next tick
            if t % CLOCK_PERIOD_MS == 0:
                fc["det_a"].observe(bit_a)
                fc["det_b"].observe(bit_b)
                fc["truth"].observe(a & b)

            # preview at ~30 fps
            now = time.perf_counter()
            if args.preview and now - last_preview > 0.033:
                status = (f"t={t}ms a={a} b={b} V(C)={v_c:.2f} | next-tick forecast: "
                          f"A={fc['det_a'].forecast} B={fc['det_b'].forecast} "
                          f"a&b={fc['truth'].forecast}")
                keep_going = bench.preview(bit_a, bit_b, status)
                last_preview = now

            t += DT_MS
    finally:
        bench.stop()
        if args.preview:
            cv2.destroyAllWindows()

    return trace, probe.log, fc


def main():
    p = argparse.ArgumentParser(description="Optoelectronic circuit driven by a real camera")
    p.add_argument("--camera", default="0", help="camera index or video file path")
    p.add_argument("--x", type=int, default=1, choices=[0, 1], help="problem instance bit")
    p.add_argument("--duration", type=int, default=10000, help="probe duration in ms")
    p.add_argument("--margin", type=float, default=15.0, help="brightness change (0-255) that counts as HIGH")
    p.add_argument("--probe-err", type=float, default=0.05, help="probe flip-noise probability")
    p.add_argument("--seed", type=int, default=None)
    p.add_argument("--mode", choices=["dark", "bright", "either"], default="either",
                   help="trigger on darkening, brightening, or any change")
    p.add_argument("--adapt", type=float, default=5.0,
                   help="seconds for the baseline to follow ambient light")
    p.add_argument("--lock-exposure", action="store_true",
                   help="try to turn off camera auto-exposure (driver dependent)")
    p.add_argument("--order", type=int, default=3, help="Markov order for forecasting")
    p.add_argument("--mirror", action="store_true", help="flip the image horizontally")
    p.add_argument("--no-preview", dest="preview", action="store_false")
    args = p.parse_args()

    trace, probe_log, fc = run(args)
    if not trace:
        return

    print("\n t(ms)  detA detB  a b  V(C)  and_dly  SELECT observe  ACC")
    for r in trace[::500]:
        print(f"{r['t']:6d}   {r['det_a']}    {r['det_b']}    {r['a']} {r['b']}  {r['v_c']:.2f}"
              f"     {r['and_dly']}      {r['select']}      {r['observe']}      {r['acc']}")

    errors = sum(r["truth"] != r["measured"] for r in probe_log)
    print(f"\nProbe samples: {len(probe_log)}, flipped by noise: {errors}")
    print("\nNext-tick (100 ms ahead) forecasts:")
    for f in fc.values():
        print("  " + f.summary())
    print(f"Main circuit ran {trace[-1]['t'] + DT_MS} ms (2x probe duration)")


if __name__ == "__main__":
    main()
