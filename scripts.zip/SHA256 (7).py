import hashlib
import struct

header_prefix = bytes.fromhex(
    "000000200000000000000000000000000000000000000000000000000000000000000000"
    "b3945bba73a20bfbb82c2511a817725fc306c691efcccfe7b61b59022c7a6cc9"
    "67def16affff001d"
)

assert len(header_prefix) == 76

def reconstruct_header(nonce):
    return header_prefix + struct.pack("<I", nonce)

def sha256d(data):
    return hashlib.sha256(
        hashlib.sha256(data).digest()
    ).digest()

nonce = 0

header = reconstruct_header(nonce)
digest = sha256d(header)

print("Prefix:", header_prefix.hex())
print("Prefix bytes:", len(header_prefix))
print("Header:", header.hex())
print("Header bytes:", len(header))
print("SHA256d:", digest[::-1].hex())
print("Nonce:", nonce)
