#!/usr/bin/env python3
"""
fastsort.py - high-speed parallel sorting of numeric datasets with raw binary I/O.

Method: parallel sample-sort.
  1. Split data into P chunks; sort each in its own thread (NumPy releases the GIL;
     integer sorts use SIMD kernels on supporting CPUs).
  2. Pick P-1 global splitters from chunk samples.
  3. Cut every sorted chunk at the splitters with searchsorted (vectorised, O(P^2 log n)).
  4. Thread j merges piece j of every chunk straight into its final output slice.
Result is written in place into one preallocated array: no Python-level loops over data.

Raw format = headerless little-endian binary (exactly what ndarray.tofile writes).
Because it is headerless, you must supply the dtype when loading.

CLI:
  python fastsort.py gen   data.raw --n 50_000_000 --dtype int64
  python fastsort.py sort  data.raw sorted.raw --dtype int64 [--mmap] [--threads 8]
  python fastsort.py bench --n 20_000_000 --dtype float64
"""
import argparse, os, time
from concurrent.futures import ThreadPoolExecutor
import numpy as np


# ----------------------------------------------------------------- raw I/O
def save_raw(arr, path):
    """Write array as headerless raw binary (little-endian)."""
    a = np.ascontiguousarray(arr)
    if a.dtype.byteorder == ">":
        a = a.astype(a.dtype.newbyteorder("<"))
    a.tofile(path)


def load_raw(path, dtype="int64", mmap=False):
    """Read raw binary. mmap=True maps the file lazily (read-only) for huge files."""
    dt = np.dtype(dtype).newbyteorder("<")
    size = os.path.getsize(path)
    if size % dt.itemsize:
        raise ValueError(f"{path}: size {size} not a multiple of {dt} ({dt.itemsize} B)")
    if mmap:
        return np.memmap(path, dtype=dt, mode="r")
    return np.fromfile(path, dtype=dt)


# ----------------------------------------------------------------- sorting
def parallel_sort(a, threads=None, min_parallel=1 << 18):
    """Return a new sorted array. Falls back to np.sort for small inputs."""
    a = np.asarray(a)
    n = a.size
    p = threads or os.cpu_count() or 1
    if p < 2 or n < min_parallel:
        return np.sort(a)

    bounds = np.linspace(0, n, p + 1, dtype=np.int64)
    chunks = [np.array(a[bounds[i]:bounds[i + 1]]) for i in range(p)]  # private copies

    with ThreadPoolExecutor(p) as ex:
        list(ex.map(lambda c: c.sort(), chunks))                       # 1. local sorts

        # 2. splitters from evenly spaced samples of the sorted chunks
        k = min(256, max(2, n // (p * 4)))
        sample = np.sort(np.concatenate(
            [c[np.linspace(0, c.size - 1, k, dtype=np.int64)] for c in chunks if c.size]))
        split = sample[np.linspace(0, sample.size - 1, p + 1, dtype=np.int64)[1:-1]]

        # 3. cut points of every chunk at every splitter
        cuts = np.array([np.concatenate(([0], np.searchsorted(c, split, side="left"), [c.size]))
                         for c in chunks])                              # shape (p, p+1)
        piece_len = np.diff(cuts, axis=1).sum(axis=0)                   # per output piece
        offs = np.concatenate(([0], np.cumsum(piece_len)))

        out = np.empty_like(a)

        # 4. each thread assembles + merges one output piece
        def build(j):
            parts = [chunks[i][cuts[i, j]:cuts[i, j + 1]] for i in range(p)]
            seg = out[offs[j]:offs[j + 1]]
            if seg.size:
                np.concatenate(parts, out=seg)
                seg.sort(kind="stable")      # runs already sorted -> timsort/radix merges fast
        list(ex.map(build, range(p)))
    return out


def sort_file(src, dst, dtype="int64", mmap=False, threads=None):
    data = load_raw(src, dtype, mmap=mmap)
    t = time.perf_counter()
    out = parallel_sort(data, threads)
    dt = time.perf_counter() - t
    save_raw(out, dst)
    return data.size, dt


# ----------------------------------------------------------------- CLI
def _gen(n, dtype, seed=0):
    rng = np.random.default_rng(seed)
    dt = np.dtype(dtype)
    if dt.kind == "f":
        return rng.random(n).astype(dt)
    info = np.iinfo(dt)
    return rng.integers(info.min, info.max, n, dtype=dt, endpoint=True)


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawTextHelpFormatter)
    sp = ap.add_subparsers(dest="cmd", required=True)
    g = sp.add_parser("gen");   g.add_argument("path"); g.add_argument("--n", type=lambda s: int(s.replace("_", "")), default=10_000_000); g.add_argument("--dtype", default="int64")
    s = sp.add_parser("sort");  s.add_argument("src"); s.add_argument("dst"); s.add_argument("--dtype", default="int64"); s.add_argument("--mmap", action="store_true"); s.add_argument("--threads", type=int)
    b = sp.add_parser("bench"); b.add_argument("--n", type=lambda s: int(s.replace("_", "")), default=20_000_000); b.add_argument("--dtype", default="float64"); b.add_argument("--threads", type=int)
    a = ap.parse_args()

    if a.cmd == "gen":
        save_raw(_gen(a.n, a.dtype), a.path)
        print(f"wrote {a.n:,} x {a.dtype} -> {a.path}")
    elif a.cmd == "sort":
        n, dt = sort_file(a.src, a.dst, a.dtype, a.mmap, a.threads)
        print(f"sorted {n:,} elements in {dt:.3f}s ({n/dt/1e6:.1f} M/s) -> {a.dst}")
    else:
        x = _gen(a.n, a.dtype)
        t = time.perf_counter(); ref = np.sort(x); t1 = time.perf_counter() - t
        t = time.perf_counter(); out = parallel_sort(x, a.threads); t2 = time.perf_counter() - t
        assert np.array_equal(ref, out), "MISMATCH"
        print(f"n={a.n:,} {a.dtype}  np.sort {t1:.3f}s | parallel {t2:.3f}s | speedup {t1/t2:.2f}x | verified")


if __name__ == "__main__":
    main()
