#!/usr/bin/env python3
"""
Photonic LLM Subset-Sum Decoder

Pipeline:
1. Generate/load a subset-sum instance.
2. Send secret bits through a simulated photonic channel.
3. Pool optical values, gate uncertain observations, and accumulate margins.
4. Ask a local GGUF LLM to propose small repairs.
5. Verify every candidate with exact NumPy arithmetic and SHA-256.

No transformers or torch required.
"""

import argparse
import hashlib
import json
import math
import os
import re
import sys
import time
from pathlib import Path

import numpy as np
import pandas as pd

try:
    from llama_cpp import Llama
except ImportError:
    sys.exit("Missing inference dependency. Run: pip install llama-cpp-python")

try:
    from huggingface_hub import hf_hub_download
except ImportError:
    hf_hub_download = None


# ------------------------------------------------------------------
# Photonic-channel parameters
# ------------------------------------------------------------------

ROWS, COLS = 8, 16
NBITS = ROWS * COLS
REVEAL_P = 0.45
FLIP_P = 0.02
LEVEL_BLACK = 0
LEVEL_GRAY = 127
LEVEL_WHITE = 255


# ------------------------------------------------------------------
# GGUF downloader
# ------------------------------------------------------------------

def download_gguf_model(
    repo_id="Qwen/Qwen2.5-0.5B-Instruct-GGUF",
    filename="qwen2.5-0.5b-instruct-q4_k_m.gguf",
    revision=None,
    local_dir="./models",
    token=None
):
    """
    Download a GGUF file from Hugging Face if it is not already local.

    Returns a local path usable by llama_cpp.Llama(model_path=...).
    """
    local_path = Path(local_dir) / filename

    if local_path.exists() and local_path.stat().st_size > 0:
        print(f"[+] GGUF already present: {local_path}")
        return str(local_path)

    if hf_hub_download is None:
        sys.exit(
            "Missing downloader dependency.\n"
            "Run: pip install huggingface-hub"
        )

    print("[+] Downloading GGUF model")
    print(f"    repository:  {repo_id}")
    print(f"    file:        {filename}")
    print(f"    destination: {local_path}")

    downloaded = hf_hub_download(
        repo_id=repo_id,
        filename=filename,
        revision=revision,
        local_dir=local_dir,
        token=token
    )

    downloaded_path = Path(downloaded)

    if not downloaded_path.exists() or downloaded_path.stat().st_size == 0:
        sys.exit(f"Download failed or produced an empty file: {downloaded_path}")

    print(f"[+] GGUF ready: {downloaded_path}")
    return str(downloaded_path)


# ------------------------------------------------------------------
# Local GGUF LLM
# ------------------------------------------------------------------

class LlamaCppDecoder:
    """
    Local GGUF inference through llama-cpp-python.

    No transformers, no torch, no external API.
    """

    def __init__(
        self,
        model_path=None,
        hf_repo="Qwen/Qwen2.5-0.5B-Instruct-GGUF",
        hf_file="qwen2.5-0.5b-instruct-q4_k_m.gguf",
        hf_revision=None,
        hf_token=None,
        n_ctx=4096,
        n_gpu_layers=0,
        temperature=0.2,
        max_tokens=220,
        seed=1337
    ):
        self.temperature = temperature
        self.max_tokens = max_tokens
        self.calls = 0
        self.prompt_chars = 0
        self.completion_chars = 0

        if model_path is None:
            model_path = download_gguf_model(
                repo_id=hf_repo,
                filename=hf_file,
                revision=hf_revision,
                local_dir="./models",
                token=hf_token
            )

        print(f"[+] Loading GGUF model: {model_path}")

        self.llm = Llama(
            model_path=model_path,
            n_ctx=n_ctx,
            n_gpu_layers=n_gpu_layers,
            seed=seed,
            verbose=False
        )

    def complete(self, prompt):
        self.calls += 1
        self.prompt_chars += len(prompt)

        response = self.llm.create_completion(
            prompt=prompt,
            max_tokens=self.max_tokens,
            temperature=self.temperature,
            top_p=0.90,
            stop=["\n\n", "User:", "###"]
        )

        text = response["choices"][0]["text"]
        self.completion_chars += len(text)

        return text


# ------------------------------------------------------------------
# Dataset generation and loading
# ------------------------------------------------------------------

def generate_dataset(rows, cols, filename="photonic_tough.csv", seed=42):
    rng = np.random.default_rng(seed)
    m = rows * cols

    weights = rng.integers(10**11, 10**12, size=m, dtype=np.int64)
    secret_b = rng.integers(0, 2, size=m, dtype=np.int8)

    if secret_b.sum() == 0:
        secret_b[0] = 1

    target_sum = int(np.dot(weights, secret_b))

    df = pd.DataFrame({
        "weight": weights,
        "secret_b": secret_b
    })

    with open(filename, "w") as f:
        f.write(f"# TARGET_SUM={target_sum}\n")
        f.write(f"# VARIABLES={m}\n")
        df.to_csv(f, index=False)

    print(f"[+] Generated {filename}")
    print(f"    variables: {m}")
    print(f"    target sum: {target_sum}")

    return weights, secret_b, target_sum


def load_dataset(filename):
    target_sum = None

    with open(filename, "r") as f:
        for line in f:
            if "TARGET_SUM=" in line:
                target_sum = int(line.strip().split("TARGET_SUM=")[1])
                break

    df = pd.read_csv(filename, comment="#")

    weights = df["weight"].to_numpy(dtype=np.int64)
    secret_b = df["secret_b"].to_numpy(dtype=np.uint8)

    if target_sum is None:
        target_sum = int(np.dot(weights, secret_b))

    return weights, secret_b, target_sum


# ------------------------------------------------------------------
# Photonic channel
# ------------------------------------------------------------------

class PhotonicChannel:
    """
    Simulated optical channel.

    Fold 1: pooled optical response.
    Fold 2: confidence gate marks ambiguous cells as erased.
    Fold 3: temporal voting accumulates ones minus zeros.
    """

    def __init__(
        self,
        m,
        reveal_p=REVEAL_P,
        flip_p=FLIP_P,
        pixels_per_cell=144,
        pixel_noise=12.0,
        gain=0.80,
        offset=20.0,
        gamma=1.40,
        seed=7
    ):
        self.m = m
        self.reveal_p = reveal_p
        self.flip_p = flip_p
        self.rng = np.random.default_rng(seed)

        self.pixels_per_cell = pixels_per_cell
        self.sigma = pixel_noise / math.sqrt(pixels_per_cell)
        self.gain = gain
        self.offset = offset
        self.gamma = gamma

    def pooled(self, bits, reveal, flips):
        shown = np.bitwise_xor(bits, flips.astype(np.int8))

        levels = np.where(shown == 1, LEVEL_WHITE, LEVEL_BLACK)
        levels = np.where(reveal, levels, LEVEL_GRAY)

        optical = 255.0 * (levels.astype(np.float64) / 255.0) ** self.gamma
        optical = optical * self.gain + self.offset

        noise = self.rng.normal(0.0, self.sigma, size=self.m)

        return optical + noise

    def observe(self, secret_b):
        reveal = self.rng.random(self.m) < self.reveal_p
        flips = self.rng.random(self.m) < self.flip_p

        pooled = self.pooled(secret_b, reveal, flips)
        return pooled, reveal, flips


def calibrate_photonic_channel(channel, calibration_cycles=8):
    lows = []
    grays = []
    highs = []

    reveal = np.ones(channel.m, dtype=bool)
    no_flips = np.zeros(channel.m, dtype=np.int8)

    zeros = np.zeros(channel.m, dtype=np.int8)
    ones = np.ones(channel.m, dtype=np.int8)

    for _ in range(calibration_cycles):
        lows.append(channel.pooled(zeros, reveal, no_flips))
        grays.append(channel.pooled(zeros, reveal, no_flips))
        highs.append(channel.pooled(ones, reveal, no_flips))

    lo = np.mean(lows, axis=0)
    gray = np.mean(grays, axis=0)
    hi = np.mean(highs, axis=0)

    span = np.maximum(hi - lo, 1e-6)
    gray_z = (gray - lo) / span

    return lo, span, gray_z


def confidence_gate(pooled, lo, span, gray_z, gate_width=0.20):
    """
    Fold 2: pooled optical value -> bit or erased.

    A value close to the gray calibration point is unreliable and erased.
    """
    z = (pooled - lo) / span
    valid = np.abs(z - gray_z) >= gate_width
    bit = (z > gray_z).astype(np.uint8)

    return bit, valid


# ------------------------------------------------------------------
# Exact verifier
# ------------------------------------------------------------------

def verify_candidate(weights, target_sum, candidate, salt, commit):
    """
    Exact verifier.

    A candidate is accepted only when:
    1. weights @ candidate == target_sum
    2. SHA-256(salt + packed candidate bits) == commit
    """
    candidate = np.asarray(candidate, dtype=np.uint8)

    if candidate.shape != weights.shape:
        return False, 0, target_sum, False

    candidate_sum = int(np.dot(
        weights.astype(np.int64),
        candidate.astype(np.int64)
    ))

    packed = np.packbits(candidate).tobytes()
    digest = hashlib.sha256(salt + packed).digest()

    sum_match = candidate_sum == target_sum
    digest_match = digest == commit

    return (
        sum_match and digest_match,
        candidate_sum,
        target_sum - candidate_sum,
        digest_match
    )


# ------------------------------------------------------------------
# LLM prompt and response parsing
# ------------------------------------------------------------------

def build_llm_prompt(
    m,
    target_sum,
    current_sum,
    residual,
    candidate,
    margins,
    weights,
    uncertain,
    round_no,
    max_proposals,
    max_flips
):
    if residual < 0:
        direction = (
            "The current sum is TOO HIGH. "
            "Propose 1 -> 0 flips."
        )
    else:
        direction = (
            "The current sum is TOO LOW. "
            "Propose 0 -> 1 flips."
        )

    rows = []

    for i in uncertain:
        rows.append(
            f"index={i}, "
            f"weight={int(weights[i])}, "
            f"current_bit={int(candidate[i])}, "
            f"photonic_margin={int(margins[i])}"
        )

    uncertain_text = "\n".join(rows)

    return f"""Photonic subset-sum repair, round {round_no}.

Variables: {m}
Target subset sum: {target_sum}
Current subset sum: {current_sum}
Signed residual: {residual}
{direction}

Least-reliable photonic observations:
{uncertain_text}

Propose up to {max_proposals} small repair moves.
Each move may flip at most {max_flips} indices.
Choose moves whose total weight change moves current_sum toward target_sum.
Do not repeat an index within one move.
Use only indices between 0 and {m - 1}.

Return JSON only, exactly in this form:
{{"flips": [[index1, index2], [index3]]}}
"""


def parse_llm_proposals(
    text,
    m,
    max_proposals=8,
    max_flips=6
):
    """
    Accepts:
      {"flips": [[12, 47], [303]]}
      [[12, 47], [303]]
      [12, 47, 303]
    """
    proposals = []

    try:
        parsed = json.loads(text)

        if isinstance(parsed, dict) and "flips" in parsed:
            raw = parsed["flips"]
        else:
            raw = parsed

        if isinstance(raw, list):
            if raw and isinstance(raw[0], list):
                proposals = raw
            else:
                proposals = [raw]

    except Exception:
        numbers = [int(x) for x in re.findall(r"\b\d+\b", text)]

        if numbers:
            proposals = [numbers[:max_flips]]

    clean = []

    for proposal in proposals[:max_proposals]:
        if not isinstance(proposal, list):
            continue

        flips = []

        for value in proposal:
            try:
                index = int(value)
            except Exception:
                continue

            if 0 <= index < m and index not in flips:
                flips.append(index)

        if flips and len(flips) <= max_flips:
            clean.append(flips)

    return clean


# ------------------------------------------------------------------
# LLM-guided decoder
# ------------------------------------------------------------------

def photonic_llm_decode(
    weights,
    target_sum,
    est_b,
    margins,
    salt,
    commit,
    llm,
    max_rounds=10,
    proposals_per_round=8,
    max_flips=6,
    uncertain_window=64,
    use_local_fallback=True
):
    m = len(weights)
    weights = weights.astype(np.int64)

    best = est_b.astype(np.uint8).copy()

    verified, best_sum, best_residual, _ = verify_candidate(
        weights, target_sum, best, salt, commit
    )

    candidate_tests = 1

    if verified:
        return best, {
            "verified": True,
            "source": "photonic_majority",
            "llm_calls": 0,
            "candidate_tests": candidate_tests,
            "rounds": 0,
            "residual": 0
        }

    best_abs_residual = abs(best_residual)
    uncertain = np.argsort(np.abs(margins), kind="stable")[:uncertain_window]

    for round_no in range(1, max_rounds + 1):
        prompt = build_llm_prompt(
            m=m,
            target_sum=target_sum,
            current_sum=best_sum,
            residual=best_residual,
            candidate=best,
            margins=margins,
            weights=weights,
            uncertain=uncertain,
            round_no=round_no,
            max_proposals=proposals_per_round,
            max_flips=max_flips
        )

        print(f"[LLM] Round {round_no}: requesting repairs")

        response = llm.complete(prompt)
        proposals = parse_llm_proposals(
            response,
            m,
            max_proposals=proposals_per_round,
            max_flips=max_flips
        )

        if not proposals:
            print("[LLM] No usable proposals returned")
            continue

        round_best = None
        round_best_sum = best_sum
        round_best_residual = best_residual
        round_best_abs_residual = best_abs_residual

        for flips in proposals:
            candidate = best.copy()
            indices = np.asarray(flips, dtype=np.int64)
            candidate[indices] ^= 1

            verified, candidate_sum, residual, _ = verify_candidate(
                weights, target_sum, candidate, salt, commit
            )
            candidate_tests += 1

            if verified:
                return candidate, {
                    "verified": True,
                    "source": f"llm_round_{round_no}",
                    "llm_calls": llm.calls,
                    "candidate_tests": candidate_tests,
                    "rounds": round_no,
                    "residual": 0
                }

            error = abs(residual)

            if error < round_best_abs_residual:
                round_best = candidate
                round_best_sum = candidate_sum
                round_best_residual = residual
                round_best_abs_residual = error

        if round_best is not None:
            best = round_best
            best_sum = round_best_sum
            best_residual = round_best_residual
            best_abs_residual = round_best_abs_residual

            print(
                f"[LLM] Improved residual to {best_residual} "
                f"(absolute {best_abs_residual})"
            )
        else:
            print("[LLM] No proposal improved the residual")

    if use_local_fallback:
        print("[+] Running deterministic residual fallback")

        candidate, fallback_tests, verified = local_residual_repair(
            weights=weights,
            target_sum=target_sum,
            start=best,
            margins=margins,
            salt=salt,
            commit=commit,
            max_candidates=100_000
        )

        candidate_tests += fallback_tests

        if verified:
            return candidate, {
                "verified": True,
                "source": "local_fallback",
                "llm_calls": llm.calls,
                "candidate_tests": candidate_tests,
                "rounds": max_rounds,
                "residual": 0
            }

    return best, {
        "verified": False,
        "source": "unverified",
        "llm_calls": llm.calls,
        "candidate_tests": candidate_tests,
        "rounds": max_rounds,
        "residual": int(best_residual)
    }


def local_residual_repair(
    weights,
    target_sum,
    start,
    margins,
    salt,
    commit,
    max_candidates=100_000
):
    """
    Fast deterministic fallback.

    - Starts from the photonic/LLM candidate.
    - Uses low-margin indices only.
    - Updates the subset sum incrementally.
    - Verifies exact sum and SHA-256.
    """
    m = len(weights)
    weights = weights.astype(np.int64)

    candidate = start.astype(np.uint8).copy()
    current_sum = int(np.dot(weights, candidate))
    residual = target_sum - current_sum

    uncertain = np.argsort(np.abs(margins), kind="stable")

    ones_indices = uncertain[candidate[uncertain] == 1]
    zeros_indices = uncertain[candidate[uncertain] == 0]

    down = ones_indices[np.argsort(weights[ones_indices])[::-1]]
    up = zeros_indices[np.argsort(weights[zeros_indices])[::-1]]

    tests = 0

    def test(candidate_array, candidate_sum):
        nonlocal tests
        tests += 1

        packed = np.packbits(candidate_array).tobytes()
        digest = hashlib.sha256(salt + packed).digest()

        return candidate_sum == target_sum and digest == commit

    while residual != 0 and tests < max_candidates:
        improved = False

        if residual > 0:
            usable = up[weights[up] <= residual]

            if usable.size:
                index = int(usable[0])
                candidate[index] = 1
                current_sum += int(weights[index])
                residual -= int(weights[index])
                up = up[1:]
                improved = True

        else:
            usable = down[weights[down] <= -residual]

            if usable.size:
                index = int(usable[0])
                candidate[index] = 0
                current_sum -= int(weights[index])
                residual += int(weights[index])
                down = down[1:]
                improved = True

        if not improved:
            break

        if test(candidate, current_sum):
            return candidate, tests, True

    return candidate, tests, test(candidate, current_sum)


# ------------------------------------------------------------------
# Main
# ------------------------------------------------------------------

def main():
    parser = argparse.ArgumentParser(
        description="Photonic LLM subset-sum decoder using a local GGUF model"
    )

    parser.add_argument(
        "--dataset",
        default="photonic_tough.csv",
        help="Subset-sum dataset CSV"
    )

    parser.add_argument(
        "--generate",
        action="store_true",
        help="Generate a new dataset before decoding"
    )

    parser.add_argument("--rows", type=int, default=50)
    parser.add_argument("--cols", type=int, default=20)
    parser.add_argument("--seed", type=int, default=42)

    parser.add_argument(
        "--cycles",
        type=int,
        default=49,
        help="Number of photonic observation cycles"
    )

    parser.add_argument(
        "--reveal",
        type=float,
        default=REVEAL_P,
        help="Probability a bit is revealed in one cycle"
    )

    parser.add_argument(
        "--flip",
        type=float,
        default=FLIP_P,
        help="Bit-flip probability in one cycle"
    )

    parser.add_argument(
        "--gate",
        type=float,
        default=0.20,
        help="Confidence-gate erasure half-width"
    )

    parser.add_argument(
        "--model",
        default=None,
        help="Optional existing local GGUF path"
    )

    parser.add_argument(
        "--hf-repo",
        default="Qwen/Qwen2.5-0.5B-Instruct-GGUF",
        help="Hugging Face repository containing the GGUF model"
    )

    parser.add_argument(
        "--hf-file",
        default="qwen2.5-0.5b-instruct-q4_k_m.gguf",
        help="GGUF filename in the Hugging Face repository"
    )

    parser.add_argument(
        "--hf-revision",
        default=None,
        help="Optional Hugging Face revision, tag, or commit hash"
    )

    parser.add_argument(
        "--hf-token",
        default=None,
        help="Optional Hugging Face access token"
    )

    parser.add_argument("--context", type=int, default=4096)
    parser.add_argument("--gpu-layers", type=int, default=0)

    parser.add_argument("--max-rounds", type=int, default=10)
    parser.add_argument("--proposals", type=int, default=8)
    parser.add_argument("--max-flips", type=int, default=6)
    parser.add_argument("--uncertain-window", type=int, default=64)

    parser.add_argument(
        "--no-fallback",
        action="store_true",
        help="Disable deterministic residual fallback"
    )

    args = parser.parse_args()

    if args.generate:
        generate_dataset(
            rows=args.rows,
            cols=args.cols,
            filename=args.dataset,
            seed=args.seed
        )

    weights, secret_b, target_sum = load_dataset(args.dataset)
    m = len(weights)

    print(f"[+] Loaded {args.dataset}")
    print(f"    variables: {m}")
    print(f"    target sum: {target_sum}")

    salt = os.urandom(16)
    packed_secret = np.packbits(secret_b).tobytes()
    commit = hashlib.sha256(salt + packed_secret).digest()

    channel = PhotonicChannel(
        m=m,
        reveal_p=args.reveal,
        flip_p=args.flip,
        seed=args.seed + 1
    )

    lo, span, gray_z = calibrate_photonic_channel(channel)

    ones_counts = np.zeros(m, dtype=np.int32)
    zeros_counts = np.zeros(m, dtype=np.int32)

    print(f"[+] Running {args.cycles} photonic observation cycles")

    for cycle in range(1, args.cycles + 1):
        pooled, reveal, flips = channel.observe(secret_b)

        bit, valid = confidence_gate(
            pooled=pooled,
            lo=lo,
            span=span,
            gray_z=gray_z,
            gate_width=args.gate
        )

        ones_counts += (valid & (bit == 1)).astype(np.int32)
        zeros_counts += (valid & (bit == 0)).astype(np.int32)

        if cycle % 10 == 0 or cycle == args.cycles:
            covered = int(np.sum(ones_counts + zeros_counts > 0))
            print(
                f"[cycle {cycle:3d}] covered={covered}/{m} "
                f"ones={int(ones_counts.sum())} "
                f"zeros={int(zeros_counts.sum())}"
            )

    margins = ones_counts - zeros_counts
    est_b = (margins > 0).astype(np.uint8)

    majority_verified, majority_sum, majority_residual, _ = verify_candidate(
        weights, target_sum, est_b, salt, commit
    )

    print("\n[+] Photonic majority estimate")
    print(f"    sum: {majority_sum}")
    print(f"    residual: {majority_residual}")
    print(f"    bit errors: {int(np.sum(secret_b != est_b))}")
    print(f"    verified: {majority_verified}")

    llm = LlamaCppDecoder(
        model_path=args.model,
        hf_repo=args.hf_repo,
        hf_file=args.hf_file,
        hf_revision=args.hf_revision,
        hf_token=args.hf_token,
        n_ctx=args.context,
        n_gpu_layers=args.gpu_layers,
        temperature=0.2,
        max_tokens=220,
        seed=args.seed
    )

    start_time = time.time()

    recovered, stats = photonic_llm_decode(
        weights=weights,
        target_sum=target_sum,
        est_b=est_b,
        margins=margins,
        salt=salt,
        commit=commit,
        llm=llm,
        max_rounds=args.max_rounds,
        proposals_per_round=args.proposals,
        max_flips=args.max_flips,
        uncertain_window=args.uncertain_window,
        use_local_fallback=not args.no_fallback
    )

    elapsed = time.time() - start_time

    final_verified, final_sum, final_residual, digest_match = verify_candidate(
        weights, target_sum, recovered, salt, commit
    )

    result = pd.DataFrame({
        "weight": weights,
        "true_b": secret_b,
        "ones_count": ones_counts,
        "zeros_count": zeros_counts,
        "photonic_margin": margins,
        "majority_b": est_b,
        "recovered_b": recovered
    })

    result.to_csv("photonic_llm_decoder_result.csv", index=True)

    print("\n================ PHOTONIC LLM DECODER ================")
    print(f"Verified exact recovery: {final_verified}")
    print(f"Final subset sum:        {final_sum}")
    print(f"Target subset sum:       {target_sum}")
    print(f"Final residual:          {final_residual}")
    print(f"SHA-256 digest match:    {digest_match}")
    print(f"Bit errors vs secret:    {int(np.sum(secret_b != recovered))}")
    print(f"LLM calls:               {stats['llm_calls']}")
    print(f"LLM prompt characters:   {llm.prompt_chars}")
    print(f"LLM output characters:   {llm.completion_chars}")
    print(f"Candidate tests:         {stats['candidate_tests']}")
    print(f"LLM rounds:              {stats['rounds']}")
    print(f"Recovery source:         {stats['source']}")
    print(f"Elapsed decoding time:   {elapsed:.3f} seconds")
    print("Result saved to:         photonic_llm_decoder_result.csv")
    print("=======================================================\n")


if __name__ == "__main__":
    main()
