#!/usr/bin/env python3
"""
rp_anchor.py - record decoded block data on the Bitcoin blockchain with YOUR wallet.

What this does (and does not do)
--------------------------------
* It publishes a small OP_RETURN transaction that commits to the decoded block
  hash, height and a SHA-256 digest of all decoded block fields. Anyone can later
  prove "this data existed at block X" from the chain.
* It does NOT mine, claim a block, or earn a block reward. A block hash that has
  already been mined cannot be re-submitted; the only thing you can put on-chain
  is data inside an ordinary transaction, and that costs a network fee.
* Your private key never leaves your machine. It is read from the environment
  variable ANCHOR_WIF (never hard-code it, never paste it into chat).
* Everything is DRY-RUN by default: the transaction is built and signed, then
  printed, but NOT sent, unless you pass --broadcast (CLI) or set
  ANCHOR_AUTO=broadcast (pipeline hook).

Wallet: a single-key native SegWit (P2WPKH, bc1q... / tb1q...) address derived
from the WIF key. Fund that address, then anchor.

CLI
---
  python rp_anchor.py selftest
  export ANCHOR_WIF="..."            # compressed-key WIF (mainnet or testnet/signet)
  python rp_anchor.py address
  python rp_anchor.py anchor --hash <64hex> --height N [--network mainnet|testnet|signet]
                             [--fee-rate SAT_PER_VB] [--utxo txid:vout:sats] [--broadcast]
"""

import argparse
import hashlib
import hmac
import json
import math
import os
import struct
import sys
import time
import urllib.request

# ---------------------------------------------------------------- constants
MAGIC = b"RPGH"                # payload tag
PAYLOAD_VERSION = 1
MAX_OP_RETURN = 80             # standard-relay data limit
DUST_SATS = 294                # P2WPKH dust threshold
DEFAULT_MAX_FEE_SATS = 5000    # refuse to pay more than this unless overridden
ANCHOR_LOG = "anchors.jsonl"

NETWORKS = {
    "mainnet": {"wif": 0x80, "hrp": "bc", "api": "https://mempool.space/api"},
    "testnet": {"wif": 0xEF, "hrp": "tb", "api": "https://mempool.space/testnet/api"},
    "signet":  {"wif": 0xEF, "hrp": "tb", "api": "https://mempool.space/signet/api"},
}

# ------------------------------------------------------------------ hashing
def sha256(b):
    return hashlib.sha256(b).digest()


def dsha256(b):
    return sha256(sha256(b))


def _rol(x, n):
    return ((x << n) | (x >> (32 - n))) & 0xFFFFFFFF


def _ripemd160_py(data):
    """Pure-Python RIPEMD-160 (fallback for OpenSSL builds without it)."""
    r1 = [0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,7,4,13,1,10,6,15,3,12,0,9,5,2,14,11,8,
          3,10,14,4,9,15,8,1,2,7,0,6,13,11,5,12,1,9,11,10,0,8,12,4,13,3,7,15,14,5,6,2,
          4,0,5,9,7,12,2,10,14,1,3,8,11,6,15,13]
    r2 = [5,14,7,0,9,2,11,4,13,6,15,8,1,10,3,12,6,11,3,7,0,13,5,10,14,15,8,12,4,9,1,2,
          15,5,1,3,7,14,6,9,11,8,12,2,10,0,4,13,8,6,4,1,3,11,15,0,5,12,2,13,9,7,10,14,
          12,15,10,4,1,5,8,7,6,2,13,14,0,3,9,11]
    s1 = [11,14,15,12,5,8,7,9,11,13,14,15,6,7,9,8,7,6,8,13,11,9,7,15,7,12,15,9,11,7,13,12,
          11,13,6,7,14,9,13,15,14,8,13,6,5,12,7,5,11,12,14,15,14,15,9,8,9,14,5,6,8,6,5,12,
          9,15,5,11,6,8,13,12,5,12,13,14,11,8,5,6]
    s2 = [8,9,9,11,13,15,15,5,7,7,8,11,14,14,12,6,9,13,15,7,12,8,9,11,7,7,12,7,6,15,13,11,
          9,7,15,11,8,6,6,14,12,13,5,14,13,13,7,5,15,5,8,11,14,14,6,14,6,9,12,9,12,5,15,8,
          8,5,12,9,12,5,14,6,8,13,6,5,15,13,11,11]
    k1 = [0x00000000, 0x5A827999, 0x6ED9EBA1, 0x8F1BBCDC, 0xA953FD4E]
    k2 = [0x50A28BE6, 0x5C4DD124, 0x6D703EF3, 0x7A6D76E9, 0x00000000]

    def f(j, x, y, z):
        if j < 16: return x ^ y ^ z
        if j < 32: return (x & y) | (~x & z)
        if j < 48: return (x | ~y) ^ z
        if j < 64: return (x & z) | (y & ~z)
        return x ^ (y | ~z)

    h = [0x67452301, 0xEFCDAB89, 0x98BADCFE, 0x10325476, 0xC3D2E1F0]
    msg = bytearray(data) + b"\x80"
    msg += b"\x00" * ((56 - len(msg)) % 64) + struct.pack("<Q", len(data) * 8)
    for off in range(0, len(msg), 64):
        X = struct.unpack("<16I", msg[off:off + 64])
        a1, b1, c1, d1, e1 = h
        a2, b2, c2, d2, e2 = h
        for j in range(80):
            t = (_rol((a1 + f(j, b1, c1, d1) + X[r1[j]] + k1[j // 16]) & 0xFFFFFFFF, s1[j]) + e1) & 0xFFFFFFFF
            a1, e1, d1, c1, b1 = e1, d1, _rol(c1, 10), b1, t
            t = (_rol((a2 + f(79 - j, b2, c2, d2) + X[r2[j]] + k2[j // 16]) & 0xFFFFFFFF, s2[j]) + e2) & 0xFFFFFFFF
            a2, e2, d2, c2, b2 = e2, d2, _rol(c2, 10), b2, t
        t = (h[1] + c1 + d2) & 0xFFFFFFFF
        h[1] = (h[2] + d1 + e2) & 0xFFFFFFFF
        h[2] = (h[3] + e1 + a2) & 0xFFFFFFFF
        h[3] = (h[4] + a1 + b2) & 0xFFFFFFFF
        h[4] = (h[0] + b1 + c2) & 0xFFFFFFFF
        h[0] = t
    return struct.pack("<5I", *h)


def ripemd160(b):
    try:
        return hashlib.new("ripemd160", b).digest()
    except (ValueError, TypeError):
        return _ripemd160_py(b)


def hash160(b):
    return ripemd160(sha256(b))


# ------------------------------------------------- base58check / bech32 / ec
_B58 = "123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz"


def b58check_decode(s):
    n = 0
    for ch in s:
        n = n * 58 + _B58.index(ch)
    raw = n.to_bytes((n.bit_length() + 7) // 8, "big")
    raw = b"\x00" * (len(s) - len(s.lstrip("1"))) + raw
    payload, chk = raw[:-4], raw[-4:]
    if dsha256(payload)[:4] != chk:
        raise ValueError("bad WIF checksum")
    return payload


_BECH = "qpzry9x8gf2tvdw0s3jn54khce6mua7l"


def _bech32_polymod(values):
    gen = [0x3b6a57b2, 0x26508e6d, 0x1ea119fa, 0x3d4233dd, 0x2a1462b3]
    chk = 1
    for v in values:
        b = chk >> 25
        chk = ((chk & 0x1ffffff) << 5) ^ v
        for i in range(5):
            chk ^= gen[i] if (b >> i) & 1 else 0
    return chk


def segwit_v0_address(hrp, program):
    def convert(data):  # 8-bit -> 5-bit
        acc = bits = 0
        out = []
        for v in data:
            acc = (acc << 8) | v
            bits += 8
            while bits >= 5:
                bits -= 5
                out.append((acc >> bits) & 31)
        if bits:
            out.append((acc << (5 - bits)) & 31)
        return out
    data = [0] + convert(program)
    hrp_exp = [ord(c) >> 5 for c in hrp] + [0] + [ord(c) & 31 for c in hrp]
    poly = _bech32_polymod(hrp_exp + data + [0] * 6) ^ 1
    checksum = [(poly >> 5 * (5 - i)) & 31 for i in range(6)]
    return hrp + "1" + "".join(_BECH[d] for d in data + checksum)


P = 0xFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFEFFFFFC2F
N = 0xFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFEBAAEDCE6AF48A03BBFD25E8CD0364141
G = (0x79BE667EF9DCBBAC55A06295CE870B07029BFCDB2DCE28D959F2815B16F81798,
     0x483ADA7726A3C4655DA4FBFC0E1108A8FD17B448A68554199C47D08FFB10D4B8)


def _add(p, q):
    if p is None: return q
    if q is None: return p
    if p[0] == q[0] and (p[1] + q[1]) % P == 0: return None
    if p == q:
        lam = 3 * p[0] * p[0] * pow(2 * p[1], -1, P) % P
    else:
        lam = (q[1] - p[1]) * pow(q[0] - p[0], -1, P) % P
    x = (lam * lam - p[0] - q[0]) % P
    return x, (lam * (p[0] - x) - p[1]) % P


def _mul(k, p=G):
    r = None
    while k:
        if k & 1: r = _add(r, p)
        p = _add(p, p)
        k >>= 1
    return r


def pubkey_compressed(priv):
    x, y = _mul(priv)
    return bytes([2 + (y & 1)]) + x.to_bytes(32, "big")


def _rfc6979_k(priv, z):
    x = priv.to_bytes(32, "big")
    h = (z % N).to_bytes(32, "big")
    V, K = b"\x01" * 32, b"\x00" * 32
    K = hmac.new(K, V + b"\x00" + x + h, hashlib.sha256).digest()
    V = hmac.new(K, V, hashlib.sha256).digest()
    K = hmac.new(K, V + b"\x01" + x + h, hashlib.sha256).digest()
    V = hmac.new(K, V, hashlib.sha256).digest()
    while True:
        V = hmac.new(K, V, hashlib.sha256).digest()
        k = int.from_bytes(V, "big")
        if 1 <= k < N:
            return k
        K = hmac.new(K, V + b"\x00", hashlib.sha256).digest()
        V = hmac.new(K, V, hashlib.sha256).digest()


def ecdsa_sign_der(priv, z):
    """Deterministic (RFC6979), low-S ECDSA signature, DER encoded."""
    k = _rfc6979_k(priv, z)
    r = _mul(k)[0] % N
    s = pow(k, -1, N) * (z + r * priv) % N
    if s > N // 2:
        s = N - s
    def der_int(v):
        b = v.to_bytes((v.bit_length() + 7) // 8 or 1, "big")
        return (b"\x00" + b) if b[0] & 0x80 else b
    ri, si = der_int(r), der_int(s)
    body = b"\x02" + bytes([len(ri)]) + ri + b"\x02" + bytes([len(si)]) + si
    return b"\x30" + bytes([len(body)]) + body


def ecdsa_verify(pub33, z, r, s):
    x = int.from_bytes(pub33[1:], "big")
    y2 = (pow(x, 3, P) + 7) % P
    y = pow(y2, (P + 1) // 4, P)
    if (y & 1) != (pub33[0] & 1):
        y = P - y
    w = pow(s, -1, N)
    pt = _add(_mul(z * w % N), _mul(r * w % N, (x, y)))
    return pt is not None and pt[0] % N == r


# ------------------------------------------------------------- transactions
def varint(n):
    if n < 0xFD: return bytes([n])
    if n <= 0xFFFF: return b"\xfd" + struct.pack("<H", n)
    return b"\xfe" + struct.pack("<I", n)


def p2wpkh_script(h160):
    return b"\x00\x14" + h160


def op_return_script(payload):
    if len(payload) > MAX_OP_RETURN:
        raise ValueError(f"payload {len(payload)} B exceeds {MAX_OP_RETURN} B")
    push = bytes([len(payload)]) if len(payload) <= 75 else b"\x4c" + bytes([len(payload)])
    return b"\x6a" + push + payload


def ser_output(value, script):
    return struct.pack("<q", value) + varint(len(script)) + script


def ser_outpoint(txid_hex, vout):
    return bytes.fromhex(txid_hex)[::-1] + struct.pack("<I", vout)


def sign_p2wpkh_tx(priv, pub, utxos, outputs, version=2, locktime=0):
    """utxos: [{txid, vout, value}]; outputs: [(value, script)]. Returns (raw_hex, txid, vsize)."""
    seq = 0xFFFFFFFD  # RBF-enabled
    h160 = hash160(pub)
    hash_prevouts = dsha256(b"".join(ser_outpoint(u["txid"], u["vout"]) for u in utxos))
    hash_sequence = dsha256(b"".join(struct.pack("<I", seq) for _ in utxos))
    out_blob = b"".join(ser_output(v, s) for v, s in outputs)
    hash_outputs = dsha256(out_blob)
    script_code = b"\x19\x76\xa9\x14" + h160 + b"\x88\xac"
    witnesses = []
    for u in utxos:
        pre = (struct.pack("<I", version) + hash_prevouts + hash_sequence
               + ser_outpoint(u["txid"], u["vout"]) + script_code
               + struct.pack("<q", u["value"]) + struct.pack("<I", seq)
               + hash_outputs + struct.pack("<I", locktime) + struct.pack("<I", 1))
        z = int.from_bytes(dsha256(pre), "big")
        sig = ecdsa_sign_der(priv, z) + b"\x01"
        witnesses.append(b"\x02" + varint(len(sig)) + sig + varint(len(pub)) + pub)
    ins = b"".join(ser_outpoint(u["txid"], u["vout"]) + b"\x00" + struct.pack("<I", seq) for u in utxos)
    body = varint(len(utxos)) + ins + varint(len(outputs)) + out_blob
    legacy = struct.pack("<I", version) + body + struct.pack("<I", locktime)
    full = (struct.pack("<I", version) + b"\x00\x01" + body + b"".join(witnesses)
            + struct.pack("<I", locktime))
    weight = len(legacy) * 3 + len(full)
    return full.hex(), dsha256(legacy)[::-1].hex(), math.ceil(weight / 4)


# -------------------------------------------------------------------- wallet
def load_wallet(network):
    wif = os.environ.get("ANCHOR_WIF", "").strip()
    if not wif:
        raise SystemExit("Set ANCHOR_WIF in your environment (compressed-key WIF). Never hard-code it.")
    raw = b58check_decode(wif)
    if raw[0] != NETWORKS[network]["wif"]:
        raise SystemExit(f"WIF does not match network '{network}'.")
    if len(raw) != 34 or raw[-1] != 1:
        raise SystemExit("Need a COMPRESSED-key WIF (required for SegWit).")
    priv = int.from_bytes(raw[1:33], "big")
    pub = pubkey_compressed(priv)
    addr = segwit_v0_address(NETWORKS[network]["hrp"], hash160(pub))
    return priv, pub, addr


# ----------------------------------------------------------------- payload
def block_digest(data):
    """SHA-256 of the canonical JSON of the decoded block fields."""
    return sha256(json.dumps(data, sort_keys=True, separators=(",", ":")).encode())


def build_payload(height, hash_hex, data):
    """RPGH | v1 | height(4,BE) | block hash(32) | sha256(all decoded fields)(32)  = 73 bytes."""
    return (MAGIC + bytes([PAYLOAD_VERSION]) + struct.pack(">I", height)
            + bytes.fromhex(hash_hex) + block_digest(data))


# ------------------------------------------------------------------- network
def _http(url, data=None, timeout=15):
    req = urllib.request.Request(url, data=data, headers={"User-Agent": "rp-anchor/1.0"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.read().decode()


def fetch_utxos(network, addr):
    rows = json.loads(_http(f"{NETWORKS[network]['api']}/address/{addr}/utxo"))
    return [{"txid": r["txid"], "vout": r["vout"], "value": r["value"]} for r in rows]


def fetch_fee_rate(network, which="hourFee"):
    return float(json.loads(_http(f"{NETWORKS[network]['api']}/v1/fees/recommended"))[which])


def broadcast(network, raw_hex):
    return _http(f"{NETWORKS[network]['api']}/tx", data=raw_hex.encode()).strip()


# --------------------------------------------------------------------- core
def anchor(height, hash_hex, data, network="mainnet", fee_rate=None, manual_utxos=None,
           do_broadcast=False, max_fee_sats=DEFAULT_MAX_FEE_SATS, log_path=ANCHOR_LOG):
    """Build + sign an OP_RETURN anchor tx from the wallet. Broadcast only if do_broadcast."""
    priv, pub, addr = load_wallet(network)
    payload = build_payload(height, hash_hex, data)
    op_script = op_return_script(payload)
    utxos = manual_utxos if manual_utxos is not None else fetch_utxos(network, addr)
    if not utxos:
        raise SystemExit(f"No spendable coins at {addr}. Fund this address first.")
    rate = fee_rate if fee_rate is not None else fetch_fee_rate(network)

    # vsize estimate: 10.5 overhead + 68/input + 31 change + (9 + script) OP_RETURN output
    chosen, total = [], 0
    for u in sorted(utxos, key=lambda x: -x["value"]):
        chosen.append(u)
        total += u["value"]
        vsize_est = 11 + 68 * len(chosen) + 31 + 9 + len(op_script)
        fee = math.ceil(vsize_est * rate)
        if total >= fee + DUST_SATS:
            break
    else:
        raise SystemExit(f"Insufficient funds: have {total} sats, need about {fee + DUST_SATS}.")
    if fee > max_fee_sats:
        raise SystemExit(f"Fee {fee} sats exceeds cap {max_fee_sats} (raise --max-fee-sats to allow).")

    change = total - fee
    outputs = [(0, op_script), (change, p2wpkh_script(hash160(pub)))]
    raw, txid, vsize = sign_p2wpkh_tx(priv, pub, chosen, outputs)

    result = {"network": network, "address": addr, "txid": txid, "fee_sats": fee,
              "fee_rate": rate, "vsize": vsize, "payload_hex": payload.hex(),
              "digest": block_digest(data).hex(), "raw_tx": raw, "broadcast": False}
    if do_broadcast:
        result["txid"] = broadcast(network, raw)
        result["broadcast"] = True
    record = dict(result, height=height, hash=hash_hex, data=data, time=int(time.time()))
    record.pop("raw_tx")
    with open(log_path, "a") as fh:
        fh.write(json.dumps(record) + "\n")
    return result


# -------------------------------------------------------------------- tests
def selftest():
    # 1) RIPEMD-160 fallback agrees with the reference vector
    assert _ripemd160_py(b"abc").hex() == "8eb208f7e05d987a9b044a8e98c6b087f15a0bfc"
    # 2) BIP143 native P2WPKH test vector: sighash, deterministic signature and txid
    priv = int("619c335025c7f4012e556c2a58b2506e30b8511b53ade95ea316fd8c3286feb9", 16)
    pub = pubkey_compressed(priv)
    assert pub.hex() == "025476c2e83188368da1ff3e292e7acafcdb3566bb0ad253f62fc70f07aeee6357"
    assert hash160(pub).hex() == "1d0f172a0ecb48aee1be1f2687d2963ae33f71a1"
    h_prev = dsha256(bytes.fromhex("fff7f7881a8099afa6940d42d1e7f6362bec38171ea3edf433541db4e4ad969f00000000"
                                   "ef51e1b804cc89d182d279655c3aa89e815b1b309fe287d9b2b55d57b90ec68a01000000"))
    h_seq = dsha256(bytes.fromhex("eeffffff" "ffffffff"))
    h_out = dsha256(bytes.fromhex("202cb206000000001976a9148280b37df378db99f66f85c95a783a76ac7a6d5988ac"
                                  "9093510d000000001976a9143bde42dbee7e4dbe6a21b2d50ce2f0167faa815988ac"))
    pre = (struct.pack("<I", 1) + h_prev + h_seq
           + bytes.fromhex("ef51e1b804cc89d182d279655c3aa89e815b1b309fe287d9b2b55d57b90ec68a01000000")
           + b"\x19\x76\xa9\x14" + hash160(pub) + b"\x88\xac"
           + struct.pack("<q", 600000000) + bytes.fromhex("ffffffff") + h_out
           + struct.pack("<I", 0x11) + struct.pack("<I", 1))
    sighash = dsha256(pre)
    assert sighash.hex() == "c37af31116d1b27caf68aae9e3ac82f1477929014d5b917657d0eb49478cb670", "BIP143 sighash"
    der = ecdsa_sign_der(priv, int.from_bytes(sighash, "big"))
    assert der.hex() == ("304402203609e17b84f6a7d30c80bfa610b5b4542f32a8a0d5447a12fb1366d7f01cc44a"
                         "0220573a954c4518331561406f90300e8f3358f51928d43c212a8caed02de67eebee"), "signature"
    r = int.from_bytes(der[4:36], "big"); s = int.from_bytes(der[38:70], "big")
    assert ecdsa_verify(pub, int.from_bytes(sighash, "big"), r, s)
    # 3) address derivation (BIP173 example key => known address)
    assert segwit_v0_address("bc", bytes.fromhex("751e76e8199196d454941c45d1b3a323f1433bd6")) == \
        "bc1qw508d6qejxtdg4y5r3zarvary0c5xw7kv8f3t4"
    # 4) payload layout
    p = build_payload(965188, "00" * 32, {"a": 1})
    assert len(p) == 73 and p[:4] == MAGIC
    print("selftest: OK (RIPEMD-160, BIP143 sighash + RFC6979 signature, bech32, payload)")


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest="cmd", required=True)
    sub.add_parser("selftest")
    a = sub.add_parser("address"); a.add_argument("--network", default="mainnet", choices=NETWORKS)
    c = sub.add_parser("anchor")
    c.add_argument("--hash", required=True); c.add_argument("--height", type=int, required=True)
    c.add_argument("--data", help="JSON file with the decoded block fields to commit to")
    c.add_argument("--network", default="mainnet", choices=NETWORKS)
    c.add_argument("--fee-rate", type=float); c.add_argument("--max-fee-sats", type=int, default=DEFAULT_MAX_FEE_SATS)
    c.add_argument("--utxo", action="append", help="txid:vout:sats (skips the explorer lookup)")
    c.add_argument("--broadcast", action="store_true", help="actually send it (otherwise dry-run)")
    args = ap.parse_args()

    if args.cmd == "selftest":
        return selftest()
    if args.cmd == "address":
        print(load_wallet(args.network)[2]); return
    data = json.load(open(args.data)) if args.data else {"hash": args.hash, "height": args.height}
    utxos = None
    if args.utxo:
        utxos = [dict(zip(("txid", "vout", "value"), (t, int(v), int(s))))
                 for t, v, s in (u.split(":") for u in args.utxo)]
    if args.broadcast and input(f"Broadcast a real {args.network} transaction? type BROADCAST: ") != "BROADCAST":
        raise SystemExit("Cancelled.")
    res = anchor(args.height, args.hash, data, args.network, args.fee_rate, utxos,
                 args.broadcast, args.max_fee_sats)
    print(json.dumps({k: v for k, v in res.items() if k != "raw_tx"}, indent=2))
    if not res["broadcast"]:
        print("DRY-RUN: signed but not sent. Raw tx:\n" + res["raw_tx"])


if __name__ == "__main__":
    main()
