#!/usr/bin/env python3
"""
photon.py — sparse arbitrary-precision photon period decoder
Author: George Wagenknecht

512-bit-safe integer arithmetic:
- No NumPy int64 random-range operations.
- No dense 2**phase_bits histogram.
- Python integers represent phase bins and register size.
- Sparse dictionaries store only measured photon bins.
- Fraction arithmetic reconstructs periods exactly.

IMPORTANT:
This remains a simulated period-measurement pipeline. For small N,
the program can generate a reference order classically. For large N,
including 512-bit N, use --order only to test the photon decoder with
a supplied period. Supplying the order is NOT factoring N: it supplies
the key period that a real modular-exponentiation/quantum circuit would
have to produce. This script does not claim to factor unknown 512-bit
semiprimes efficiently.
"""

import argparse
import math
import random
import sys
import time
from collections import defaultdict
from fractions import Fraction


DEFAULT_PHOTONS = 12000
DEFAULT_DARK_RATE = 0.025
DEFAULT_REFERENCE_GAIN = 1.0
MAX_PHASE_BITS = 4096
MAX_CLASSICAL_ORDER_N_BITS = 24


def lcm(a, b):
    if not a or not b:
        return 0
    return abs(a // math.gcd(a, b) * b)


def poisson_sample(mean, rng):
    """Knuth Poisson sampler; avoids NumPy's int64-limited APIs."""
    mean = float(mean)
    if mean <= 0:
        return 0
    limit = math.exp(-mean)
    product = 1.0
    count = 0
    while product > limit:
        count += 1
        product *= rng.random()
    return count - 1


def compute_order_classically(a, n, max_steps=2_000_000):
    """Small-input simulation oracle; deliberately capped."""
    value = 1
    for r in range(1, max_steps + 1):
        value = (value * a) % n
        if value == 1:
            return r
    return None


def extract_factors(a, r, n):
    if r is None or r <= 0 or r % 2:
        return None

    x = pow(a, r // 2, n)
    if x in (1, n - 1):
        return None

    p = math.gcd(x - 1, n)
    q = math.gcd(x + 1, n)

    if p in (1, n) or q in (1, n) or p * q != n:
        return None

    return tuple(sorted((p, q)))


class PhotonPhaseSource:
    """
    Sparse phase-register detector.

    Q = 2**phase_bits may be vastly larger than int64.
    All bin arithmetic therefore uses Python integers.

    The simulated ideal peaks are near j*Q/r, where j is sampled
    uniformly from [0, r). Detector uncertainty is a small integer
    offset around each peak.
    """

    def __init__(self, order, phase_bits, photons, dark_rate, rng):
        self.order = int(order)
        self.phase_bits = int(phase_bits)
        self.photons = int(photons)
        self.dark_rate = float(dark_rate)
        self.rng = rng
        self.Q = 1 << self.phase_bits

        self.photon_events = 0
        self.dark_events = 0

    def measure(self):
        observed = defaultdict(float)
        reference = defaultdict(float)

        # Python's random.randrange supports arbitrary-size integers.
        # This replaces np.random.integers(0, Q), which is int64-limited.
        for _ in range(self.photons):
            j = self.rng.randrange(self.order)

            # Exact integer rounding of j*Q/order.
            k = (2 * j * self.Q + self.order) // (2 * self.order)

            # Small detector-bin uncertainty; modulo is arbitrary precision.
            k = (k + self.rng.choice((-1, 0, 1))) % self.Q
            observed[k] += 1.0

        # Common-mode dark events are recorded by both channels.
        # Digital subtraction can therefore cancel them.
        dark_count = poisson_sample(
            self.dark_rate * self.photons,
            self.rng
        )
        for _ in range(dark_count):
            k = self.rng.randrange(self.Q)
            observed[k] += 1.0
            reference[k] += 1.0

        self.photon_events = self.photons
        self.dark_events = dark_count
        return dict(observed), dict(reference)


class DigitalNoiseCancellation:
    def __init__(self, gain=DEFAULT_REFERENCE_GAIN):
        self.gain = float(gain)

    def process(self, observed, reference):
        residual = dict(observed)
        for k, value in reference.items():
            residual[k] = residual.get(k, 0.0) - self.gain * value
        return {k: value for k, value in residual.items() if value > 0.0}


class PhotonPeriodDecoder:
    """
    Converts measured bins k into exact fractions k/Q, then uses
    continued fractions to estimate their reduced denominators.

    Multiple denominators are combined with LCM. A recovered order
    is accepted only if modular exponentiation verifies a**r == 1 mod N.
    """

    def __init__(self, n, phase_bits, peak_count=4096):
        self.n = int(n)
        self.phase_bits = int(phase_bits)
        self.Q = 1 << self.phase_bits
        self.peak_count = int(peak_count)
        self.detected_peaks = []
        self.phase_estimates = []
        self.denominators = []

    def decode(self, residual):
        if not residual:
            return None

        peaks = sorted(
            residual.items(),
            key=lambda item: item[1],
            reverse=True
        )[:self.peak_count]

        self.detected_peaks = [int(k) for k, value in peaks if value > 0]
        combined = 1

        for k in self.detected_peaks:
            # Exact rational: no float conversion of a 512-bit phase.
            measured_phase = Fraction(int(k), self.Q)
            approximation = measured_phase.limit_denominator(self.n)

            self.phase_estimates.append(approximation)
            denominator = approximation.denominator

            if 1 < denominator <= self.n:
                self.denominators.append(denominator)
                combined = lcm(combined, denominator)

                # Stop if the accumulated period is already verified.
                # Verification is against N and a in the caller.
        return combined if combined > 1 else None


class PhotonOrderFinding:
    def __init__(self, n, photons, dark_rate, phase_bits, seed=None):
        self.n = int(n)
        self.photons = int(photons)
        self.dark_rate = float(dark_rate)
        self.phase_bits = int(phase_bits)
        self.rng = random.Random(seed)
        self.noise_cancellation = DigitalNoiseCancellation()
        self.total_photons = 0
        self.total_dark_counts = 0

    def measure_phase(self, order):
        source = PhotonPhaseSource(
            order=order,
            phase_bits=self.phase_bits,
            photons=self.photons,
            dark_rate=self.dark_rate,
            rng=self.rng
        )
        observed, reference = source.measure()
        residual = self.noise_cancellation.process(observed, reference)
        self.total_photons += source.photon_events
        self.total_dark_counts += source.dark_events
        return residual, source

    def recover_order(self, a, supplied_order):
        residual, source = self.measure_phase(supplied_order)
        decoder = PhotonPeriodDecoder(self.n, self.phase_bits)
        recovered = decoder.decode(residual)

        # LCM can recover r from several reduced fractions. Verify it.
        if recovered and pow(a, recovered, self.n) == 1:
            return recovered, {
                "source": source,
                "decoder": decoder,
                "residual": residual
            }

        # A denominator may be a divisor of r. If the LCM of observed
        # fractions is incomplete, report failure rather than inventing r.
        return None, {
            "source": source,
            "decoder": decoder,
            "residual": residual
        }


def factorise(
    n,
    photons=DEFAULT_PHOTONS,
    dark_rate=DEFAULT_DARK_RATE,
    phase_bits=None,
    max_attempts=20,
    seed=None,
    supplied_order=None,
    supplied_base=None,
    diagnostics=False
):
    start = time.perf_counter()

    if n <= 1:
        raise ValueError("Input must be greater than 1")
    if n % 2 == 0:
        return 2, n // 2
    root = math.isqrt(n)
    if root * root == n:
        return root, root

    required_bits = 2 * n.bit_length() + 2
    if phase_bits is None:
        phase_bits = required_bits
    if phase_bits < required_bits:
        raise ValueError(
            f"Need at least {required_bits} phase bits for this N; "
            f"received {phase_bits}."
        )
    if phase_bits > MAX_PHASE_BITS:
        raise ValueError(
            f"Phase register limited to {MAX_PHASE_BITS} bits."
        )

    if supplied_order is None and n.bit_length() > MAX_CLASSICAL_ORDER_N_BITS:
        raise ValueError(
            "A classical period oracle is intentionally disabled for "
            f"inputs above {MAX_CLASSICAL_ORDER_N_BITS} bits. For a 512-bit "
            "input, the real photon/modular-exponentiation circuit must "
            "supply the period. You can test the decoder with --order R, "
            "but that supplies the period and is not an unknown-factor solve."
        )

    rng = random.Random(seed)
    pipeline = PhotonOrderFinding(
        n=n,
        photons=photons,
        dark_rate=dark_rate,
        phase_bits=phase_bits,
        seed=seed
    )

    print("=" * 72)
    print("512-BIT-SAFE PHOTON PERIOD / FACTORISATION PIPELINE")
    print("=" * 72)
    print("N bits             :", n.bit_length())
    print("Phase bits         :", phase_bits)
    print("Phase register Q   :", f"2^{phase_bits}")
    print("Sparse photon bins : enabled")
    print("Integer arithmetic : arbitrary precision")
    print("Photon samples     :", photons)
    print("Dark rate          :", dark_rate)
    print("Period source      :", "supplied" if supplied_order else "small-N simulation")
    print()

    for attempt in range(1, max_attempts + 1):
        if supplied_order is not None:
            if supplied_base is None:
                raise ValueError("--order requires --base so the supplied period can be checked.")
            a = int(supplied_base)
            r = int(supplied_order)
            if not (1 < a < n and 1 < r <= n and pow(a, r, n) == 1):
                raise ValueError(
                    f"Supplied order {r} is not a valid period for base {a} modulo N."
                )
        else:
            a = rng.randrange(2, n - 1)
            g = math.gcd(a, n)
            if 1 < g < n:
                factors = tuple(sorted((g, n // g)))
                print("Direct GCD found factors:", factors)
                return factors
            r = compute_order_classically(a, n)
            if r is None:
                print(f"Attempt {attempt}: classical order cap reached; retrying.")
                continue

        print(f"Attempt {attempt}/{max_attempts} | base a = {a} | period input = {r}")

        recovered_order, details = pipeline.recover_order(a, r)

        if recovered_order is None:
            print("Photon period decoding did not recover a verified order.")
            if diagnostics:
                decoder = details["decoder"]
                print("Detected sparse bins:", decoder.detected_peaks[:12])
                print("Recovered denominators:", decoder.denominators[:12])
            continue

        print("Decoded order r     :", recovered_order)
        print("Order verification  :", pow(a, recovered_order, n) == 1)

        factors = extract_factors(a, recovered_order, n)
        if factors is None:
            print("Order did not yield non-trivial factors; trying another base.")
            continue

        p, q = factors
        elapsed = time.perf_counter() - start

        print()
        print("=" * 72)
        print("FACTORS RECOVERED")
        print("=" * 72)
        print("N =", n)
        print("p =", p)
        print("q =", q)
        print("p * q =", p * q)
        print("Verified =", p * q == n)
        print()
        print("Photon events       :", pipeline.total_photons)
        print("Dark events         :", pipeline.total_dark_counts)
        print("Sparse bins retained:", len(details["residual"]))
        print("Elapsed             :", f"{elapsed:.6f} s")
        print("=" * 72)
        return p, q

    print("No non-trivial factor pair recovered in the allotted attempts.")
    return None


def main():
    parser = argparse.ArgumentParser(
        description="Sparse arbitrary-precision photon period decoder"
    )
    parser.add_argument("number", type=lambda x: int(x, 0))
    parser.add_argument("--photons", type=int, default=DEFAULT_PHOTONS)
    parser.add_argument("--dark-rate", type=float, default=DEFAULT_DARK_RATE)
    parser.add_argument("--phase-bits", type=int, default=None)
    parser.add_argument("--attempts", type=int, default=20)
    parser.add_argument("--seed", type=int, default=None)
    parser.add_argument(
        "--order",
        type=lambda x: int(x, 0),
        default=None,
        help="Known period for decoder testing; does not solve unknown factorisation"
    )
    parser.add_argument(
        "--base",
        type=lambda x: int(x, 0),
        default=None,
        help="Base associated with --order"
    )
    parser.add_argument("--diagnostics", action="store_true")
    args = parser.parse_args()

    if args.photons < 100:
        parser.error("--photons must be at least 100")
    if args.dark_rate < 0:
        parser.error("--dark-rate cannot be negative")
    if args.attempts < 1:
        parser.error("--attempts must be at least 1")

    try:
        factorise(
            n=args.number,
            photons=args.photons,
            dark_rate=args.dark_rate,
            phase_bits=args.phase_bits,
            max_attempts=args.attempts,
            seed=args.seed,
            supplied_order=args.order,
            supplied_base=args.base,
            diagnostics=args.diagnostics
        )
    except (ValueError, OverflowError) as exc:
        parser.error(str(exc))


if __name__ == "__main__":
    main()
