"""
Optoelectronic circuit (optoelectronics_v2.png) driven by a real camera + ambient light,
with online next-tick forecasting. Single-file version.

  Camera (ambient light)  : right half of frame = detector A, left half = detector B.
                            A detector is HIGH when its half's brightness departs from a
                            slowly adapting baseline by more than --margin
                            (cover it with your hand, shine a torch on it, flip a lamp).
  Parallel drivers        : Driver A (randomized) -> a ; Driver B (deterministic) -> RC node
                            (tau 50 ms) -> NPN (V(C) > 0.7 V) -> b
  Main circuit (2x longer): AND(a,b) -> 150 ms delay -> and_dly -> accumulator (running AND)
                            and_dly OR Y(a OR b) -> D -> 74HC74 @ 10 Hz -> SELECT, observe
  Independent probe       : AND(a,b) -> flip noise (probe_err) -> probe log (stops at duration)
  Forecasting             : order-k Markov model predicts the next 100 ms tick of detector A,
                            detector B and a AND b, scored against chance and persistence.

Usage:
    pip install opencv-python numpy
    python optoelectronics_all.py                          # default webcam, 10 s probe
    python optoelectronics_all.py --mode dark --margin 25 --adapt 8 --lock-exposure
    python optoelectronics_all.py --camera clip.mp4 --no-preview

Press 'q' in the preview window to stop early.
"""

import argparse
import random
import threading
import time
from collections import defaultdict, deque
from dataclasses import dataclass, field
from math import comb

import cv2
import numpy as np

DT_MS = 1                 # simulation step (ms)
CLOCK_PERIOD_MS = 100     # 10 Hz clock, T = 100 ms
DELAY_MS = 150            # delay block
RC_TAU_MS = 50            # RC node time constant
RAIL_V = 5.0              # NPN +5 V rail
NPN_THRESHOLD_V = 0.7     # IF V(C) > 0.7 V THEN output HIGH




# ----------------------------------------------------------------------- drivers
class DriverA:
    """Randomized driver: output depends on x and a random coin."""

    def __init__(self, rng):
        self.rng = rng

    def drive(self, x, detector_bit):
        coin = self.rng.getrandbits(1)
        return int((x ^ coin) | detector_bit) if detector_bit else coin


class DriverB:
    """Deterministic driver: output is a pure function of x and detector B."""

    def drive(self, x, detector_bit):
        return int(x and detector_bit) or int(x)


class RCNode:
    """First-order RC: V(C) moves toward the drive level with time constant tau."""

    def __init__(self, tau_ms=RC_TAU_MS, rail=RAIL_V):
        self.tau = tau_ms
        self.rail = rail
        self.v = 0.0

    def step(self, drive_bit, dt_ms=DT_MS):
        target = self.rail if drive_bit else 0.0
        self.v += (target - self.v) * (dt_ms / self.tau)
        return self.v


class NPN:
    """IF V(C) > 0.7 V THEN output HIGH."""

    def __init__(self, threshold=NPN_THRESHOLD_V):
        self.threshold = threshold

    def out(self, v):
        return int(v > self.threshold)


# ------------------------------------------------------------------ main circuit
class DelayLine:
    def __init__(self, delay_ms=DELAY_MS, dt_ms=DT_MS):
        self.buf = deque([0] * int(delay_ms / dt_ms), maxlen=int(delay_ms / dt_ms))

    def step(self, bit):
        out = self.buf[0]
        self.buf.append(bit)
        return out


class Accumulator:
    """Running AND of every sample seen so far."""

    def __init__(self):
        self.value = 1

    def update(self, bit):
        self.value &= bit
        return self.value


class DFlipFlop74HC74:
    """Rising-edge D flip-flop. Q -> SELECT, not Q -> observe."""

    def __init__(self):
        self.q = 0
        self._prev_clk = 0

    def step(self, d, clk):
        if clk and not self._prev_clk:
            self.q = d
        self._prev_clk = clk
        return self.q, 1 - self.q


class Clock:
    def __init__(self, period_ms=CLOCK_PERIOD_MS):
        self.period = period_ms

    def level(self, t_ms):
        return int((t_ms % self.period) < self.period / 2)


# ------------------------------------------------------------- independent probe
@dataclass
class Probe:
    probe_err: float
    rng: random.Random
    log: list = field(default_factory=list)

    def sample(self, t_ms, a, b):
        truth = a & b
        measured = truth ^ int(self.rng.random() < self.probe_err)  # flip noise
        self.log.append({"t_ms": t_ms, "truth": truth, "measured": measured})
        return measured



# ------------------------------------------------------------------ forecasting
def binom_tail(hits, n, p=0.5):
    """P(X >= hits) for X ~ Binomial(n, p)."""
    if n == 0:
        return 1.0
    return sum(comb(n, k) * p**k * (1 - p) ** (n - k) for k in range(hits, n + 1))


class MarkovPredictor:
    """Order-k Markov model with Laplace smoothing; falls back to lower orders."""

    def __init__(self, order=3):
        self.order = order
        self.counts = [defaultdict(lambda: [0, 0]) for _ in range(order + 1)]
        self.hist = deque(maxlen=order)

    def prob_one(self):
        """Probability the next bit is 1, using the longest context seen so far."""
        h = tuple(self.hist)
        for k in range(min(len(h), self.order), -1, -1):
            n0, n1 = self.counts[k][h[len(h) - k:]]
            if n0 + n1 > 0:
                return (n1 + 1) / (n0 + n1 + 2)
        return 0.5

    def update(self, bit):
        h = tuple(self.hist)
        for k in range(min(len(h), self.order) + 1):
            self.counts[k][h[len(h) - k:]][bit] += 1
        self.hist.append(bit)


class StreamForecaster:
    def __init__(self, name, order=3):
        self.name = name
        self.model = MarkovPredictor(order)
        self.p1 = 0.5                  # current forecast: P(next bit = 1)
        self.last = None
        self.n = self.hits = self.persist_hits = 0
        self.ones = 0                  # for the majority-class baseline
        self.better = self.worse = 0   # ticks only the forecaster / only persistence got right
        self.ready = False             # True once a forecast exists to be scored

    @property
    def forecast(self):
        return int(self.p1 >= 0.5)

    def observe(self, bit):
        if self.ready:
            self.n += 1
            self.hits += int(self.forecast == bit)
            self.persist_hits += int(self.last == bit)
            self.ones += bit
            f_ok, p_ok = self.forecast == bit, self.last == bit
            self.better += int(f_ok and not p_ok)
            self.worse += int(p_ok and not f_ok)
        self.model.update(bit)
        self.last = bit
        self.p1 = self.model.prob_one()   # forecast for the NEXT tick
        self.ready = True

    def summary(self):
        if self.n == 0:
            return f"{self.name}: no scored forecasts yet"
        acc = self.hits / self.n
        pers = self.persist_hits / self.n
        major = max(self.ones, self.n - self.ones) / self.n
        # sign test on the ticks where forecaster and persistence disagree
        p = binom_tail(self.better, self.better + self.worse)
        if p < 0.05:
            verdict = "beats persistence"
        else:
            verdict = "no better than persistence"
        return (f"{self.name:<7} n={self.n:4d}  forecaster={acc:5.1%}  persistence={pers:5.1%}  "
                f"majority={major:5.1%}  wins/losses vs persistence={self.better}/{self.worse}  "
                f"p={p:.3f}  -> {verdict}")


# ---------------------------------------------------------------------- camera + run
class CameraBench:
    """Grabs frames in a background thread and exposes two ROI brightness values."""

    def __init__(self, source=0, margin=15.0, mirror=False, mode="either",
                 adapt_s=5.0, lock_exposure=False):
        src = int(source) if str(source).isdigit() else source
        self.is_file = not isinstance(src, int)
        self.cap = cv2.VideoCapture(src)
        if not self.cap.isOpened():
            raise RuntimeError(f"Could not open camera/source: {source!r}")
        self.margin = margin
        self.mirror = mirror
        self.mode = mode                         # dark | bright | either
        self.alpha = (DT_MS / 1000.0) / adapt_s  # baseline EMA step per 1 ms tick
        if lock_exposure:                        # best effort; driver dependent
            self.cap.set(cv2.CAP_PROP_AUTO_EXPOSURE, 0.25)
        self.baseline_a = self.baseline_b = None
        self.level_a = self.level_b = 0.0
        self.frame = None
        self._lock = threading.Lock()
        self._running = False

    # -- capture thread ------------------------------------------------------
    def start(self):
        self._running = True
        self._thread = threading.Thread(target=self._loop, daemon=True)
        self._thread.start()
        t0 = time.time()
        while self.frame is None:                # wait for the first frame
            if time.time() - t0 > 5:
                raise RuntimeError("Camera produced no frames")
            time.sleep(0.01)
        with self._lock:                         # no calibration: start from the first frame
            self.baseline_a, self.baseline_b = self.level_a, self.level_b

    def stop(self):
        self._running = False
        self._thread.join(timeout=1)
        self.cap.release()

    def _loop(self):
        while self._running:
            ok, frame = self.cap.read()
            if not ok:
                if self.is_file:                 # loop video files
                    self.cap.set(cv2.CAP_PROP_POS_FRAMES, 0)
                    continue
                time.sleep(0.01)
                continue
            if self.mirror:
                frame = cv2.flip(frame, 1)
            gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
            h, w = gray.shape
            left_b = float(np.mean(gray[:, : w // 2]))     # detector B
            right_a = float(np.mean(gray[:, w // 2:]))     # detector A
            with self._lock:
                self.level_a, self.level_b, self.frame = right_a, left_b, frame

    # -- detectors -----------------------------------------------------------
    def read_bits(self):
        with self._lock:
            a, b = self.level_a, self.level_b
        bit_a = self._detect(a - self.baseline_a)
        bit_b = self._detect(b - self.baseline_b)
        # slowly track ambient drift so only quick changes trigger
        self.baseline_a += self.alpha * (a - self.baseline_a)
        self.baseline_b += self.alpha * (b - self.baseline_b)
        return bit_a, bit_b

    def _detect(self, delta):
        if self.mode == "dark":
            return int(delta < -self.margin)
        if self.mode == "bright":
            return int(delta > self.margin)
        return int(abs(delta) > self.margin)

    def preview(self, bit_a, bit_b, status=""):
        with self._lock:
            frame = None if self.frame is None else self.frame.copy()
        if frame is None:
            return True
        h, w = frame.shape[:2]
        col = lambda bit: (0, 255, 0) if bit else (0, 0, 255)
        cv2.rectangle(frame, (w // 2, 0), (w - 1, h - 1), col(bit_a), 3)   # A
        cv2.rectangle(frame, (0, 0), (w // 2 - 1, h - 1), col(bit_b), 3)   # B
        cv2.putText(frame, f"B={bit_b}", (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.9, col(bit_b), 2)
        cv2.putText(frame, f"A={bit_a}", (w // 2 + 10, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.9, col(bit_a), 2)
        cv2.putText(frame, status, (10, h - 12), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 2)
        cv2.imshow("optoelectronics", frame)
        return (cv2.waitKey(1) & 0xFF) != ord("q")


def run(args):
    rng = random.Random(args.seed)
    bench = CameraBench(args.camera, margin=args.margin, mirror=args.mirror,
                        mode=args.mode, adapt_s=args.adapt,
                        lock_exposure=args.lock_exposure)
    bench.start()
    print("Running - cover/shade or light up one half of the view to trigger a detector.")

    drv_a, drv_b = DriverA(rng), DriverB()
    rc, npn = RCNode(), NPN()
    delay, acc, ff, clock = DelayLine(), Accumulator(), DFlipFlop74HC74(), Clock()
    probe = Probe(args.probe_err, rng)
    fc = {k: StreamForecaster(k, args.order) for k in ("det_a", "det_b", "truth")}

    main_duration = 2 * args.duration            # main circuit runs 2x longer
    trace = []
    start = time.perf_counter()
    last_preview = 0.0
    keep_going = True

    try:
        t = 0
        while t < main_duration and keep_going:
            # pace the loop to wall-clock time (1 ms logical ticks)
            while time.perf_counter() - start < t / 1000.0:
                time.sleep(0.0002)

            # camera -> detectors
            bit_a, bit_b = bench.read_bits()

            # parallel drivers
            a = drv_a.drive(args.x, bit_a)
            v_c = rc.step(drv_b.drive(args.x, bit_b))
            b = npn.out(v_c)

            # main circuit
            and_dly = delay.step(a & b)
            y = a | b                              # time code, forces HIGH
            d = and_dly | y                        # leak path
            select, observe = ff.step(d, clock.level(t))
            acc_val = acc.update(and_dly) if t >= DELAY_MS else 1

            # independent probe (stops at duration)
            if t < args.duration and t % CLOCK_PERIOD_MS == 0:
                probe.sample(t, a, b)

            trace.append(dict(t=t, det_a=bit_a, det_b=bit_b, a=a, b=b, v_c=v_c,
                              and_dly=and_dly, y=y, d=d,
                              select=select, observe=observe, acc=acc_val))

            # forecasting: score last tick's forecast, learn, forecast the next tick
            if t % CLOCK_PERIOD_MS == 0:
                fc["det_a"].observe(bit_a)
                fc["det_b"].observe(bit_b)
                fc["truth"].observe(a & b)

            # preview at ~30 fps
            now = time.perf_counter()
            if args.preview and now - last_preview > 0.033:
                status = (f"t={t}ms a={a} b={b} V(C)={v_c:.2f} | next-tick forecast: "
                          f"A={fc['det_a'].forecast} B={fc['det_b'].forecast} "
                          f"a&b={fc['truth'].forecast}")
                keep_going = bench.preview(bit_a, bit_b, status)
                last_preview = now

            t += DT_MS
    finally:
        bench.stop()
        if args.preview:
            cv2.destroyAllWindows()

    return trace, probe.log, fc


def main():
    p = argparse.ArgumentParser(description="Optoelectronic circuit driven by a real camera")
    p.add_argument("--camera", default="0", help="camera index or video file path")
    p.add_argument("--x", type=int, default=1, choices=[0, 1], help="problem instance bit")
    p.add_argument("--duration", type=int, default=10000, help="probe duration in ms")
    p.add_argument("--margin", type=float, default=15.0, help="brightness change (0-255) that counts as HIGH")
    p.add_argument("--probe-err", type=float, default=0.05, help="probe flip-noise probability")
    p.add_argument("--seed", type=int, default=None)
    p.add_argument("--mode", choices=["dark", "bright", "either"], default="either",
                   help="trigger on darkening, brightening, or any change")
    p.add_argument("--adapt", type=float, default=5.0,
                   help="seconds for the baseline to follow ambient light")
    p.add_argument("--lock-exposure", action="store_true",
                   help="try to turn off camera auto-exposure (driver dependent)")
    p.add_argument("--order", type=int, default=3, help="Markov order for forecasting")
    p.add_argument("--mirror", action="store_true", help="flip the image horizontally")
    p.add_argument("--no-preview", dest="preview", action="store_false")
    args = p.parse_args()

    trace, probe_log, fc = run(args)
    if not trace:
        return

    print("\n t(ms)  detA detB  a b  V(C)  and_dly  SELECT observe  ACC")
    for r in trace[::500]:
        print(f"{r['t']:6d}   {r['det_a']}    {r['det_b']}    {r['a']} {r['b']}  {r['v_c']:.2f}"
              f"     {r['and_dly']}      {r['select']}      {r['observe']}      {r['acc']}")

    errors = sum(r["truth"] != r["measured"] for r in probe_log)
    print(f"\nProbe samples: {len(probe_log)}, flipped by noise: {errors}")
    print("\nNext-tick (100 ms ahead) forecasts:")
    for f in fc.values():
        print("  " + f.summary())
    print(f"Main circuit ran {trace[-1]['t'] + DT_MS} ms (2x probe duration)")


if __name__ == "__main__":
    main()
