#!/usr/bin/env python3
"""
Camera-driven, paper-inspired optoelectronic viewport.

Implemented:
    Camera acquisition
    Frame-difference motion-energy mask
    Toy hash requested by the user
    Witness-base selection
    Driver A Miller-Rabin witness evaluation
    Live display
    Optional CSV logging

Explicit prototype choices:
    E = squared differences of consecutive grayscale frames
    E serialization = dimensions plus little-endian uint16 pixels
    SHA-256 replaced with the requested toy hash

Not supplied by the paper:
    Driver B's c(n)
    Executable reversed-process oracle
    Factor extraction

Those components return explicit status records, not exceptions
or fabricated results. No fallback factorization algorithm is used.
"""

import argparse
import csv
import math
import time
from pathlib import Path

import cv2
import numpy as np


def toy_hash(data):
    """Reproducible 16-bit toy hash."""
    value = 0

    for byte in data:
        value = (31 * value + byte) % 65536

    return value


def motion_energy(previous, current):
    """Prototype E: squared differences of grayscale intensities."""
    difference = (
        current.astype(np.int32)
        - previous.astype(np.int32)
    )
    return (difference * difference).astype(np.uint16)


def encode_energy(energy):
    """Encode dimensions and pixels reproducibly."""
    height, width = energy.shape

    header = (
        height.to_bytes(4, "little")
        + width.to_bytes(4, "little")
    )

    pixels = energy.astype("<u2", copy=False).tobytes(order="C")

    return header + pixels


def miller_rabin_witness(n, base):
    """True means this base establishes that n is composite.

    False means this base did not establish compositeness.
    It does not mean n is prime.
    """
    if n <= 3 or n % 2 == 0:
        raise ValueError("Driver A requires an odd integer greater than 3.")

    if not 2 <= base <= n - 2:
        raise ValueError("Witness base is outside the allowed range.")

    d = n - 1
    s = 0

    while d % 2 == 0:
        d //= 2
        s += 1

    value = pow(base, d, n)

    if value in (1, n - 1):
        return False

    for _ in range(s - 1):
        value = value * value % n

        if value == n - 1:
            return False

    return True


def driver_a(n, energy):
    """Camera energy -> toy hash -> witness base -> binary result."""
    hash_value = toy_hash(encode_energy(energy))
    base = 2 + hash_value % (n - 3)
    witness = miller_rabin_witness(n, base)

    return {
        "status": "evaluated",
        "hash": hash_value,
        "base": base,
        "value": int(witness),
    }


def driver_b(n):
    """Missing c(n) is represented explicitly, never as False or zero."""
    return {
        "status": "not_specified",
        "value": None,
        "reason": "The paper does not define c(n).",
    }


def reversed_process_oracle(state, history):
    """No hidden factorization implementation."""
    return {
        "status": "not_specified",
        "output": None,
        "factors": None,
        "reason": "The paper does not define the oracle's computation.",
    }


def read_gray(camera, width, height):
    success, frame = camera.read()

    if not success or frame is None:
        raise RuntimeError("The camera did not return a usable frame.")

    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

    return cv2.resize(
        gray,
        (width, height),
        interpolation=cv2.INTER_AREA,
    )


def shorten(value, length=65):
    text = str(value)

    if len(text) <= length:
        return text

    return text[:length - 3] + "..."


def make_viewport(gray, energy, lines):
    # Visual reflection only, not a temporal transformation.
    reflected = cv2.flip(gray, 1)

    motion = np.sqrt(
        energy.astype(np.float32)
    ).astype(np.uint8)

    panels = [
        cv2.cvtColor(gray, cv2.COLOR_GRAY2BGR),
        cv2.cvtColor(reflected, cv2.COLOR_GRAY2BGR),
        cv2.applyColorMap(motion, cv2.COLORMAP_TURBO),
    ]

    labels = (
        "Camera intensity",
        "Visual reflection only",
        "Motion energy",
    )

    for panel, label in zip(panels, labels):
        cv2.rectangle(
            panel,
            (0, 0),
            (panel.shape[1], 27),
            (0, 0, 0),
            -1,
        )
        cv2.putText(
            panel,
            label,
            (8, 19),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.45,
            (255, 255, 255),
            1,
            cv2.LINE_AA,
        )

    images = np.hstack(panels)

    banner = np.zeros(
        (30 * len(lines) + 15, images.shape[1], 3),
        dtype=np.uint8,
    )

    for index, line in enumerate(lines):
        cv2.putText(
            banner,
            line,
            (10, 25 + index * 30),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.5,
            (235, 235, 235),
            1,
            cv2.LINE_AA,
        )

    return np.vstack((banner, images))


def parse_arguments():
    parser = argparse.ArgumentParser(
        description="Camera viewport and Driver A prototype."
    )

    parser.add_argument(
        "n",
        type=int,
        help="Odd integer greater than 3",
    )
    parser.add_argument(
        "--camera",
        type=int,
        default=0,
        help="Camera index; default: 0",
    )
    parser.add_argument(
        "--width",
        type=int,
        default=320,
        help="Processing width; minimum: 320",
    )
    parser.add_argument(
        "--height",
        type=int,
        default=240,
        help="Processing height; minimum: 120",
    )
    parser.add_argument(
        "--seconds",
        type=float,
        default=30.0,
        help="Acquisition duration; default: 30 seconds",
    )
    parser.add_argument(
        "--csv",
        type=Path,
        help="Optional new CSV file; existing files are not overwritten",
    )

    args = parser.parse_args()

    if args.n <= 3 or args.n % 2 == 0:
        parser.error("n must be an odd integer greater than 3.")

    if args.width < 320 or args.height < 120:
        parser.error("Use width >= 320 and height >= 120.")

    if not math.isfinite(args.seconds) or args.seconds <= 0:
        parser.error("--seconds must be finite and positive.")

    return args


def run(args):
    camera = cv2.VideoCapture(args.camera)
    log_file = None
    writer = None

    frame_count = 0
    witness_count = 0
    distinct_bases = set()

    # Only the latest observation is retained.
    # This is an observation summary, not a definition of the paper's H_n.
    observation_summary = {}

    try:
        if not camera.isOpened():
            raise RuntimeError(
                f"Could not open camera {args.camera}. "
                "Check camera permissions and the device index."
            )

        if args.csv is not None:
            log_file = args.csv.open(
                "x",
                newline="",
                encoding="utf-8",
            )

            writer = csv.writer(log_file)
            writer.writerow([
                "frame",
                "elapsed_seconds",
                "toy_hash",
                "witness_base",
                "driver_a",
                "mean_motion_energy",
                "driver_b_status",
                "oracle_status",
            ])

        previous = read_gray(
            camera,
            args.width,
            args.height,
        )

        start = time.monotonic()

        while time.monotonic() - start < args.seconds:
            current = read_gray(
                camera,
                args.width,
                args.height,
            )

            energy = motion_energy(previous, current)
            previous = current

            a_result = driver_a(args.n, energy)
            b_result = driver_b(args.n)

            frame_count += 1
            witness_count += a_result["value"]
            distinct_bases.add(a_result["base"])

            observation_summary = {
                "n": args.n,
                "frames": frame_count,
                "witnesses_observed": witness_count,
                "distinct_bases": len(distinct_bases),
            }

            state = {
                "n": args.n,
                "driver_a": a_result,
                "driver_b": b_result,
            }

            oracle_result = reversed_process_oracle(
                state,
                observation_summary,
            )

            elapsed = time.monotonic() - start

            if writer is not None:
                writer.writerow([
                    frame_count,
                    f"{elapsed:.6f}",
                    a_result["hash"],
                    a_result["base"],
                    a_result["value"],
                    f"{float(energy.mean()):.6f}",
                    b_result["status"],
                    oracle_result["status"],
                ])

            conclusion = (
                "Composite: at least one witness observed"
                if witness_count
                else "No witness observed; primality not established"
            )

            lines = [
                f"n = {shorten(args.n)}",
                (
                    f"Frame {frame_count} | "
                    f"hash {a_result['hash']} | "
                    f"base {shorten(a_result['base'], 35)} | "
                    f"A = {a_result['value']}"
                ),
                conclusion,
                "Driver B: not specified | Oracle: not specified",
                "Factors: no result | Press Q to stop",
            ]

            display = make_viewport(
                current,
                energy,
                lines,
            )

            cv2.imshow("Camera optoelectronic viewport", display)

            if cv2.waitKey(1) & 0xFF == ord("q"):
                break

        print(f"Input: {args.n}")
        print(f"Frames processed: {frame_count}")
        print(f"Distinct bases: {len(distinct_bases)}")
        print(f"Witness observations: {witness_count}")

        if witness_count:
            print("Driver A conclusion: composite.")
        else:
            print("Driver A conclusion: primality not established.")

        print("Driver B: not specified; no value returned.")
        print("Oracle: not specified; no output returned.")
        print("Factorization: no result.")

    finally:
        camera.release()
        cv2.destroyAllWindows()

        if log_file is not None:
            log_file.close()


def main():
    args = parse_arguments()

    try:
        run(args)
    except KeyboardInterrupt:
        print("\nStopped by user.")
        return 130
    except (RuntimeError, OSError, cv2.error) as error:
        print(f"Error: {error}")
        return 1

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
