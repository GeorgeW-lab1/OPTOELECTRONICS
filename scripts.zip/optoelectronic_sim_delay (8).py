#!/usr/bin/env python3
"""
Webcam-driven simulation of the optoelectronic circuit with a DELAY LINE and a
meter that measures what the AND-accumulating "denoiser" recovers from the leak.

  IR detector A/B (two webcam ROIs) -> Driver A / Driver B
  Driver B -> RC node C -> NPN "IF V(C) > 0.7 V THEN output HIGH"  (B_out)
  A and B_out -> OR / AND gates
  Y (time code latched from an isolated number) forces D HIGH
  D = Y OR AND_dly                  [only with --leak]
  74HC74 D flip-flop clocked at 10 Hz -> Q = SELECT bit
  SELECT bits pooled into a word; attacker AND-accumulates words; SHA-256
  commitment confirms a correct accumulated guess.

Changes vs. previous version
  * --delay-ms default is now 150 (was 1e7 ms, which silently disabled the leak).
  * DelayLine picks the nearest sample (ties -> older) instead of "at least
    `delay` old"; --frame-hz (virtual clock, default 100) makes 50/100/150/300/600 ms
    land exactly on a frame. The effective delay is printed.
  * Warm-up: slot clock starts only after delay + 3*RC, so the delay line and RC
    node are filled and word 1 is not artificially clean.
  * Driver A is now SLOW by default (hash of a quantised, EMA-smoothed ROI mean),
    so the AND has temporal structure on the scale of tau. --a-step 0 restores the
    old white (per-frame coin flip) behaviour.
  * --delay-mode {post,a,b}: where the delay sits.
        post : AND -> delay -> D                      (original; pure shift)
        a    : delay A before the AND
        b    : delay B_out before the AND
    Only a/b can change statistics (AND duty, corrAB): they change the relative
    lag of two correlated signals. A pure post-AND delay of a stationary signal
    cannot change p_leak, because the secret bits are independent of it.
  * New meter column corrAB: correlation of A and the (possibly delayed) B_out.

AND probe reconstruction (--probe)
  The attacker taps the AND node. At each clock edge the probe says whether the
  corrupting bit was 1 (tainted slot) or 0 (clean slot):
      SELECT_i = 0                -> secret_i = 0   (noise only adds 1s; always certain)
      SELECT_i = 1, probe clean   -> secret_i = 1   (certain if probe is right)
      SELECT_i = 1, probe tainted -> unknown        (50/50)
  In delay-mode post the tap is the raw AND, so it must be re-aligned by the
  attacker's estimate of the delay (--probe-offset-ms is the error in that
  estimate; probe_err adds random probe misreads). Unknown bits are brute-forced
  against the commitment oracle (2^k candidates, k <= --max-unknown), so a word
  that leaves k unknown bits costs <= 2^k oracle queries instead of waiting for
  more words. Meter: known@1, probe words, oracle queries, probe error rate.

Usage
  python optoelectronic_sim_delay.py --leak --synthetic --headless --fast --delay-ms 150 --probe
  python optoelectronic_sim_delay.py --leak --synthetic --headless --fast \
        --sweep-delay 0,50,100,150,300,600 --trials 10 --delay-mode b
  python optoelectronic_sim_delay.py --leak --delay-ms 150            # webcam + window

Keys (window): q = quit, r = restart word
Requires: numpy, opencv-python (opencv only for webcam / window)
"""
import argparse
import collections
import hashlib
import math
import secrets
import time
import numpy as np

VCC = 5.0
V_BE = 0.7
R_OHM = 10e3
C_FARAD = 15e-6          # tau = RC = 0.15 s
CLK_PERIOD = 0.100       # 10 Hz
PHOTONS_PER_LEVEL = 4.0  # synthetic camera: photon shot-noise scale


# --------------------------------------------------------------------------- time
class Clock:
    """Real time, or virtual time (--fast) advanced one frame per tick."""
    def __init__(self, virtual=False, frame_dt=1 / 30):
        self.virtual, self.frame_dt, self.t = virtual, frame_dt, 0.0

    def now(self):
        return self.t if self.virtual else time.time()

    def tick(self):
        if self.virtual:
            self.t += self.frame_dt


# --------------------------------------------------------------------------- sources
class Camera:
    def __init__(self, index, clock, synthetic=False, seed=1):
        self.synthetic, self.clock = synthetic, clock
        self.t0 = clock.now()
        self.rng = np.random.default_rng(seed)
        if not synthetic:
            import cv2
            self.cap = cv2.VideoCapture(index)
            if not self.cap.isOpened():
                raise RuntimeError(f"Cannot open webcam {index}")

    def read(self):
        """Return (gray uint8 image, bgr image)."""
        if self.synthetic:
            t = self.clock.now() - self.t0
            h, w = 120, 160
            base = np.zeros((h, w), np.float32)
            base[:, : w // 2] = 110 + 90 * np.sin(2 * np.pi * 0.4 * t)       # B side
            base[:, w // 2:] = 110 + 90 * np.sin(2 * np.pi * 0.7 * t + 1.0)  # A side
            lam = np.clip(base, 0, None) * PHOTONS_PER_LEVEL                 # photon shot noise
            img = np.clip(self.rng.poisson(lam) / PHOTONS_PER_LEVEL, 0, 255).astype(np.uint8)
            return img, np.dstack([img, img, img])
        import cv2
        ok, bgr = self.cap.read()
        if not ok:
            raise RuntimeError("Webcam read failed")
        return cv2.cvtColor(bgr, cv2.COLOR_BGR2GRAY), bgr

    def release(self):
        if not self.synthetic:
            self.cap.release()


# --------------------------------------------------------------------------- circuit blocks
class DriverB:
    """Deterministic Schmitt comparator on detector-B intensity; threshold set by instance x."""
    def __init__(self, x):
        self.thr = 0.30 + 0.40 * (((x * 2654435761) % 2**32) / 2**32)
        self.hyst = 0.03
        self.state = False

    def step(self, intensity):
        if self.state and intensity < self.thr - self.hyst:
            self.state = False
        elif not self.state and intensity > self.thr + self.hyst:
            self.state = True
        return VCC if self.state else 0.0


class DriverA:
    """Randomized driver on detector A.
    q_step == 0 : legacy, hash parity of the raw ROI (white, fresh coin each frame).
    q_step  > 0 : hash parity of the quantised EMA of the ROI mean. The output only
                  changes when the smoothed intensity crosses a bin edge (photon noise
                  dithers it near edges), so A has memory on the scale of tau_a."""
    def __init__(self, tau_a=0.1, q_step=16.0):
        self.tau_a, self.q_step, self.ema = tau_a, q_step, None

    def step(self, roi, dt):
        if self.q_step <= 0:
            digest = hashlib.sha256(np.ascontiguousarray(roi).tobytes()).digest()
        else:
            m = float(roi.mean())
            if self.ema is None or self.tau_a <= 0:
                self.ema = m
            else:
                self.ema += (m - self.ema) * (1 - math.exp(-dt / self.tau_a))
            level = int(self.ema // self.q_step)
            digest = hashlib.sha256(str(level).encode()).digest()
        return VCC if digest[0] & 1 else 0.0


class IfThenLink:
    """RC node + NPN: IF V(C) > 0.7 V THEN output HIGH."""
    def __init__(self):
        self.vc = 0.0

    def step(self, v_drive, dt):
        self.vc += (v_drive - self.vc) * (1 - np.exp(-dt / (R_OHM * C_FARAD)))
        return VCC if self.vc > V_BE else 0.0


class DelayLine:
    """Transport delay: output is the stored sample nearest to (t - delay); ties go to the
    older sample. Before the line is full it holds the first value (see warm-up)."""
    def __init__(self, delay_s):
        self.delay = delay_s
        self.q = collections.deque()

    def step(self, t, v, dt):
        self.q.append((t, bool(v)))
        target = t - self.delay
        while len(self.q) > 1 and self.q[1][0] <= target + 0.5 * dt - 1e-9:
            self.q.popleft()
        return self.q[0][1]


class TimeCodeLatch:
    def __init__(self, value, nbits):
        self.value, self.nbits = value, nbits

    def bit(self, slot):
        return (self.value >> (self.nbits - 1 - slot)) & 1


class DFlipFlop74HC74:
    def __init__(self):
        self.q = 0

    def clock(self, d):
        self.q = int(d)


def hi(v):
    return v > VCC / 2


# --------------------------------------------------------------------------- commitment
def commit_hash(salt, value, nbits):
    return hashlib.sha256(f"{salt}:{value:0{nbits // 4}X}".encode()).hexdigest()


class Verifier:
    """Holds only a salted SHA-256 commitment, never the number."""
    def __init__(self, value, nbits, salt=None):
        self.nbits = nbits
        self.salt = salt or secrets.token_hex(8)
        self.commitment = commit_hash(self.salt, value, nbits)

    def check(self, value):
        return secrets.compare_digest(commit_hash(self.salt, value, self.nbits), self.commitment)


# --------------------------------------------------------------------------- attacker + meter
class AndAccumulator:
    """Noise only adds 1s, so AND-ing SELECT words strips it."""
    def __init__(self, nbits):
        self.nbits = nbits
        self.acc = (1 << nbits) - 1
        self.ones = np.zeros(nbits, int)
        self.n = 0

    def update(self, word):
        self.acc &= word
        self.n += 1
        for i in range(self.nbits):
            self.ones[i] += (word >> (self.nbits - 1 - i)) & 1

    def confidence(self):
        zero_pos = [i for i in range(self.nbits)
                    if not (self.acc >> (self.nbits - 1 - i)) & 1]
        if self.n == 0 or not zero_pos:
            return 0.0
        p = float(np.mean([self.ones[i] / self.n for i in zero_pos]))
        return (1 - p ** self.n) ** (self.nbits - len(zero_pos))


class ProbeAttacker:
    """Reconstructs the secret from SELECT words + AND-probe taint flags."""
    def __init__(self, nbits, confirm=1):
        self.n, self.confirm = nbits, confirm
        self.zero = np.zeros(nbits, bool)
        self.clean1 = np.zeros(nbits, int)

    def update(self, sel_bits, taint_bits):
        for i, (sb, tb) in enumerate(zip(sel_bits, taint_bits)):
            if sb == 0:
                self.zero[i] = True          # certain: noise cannot clear a bit
            elif not tb:
                self.clean1[i] += 1          # SELECT=1 with no noise -> secret=1

    def known(self):
        return [0 if self.zero[i] else (1 if self.clean1[i] >= self.confirm else None)
                for i in range(self.n)]

    def n_known(self):
        return sum(k is not None for k in self.known())

    def candidates(self, max_unknown):
        kn = self.known()
        unk = [i for i, k in enumerate(kn) if k is None]
        if len(unk) > max_unknown:
            return
        base = 0
        for i, k in enumerate(kn):
            if k == 1:
                base |= 1 << (self.n - 1 - i)
        for m in range((1 << len(unk)) - 1, -1, -1):   # all-ones guess first
            v = base
            for j, i in enumerate(unk):
                if (m >> j) & 1:
                    v |= 1 << (self.n - 1 - i)
            yield v


def h2(p):
    return 0.0 if p <= 0 or p >= 1 else -p * math.log2(p) - (1 - p) * math.log2(1 - p)


def zchannel_info(p):
    """I(X;Y) in bits for uniform input through a Z-channel (1->1 always, 0->1 w.p. p)."""
    return h2(0.5 + 0.5 * p) - 0.5 * h2(p)


def safe_corr(x, y):
    x, y = np.asarray(x, float), np.asarray(y, float)
    if len(x) < 3 or x.std() == 0 or y.std() == 0:
        return 0.0
    return float(np.corrcoef(x, y)[0, 1])


class LeakMeter:
    """Scores the leak. Uses the true secret only for scoring, never for attacking."""
    def __init__(self, secret, nbits):
        self.secret, self.nbits = secret, nbits
        self.y, self.and_raw, self.and_dly = [], [], []
        self.fa, self.fb = [], []
        self.probe_est = []
        self.frames = self.and_frames = 0
        self.hamming = []

    def frame(self, g_and, a, b_eff):
        self.frames += 1
        self.and_frames += int(g_and)
        self.fa.append(int(a)); self.fb.append(int(b_eff))

    def slot(self, y, g_and, g_and_dly, probe=None):
        self.y.append(int(y)); self.and_raw.append(int(g_and)); self.and_dly.append(int(g_and_dly))
        if probe is not None:
            self.probe_est.append(int(probe))

    def word(self, acc):
        self.hamming.append(bin(acc ^ self.secret).count("1"))

    def summary(self):
        y, ad = np.array(self.y), np.array(self.and_dly, float)
        zeros = ad[y == 0]
        p_leak = float(zeros.mean()) if len(zeros) else float("nan")
        ac = safe_corr(ad[:-1], ad[1:]) if len(ad) > 2 else 0.0
        return dict(duty=self.and_frames / max(1, self.frames), p_leak=p_leak, autocorr=ac,
                    corr_ab=safe_corr(self.fa, self.fb),
                    probe_err=(float(np.mean(np.array(self.probe_est) != ad)) if self.probe_est else float("nan")),
                    bits_per_word=zchannel_info(p_leak) * self.nbits if p_leak == p_leak else 0.0,
                    hamming=self.hamming)


# --------------------------------------------------------------------------- drawing
def draw(frame, roiB, roiA, text_lines, traces):
    import cv2
    h, w = frame.shape[:2]
    out = frame.copy()
    cv2.rectangle(out, (roiB[0], roiB[1]), (roiB[2], roiB[3]), (60, 60, 255), 2)
    cv2.putText(out, "IR det B", (roiB[0] + 4, roiB[1] + 18), 0, 0.5, (60, 60, 255), 1)
    cv2.rectangle(out, (roiA[0], roiA[1]), (roiA[2], roiA[3]), (60, 200, 60), 2)
    cv2.putText(out, "IR det A", (roiA[0] + 4, roiA[1] + 18), 0, 0.5, (60, 200, 60), 1)
    y = h - 8 - 16 * len(text_lines)
    for line in text_lines:
        cv2.putText(out, line, (8, y), cv2.FONT_HERSHEY_SIMPLEX, 0.45, (255, 255, 255), 1, cv2.LINE_AA)
        y += 16

    names = ["A", "B_out", "OR", "AND", "AND_dly", "Y", "D", "SELECT"]
    pw, rowh = max(w, 480), 22
    panel = np.full((rowh * len(names) + 8, pw, 3), 25, np.uint8)
    for i, n in enumerate(names):
        y0 = 4 + i * rowh
        cv2.putText(panel, n, (4, y0 + 15), cv2.FONT_HERSHEY_SIMPLEX, 0.4, (200, 200, 200), 1)
        data = list(traces[n])[-(pw - 70):]
        pts = [(60 + k, y0 + (4 if v else 17)) for k, v in enumerate(data)]
        for p, q in zip(pts[:-1], pts[1:]):
            cv2.line(panel, p, q, (0, 220, 255), 1)
    if panel.shape[1] != out.shape[1]:
        pad = np.zeros((out.shape[0], panel.shape[1] - out.shape[1], 3), np.uint8)
        out = np.hstack([out, pad])
    return np.vstack([out, panel])


# --------------------------------------------------------------------------- one session
def effective_delay_ms(cfg, delay_ms):
    if not cfg.fast:
        return delay_ms
    dt = 1.0 / cfg.frame_hz
    return math.floor(delay_ms / 1000.0 / dt + 0.5 - 1e-9) * dt * 1000.0


def run_session(cfg, delay_ms, seed=1, verbose=True):
    nbits = max(4, cfg.bits - cfg.bits % 4)
    mask = (1 << nbits) - 1
    secret = (int(cfg.secret, 16) if cfg.secret else secrets.randbits(nbits)) & mask
    hexw = nbits // 4
    verifier = Verifier(secret, nbits)
    max_words = cfg.runs or (200 if (cfg.sweep_delay or not cfg.leak or cfg.probe) else 0)

    clock = Clock(virtual=cfg.fast, frame_dt=1.0 / cfg.frame_hz)
    cam = Camera(cfg.cam, clock, cfg.synthetic, seed)
    drvA = DriverA(cfg.a_tau, cfg.a_step)
    drvB, link = DriverB(cfg.x), IfThenLink()
    delay = DelayLine(delay_ms / 1000.0)
    latch, ff = TimeCodeLatch(secret, nbits), DFlipFlop74HC74()
    traces = collections.defaultdict(lambda: collections.deque(maxlen=600))
    attacker, meter = AndAccumulator(nbits), LeakMeter(secret, nbits)
    probe_line = DelayLine(max(0.0, delay_ms + cfg.probe_offset_ms) / 1000.0)
    patk = ProbeAttacker(nbits, cfg.confirm)
    prng = np.random.default_rng(seed + 777)
    taint_bits, known_at_1 = [], None
    base_words = probe_words = cert_words = None
    cert_ok = None
    queries = 0

    slot, select_bits, runs, recovered = 0, [], 0, None
    HID = "*" * hexw
    last_t = clock.now()
    warmup = delay_ms / 1000.0 + 3 * R_OHM * C_FARAD     # fill delay line + settle RC
    next_clk = last_t + warmup + CLK_PERIOD
    prev_I_B = None

    try:
        while True:
            gray, bgr = cam.read()
            clock.tick()
            now = clock.now()
            dt, last_t = now - last_t, now
            h, w = gray.shape
            roiB_box = (0, 0, w // 2 - 4, h - 1)
            roiA_box = (w // 2 + 4, 0, w - 1, h - 1)
            roiB = gray[roiB_box[1]:roiB_box[3], roiB_box[0]:roiB_box[2]]
            roiA = gray[roiA_box[1]:roiA_box[3], roiA_box[0]:roiA_box[2]]

            I_B = float(roiB.mean()) / 255.0
            d_int = 0.0 if prev_I_B is None else I_B - prev_I_B
            prev_I_B = I_B

            vA, vB = drvA.step(roiA, max(dt, 1e-6)), drvB.step(I_B)
            vB_out = link.step(vB, dt)
            a, b = hi(vA), hi(vB_out)
            g_or = a or b

            if cfg.delay_mode == "a":
                a_eff, b_eff = delay.step(now, a, dt), b
                g_and = a_eff and b_eff
                g_and_dly = g_and
            elif cfg.delay_mode == "b":
                a_eff, b_eff = a, delay.step(now, b, dt)
                g_and = a_eff and b_eff
                g_and_dly = g_and
            else:                                            # post: AND -> delay -> D
                a_eff, b_eff = a, b
                g_and = a and b
                g_and_dly = delay.step(now, g_and, dt)
            if cfg.delay_mode == "post":                   # raw AND tap, re-aligned by attacker's tau_hat
                p_est = probe_line.step(now, g_and, dt)
            else:                                          # tap already sits after the delayed input
                p_est = g_and
            if cfg.probe_err > 0 and prng.random() < cfg.probe_err:
                p_est = not p_est
            if now > warmup + 0.0:
                meter.frame(g_and, a_eff, b_eff)

            y = bool(latch.bit(slot))
            d = y or (g_and_dly and cfg.leak)

            for k, v in zip(["A", "B_out", "OR", "AND", "AND_dly", "Y", "D", "SELECT"],
                            [a, b, g_or, g_and, g_and_dly, y, d, ff.q]):
                traces[k].append(int(v))

            if now >= next_clk:                              # 10 Hz clock edge
                next_clk += CLK_PERIOD
                meter.slot(y, g_and, g_and_dly, p_est)
                ff.clock(d)
                select_bits.append(ff.q)
                taint_bits.append(int(p_est))
                slot += 1

                if slot == nbits:
                    val = int("".join(map(str, select_bits)), 2)
                    attacker.update(val)                     # attacker sees only SELECT
                    ok = verifier.check(attacker.acc)        # baseline: one oracle query per word
                    meter.word(attacker.acc)
                    runs += 1
                    if ok and base_words is None:
                        base_words, recovered = runs, attacker.acc
                    if cfg.probe:
                        patk.update(select_bits, taint_bits)
                        if known_at_1 is None:
                            known_at_1 = patk.n_known()
                        if cert_words is None and patk.n_known() == nbits:
                            cert_words = runs
                            kv = patk.known()
                            cert_ok = int("".join(map(str, kv)), 2) == secret
                        if probe_words is None:
                            for cand in patk.candidates(cfg.max_unknown):
                                queries += 1
                                if verifier.check(cand):
                                    probe_words = runs
                                    break
                    if verbose:
                        tag = "RECOVERED" if ok else "waiting"
                        sh = f"{val:0{hexw}X}" if (ok or cfg.reveal) else HID
                        gh = f"{attacker.acc:0{hexw}X}" if (ok or cfg.reveal) else HID
                        extra = (f"  known={patk.n_known():2d}/{nbits}  probe={'HIT' if probe_words else '-'}"
                                 if cfg.probe else "")
                        print(f"run {runs:3d}  SELECT={sh}  ACC={gh}  "
                              f"hamming={meter.hamming[-1]:2d}  conf~{attacker.confidence():.4f}  {tag}{extra}"
                              + (f"  (hidden={secret:0{hexw}X})" if cfg.reveal else ""))
                    slot, select_bits, taint_bits = 0, [], []
                    done = base_words is not None and (not cfg.probe or probe_words is not None)
                    if done or (max_words and runs >= max_words):
                        break

            if cfg.headless:
                if not cfg.fast:
                    time.sleep(0.01)
                continue

            import cv2
            sel = "".join(map(str, select_bits))
            lines = [f"I_B={I_B:.2f} dI={d_int:+.3f}  Vc={link.vc:.2f}V  thr={drvB.thr:.2f}  "
                     f"delay={delay_ms:.0f}ms ({cfg.delay_mode})",
                     f"A={int(a)} Bout={int(b)} OR={int(g_or)} AND={int(g_and)} "
                     f"ANDdly={int(g_and_dly)} Y={int(y)} D={int(d)} Q={ff.q}",
                     f"slot {slot}/{nbits}  SELECT bits={sel}",
                     f"ACC hamming={meter.hamming[-1] if meter.hamming else nbits}  runs={runs}"]
            cv2.imshow("optoelectronic sim", draw(bgr, roiB_box, roiA_box, lines, traces))
            k = cv2.waitKey(1) & 0xFF
            if k == ord("q"):
                break
            if k == ord("r"):
                slot, select_bits, taint_bits = 0, [], []
    finally:
        cam.release()
        if not cfg.headless:
            import cv2
            cv2.destroyAllWindows()

    s = meter.summary()
    s.update(known_at_1=known_at_1, base_words=base_words, probe_words=probe_words,
             cert_words=cert_words, cert_ok=cert_ok, queries=queries,
             recovered=recovered is not None, words=runs, secret=secret, acc=attacker.acc,
             commitment=verifier.commitment, hexw=hexw)
    return s


# --------------------------------------------------------------------------- main
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--cam", type=int, default=0)
    ap.add_argument("--synthetic", action="store_true", help="fake camera (no hardware)")
    ap.add_argument("--headless", action="store_true")
    ap.add_argument("--fast", action="store_true",
                    help="virtual time, no sleeping; needs --synthetic --headless")
    ap.add_argument("--frame-hz", type=float, default=100.0,
                    help="virtual frame rate for --fast (default 100 -> 10 ms delay resolution)")
    ap.add_argument("--bits", type=int, default=16)
    ap.add_argument("--secret", default=None, help="hidden number, hex (default random)")
    ap.add_argument("--reveal", action="store_true")
    ap.add_argument("--x", type=int, default=12345)
    ap.add_argument("--leak", action="store_true", help="enable D = Y OR AND_dly")
    ap.add_argument("--delay-ms", type=float, default=100000.0, help="delay (default 150 ms ~ RC tau)")
    ap.add_argument("--delay-mode", choices=["post", "a", "b"], default="post",
                    help="post: AND->delay->D; a/b: delay input A or B_out before the AND")
    ap.add_argument("--a-tau", type=float, default=0.1, help="Driver A EMA time constant, s")
    ap.add_argument("--a-step", type=float, default=16.0,
                    help="Driver A quantisation step in grey levels; 0 = legacy white A")
    ap.add_argument("--probe", action="store_true", help="attacker also taps the AND node")
    ap.add_argument("--probe-offset-ms", type=float, default=0.0,
                    help="error in attacker's estimate of the delay (post mode)")
    ap.add_argument("--probe-err", type=float, default=0.0, help="random probe misread probability")
    ap.add_argument("--confirm", type=int, default=1, help="clean-1 sightings needed to lock a 1")
    ap.add_argument("--max-unknown", type=int, default=12, help="brute-force at most 2^N candidates/word")
    ap.add_argument("--sweep-delay", default=None, help="comma list of delays in ms")
    ap.add_argument("--trials", type=int, default=10, help="trials per sweep point")
    ap.add_argument("--runs", type=int, default=0, help="stop after N words (0 = until recovered)")
    cfg = ap.parse_args()

    if cfg.fast and not (cfg.synthetic and cfg.headless):
        ap.error("--fast requires --synthetic and --headless")

    if not cfg.sweep_delay:
        if not cfg.leak:
            print("Note: without --leak, D == Y, so the first SELECT word equals the secret.")
        s = run_session(cfg, cfg.delay_ms)
        print(f"\ncommitment : {s['commitment']}")
        print(f"delay      : {cfg.delay_ms:.0f} ms requested, {effective_delay_ms(cfg, cfg.delay_ms):.0f} ms "
              f"effective ({cfg.delay_mode})")
        print(f"AND duty   : {s['duty']:.3f}")
        print(f"corrAB     : {s['corr_ab']:+.3f}   (A vs B_out at the AND inputs)")
        print(f"p_leak     : {s['p_leak']:.3f}   (P[AND_dly=1 | secret bit=0])")
        print(f"autocorr   : {s['autocorr']:+.3f}   (lag-1, successive slots)")
        print(f"leak/word  : {s['bits_per_word']:.2f} of {cfg.bits} bits (Z-channel)")
        if cfg.probe:
            print(f"probe      : err vs true AND_dly {s['probe_err']:.3f}; bits known after word 1: "
                  f"{s['known_at_1']}/{cfg.bits}")
            print(f"probe recon: recovered at word {s['probe_words']} using {s['queries']} oracle queries "
                  f"(AND-accumulate alone: word {s['base_words']}, 1 query/word)")
            print(f"certified without oracle: word {s['cert_words']}  correct={s['cert_ok']}")
        if s["recovered"]:
            print(f"SECRET RECOVERED after {s['words']} words: {s['acc']:0{s['hexw']}X}")
        else:
            print(f"Not recovered after {s['words']} words; best guess {s['acc']:0{s['hexw']}X}")
        return

    delays = [float(v) for v in cfg.sweep_delay.split(",")]
    cfg.headless = True
    print(f"Sweep: {cfg.trials} trials/point, {cfg.bits}-bit secret, leak={'on' if cfg.leak else 'OFF'}, "
          f"mode={cfg.delay_mode}, A={'white' if cfg.a_step <= 0 else f'slow(tau={cfg.a_tau}s,step={cfg.a_step})'}\n")
    pcols = f" {'probeErr':>8} {'known@1':>8} {'base wds':>9} {'probe wds':>10} {'queries':>8} {'cert ok':>8}" if cfg.probe else ""
    print(f"{'delay ms':>8} {'eff ms':>7} {'AND duty':>9} {'corrAB':>7} {'p_leak':>7} {'autocorr':>9} "
          f"{'bits/word':>10} {'recovered':>10} {'words (mean)':>13} {'Hamming@5':>10}" + pcols)
    for dly in delays:
        res = [run_session(cfg, dly, seed=1000 + i, verbose=False) for i in range(cfg.trials)]
        rec = [r["words"] for r in res if r["recovered"]]
        h5 = [r["hamming"][min(4, len(r["hamming"]) - 1)] for r in res]
        line = (f"{dly:8.0f} {effective_delay_ms(cfg, dly):7.0f} "
                f"{np.mean([r['duty'] for r in res]):9.3f} "
                f"{np.mean([r['corr_ab'] for r in res]):+7.3f} "
                f"{np.nanmean([r['p_leak'] for r in res]):7.3f} "
                f"{np.mean([r['autocorr'] for r in res]):+9.3f} "
                f"{np.mean([r['bits_per_word'] for r in res]):10.2f} "
                f"{len(rec):>6}/{cfg.trials:<3} "
                f"{(np.mean(rec) if rec else float('nan')):13.1f} {np.mean(h5):10.2f}")
        if cfg.probe:
            pw = [r["probe_words"] for r in res if r["probe_words"]]
            bw = [r["base_words"] for r in res if r["base_words"]]
            co = [r["cert_ok"] for r in res if r["cert_ok"] is not None]
            line += (f" {np.nanmean([r['probe_err'] for r in res]):8.3f}"
                     f" {np.mean([r['known_at_1'] for r in res]):8.1f}"
                     f" {(np.mean(bw) if bw else float('nan')):9.2f}"
                     f" {(np.mean(pw) if pw else float('nan')):10.2f}"
                     f" {np.mean([r['queries'] for r in res]):8.1f}"
                     f" {(sum(co) if co else 0):>4}/{len(co):<3}")
        print(line)


if __name__ == "__main__":
    main()
