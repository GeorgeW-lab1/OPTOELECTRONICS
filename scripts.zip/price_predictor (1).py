#!/usr/bin/env python3
"""
Webcam-driven simulation of the optoelectronic circuit:

IR detector A/B (two webcam ROIs) -> Driver A (randomized) / Driver B (deterministic)
Driver B -> RC node C -> NPN "IF V(C) > 0.7 V THEN output HIGH" (IF/THEN link)
A and B_out -> OR / AND gates
Y (time code, latched from an isolated number) forces D HIGH
74HC74 D flip-flop clocked at 10 Hz (T = 100 ms) -> SELECT bit
SELECT bits are pooled into a hex number and compared with the isolated number.

The isolated number is now the LIVE Bitcoin BTC-USD price, converted into the
latch word width. It is refreshed whenever a new live Coinbase price arrives.

Usage:
python optoelectronic_sim-5.py --price
python optoelectronic_sim-5.py --price --price-poll 2
python optoelectronic_sim-5.py --synthetic --headless --price --runs 5
python optoelectronic_sim-5.py --cam 1 --price --bits 16

Keys (window): q = quit, r = restart word.
Requires: numpy, opencv-python
"""

import argparse
import collections
import json
import queue
import threading
import time
import urllib.request

import numpy as np

VCC = 5.0
V_BE = 0.7
R_OHM = 10e3
C_FARAD = 15e-6  # tau = RC = 0.15 s
CLK_PERIOD = 0.100  # 10 Hz


# --------------------------------------------------------------------------- sources
class Camera:
    def __init__(self, index, synthetic=False):
        self.synthetic = synthetic
        self.t0 = time.time()
        self.rng = np.random.default_rng(1)

        if not synthetic:
            import cv2
            self.cap = cv2.VideoCapture(index)
            if not self.cap.isOpened():
                raise RuntimeError(f"Cannot open webcam {index}")

    def read(self):
        """Return (gray uint8 image, bgr image)."""
        import cv2

        if self.synthetic:
            t = time.time() - self.t0
            h, w = 240, 320
            base = np.zeros((h, w), np.float32)
            base[:, : w // 2] = 110 + 90 * np.sin(2 * np.pi * 0.4 * t)
            base[:, w // 2:] = 110 + 90 * np.sin(2 * np.pi * 0.7 * t + 1.0)
            img = np.clip(
                base + self.rng.normal(0, 3, (h, w)), 0, 255
            ).astype(np.uint8)
            return img, cv2.cvtColor(img, cv2.COLOR_GRAY2BGR)

        ok, bgr = self.cap.read()
        if not ok:
            raise RuntimeError("Webcam read failed")
        return cv2.cvtColor(bgr, cv2.COLOR_BGR2GRAY), bgr

    def release(self):
        if not self.synthetic:
            self.cap.release()


# --------------------------------------------------------------------------- circuit blocks
class DriverB:
    """Deterministic: Schmitt comparator on detector-B intensity."""

    def __init__(self, x):
        self.thr = 0.30 + 0.40 * (
            ((x * 2654435761) % 2**32) / 2**32
        )
        self.hyst = 0.03
        self.state = False

    def step(self, intensity):
        if self.state and intensity < self.thr - self.hyst:
            self.state = False
        elif not self.state and intensity > self.thr + self.hyst:
            self.state = True
        return VCC if self.state else 0.0


class DriverA:
    """Randomized: parity of the sensor-noise LSBs in detector-A ROI."""

    def step(self, roi):
        return VCC if int(np.bitwise_and(roi, 1).sum()) & 1 else 0.0


class IfThenLink:
    """RC node + NPN: IF V(C) > 0.7 V THEN output HIGH."""

    def __init__(self):
        self.vc = 0.0

    def step(self, v_drive, dt):
        self.vc += (v_drive - self.vc) * (
            1 - np.exp(-dt / (R_OHM * C_FARAD))
        )
        return VCC if self.vc > V_BE else 0.0


class TimeCodeLatch:
    """Latch holding the isolated number; outputs one bit per clock slot."""

    def __init__(self, value, nbits):
        self.value = value
        self.nbits = nbits

    def bit(self, slot):
        return (self.value >> (self.nbits - 1 - slot)) & 1


class DFlipFlop74HC74:
    def __init__(self):
        self.q = 0

    def clock(self, d):
        self.q = int(d)

    @property
    def qbar(self):
        return 1 - self.q


def hi(v):
    return v > VCC / 2


# --------------------------------------------------------------------------- live Bitcoin price
def live_btc_price():
    """Fetch the current live BTC-USD spot price from Coinbase."""
    url = "https://api.coinbase.com/v2/prices/BTC-USD/spot"

    with urllib.request.urlopen(url, timeout=5) as response:
        data = json.load(response)

    return float(data["data"]["amount"])


def btc_to_isolated(price, nbits):
    """Convert live BTC price into an isolated number that fits the latch."""
    max_value = (1 << nbits) - 1
    return int(price) % (max_value + 1)


class PriceOracle:
    """Samples BTC-USD and hot-verifies its previous prediction."""

    URL = "https://api.coinbase.com/v2/prices/BTC-USD/spot"

    def __init__(self, simulated=False, poll=5.0, window=12):
        self.simulated = simulated
        self.poll = poll
        self.window = window
        self.hist = collections.deque(maxlen=max(4 * window, 60))
        self.events = queue.Queue()
        self.price = None
        self.pred = None
        self.pending = None
        self.hits = 0
        self.total = 0
        self.abs_err = 0.0
        self._p = 60000.0
        self._drift = 0.0
        self._rng = np.random.default_rng(7)
        self._stop = threading.Event()

        threading.Thread(target=self._run, daemon=True).start()

    def _fetch(self):
        if self.simulated:
            if self._rng.random() < 0.08:
                self._drift = self._rng.choice([-1, 0, 1]) * 0.0012

            self._p *= 1 + self._drift + self._rng.normal(0, 0.0003)
            return self._p

        with urllib.request.urlopen(self.URL, timeout=4) as response:
            return float(json.load(response)["data"]["amount"])

    def _predict_next(self):
        history = list(self.hist)[-self.window:]

        if len(history) < self.window:
            return None

        slope, intercept = np.polyfit(
            np.arange(len(history)), history, 1
        )
        return float(slope * len(history) + intercept)

    def _on_sample(self, price):
        self.hist.append(price)
        self.price = price

        if self.pending:
            prediction, base = self.pending
            hit = (prediction - base) * (price - base) > 0

            self.total += 1
            self.hits += int(hit)
            self.abs_err += abs(price - prediction)

            self.events.put(
                f"VERIFIED predicted ${prediction:,.2f} "
                f"actual ${price:,.2f} "
                f"dir {'HIT' if hit else 'MISS'} "
                f"err ${abs(price - prediction):,.2f} "
                f"[{self.rate()}]"
            )

        self.pred = self._predict_next()

        if self.pred is not None:
            self.pending = (self.pred, price)
        else:
            self.pending = None

        if self.pred is not None:
            self.events.put(
                f"price ${price:,.2f} -> predicted next ${self.pred:,.2f}"
            )
        else:
            self.events.put(
                f"price ${price:,.2f} "
                f"(warming up {len(self.hist)}/{self.window})"
            )

    def _run(self):
        while not self._stop.is_set():
            try:
                self._on_sample(self._fetch())
            except Exception as error:
                self.events.put(f"[oracle] error: {str(error)[:60]}")

            self._stop.wait(self.poll)

    def rate(self):
        if not self.total:
            return "n/a"

        return (
            f"{self.hits}/{self.total} "
            f"({100 * self.hits / self.total:.0f}%), "
            f"mean err ${self.abs_err / self.total:,.2f}"
        )

    def stop(self):
        self._stop.set()


# --------------------------------------------------------------------------- drawing
def draw(frame, roiB, roiA, text_lines, traces):
    import cv2

    h, w = frame.shape[:2]
    out = frame.copy()

    cv2.rectangle(
        out,
        (roiB[0], roiB[1]),
        (roiB[2], roiB[3]),
        (60, 60, 255),
        2,
    )
    cv2.putText(
        out,
        "IR det B",
        (roiB[0] + 4, roiB[1] + 18),
        0,
        0.5,
        (60, 60, 255),
        1,
    )

    cv2.rectangle(
        out,
        (roiA[0], roiA[1]),
        (roiA[2], roiA[3]),
        (60, 200, 60),
        2,
    )
    cv2.putText(
        out,
        "IR det A",
        (roiA[0] + 4, roiA[1] + 18),
        0,
        0.5,
        (60, 200, 60),
        1,
    )

    y = h - 8 - 16 * len(text_lines)

    for line in text_lines:
        cv2.putText(
            out,
            line,
            (8, y),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.45,
            (255, 255, 255),
            1,
            cv2.LINE_AA,
        )
        y += 16

    names = ["A", "B_out", "OR", "AND", "Y", "D", "SELECT"]
    pw = max(w, 480)
    rowh = 22
    panel = np.full((rowh * len(names) + 8, pw, 3), 25, np.uint8)

    for i, name in enumerate(names):
        y0 = 4 + i * rowh
        cv2.putText(
            panel,
            name,
            (4, y0 + 15),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.4,
            (200, 200, 200),
            1,
        )

        data = list(traces[name])[-(pw - 70):]
        points = [
            (60 + k, y0 + (4 if value else 17))
            for k, value in enumerate(data)
        ]

        for p, q in zip(points[:-1], points[1:]):
            cv2.line(panel, p, q, (0, 220, 255), 1)

    if panel.shape[1] != out.shape[1]:
        pad = np.zeros(
            (out.shape[0], panel.shape[1] - out.shape[1], 3),
            np.uint8,
        )
        out = np.hstack([out, pad])

    return np.vstack([out, panel])


# --------------------------------------------------------------------------- main
def main():
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--cam",
        type=int,
        default=0,
        help="USB webcam index",
    )
    parser.add_argument(
        "--synthetic",
        action="store_true",
        help="fake camera (no hardware)",
    )
    parser.add_argument(
        "--headless",
        action="store_true",
        help="no window, print results",
    )
    parser.add_argument(
        "--bits",
        type=int,
        default=16,
        help="word length (multiple of 4)",
    )
    parser.add_argument(
        "--x",
        type=int,
        default=12345,
        help="problem instance x",
    )
    parser.add_argument(
        "--leak",
        action="store_true",
        help="AND-gate output also feeds D",
    )
    parser.add_argument(
        "--runs",
        type=int,
        default=0,
        help="stop after N words (0 = forever)",
    )
    parser.add_argument(
        "--price",
        action="store_true",
        help="use live BTC price as the isolated number",
    )
    parser.add_argument(
        "--price-sim",
        action="store_true",
        help="simulated price walk instead of live feed",
    )
    parser.add_argument(
        "--price-poll",
        type=float,
        default=5.0,
        help="seconds between live BTC price samples",
    )
    parser.add_argument(
        "--price-window",
        type=int,
        default=12,
        help="samples used for prediction",
    )
    args = parser.parse_args()

    nbits = args.bits - args.bits % 4
    hexw = nbits // 4

    if not args.price:
        raise SystemExit(
            "This version requires --price: "
            "the isolated number is the live Bitcoin price."
        )

    # Initial isolated number comes from the live BTC price.
    initial_btc_price = live_btc_price()
    secret = btc_to_isolated(initial_btc_price, nbits)

    cam = Camera(args.cam, args.synthetic)
    driver_a = DriverA()
    driver_b = DriverB(args.x)
    link = IfThenLink()
    latch = TimeCodeLatch(secret, nbits)
    flip_flop = DFlipFlop74HC74()

    traces = collections.defaultdict(
        lambda: collections.deque(maxlen=600)
    )

    slot = 0
    select_bits = []
    runs = 0

    oracle = PriceOracle(
        simulated=args.price_sim or args.synthetic,
        poll=args.price_poll,
        window=args.price_window,
    )

    last_time = time.time()
    next_clock = last_time + CLK_PERIOD
    previous_intensity_b = None

    print(
        f"ISOLATED NUMBER = {secret:0{hexw}X} "
        f"from live BTC-USD ${initial_btc_price:,.2f} "
        f"(bits={nbits})"
    )

    try:
        while True:
            gray, bgr = cam.read()
            now = time.time()
            dt = now - last_time
            last_time = now

            h, w = gray.shape

            roi_b_box = (0, 0, w // 2 - 4, h - 1)
            roi_a_box = (w // 2 + 4, 0, w - 1, h - 1)

            roi_b = gray[
                roi_b_box[1]:roi_b_box[3],
                roi_b_box[0]:roi_b_box[2],
            ]
            roi_a = gray[
                roi_a_box[1]:roi_a_box[3],
                roi_a_box[0]:roi_a_box[2],
            ]

            intensity_b = float(roi_b.mean()) / 255.0

            if previous_intensity_b is None:
                delta_intensity = 0.0
            else:
                delta_intensity = (
                    intensity_b - previous_intensity_b
                )

            previous_intensity_b = intensity_b

            v_a = driver_a.step(roi_a)
            v_b = driver_b.step(intensity_b)
            v_b_out = link.step(v_b, dt)

            a = hi(v_a)
            b = hi(v_b_out)
            g_or = a or b
            g_and = a and b

            y = bool(latch.bit(slot))
            d = y or (g_and and args.leak)

            for name, value in zip(
                [
                    "A",
                    "B_out",
                    "OR",
                    "AND",
                    "Y",
                    "D",
                    "SELECT",
                ],
                [a, b, g_or, g_and, y, d, flip_flop.q],
            ):
                traces[name].append(int(value))

            if now >= next_clock:
                next_clock += CLK_PERIOD
                flip_flop.clock(d)
                select_bits.append(flip_flop.q)
                slot += 1

                if slot == nbits:
                    reconstructed = int(
                        "".join(map(str, select_bits)), 2
                    )

                    if reconstructed == secret:
                        result = "RECONSTRUCTED"
                    else:
                        result = "MISMATCH"

                    print(
                        f"SELECT = {reconstructed:0{hexw}X} "
                        f"vs live-BTC isolated "
                        f"{secret:0{hexw}X} -> {result}"
                    )

                    runs += 1
                    slot = 0
                    select_bits = []

                    if args.runs and runs >= args.runs:
                        break

            # Drain live oracle events.
            while not oracle.events.empty():
                print(oracle.events.get())

            # Live-verify and update the isolated Bitcoin price.
            if oracle.price is not None:
                new_isolated = btc_to_isolated(
                    oracle.price, nbits
                )

                if new_isolated != secret:
                    secret = new_isolated
                    latch = TimeCodeLatch(secret, nbits)

                    print(
                        f"ISOLATED UPDATED from live BTC "
                        f"${oracle.price:,.2f} -> "
                        f"{secret:0{hexw}X}"
                    )

            if (
                args.headless
                and args.runs
                and oracle.total >= args.runs
            ):
                break

            if args.headless:
                time.sleep(0.01)
                continue

            import cv2

            selected = "".join(map(str, select_bits))

            if selected:
                selected_hex = f"{int(selected, 2):X}"
            else:
                selected_hex = "-"

            lines = [
                f"I_B={intensity_b:.2f} "
                f"dI={delta_intensity:+.3f} "
                f"Vc={link.vc:.2f}V "
                f"thr={driver_b.thr:.2f}",
                f"A={int(a)} Bout={int(b)} "
                f"OR={int(g_or)} AND={int(g_and)} "
                f"Y={int(y)} D={int(d)} Q={flip_flop.q}",
                f"slot {slot}/{nbits} "
                f"SELECT bits={selected} hex={selected_hex}",
                f"isolated number = {secret:0{hexw}X} "
                f"(live BTC-verified)",
                (
                    f"BTC ${oracle.price:,.2f} "
                    f"next ~${oracle.pred:,.2f} "
                    f"hot verify: {oracle.rate()}"
                    if oracle.price is not None
                    and oracle.pred is not None
                    else "BTC price: warming up..."
                ),
            ]

            cv2.imshow(
                "optoelectronic sim",
                draw(
                    bgr,
                    roi_b_box,
                    roi_a_box,
                    lines,
                    traces,
                ),
            )

            key = cv2.waitKey(1) & 0xFF

            if key == ord("q"):
                break

            if key == ord("r"):
                slot = 0
                select_bits = []

    finally:
        oracle.stop()
        cam.release()

        if not args.headless:
            import cv2
            cv2.destroyAllWindows()


if __name__ == "__main__":
    main()
