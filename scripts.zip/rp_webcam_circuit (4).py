#!/usr/bin/env python3
"""
Webcam simulation of the Reversed-Process decision circuit (camera build).

Pipeline per clock tick (strictly feed-forward, like the paper):
  frame -> motion-energy mask E -> x = (#moving pixels) + 5
  r = 2 + SHA256(E) mod (x-3)                      (hash-derived witness)
  A = Miller-Rabin witness test of x with witness r (one-sided error)
  B = deterministic precondition, gated by the RC link timing (1.83 RC < T)
  Y = time-code bit (latch mode) or 1 (decide mode)
  Q = A AND B AND Y   -> 74HC74 D flip-flop on the clock edge

Modes
  decide : k frames per instance, accept if any Q=1. Measures false-accept
           (must be 0), witness rate p-hat on composites (P5), error vs (1/2)^k.
  latch  : serialises a stored integer through Y and checks reconstruction
           against the p^w prediction from Section 2.3.
  sweep  : every x in [5, W*H+5] (all primes included) at a 0.1 ms clock.

Hidden-number prediction (commit-then-reveal)
  Each tick the circuit forms an m-bit guess from its own state (--predict),
  commits to it with a salted hash, and only THEN is the hidden number drawn
  from an independent source (secrets). The guess is scored against chance
  (2^-m exact, 0.5 per bit). Nothing in the camera/hash/Miller-Rabin chain
  carries information about the hidden number, so expect NULL results.

Photon channels for the guess (--predict det|nd|both)
  det  : deterministic photons. Low-frequency scene structure (strip means vs
         global mean); thousands of photons averaged, so it follows the lit scene.
  nd   : non-deterministic photons. Sensor LSB noise (shot + read/thermal),
         von Neumann debiased. Quantum in origin, but independent of the hidden
         number, so it cannot help predict it.
  both : XOR of the two. All three are scored every run, whichever you pick.

Hidden number: random by default. --hidden N fixes it; --hidden-file F reads it
from a text file every tick, so you can edit it while the run is going. With a
fixed hidden number, hits only measure how often your guess lands on that value
(biased guesses can beat 2^-m by luck), so compare against --predict const.

Protocol log (Section 9): frame digest, x, r, Q, guess, commit, hidden, and a
nonce drawn AFTER the frame from an independent source (secrets/os.urandom).
Offline analysis:
  P1 hidden-number prediction vs 2^-m, P3 hash-bit bias, P4 frame/nonce corr.
This is a deterministic classical machine: expect NULL results on P1/P3/P4.

Usage
  pip install opencv-python numpy
  python rp_webcam_circuit.py --mode decide --frames 600 --show
  python rp_webcam_circuit.py --mode decide --predict x --m 8 --frames 6500 --fast
  python rp_webcam_circuit.py --mode latch --value 0xA5 --nbits 8 --frames 2000 --fast
  python rp_webcam_circuit.py --mode sweep --realtime
  python rp_webcam_circuit.py --synthetic --fast --frames 100000   # no camera
"""
import argparse, csv, hashlib, math, secrets, signal, sys, time
import numpy as np

try:
    import cv2
except ImportError:
    cv2 = None

W, H = 128, 96          # 12288 pixels -> at most 13.6 bits in x
CLOCK_S = 0.1           # 10 Hz clock, T = 100 ms (sweep mode overrides this)


# ---------------------------------------------------------------- sources
def webcam_frames(index):
    print(f"opening camera {index} (grant camera permission if prompted)...", flush=True)
    cap = cv2.VideoCapture(index)
    if not cap.isOpened():
        raise RuntimeError(f"cannot open webcam {index}; try --camera 1 or --synthetic")
    cap.set(cv2.CAP_PROP_BUFFERSIZE, 1)      # avoid stale queued frames
    for _ in range(5):                       # warm-up / auto-exposure
        cap.read()
    print("camera ready", flush=True)
    fails = 0
    try:
        while True:
            ok, f = cap.read()
            if not ok:
                fails += 1
                if fails > 30:
                    raise RuntimeError("webcam read failed repeatedly")
                time.sleep(0.05)
                continue
            fails = 0
            g = cv2.cvtColor(f, cv2.COLOR_BGR2GRAY)
            yield cv2.resize(g, (W, H), interpolation=cv2.INTER_AREA)
    finally:
        cap.release()


def synthetic_frames(seed=None):
    rng = np.random.default_rng(seed)
    t = 0
    while True:
        f = rng.normal(100, 6, (H, W))
        cx, cy = int(W / 2 + 40 * math.sin(t / 7)), int(H / 2 + 25 * math.cos(t / 11))
        f[max(cy - 10, 0):cy + 10, max(cx - 10, 0):cx + 10] += 60
        t += 1
        yield np.clip(f, 0, 255).astype(np.uint8)


# ---------------------------------------------------------------- circuit
def is_prime(n):
    if n < 2:
        return False
    if n % 2 == 0:
        return n == 2
    i = 3
    while i * i <= n:
        if n % i == 0:
            return False
        i += 2
    return True


def driver_A(x, r):
    """Miller-Rabin witness test. 1 => r proves x composite. Never 1 for primes."""
    if x % 2 == 0:
        return 1                      # even, x > 2: composite
    d, s = x - 1, 0
    while d % 2 == 0:
        d //= 2
        s += 1
    y = pow(r, d, x)
    if y in (1, x - 1):
        return 0
    for _ in range(s - 1):
        y = y * y % x
        if y == x - 1:
            return 0
    return 1


def link_valid_time(RC, vs=5.0, vih=3.5, vbe=0.7):
    """Time for the emitter-follower output to reach a valid 74HC HIGH."""
    return RC * math.log(vs / (vs - vih - vbe))


def driver_B(x, RC):
    """Deterministic precondition (true for every composite) + RC link timing."""
    pre = 1 if x >= 4 else 0
    in_time = link_valid_time(RC) < CLOCK_S
    return 1 if (pre and in_time) else 0


class DFlipFlop:
    def __init__(self):
        self.q = 0

    def clock(self, d):
        self.q = d
        return self.q


def step(prev, cur, thr, RC, y):
    mask = np.abs(cur.astype(np.int16) - prev.astype(np.int16)) > thr
    x = int(mask.sum()) + 5
    E = np.packbits(mask).tobytes()
    r = 2 + int.from_bytes(hashlib.sha256(E).digest(), "big") % (x - 3)
    A, B = driver_A(x, r), driver_B(x, RC)
    return dict(x=x, r=r, A=A, B=B, Y=y, Q=A & B & y,
                digest=hashlib.sha256(cur.tobytes()).hexdigest(), mask=mask)


# ---------------------------------------------------------------- prediction
def det_photon_bits(cur, m):
    """Deterministic-photon channel: the scene's low-frequency structure.
    Thousands of photons are averaged per strip, so shot noise is washed out
    and the bits follow the lit scene (same scene -> same bits, except for
    strips whose mean sits right at the threshold)."""
    g = float(cur.mean())
    word = 0
    for strip in np.array_split(cur.astype(np.float32), m, axis=1):
        word = (word << 1) | int(strip.mean() > g)
    return word


def nd_photon_bits(prev, cur, m):
    """Non-deterministic-photon channel: sensor LSB noise (photon shot noise
    plus read/thermal noise). LSBs of the frame-to-frame XOR, von Neumann
    debiased on adjacent pairs, first m surviving bits."""
    lsb = ((cur ^ prev) & 1).ravel()
    n = len(lsb) // 2 * 2
    a, b = lsb[0:n:2], lsb[1:n:2]
    out = a[a != b][:m]
    if len(out) < m:                    # frozen/saturated sensor: pad with zeros
        out = np.concatenate([out, np.zeros(m - len(out), dtype=out.dtype)])
    return int("".join(map(str, out.tolist())), 2)


def make_guess(kind, s, m, abits):
    """Circuit's m-bit guess, computed BEFORE the hidden number is drawn."""
    mask = (1 << m) - 1
    if kind == "det":                   # deterministic photons (scene structure)
        return s["det"]
    if kind == "nd":                    # non-deterministic photons (sensor noise)
        return s["nd"]
    if kind == "both":                  # XOR of the two channels
        return s["det"] ^ s["nd"]
    if kind == "x":                     # low bits of the moving-pixel count
        return s["x"] & mask
    if kind == "r":                     # low bits of the hash-derived witness
        return s["r"] & mask
    if kind == "a":                     # last m witness-test outputs, as a word
        bits = ([0] * m + abits)[-m:]
        return int("".join(map(str, bits)), 2)
    return 0                            # "const" baseline


# ---------------------------------------------------------------- hidden number
def get_hidden(a):
    """Hidden number for this tick, drawn AFTER the guess is committed.
    Priority: --hidden-file (re-read every tick, edit it live) > --hidden (fixed)
    > random from secrets. Values are masked to m bits."""
    mask = (1 << a.m) - 1
    if a.hidden_file:
        try:
            txt = open(a.hidden_file).read().strip()
            if txt:
                return int(txt, 0) & mask
        except (OSError, ValueError):
            pass                        # missing/garbled file: fall through
    if a.hidden is not None:
        return a.hidden & mask
    return secrets.randbits(a.m)


# ---------------------------------------------------------------- analysis
def z_binom(hits, n, p):
    return (hits - n * p) / math.sqrt(n * p * (1 - p)) if n and 0 < p < 1 else float("nan")


def analyse(log, m=8):
    n = len(log)
    print("\n=== Protocol analysis (guess committed before hidden drawn) ===")
    # P1: prediction of the hidden number
    hits = sum(r["hit"] for r in log)
    print(f"P1 exact-guess hits: {hits}/{n}  null rate {2**-m:.5f}  "
          f"z={z_binom(hits, n, 2**-m):+.2f}  (5-sigma needs ~{25 * 2**m} trials)")
    bits_ok = sum(r["bit_ok"] for r in log)
    zb = (bits_ok - n * m / 2) / (math.sqrt(n * m) / 2)
    print(f"P1 bitwise accuracy: {bits_ok / (n * m):.4f}  (null 0.5000)  z={zb:+.2f}")
    for name, hk, bk in (("deterministic photons    ", "hit_det", "bit_ok_det"),
                         ("non-deterministic photons", "hit_nd", "bit_ok_nd"),
                         ("both (XOR)               ", "hit_both", None)):
        h = sum(r[hk] for r in log)
        line = f"  {name}: exact {h}/{n} z={z_binom(h, n, 2**-m):+.2f}"
        if bk:
            b = sum(r[bk] for r in log)
            line += f"  bitwise {b / (n * m):.4f} z={(b - n * m / 2) / (math.sqrt(n * m) / 2):+.2f}"
        print(line)
    nd_ones = sum(bin(r["nd_guess"]).count("1") for r in log)
    print(f"  nd channel bit balance: {nd_ones / (n * m):.4f} (healthy noise source ~0.5)")
    # P3
    ones = sum(r["hash_bit"] for r in log)
    print(f"P3 hash-bit bias: ones={ones}/{n}  z={z_binom(ones, n, .5):+.2f}")
    # P4
    if n > 3:
        xs = np.array([r["x"] for r in log], float)
        ns = np.array([r["nonce_low"] for r in log], float)
        if xs.std() > 0 and ns.std() > 0:
            rho = float(np.corrcoef(xs, ns)[0, 1])
            print(f"P4 corr(x, nonce) rho={rho:+.4f}  z={rho * math.sqrt(n):+.2f}  "
                  f"(rho=0.01 needs ~{25 / 0.01**2:.0f} trials)")
    print("Expected: all |z| < ~3. A classical deterministic camera cannot beat the nulls.")


def write_log(path, log, quiet=False):
    keys = [k for k in log[0] if k != "mask"]
    with open(path, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=keys)
        w.writeheader()
        for r in log:
            w.writerow({k: r[k] for k in keys})
    if not quiet:
        print(f"log written: {path}")


# ---------------------------------------------------------------- sweep
def sweep(a, src):
    """Every x in [5, W*H+5] (all primes included) at a 0.1 ms clock.
    One camera frame pair seeds E; each tick = one witness trial through
    A AND B -> flip-flop. Accept if any of k ticks gives Q=1."""
    global CLOCK_S
    CLOCK_S = a.clock_us * 1e-6
    rc = min(a.rc, 0.5 * CLOCK_S / math.log(5 / 0.8))   # keep 1.83RC well under the clock
    print(f"clock {a.clock_us:g} us ({1e6 / a.clock_us:,.0f} Hz); RC = {rc * 1e6:.1f} us; "
          f"1.83RC = {link_valid_time(rc) * 1e6:.1f} us -> B OK")
    prev, cur = next(src), next(src)
    E = np.packbits(np.abs(cur.astype(np.int16) - prev.astype(np.int16)) > a.thr).tobytes()
    N = W * H + 5
    sieve = bytearray([1]) * (N + 1)
    sieve[0:2] = b"\x00\x00"
    for i in range(2, int(N ** .5) + 1):
        if sieve[i]:
            sieve[i * i::i] = bytearray(len(sieve[i * i::i]))
    ff, ticks = DFlipFlop(), 0
    pr = pr_acc = co = co_miss = co_A = co_trials = 0
    worst = (0.0, None)
    nxt = time.perf_counter()
    t0 = nxt
    for x in range(5, N + 1):
        B, hit, fires = driver_B(x, rc), 0, 0
        xb = x.to_bytes(4, "big")
        for j in range(a.k):
            r = 2 + int.from_bytes(hashlib.sha256(E + xb + j.to_bytes(2, "big")).digest(), "big") % (x - 3)
            A = driver_A(x, r)
            hit |= ff.clock(A & B)
            fires += A
            ticks += 1
            if a.realtime:                       # hold the clock
                nxt += CLOCK_S
                while time.perf_counter() < nxt:
                    pass
        if sieve[x]:
            pr += 1
            pr_acc += hit
        else:
            co += 1
            co_miss += 1 - hit
            co_A += fires
            co_trials += a.k
            if (a.k - fires) / a.k > worst[0]:
                worst = ((a.k - fires) / a.k, x)
    dt = time.perf_counter() - t0
    print(f"x in [5, {N}]: {pr} primes, {co} composites, k={a.k} ticks each, {ticks:,} ticks")
    print(f"achieved {dt / ticks * 1e6:.1f} us/tick ({'realtime-paced' if a.realtime else 'free-running'}); "
          f"total {dt:.2f} s; budget {a.clock_us:g} us/tick -> {'MET' if dt / ticks <= CLOCK_S * 1.05 else 'NOT MET'}")
    print(f"primes falsely accepted: {pr_acc} / {pr}   <- MUST be 0")
    print(f"composites rejected (missed all k): {co_miss} / {co}  = {co_miss / co:.2e}  "
          f"(worst-case bound (1/2)^k = {0.5 ** a.k:.2e})")
    print(f"per-trial witness rate on composites: {co_A / co_trials:.4f}")
    print(f"worst x by fraction of failed trials: x={worst[1]} ({worst[0]:.2f} of trials)")


# ---------------------------------------------------------------- main
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--mode", choices=["decide", "latch", "sweep"], default="decide")
    ap.add_argument("--frames", type=int, default=6500)
    ap.add_argument("--camera", type=int, default=0)
    ap.add_argument("--synthetic", action="store_true", help="no webcam; synthetic noise")
    ap.add_argument("--fast", action="store_true", help="ignore the 10 Hz pacing")
    ap.add_argument("--show", action="store_true", help="show frame + motion mask")
    ap.add_argument("--thr", type=int, default=8, help="motion threshold")
    ap.add_argument("--k", type=int, default=5, help="trials per instance (decide/sweep)")
    ap.add_argument("--rc", type=float, default=0.02, help="RC in seconds (paper's 0.1 fails)")
    ap.add_argument("--value", type=lambda s: int(s, 0), default=0xA5)
    ap.add_argument("--nbits", type=int, default=8)
    ap.add_argument("--m", type=int, default=8, help="bits for P1 hidden number")
    ap.add_argument("--hidden", type=lambda s: int(s, 0), default=None,
                    help="fix the hidden number (e.g. 0x5A or 90); default: random each tick")
    ap.add_argument("--hidden-file", default=None,
                    help="text file holding the hidden number, re-read every tick so you can edit it live")
    ap.add_argument("--predict", choices=["det", "nd", "both", "x", "r", "a", "const"], default="both",
                    help="what the circuit uses to guess the hidden number")
    ap.add_argument("--verbose", action="store_true", help="show progress and full statistics (default: only hits)")
    ap.add_argument("--log", default="rp_log.csv")
    ap.add_argument("--clock-us", type=float, default=10.0, help="sweep clock period in us (0.1 ms = 100)")
    ap.add_argument("--realtime", action="store_true", help="sweep: spin-wait to hold the clock")
    a = ap.parse_args()
    if a.hidden is not None and not 0 <= a.hidden < (1 << a.m):
        ap.error(f"--hidden must fit in --m={a.m} bits (0..{(1 << a.m) - 1})")

    use_cam = not a.synthetic and cv2 is not None
    if not a.synthetic and cv2 is None:
        print("OpenCV missing -> synthetic frames (pip install opencv-python)")
    src = webcam_frames(a.camera) if use_cam else synthetic_frames()
    if a.mode == "sweep":
        sweep(a, src)
        return
    if a.verbose: print(f"link: 1.83RC = {link_valid_time(a.rc) * 1000:.1f} ms vs clock {CLOCK_S * 1000:.0f} ms "
          f"-> B {'OK' if link_valid_time(a.rc) < CLOCK_S else 'TOO SLOW (all Q=0)'}")

    ff, log, prev = DFlipFlop(), [], next(src)
    stats = dict(comp=0, comp_A=0, prime=0, prime_A=0)
    latch_bits, latch_ok, latch_words = [], 0, 0
    abits = []
    t0 = time.time()

    stop = {"v": False}
    signal.signal(signal.SIGINT, lambda *_: stop.update(v=True))
    if a.verbose: print("running; Ctrl+C (or ESC in the window) stops early and prints results", flush=True)

    for t in range(a.frames):
        if stop["v"]:
            break
        tick = time.time()
        cur = next(src)
        y = (a.value >> (a.nbits - 1 - t % a.nbits)) & 1 if a.mode == "latch" else 1
        s = step(prev, cur, a.thr, a.rc, y)
        q = ff.clock(s["Q"])

        # ground truth bookkeeping (exact primality test, for evaluation only)
        x = s["x"]
        if is_prime(x):
            stats["prime"] += 1
            stats["prime_A"] += s["A"]
        else:
            stats["comp"] += 1
            stats["comp_A"] += s["A"]

        if a.mode == "latch":
            latch_bits.append(q)
            if len(latch_bits) == a.nbits:
                latch_words += 1
                word = int("".join(map(str, latch_bits)), 2)
                latch_ok += word == a.value
                latch_bits = []

        # ---- commit-then-reveal: guess is fixed and hashed BEFORE hidden is drawn
        abits.append(s["A"])
        abits = abits[-a.m:]
        s["det"] = det_photon_bits(cur, a.m)
        s["nd"] = nd_photon_bits(prev, cur, a.m)
        guess = make_guess(a.predict, s, a.m, abits)
        salt = secrets.token_bytes(8)
        commit = hashlib.sha256(guess.to_bytes(4, "big") + salt).hexdigest()[:16]
        nonce = secrets.token_bytes(8)
        hidden = get_hidden(a)                      # drawn last (random unless you set it)
        assert hashlib.sha256(guess.to_bytes(4, "big") + salt).hexdigest()[:16] == commit
        bit_ok = a.m - bin(guess ^ hidden).count("1")
        hdr = hashlib.sha256(hashlib.sha256(s["digest"].encode() + nonce).digest()).digest()
        log.append(dict(t=t, x=x, r=s["r"], A=s["A"], B=s["B"], Y=y, Q=q,
                        digest=s["digest"][:16], nonce_low=nonce[0],
                        guess=guess, commit=commit, hidden=hidden,
                        hit=int(guess == hidden), bit_ok=bit_ok,
                        det_guess=s["det"], nd_guess=s["nd"],
                        hit_det=int(s["det"] == hidden), hit_nd=int(s["nd"] == hidden),
                        hit_both=int((s["det"] ^ s["nd"]) == hidden),
                        bit_ok_det=a.m - bin(s["det"] ^ hidden).count("1"),
                        bit_ok_nd=a.m - bin(s["nd"] ^ hidden).count("1"),
                        hash_bit=hdr[0] >> 7))

        if a.show and use_cam:
            vis = np.hstack([cur, (s["mask"] * 255).astype(np.uint8)])
            vis = cv2.resize(vis, None, fx=3, fy=3, interpolation=cv2.INTER_NEAREST)
            cv2.putText(vis, f"x={x} r={s['r']} A={s['A']} B={s['B']} Y={y} Q={q} guess={guess}",
                        (6, 20), cv2.FONT_HERSHEY_SIMPLEX, .6, 255, 2)
            cv2.imshow("RP circuit", vis)
        prev = cur
        rec = log[-1]
        hit_ch = [n_ for n_, k_ in (("chosen", "hit"), ("det", "hit_det"),
                                    ("nd", "hit_nd"), ("both", "hit_both")) if rec[k_]]
        if hit_ch:
            print(f"HIT t={t} hidden={hidden} ({'/'.join(hit_ch)})  x={x}", flush=True)
        elif a.verbose and (t % 10 == 9 or t == 0):
            print(f"\rtick {t + 1}/{a.frames}  x={x}  A={s['A']} B={s['B']} Q={q}   ",
                  end="", flush=True)
        # pace to the clock while keeping the preview window responsive
        while not a.fast and time.time() - tick < CLOCK_S:
            if a.show and use_cam:
                if cv2.waitKey(10) & 255 == 27:
                    stop["v"] = True
                    break
            else:
                time.sleep(0.01)
        if a.fast and a.show and use_cam and cv2.waitKey(1) & 255 == 27:
            stop["v"] = True

    if a.show and use_cam:
        cv2.destroyAllWindows()

    n = len(log)
    if n == 0:
        print("no frames processed")
        return
    nh = sum(1 for r in log if r["hit"] or r["hit_det"] or r["hit_nd"] or r["hit_both"])
    if not a.verbose:
        if not nh:
            print(f"no hits in {n} frames")
    else:
        print(f"\n{n} frames in {time.time() - t0:.1f} s")
        print(f"x range: {min(r['x'] for r in log)}..{max(r['x'] for r in log)}  "
              f"(distinct {len(set(r['x'] for r in log))})")
        print(f"primes seen {stats['prime']}, A fired on primes {stats['prime_A']}  "
              f"<- false accepts, MUST be 0")
        if stats["comp"]:
            p = stats["comp_A"] / stats["comp"]
            print(f"composites {stats['comp']}, witness rate p-hat = {p:.3f}  (RP bound >= 0.5; P5 asks > 0.75)")
            print(f"  predicted error with k={a.k}: (1-p)^k = {(1 - p) ** a.k:.2e}  vs worst case {0.5 ** a.k:.2e}")
        if a.mode == "latch" and latch_words:
            ones = bin(a.value).count("1")
            p = stats["comp_A"] / max(stats["comp"] + stats["prime"], 1)   # A=0 on primes too
            print(f"latch: value {a.value:#x}, words {latch_words}, exact reconstructions {latch_ok} "
                  f"({latch_ok / latch_words:.3f}); predicted p^w = {p ** ones:.3f} (w={ones})")
            print("  Q = A.B.Y can only clear bits, so reconstruction needs A.B=1 in every 1-slot.")
        analyse(log, a.m)
    write_log(a.log, log, quiet=not a.verbose)


if __name__ == "__main__":
    main()
