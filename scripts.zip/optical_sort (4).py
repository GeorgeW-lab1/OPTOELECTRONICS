#!/usr/bin/env python3
"""Unified Optical Bench Recovery Pipeline (from Paper) & Real Monero Stratum Miner.

This script implements:
1. Parallel spatial pooling as an orthogonal Kronecker projection (24 dB noise reduction)[cite: 2, 3].
2. Coupon-collector cover time and majority-vote bit accumulation[cite: 4, 5].
3. Chase-type bounded bit-flip list decoding verified by a salted SHA-256 commitment[cite: 1, 6].
4. An 8-qubit GHZ quantum state execution diagnostic[cite: 8].
5. Real Monero Stratum networking and RandomX job handling.
"""
import argparse
import hashlib
import itertools
import json
import math
import socket
import struct
import threading
import time

import numpy as np

try:
    import pyrandomx
except ImportError:
    pyrandomx = None


# ---------------- 1. Optical Bench Pipeline (Paper Implementation) ----------------

class OpticalBenchPipeline:
    """Implements the optical bench recovery pipeline from the paper:

    spatial pooling, noise suppression, erasure gating, majority voting,
    Chase-type list decoding, SHA-256 commitment verification, and GHZ diagnostic.
    """

    def __init__(self, secret_int=9999999999999999, rows=8, cols=7, r=0.45, epsilon=0.02, c0=25):
        self.N = secret_int
        self.rows = rows
        self.cols = cols
        self.m = rows * cols  # 56 grid cells
        self.r = r            # Reveal rate
        self.epsilon = epsilon  # Sensor bit-flip probability
        self.c0 = c0          # Confidence threshold
        
        # Oracle salt and SHA-256 commitment (c = SHA-256(s || N))[cite: 1]
        self.salt = b"\x01" * 16
        self.commitment = hashlib.sha256(self.salt + str(self.N).encode()).hexdigest()
        
        # Precompute true bit representation of N (big-endian byte string)[cite: 1]
        self.true_bits = np.array([(self.N >> i) & 1 for i in range(self.m)], dtype=int)
        
        # Recogniser counters for majority voting[cite: 4]
        self.ones = np.zeros(self.m, dtype=int)
        self.zeros = np.zeros(self.m, dtype=int)
        self.valid_counts = np.zeros(self.m, dtype=int)

    def spatial_pooling_operator(self, frame_grid, sigma=40.0):
        """Simulates parallel spatial pooling: Kronecker projection (A_R \otimes A_C).

        Reduces variance by 256-fold (s = sigma / 16)[cite: 2, 3].
        """
        R, C = self.rows, self.cols
        # frame_grid shape: (rows*16, cols*16)
        reshaped = frame_grid.reshape(R, 16, C, 16)
        pooled = reshaped.mean(axis=(1, 3))
        
        # Apply Gaussian sensor noise model from Section 2.3[cite: 3]
        s = sigma / 16.0
        noisy_pooled = pooled + np.random.normal(0, s, size=pooled.shape)
        return noisy_pooled

    def observe_cycle(self):
        """Simulates an exposure cycle of the observation channel (Section 3)[cite: 4]."""
        # Reveal mask: Bernoulli(r)
        revealed = np.random.random(self.m) < self.r
        # Noise mask: Bernoulli(epsilon)
        flipped = np.random.random(self.m) < self.epsilon
        
        observed_bits = np.where(flipped, 1 - self.true_bits, self.true_bits)
        
        for i in range(self.m):
            if revealed[i]:
                self.valid_counts[i] += 1
                if observed_bits[i] == 1:
                    self.ones[i] += 1
                else:
                    self.zeros[i] += 1

    def compute_cover_time_bound(self):
        """Computes theoretical cover time using Gumbel / Coupon-Collector law[cite: 5]."""
        lambda_val = -math.log(1.0 - self.r)
        euler_gamma = 0.5772
        expected_t_cov = (math.log(self.m) + euler_gamma) / lambda_val
        var_t_cov = (math.pi ** 2) / (6.0 * (lambda_val ** 2))
        return expected_t_cov, math.sqrt(var_t_cov)

    def chase_list_decode_and_verify(self, L_limit=16, t_limit=4):
        """Performs Chase-type bounded bit-flip list decoding gated by SHA-256[cite: 6]."""
        # Sufficient statistic D_i = ones_i - zeros_i[cite: 4]
        D = self.ones - self.zeros
        margins = np.abs(D)
        
        # Rank positions by ascending reliability (confidence)
        sorted_indices = np.argsort(margins)
        U = sorted_indices[:L_limit]  # L least-reliable positions[cite: 6]
        
        # Zero-flip candidate (plain majority decode)[cite: 6]
        current_est_bits = np.where(D >= 0, 1, 0)
        
        # Generate error patterns up weight t
        for k in range(t_limit + 1):
            for combo in itertools.combinations(range(len(U)), k):
                candidate_bits = current_est_bits.copy()
                for idx in combo:
                    pos = U[idx]
                    candidate_bits[pos] = 1 - candidate_bits[pos]
                
                # Reconstruct integer N from bits
                cand_int = 0
                for i, b in enumerate(candidate_bits):
                    cand_int |= (int(b) << i)
                
                # Verify against SHA-256 commitment[cite: 1, 6]
                if hashlib.sha256(self.salt + str(cand_int).encode()).hexdigest() == self.commitment:
                    return True, cand_int
                    
        return False, None

    def qiskit_ghz_diagnostic(self):
        """Simulates the 8-qubit GHZ state execution diagnostic[cite: 8]."""
        # State vector simulation for |psi> = (|0>^8 + |1>^8) / sqrt(2)
        dim = 2 ** 8
        statevector = np.zeros(dim, dtype=complex)
        statevector[0] = 1.0 / math.sqrt(2.0)
        statevector[-1] = 1.0 / math.sqrt(2.0)
        
        # Simulate 64 shots
        samples = np.random.choice([0, dim - 1], size=64, p=[0.5, 0.5])
        all_zeros_count = np.sum(samples == 0)
        
        return f"GHZ Diagnostic: 8 qubits prepared. All-zeros count in 64 shots = {all_zeros_count} (Expected mean 32, sd 4)[cite: 8]."


# ---------------- 2. Live Stratum Miner & RandomX Client ----------------

class XMRStratumMiner:
    """Connects to a Monero mining pool, receives real Stratum jobs,

    and performs actual RandomX mining to submit valid shares.
    """

    def __init__(self, host, port, wallet, worker="python-miner", password="x"):
        self.host = host
        self.port = port
        self.wallet = wallet
        self.worker = worker
        self.password = password
        self.sock = None
        self._ids = itertools.count(1)
        self.current_job = None
        self.jobs_received = 0
        self.lock = threading.Lock()
        
        self.rx_cache = None
        self.rx_vm = None
        self.last_seed_hash = None

        if pyrandomx is None:
            print("[WARNING] 'pyrandomx' package not found. Install via pip for actual RandomX hashing.")

    def _send(self, method, params):
        message = {
            "jsonrpc": "2.0",
            "id": next(self._ids),
            "method": method,
            "params": params,
        }
        data = (json.dumps(message) + "\n").encode()
        with self.lock:
            self.sock.sendall(data)

    def _handle(self, message):
        method = message.get("method")

        if method == "job" or (method is None and isinstance(message.get("result"), dict) and "job" in message.get("result", {})):
            job = message.get("params") or message.get("result", {}).get("job")
            if job:
                with self.lock:
                    self.current_job = job
                    self.jobs_received += 1
                
                job_id = job.get('job_id')
                target = job.get('target')
                seed_hash = job.get('seed_hash')
                
                print(f"\n[NEW JOB {self.jobs_received}] id={job_id} target={target}")
                
                if pyrandomx and seed_hash:
                    seed_bytes = bytes.fromhex(seed_hash)
                    if seed_bytes != self.last_seed_hash:
                        print(f"[RANDOMX] Updating cache for new seed hash: {seed_hash[:16]}...")
                        self.last_seed_hash = seed_bytes
                        self.rx_cache = pyrandomx.Cache(seed_bytes)
                        self.rx_vm = pyrandomx.VM(self.rx_cache, None)

        elif message.get("error"):
            print("[POOL ERROR]", message["error"])
        elif message.get("result") and message.get("result").get("status") == "OK":
            print("[POOL] 🎉 Share ACCEPTED by pool!")
        else:
            print("[POOL RESPONSE]", message)

    def _reader(self):
        buffer = b""
        while True:
            try:
                chunk = self.sock.recv(4096)
                if not chunk:
                    print("[LIVE] Pool disconnected.")
                    break

                buffer += chunk
                while b"\n" in buffer:
                    line, buffer = buffer.split(b"\n", 1)
                    if not line.strip():
                        continue
                    try:
                        self._handle(json.loads(line.decode()))
                    except (json.JSONDecodeError, UnicodeDecodeError) as exc:
                        print("[LIVE] Invalid pool message:", exc)
            except Exception as e:
                print(f"[LIVE] Connection error: {e}")
                break

    def connect(self):
        self.sock = socket.create_connection((self.host, self.port), timeout=30)
        print(f"[LIVE] Connected to {self.host}:{self.port}")

        threading.Thread(target=self._reader, daemon=True).start()

        self._send("login", {
            "login": self.wallet,
            "pass": self.password,
            "agent": f"{self.worker}/1.0",
        })

    def submit_share(self, job_id, nonce_hex, result_hex):
        print(f"[MINER] Submitting share -> job_id={job_id}, nonce={nonce_hex}")
        self._send("submit", {
            "id": self.worker,
            "job_id": job_id,
            "nonce": nonce_hex,
            "result": result_hex,
        })

    def mine_loop(self):
        print("[MINER] Starting RandomX mining loop...")
        nonce_int = 0

        while True:
            time.sleep(0.01)
            with self.lock:
                job = self.current_job

            if not job or not pyrandomx or not self.rx_vm:
                continue

            job_id = job.get("job_id")
            blob_hex = job.get("blob")
            target_hex = job.get("target")

            if not blob_hex or not target_hex:
                continue

            target_val = int(target_hex, 16)
            blob_bytes = bytearray.fromhex(blob_hex)
            nonce_offset = 39
            if len(blob_bytes) < nonce_offset + 4:
                continue

            struct.pack_into("<I", blob_bytes, nonce_offset, nonce_int & 0xFFFFFFFF)
            nonce_hex = f"{nonce_int & 0xFFFFFFFF:08x}"
            nonce_int += 1

            try:
                hash_bytes = self.rx_vm.calculate_hash(bytes(blob_bytes))
            except Exception:
                continue

            if int.from_bytes(hash_bytes[:8], "little") <= target_val:
                result_hex = hash_bytes.hex()
                self.submit_share(job_id, nonce_hex, result_hex)

    def run(self):
        mining_thread = threading.Thread(target=self.mine_loop, daemon=True)
        mining_thread.start()
        try:
            while True:
                time.sleep(1)
        except KeyboardInterrupt:
            print("\n[LIVE] Stopped by user.")


# ---------------- Main Entry Point ----------------

def main():
    ap = argparse.ArgumentParser(description="Unified Optical Bench Pipeline & Monero Stratum Miner")
    ap.add_argument("--pool-host", default="pool.supportxmr.com", help="Monero pool hostname")
    ap.add_argument("--pool-port", type=int, default=3333, help="Monero pool Stratum port")
    ap.add_argument("--wallet", required=True, help="YOUR XMR receive address")
    ap.add_argument("--worker", default="python-miner", help="worker name")
    ap.add_argument("--pool-password", default="x", help="pool password")
    ap.add_argument("--run-bench", action="store_true", help="Run optical bench recovery demonstration")

    a = ap.parse_args()

    if a.run_bench:
        print("=== Running Optical Bench Recovery Pipeline Demo ==[cite: 1]")
        bench = OpticalBenchPipeline()
        exp_cov, sd_cov = bench.compute_cover_time_bound()
        print(f"Commitment generated: {bench.commitment[:16]}...[cite: 1]")
        print(f"Theoretical Cover Time: Mean = {exp_cov:.2f} cycles, SD = {sd_cov:.2f}[cite: 5]")
        print(bench.qiskit_ghz_diagnostic())
        
        # Simulate optical cycles and list decoding
        print("Simulating optical exposures and Chase list decoding...")
        for cycle in range(1, 15):
            # Generate synthetic frame grid (8*16 x 7*16)
            frame = np.random.choice([0, 255], size=(128, 112))
            pooled = bench.spatial_pooling_operator(frame)
            bench.observe_cycle()
            
            success, recovered_N = bench.chase_list_decode_and_verify()
            if success:
                print(f"Cycle {cycle}: Successfully recovered secret N = {recovered_N} and verified against commitment[cite: 6]!")
                break
        print("Optical bench demo complete.\n")

    miner = XMRStratumMiner(
        host=a.pool_host,
        port=a.pool_port,
        wallet=a.wallet,
        worker=a.worker,
        password=a.pool_password,
    )
    miner.connect()
    miner.run()


if __name__ == "__main__":
    main()
