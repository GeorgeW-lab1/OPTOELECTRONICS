#!/usr/bin/env python3
"""
FAA TAKEOFF STATUS AND DIVERSIONS THROUGH THE RP-GHOST PHASE CHANNEL
--------------------------------------------------------------------
Replaces the original screen -> webcam grid transmitter with the RP-GHOST
optoelectronic phase-correlation channel.

Each FAA record is framed as:
    [8-bit index | 24-bit data | 8-bit CRC-8] = 40 slots
The 40-bit frame is encoded as a phase tilt, generated across N_WINDOWS
independent Poisson windows, averaged, thresholded at zero, and CRC-checked.

Records come from the FAA NAS status feed (US airports): diversions,
departure delays, and airport closures. Set FAA_INCLUDE_PROGRAMS=1 to include
ground stops / GDPs.

RUN
  python faa_takeoffs_phase.py --sample --once
  python faa_takeoffs_phase.py --once
  python faa_takeoffs_phase.py

Options:
  --windows N        phase-channel averaging windows (default 2000)
  --retries N        CRC retries per frame (default 5)
  --max-records N    maximum FAA records transmitted per update
"""

import argparse
import math
import os
import threading
import time
import urllib.request
import xml.etree.ElementTree as ET
from datetime import datetime, timezone

import numpy as np

# ============================================================================
# CONFIG
# ============================================================================

LAMBDA_BASE = 10000.0
SIGMA_C = 0.005
N_SLOTS = 40
CHUNK_BYTES = 3
MAX_BYTES = 96
DEFAULT_WINDOWS = 2000
MAX_RETRIES = 5

FAA_API = "https://nasstatus.faa.gov/api/airport-status-information"
POLL_SECONDS = 60
IDLE_PRINT_SECONDS = 30

WATCH = {
    a.strip().upper()
    for a in os.environ.get("FAA_AIRPORTS", "").split(",")
    if a.strip()
}
INCLUDE_PROGRAMS = os.environ.get(
    "FAA_INCLUDE_PROGRAMS", ""
) not in ("", "0", "false", "False")

SAMPLE_XML = """
<TOP_STORY>
<Update_Time>Tue Nov 17 14:05:00 2026 GMT</Update_Time>
<Delay_type>
<Name>Ground Stop Programs</Name>
<Ground_Stop_List>
<Program><ARPT>EWR</ARPT><Reason>thunderstorms</Reason><End_Time>3:00 pm EST</End_Time></Program>
</Ground_Stop_List>
</Delay_type>
<Delay_type>
<Name>Arrival/Departure Delay Info</Name>
<Arrival_Departure_Delay_List>
<Delay><ARPT>ORD</ARPT><Reason>volume</Reason>
<Arrival_Departure Type="Departure"><Min>16 minutes</Min><Max>30 minutes</Max><Trend>Increasing</Trend></Arrival_Departure>
</Delay>
<Delay><ARPT>JFK</ARPT><Reason>weather</Reason>
<Arrival_Departure Type="Arrival"><Min>20 minutes</Min><Max>45 minutes</Max><Trend>Stable</Trend></Arrival_Departure>
<Arrival_Departure Type="Departure"><Min>31 minutes</Min><Max>45 minutes</Max><Trend>Decreasing</Trend></Arrival_Departure>
</Delay>
<Delay><ARPT>SEA</ARPT><Reason>low visibility</Reason>
<Arrival_Departure Type="Departure"><Min>15 minutes</Min><Max>29 minutes</Max><Trend>Stable</Trend></Arrival_Departure>
</Delay>
</Arrival_Departure_Delay_List>
</Delay_type>
<Delay_type>
<Name>Diversion Information</Name>
<Diversion_List>
<Diversion><ARPT>EWR</ARPT><Reason>thunderstorms</Reason><Destination>PHL</Destination><Note>inbound aircraft diverting</Note></Diversion>
</Diversion_List>
</Delay_type>
<Delay_type>
<Name>Airport Closures</Name>
<Airport_Closure_List>
<Airport><ARPT>PHL</ARPT><Reason>runway repair</Reason><Start>Nov 17 at 06:00 UTC.</Start><Reopen>Nov 18 at 11:00 UTC.</Reopen></Airport>
</Airport_Closure_List>
</Delay_type>
</TOP_STORY>
"""

# ============================================================================
# CRC-8, BIT HELPERS, AND FRAMING
# ============================================================================


def crc8(data):
    crc = 0
    for byte in data:
        crc ^= byte
        for _ in range(8):
            crc = ((crc << 1) ^ 0x07) & 0xFF if crc & 0x80 else (crc << 1) & 0xFF
    return crc


def int_to_bits(value, width):
    return [(value >> (width - 1 - k)) & 1 for k in range(width)]


def bits_to_code(bits):
    code = 0
    for bit in bits:
        code = (code << 1) | (int(bit) & 1)
    return code


def encode_frame(index, chunk):
    """40 bits: 8-bit index | 24-bit data | 8-bit CRC-8 over index + data."""
    chunk = bytes(chunk).ljust(CHUNK_BYTES, b"\x00")[:CHUNK_BYTES]
    body = bytes([index & 0xFF]) + chunk
    return np.array(
        int_to_bits(body[0], 8)
        + [b for by in chunk for b in int_to_bits(by, 8)]
        + int_to_bits(crc8(body), 8),
        dtype=int,
    )


def decode_frame(bits):
    bits = np.asarray(bits, dtype=int).flatten()
    index = bits_to_code(bits[:8])
    chunk = bytes(
        bits_to_code(bits[8 + 8 * i : 16 + 8 * i]) for i in range(CHUNK_BYTES)
    )
    received_crc = bits_to_code(bits[32:40])
    ok = received_crc == crc8(bytes([index]) + chunk)
    return index, chunk, ok


def make_payload_tilt(bits, eps_abs):
    bits = np.asarray(bits, dtype=float)
    strength = max(float(eps_abs), 0.25)
    return 2.0 * strength * (bits - 0.5)


# ============================================================================
# RP-GHOST PHASE CHANNEL
# ============================================================================


class OptoelectronicViewport:
    """RP-GHOST phase-correlation channel.

    Each slot receives Poisson photon counts. A shared multiplicative
    camera/exposure-noise term creates correlated noise across slots, while
    the requested bit pattern is applied as a small additive phase tilt.
    """

    def __init__(self, lambd=LAMBDA_BASE, sigma_c=SIGMA_C):
        self.lambd = float(lambd)
        self.sigma_c = float(sigma_c)
        print(
            f"[PHASE] RP-GHOST viewport initialized: lambda={self.lambd:.0f}, "
            f"sigma_c={self.sigma_c:.4f}"
        )

    def generate_window_block(self, n_windows, n_slots, tilt=None):
        shared_noise = np.random.normal(
            0.0, self.sigma_c, size=(n_windows, 1)
        )
        lam = self.lambd * (1.0 + shared_noise)
        counts = np.random.poisson(
            np.clip(lam, 1.0, None), size=(n_windows, n_slots)
        )
        z = (counts - self.lambd) / np.sqrt(self.lambd)
        if tilt is not None:
            z += tilt
        return z


def transmit_text(viewport, text, windows=DEFAULT_WINDOWS, max_retries=MAX_RETRIES):
    """Transmit UTF-8 text through the phase channel.

    Returns (decoded_text, frames, retries, failed, min_margin_sigma).
    """
    raw = text.encode("utf-8")[:MAX_BYTES] + b"\x00"
    chunks = [raw[i : i + CHUNK_BYTES] for i in range(0, len(raw), CHUNK_BYTES)]

    sigma_z = math.sqrt(1.0 + SIGMA_C**2 * LAMBDA_BASE)
    scale = sigma_z / math.sqrt(windows)

    received = bytearray()
    retries = failed = 0
    min_margin = float("inf")

    for i, chunk in enumerate(chunks):
        bits = encode_frame(i, chunk)
        tilt = make_payload_tilt(bits, 0.02 * sigma_z)
        good = None

        for _ in range(max_retries):
            z = viewport.generate_window_block(windows, N_SLOTS, tilt=tilt)
            m = z.mean(axis=0)
            idx, data, ok = decode_frame((m > 0).astype(int))
            if ok and idx == (i & 0xFF):
                good = data
                min_margin = min(
                    min_margin, float(np.min(np.abs(m)) / scale)
                )
                break
            retries += 1

        if good is None:
            failed += 1
            good = b"?" * CHUNK_BYTES
        received += good

    out = bytes(received).split(b"\x00", 1)[0].decode("utf-8", errors="replace")
    return out, len(chunks), retries, failed, (
        0.0 if min_margin == float("inf") else min_margin
    )


def transmit_u32(
    viewport, value, windows=DEFAULT_WINDOWS, max_retries=MAX_RETRIES
):
    """Transmit a 32-bit unsigned integer plus CRC-8 through the phase channel."""
    value &= 0xFFFFFFFF
    bits = np.array(
        int_to_bits(value, 32)
        + int_to_bits(crc8(value.to_bytes(4, "big")), 8),
        dtype=int,
    )

    sigma_z = math.sqrt(1.0 + SIGMA_C**2 * LAMBDA_BASE)
    tilt = make_payload_tilt(bits, 0.02 * sigma_z)
    scale = sigma_z / math.sqrt(windows)

    retries = 0
    for _ in range(max_retries):
        z = viewport.generate_window_block(windows, N_SLOTS, tilt=tilt)
        m = z.mean(axis=0)
        decoded = (m > 0).astype(int)
        got = bits_to_code(decoded[:32])
        if bits_to_code(decoded[32:40]) == crc8(got.to_bytes(4, "big")):
            margin = float(np.min(np.abs(m)) / scale)
            return got, retries, True, margin
        retries += 1
    return None, retries, False, 0.0


# ============================================================================
# FAA FEED
# ============================================================================


def format_age(age_sec):
    s = max(0, int(age_sec))
    d, rem = divmod(s, 86400)
    h, rem = divmod(rem, 3600)
    m, sec = divmod(rem, 60)
    if d:
        return f"{d}d {h}h"
    if h:
        return f"{h}h {m}m"
    return f"{m}m {sec}s" if m else f"{sec}s"


def parse_update_time(text):
    try:
        dt = datetime.strptime(
            text.strip().replace(" GMT", ""), "%a %b %d %H:%M:%S %Y"
        )
        return int(dt.replace(tzinfo=timezone.utc).timestamp())
    except Exception:
        return None


def _clean(el, tag):
    return (el.findtext(tag) or "").strip().rstrip(".")


def parse_takeoff_records(xml_text):
    root = ET.fromstring(xml_text)
    update_time = (root.findtext("Update_Time") or "").strip()
    records = []

    def add(airport, kind, rank, parts):
        airport = airport.upper()
        if airport and (not WATCH or airport in WATCH):
            records.append(
                {
                    "airport": airport,
                    "kind": kind,
                    "rank": rank,
                    "line": "|".join(
                        [airport, kind] + [p for p in parts if p]
                    ),
                }
            )

    for dtype in root.iter("Delay_type"):
        name = (dtype.findtext("Name") or "").lower()
        for lst in dtype:
            if lst.tag == "Name":
                continue
            for rec in lst:
                arpt = _clean(rec, "ARPT")
                reason = _clean(rec, "Reason")

                if "diversion" in name:
                    destination = _clean(rec, "Destination")
                    note = _clean(rec, "Note")
                    add(
                        arpt,
                        "DIVERSION",
                        0,
                        [
                            reason,
                            "to " + destination if destination else "",
                            note,
                        ],
                    )
                elif "closure" in name:
                    start = _clean(rec, "Start")
                    reopen = _clean(rec, "Reopen")
                    add(
                        arpt,
                        "CLOSED",
                        0,
                        [
                            reason,
                            "from " + start if start else "",
                            "reopen " + reopen if reopen else "",
                        ],
                    )
                elif "arrival" in name or "departure" in name:
                    for ad in rec.findall("Arrival_Departure"):
                        if ad.attrib.get("Type", "").lower() != "departure":
                            continue
                        minimum = _clean(ad, "Min")
                        maximum = _clean(ad, "Max")
                        trend = _clean(ad, "Trend")
                        add(
                            arpt,
                            "DEP DELAY",
                            1,
                            [
                                reason,
                                "min " + minimum if minimum else "",
                                "max " + maximum if maximum else "",
                                trend,
                            ],
                        )
                elif INCLUDE_PROGRAMS and "ground stop" in name:
                    end_time = _clean(rec, "End_Time")
                    add(
                        arpt,
                        "GROUND STOP (inbound held)",
                        2,
                        [reason, "until " + end_time if end_time else ""],
                    )
                elif INCLUDE_PROGRAMS and "ground delay" in name:
                    average = _clean(rec, "Avg")
                    maximum = _clean(rec, "Max")
                    add(
                        arpt,
                        "GDP (inbound held)",
                        3,
                        [
                            reason,
                            "avg " + average if average else "",
                            "max " + maximum if maximum else "",
                        ],
                    )

    records.sort(key=lambda r: (r["rank"], r["airport"]))
    return update_time, records


class FAAFetcher(threading.Thread):
    def __init__(self, url=FAA_API, poll_seconds=POLL_SECONDS, live=True):
        super().__init__(daemon=True)
        self.url = url
        self.poll_seconds = poll_seconds
        self.live = live
        self.pending = None
        self.last_sig = None
        self.have_live = False
        self.lock = threading.Lock()
        self.running = True

    def _fetch_xml(self):
        req = urllib.request.Request(
            self.url,
            headers={
                "User-Agent": "faa-takeoffs-phase/1.0",
                "Accept": "application/xml",
            },
        )
        with urllib.request.urlopen(req, timeout=10) as resp:
            return resp.read().decode("utf-8", errors="replace")

    def ingest(self, xml_text, simulated):
        update_time, records = parse_takeoff_records(xml_text)
        sig = (update_time, tuple(r["line"] for r in records))
        with self.lock:
            if sig == self.last_sig:
                return
            self.last_sig = sig
            self.pending = {
                "update_time": update_time,
                "records": records,
                "simulated": simulated,
            }

    def run(self):
        if not self.live:
            self.ingest(SAMPLE_XML, simulated=True)
            return

        fails = 0
        while self.running:
            try:
                self.ingest(self._fetch_xml(), simulated=False)
                self.have_live, fails = True, 0
            except Exception as e:
                fails += 1
                print(f"[FAA] Fetch failed: {e}")
                if not self.have_live and fails >= 3 and self.last_sig is None:
                    print(
                        "[FAA] Feed unreachable - using SAMPLE data "
                        "(not real conditions)."
                    )
                    self.ingest(SAMPLE_XML, simulated=True)

            for _ in range(self.poll_seconds):
                if not self.running:
                    break
                time.sleep(1)

    def pop_update(self):
        with self.lock:
            snapshot, self.pending = self.pending, None
            return snapshot

    def stop(self):
        self.running = False


# ============================================================================
# DECODE AND DISPLAY
# ============================================================================


def decode_snapshot(viewport, snapshot, max_records, windows, max_retries):
    update_time = parse_update_time(snapshot["update_time"])
    if update_time is None:
        decoded_update_time, update_ok, update_margin = None, False, 0.0
    else:
        decoded_update_time, _, update_ok, update_margin = transmit_u32(
            viewport, update_time, windows=windows, max_retries=max_retries
        )

    results = []
    for record in snapshot["records"][:max_records]:
        sent = record["line"].encode("utf-8")[:MAX_BYTES].decode(
            "utf-8", errors="replace"
        )
        text, frames, retries, failed, margin = transmit_text(
            viewport,
            record["line"],
            windows=windows,
            max_retries=max_retries,
        )
        results.append(
            {
                "text": text,
                "sent": sent,
                "frames": frames,
                "retries": retries,
                "failed": failed,
                "margin": margin,
                "match": failed == 0 and text == sent,
            }
        )

    return decoded_update_time, update_ok, update_margin, results


def print_snapshot(
    snapshot,
    decoded_update_time,
    update_ok,
    update_margin,
    results,
    max_records,
    windows,
):
    tag = " (SAMPLE DATA)" if snapshot["simulated"] else ""
    total = len(snapshot["records"])
    closed = sum(1 for r in snapshot["records"] if r["kind"] == "CLOSED")
    delays = sum(
        1 for r in snapshot["records"] if r["kind"] == "DEP DELAY"
    )
    diversions = sum(
        1 for r in snapshot["records"] if r["kind"] == "DIVERSION"
    )

    print("-" * 78)
    print(
        f" [FAA TAKEOFFS] UPDATE{tag} | {total} record(s) | "
        f"{closed} closed, {delays} departure delay(s), "
        f"{diversions} diversion(s)"
    )
    print(
        f" Channel: RP-GHOST phase correlation | {windows} windows/frame"
    )

    if update_ok:
        print(
            f" Feed time (decoded): "
            f"{time.strftime('%Y-%m-%d %H:%M:%S', time.gmtime(decoded_update_time))} UTC "
            f"({format_age(time.time() - decoded_update_time)} ago) "
            f"(CRC PASS, margin {update_margin:.1f} sigma)"
        )
    else:
        print(
            " Feed time: "
            f"{snapshot['update_time'] or 'unknown'} "
            "(phase decode failed / CRC FAIL)"
        )

    if not results:
        print(" No diversions, departure delays, or closures reported.")

    for n, result in enumerate(results, 1):
        integrity = (
            ""
            if result["failed"] == 0
            else f" | {result['failed']} frame(s) unrecoverable"
        )
        print(f" [{n:02d}] {result['text']}")
        print(
            f" {result['frames']} frames | CRC retries {result['retries']} | "
            f"min margin {result['margin']:.1f} sigma | "
            f"{'MATCHES feed' if result['match'] else 'MISMATCH'}{integrity}"
        )

    if total > len(results):
        print(
            f" ... {total - len(results)} more record(s) not decoded "
            f"(--max-records {max_records})"
        )
    print("-" * 78)


# ============================================================================
# MAIN
# ============================================================================


def main():
    parser = argparse.ArgumentParser(
        description="FAA takeoff status and diversions through the RP-GHOST phase channel"
    )
    parser.add_argument(
        "--sample",
        action="store_true",
        help="use built-in sample FAA data (no network)",
    )
    parser.add_argument(
        "--once", action="store_true", help="decode one update and exit"
    )
    parser.add_argument(
        "--windows",
        type=int,
        default=DEFAULT_WINDOWS,
        help="phase-channel averaging windows per frame",
    )
    parser.add_argument(
        "--retries",
        type=int,
        default=MAX_RETRIES,
        help="CRC retries per frame",
    )
    parser.add_argument(
        "--max-records", type=int, default=80, help="maximum records per update"
    )
    args = parser.parse_args()

    print("=" * 78)
    print(" FAA TAKEOFF STATUS AND DIVERSIONS - RP-GHOST PHASE CHANNEL")
    print("=" * 78)

    viewport = OptoelectronicViewport()
    faa = FAAFetcher(live=not args.sample)
    faa.start()

    print("[START] Waiting for FAA feed. Press Ctrl+C to exit.\n")
    last_print = time.time()

    try:
        while True:
            snapshot = faa.pop_update()
            if snapshot:
                (
                    decoded_update_time,
                    update_ok,
                    update_margin,
                    results,
                ) = decode_snapshot(
                    viewport,
                    snapshot,
                    args.max_records,
                    args.windows,
                    args.retries,
                )
                print_snapshot(
                    snapshot,
                    decoded_update_time,
                    update_ok,
                    update_margin,
                    results,
                    args.max_records,
                    args.windows,
                )
                last_print = time.time()
                if args.once:
                    break
            elif time.time() - last_print >= IDLE_PRINT_SECONDS:
                print(
                    f" [FAA TAKEOFFS] no change since last update "
                    f"({time.strftime('%H:%M:%S')})"
                )
                last_print = time.time()

            time.sleep(0.2)
    except KeyboardInterrupt:
        print("\n[STOP] Shutting down...")
    finally:
        faa.stop()
        print("[DONE] Terminated.")


if __name__ == "__main__":
    main()
