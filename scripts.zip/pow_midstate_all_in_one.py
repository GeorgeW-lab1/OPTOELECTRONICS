"""
All-in-one SHA-256 PoW midstate toy pipeline (single file, numpy only).

  Step 1  Build a toy block header: version | prev block hash (YOUR custom hash) |
          merkle root = SHA256d(hidden string) | time | bits | nonce (mined at low difficulty)
  Step 2  Recover the first-block MIDSTATE from a NOISY SIMULATED LEAK channel
          (votes -> majority guess -> Chase list decoding, verified by finishing the PoW hash)
  Step 3  Recover the hidden string behind the merkle root by low-entropy enumeration

Notes: the leak in step 2 is synthetic (generated from the secret). Step 3 only works because
the hidden string's unknown part is small. A block hash alone cannot be reversed to a header.
"""
import argparse, hashlib, itertools, string, struct, sys, time
import numpy as np

# ---------------- SHA-256 compression ----------------
K = [
0x428a2f98,0x71374491,0xb5c0fbcf,0xe9b5dba5,0x3956c25b,0x59f111f1,0x923f82a4,0xab1c5ed5,
0xd807aa98,0x12835b01,0x243185be,0x550c7dc3,0x72be5d74,0x80deb1fe,0x9bdc06a7,0xc19bf174,
0xe49b69c1,0xefbe4786,0x0fc19dc6,0x240ca1cc,0x2de92c6f,0x4a7484aa,0x5cb0a9dc,0x76f988da,
0x983e5152,0xa831c66d,0xb00327c8,0xbf597fc7,0xc6e00bf3,0xd5a79147,0x06ca6351,0x14292967,
0x27b70a85,0x2e1b2138,0x4d2c6dfc,0x53380d13,0x650a7354,0x766a0abb,0x81c2c92e,0x92722c85,
0xa2bfe8a1,0xa81a664b,0xc24b8b70,0xc76c51a3,0xd192e819,0xd6990624,0xf40e3585,0x106aa070,
0x19a4c116,0x1e376c08,0x2748774c,0x34b0bcb5,0x391c0cb3,0x4ed8aa4a,0x5b9cca4f,0x682e6ff3,
0x748f82ee,0x78a5636f,0x84c87814,0x8cc70208,0x90befffa,0xa4506ceb,0xbef9a3f7,0xc67178f2]
IV = [0x6a09e667,0xbb67ae85,0x3c6ef372,0xa54ff53a,0x510e527f,0x9b05688c,0x1f83d9ab,0x5be0cd19]
M32 = 0xffffffff
rotr = lambda x, n: ((x >> n) | (x << (32 - n))) & M32

def compress(state, block):
    w = list(struct.unpack(">16I", block))
    for i in range(16, 64):
        s0 = rotr(w[i-15], 7) ^ rotr(w[i-15], 18) ^ (w[i-15] >> 3)
        s1 = rotr(w[i-2], 17) ^ rotr(w[i-2], 19) ^ (w[i-2] >> 10)
        w.append((w[i-16] + s0 + w[i-7] + s1) & M32)
    a, b, c, d, e, f, g, h = state
    for i in range(64):
        S1 = rotr(e, 6) ^ rotr(e, 11) ^ rotr(e, 25)
        t1 = (h + S1 + ((e & f) ^ (~e & g)) + K[i] + w[i]) & M32
        S0 = rotr(a, 2) ^ rotr(a, 13) ^ rotr(a, 22)
        t2 = (S0 + ((a & b) ^ (a & c) ^ (b & c))) & M32
        h, g, f, e, d, c, b, a = g, f, e, (d + t1) & M32, c, b, a, (t1 + t2) & M32
    return [(x + y) & M32 for x, y in zip(state, [a, b, c, d, e, f, g, h])]

state_to_bits = lambda s: np.unpackbits(np.frombuffer(struct.pack(">8I", *s), dtype=np.uint8))
bits_to_state = lambda b: list(struct.unpack(">8I", np.packbits(b).tobytes()))
hexs = lambda s: "".join(f"{x:08x}" for x in s)

def pad80(): return b"\x80" + b"\x00" * 39 + struct.pack(">Q", 640)

def pow_hash(midstate, tail12, nonce):
    st = compress(midstate, tail12 + struct.pack("<I", nonce) + pad80())
    return compress(IV, struct.pack(">8I", *st) + b"\x80" + b"\x00" * 23 + struct.pack(">Q", 256))

# ---------------- pipeline ----------------
CHARSETS = {"lower": string.ascii_lowercase, "upper": string.ascii_uppercase, "digits": string.digits,
            "alnum": string.ascii_letters + string.digits, "hex": "0123456789abcdef"}

def run(block_hash_hex, secret, known_prefix, charset, difficulty, raw_order, max_keyspace=5_000_000):
    # --- validate inputs
    h = block_hash_hex.strip().lower()
    if len(h) != 64 or any(c not in "0123456789abcdef" for c in h):
        sys.exit(f"block hash must be 64 hex chars (got {len(h)}): {h}")
    prev_hash = bytes.fromhex(h) if raw_order else bytes.fromhex(h)[::-1]   # header stores little-endian
    chars = CHARSETS.get(charset, charset)
    if not secret.startswith(known_prefix): sys.exit("secret must start with the known prefix")
    unknown = secret[len(known_prefix):]
    if not unknown or any(c not in chars for c in unknown): sys.exit("unknown part empty or outside charset")
    keyspace = len(chars) ** len(unknown)
    if keyspace > max_keyspace: sys.exit(f"keyspace {keyspace:,} exceeds limit {max_keyspace:,}")

    # --- STEP 1: build toy block
    version = struct.pack("<I", 0x20000000)
    merkle = hashlib.sha256(hashlib.sha256(secret.encode()).digest()).digest()
    prefix76 = version + prev_hash + merkle + struct.pack("<II", 1700000000, 0x1d00ffff)
    secret_state = compress(IV, prefix76[:64])
    secret_bits, tail12 = state_to_bits(secret_state), prefix76[64:76]
    target, nonce = 1 << (256 - difficulty), 0
    while int.from_bytes(struct.pack(">8I", *pow_hash(secret_state, tail12, nonce))[::-1], "big") >= target:
        nonce += 1
    block_hash = pow_hash(secret_state, tail12, nonce)
    verify = lambda bits: pow_hash(bits_to_state(bits), tail12, nonce) == block_hash
    m = 256

    print("=" * 78); print(" SHA-256 PoW MIDSTATE PIPELINE (all-in-one)"); print("=" * 78)
    print("[STEP 1] Toy block built")
    print(f"  Prev block hash (custom) : {h}")
    print(f"  Merkle root = SHA256d({secret!r}, hidden)")
    print(f"  Mined nonce / block hash : {nonce} / {struct.pack('>8I', *block_hash)[::-1].hex()}")
    print("\n[STEP 2] Midstate recovery from noisy simulated leakage")
    print(f"{'Cycle':<6} | {'Seen':<6} | {'Unseen':<7} | Status"); print("-" * 78)

    ch = np.random.default_rng(1)
    tau, c0, pooled_std, flip_eps, reveal_rate = 127.0, 25.0, 40.0 / 16, 0.02, 0.45
    ones = np.zeros(m, np.int32); zeros = np.zeros(m, np.int32); seen = np.zeros(m, bool)
    checks, found, t0 = 0, None, time.perf_counter()
    for cycle in range(1, 60):
        pooled = secret_bits * 255.0 + ch.normal(0, pooled_std, m)
        dec = np.full(m, -1, np.int8); dec[pooled > tau + c0] = 1; dec[pooled < tau - c0] = 0
        valid = dec != -1
        dec[valid & (ch.random(m) < flip_eps)] ^= 1
        obs = np.where(valid & (ch.random(m) < reveal_rate), dec, -1)
        ones += (obs == 1); zeros += (obs == 0); seen |= (obs != -1)
        n_seen = int(seen.sum())
        if n_seen < m:
            print(f"{cycle:<6} | {n_seen:<6} | {m-n_seen:<7} | collecting frames..."); continue
        guess = (ones > zeros).astype(np.uint8); checks += 1
        if verify(guess):
            found = guess; print(f"{cycle:<6} | {n_seen:<6} | 0       | SUCCESS: 0-flip majority guess verified"); break
        uncertain = np.argsort(np.abs(ones - zeros))[:16]
        for k in range(1, 5):
            for subset in itertools.combinations(uncertain, k):
                checks += 1; cand = guess.copy(); cand[list(subset)] ^= 1
                if verify(cand): found = cand; break
            if found is not None:
                print(f"{cycle:<6} | {n_seen:<6} | 0       | SUCCESS: Chase decode, k={k} flips"); break
        if found is not None: break
        print(f"{cycle:<6} | {n_seen:<6} | 0       | list decoding failed ({checks:,} checks)")
    if found is None: sys.exit("  Failed to recover midstate within budget.")
    words = bits_to_state(found)
    print(f"  Recovered midstate : {hexs(words)}")
    print(f"  Matches secret     : {words == secret_state}   ({checks:,} checks, {(time.perf_counter()-t0)*1000:.1f} ms)")

    # --- STEP 3: recover hidden string
    print(f"\n[STEP 3] Hidden-string search ({len(chars)}^{len(unknown)} = {keyspace:,} candidates)")
    t1, tries, rec = time.perf_counter(), 0, None
    for combo in itertools.product(chars, repeat=len(unknown)):
        tries += 1; cand = known_prefix + "".join(combo)
        mk = hashlib.sha256(hashlib.sha256(cand.encode()).digest()).digest()
        if compress(IV, version + prev_hash + mk[:28]) == words: rec = cand; break
    if rec: print(f"  Recovered hidden string : {rec!r} ({tries:,} tries, {(time.perf_counter()-t1)*1000:.0f} ms)\n  Matches ground truth    : {rec == secret}")
    else:   print("  Hidden string not found in the assumed keyspace.")

if __name__ == "__main__":
    # self-check of the compression function
    assert struct.pack(">8I", *compress(IV, b"abc" + b"\x80" + b"\x00"*52 + struct.pack(">Q", 24))) == hashlib.sha256(b"abc").digest()
    ap = argparse.ArgumentParser(description="All-in-one PoW midstate leak recovery + hidden string search")
    ap.add_argument("--block-hash", default="0000004046373980d03a2a80ddee4b63537698b7cfca077648c8b0edc6c744db",
                    help="custom 64-hex block hash, used as the header's previous-block hash")
    ap.add_argument("--raw-order", action="store_true", help="use hash bytes as given (default: reverse, Bitcoin display order)")
    ap.add_argument("--secret", default="GeorgeWagenknecht2026"); ap.add_argument("--known-prefix", default="tx-")
    ap.add_argument("--charset", default="lower", help="lower|upper|digits|alnum|hex or literal charset")
    ap.add_argument("--difficulty", type=int, default=12)
    a = ap.parse_args()
    run(a.block_hash, a.secret, a.known_prefix, a.charset, a.difficulty, a.raw_order)
