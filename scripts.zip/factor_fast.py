#!/usr/bin/env python3
"""Fast factorisation: wheel trial division + Pollard rho + Miller-Rabin."""
import math, random, sys, time

def is_prime(n):
    if n < 2: return False
    for p in (2,3,5,7,11,13,17,19,23,29,31,37):
        if n % p == 0: return n == p
    d, s = n-1, 0
    while d % 2 == 0: d//=2; s+=1
    for a in (2,3,5,7,11,13,17,19,23,29,31,37):
        x = pow(a, d, n)
        if x in (1, n-1): continue
        for _ in range(s-1):
            x = x*x % n
            if x == n-1: break
        else: return False
    return True

def pollard_rho(n):
    if n % 2 == 0: return 2
    while True:
        c = random.randrange(1, n)
        x = y = random.randrange(2, n)
        d = 1
        while d == 1:
            x = (x*x+c) % n
            y = (y*y+c) % n; y = (y*y+c) % n
            d = math.gcd(abs(x-y), n)
        if d != n: return d

def factor(n):
    fs = []
    for p in (2,3,5):
        while n % p == 0: fs.append(p); n//=p
    # 30-wheel trial division to 100k
    f, add = 7, [4,2,4,2,4,6,2,6]
    i = 0
    while f <= 100000 and f*f <= n:
        while n % f == 0: fs.append(f); n//=f
        f += add[i]; i = (i+1) % 8
    stack=[n] if n>1 else []
    while stack:
        m=stack.pop()
        if m==1: continue
        if is_prime(m): fs.append(m); continue
        d=pollard_rho(m); stack += [d, m//d]
    return sorted(fs)

if __name__=='__main__':
    n=int(sys.argv[1]); t=time.perf_counter(); fs=factor(n); dt=time.perf_counter()-t
    assert math.prod(fs)==n
    print(f'{n} = ' + ' * '.join(map(str,fs)))
    print(f'time {dt:.6f}s')
