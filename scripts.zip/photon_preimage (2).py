
#!/usr/bin/env python3
"""
PHOTON ADAPTIVE PoW
Author: George Wagenknecht

Photon-driven stochastic Proof of Work.

Architecture:
    Photon measurements
          |
          v
    RC latch + hysteresis
          |
          v
    Adaptive nonce generator
          |
          v
    Custom block header
          |
          v
    Double SHA-256
          |
          v
    Leading-zero reward
          |
          v
    Adaptive optical feedback
          |
          +------> Next photon measurement

Features:
    - No sequential nonce incrementing.
    - No conventional nonce enumeration.
    - No exhaustive candidate combinations.
    - No salt grinding.
    - Multiple stochastic nonce attempts.
    - Hash-score-driven adaptive photon probabilities.
    - Exploration prevents permanent bit-pattern locking.
    - Fixed block challenge throughout each mining session.

IMPORTANT:
This is an experimental adaptive stochastic search.
SHA-256 provides no differentiable gradient. Feedback uses
the observed leading-zero score as a statistical reward.
It does not guarantee a speed advantage over random search.
"""

import argparse
import hashlib
import secrets
import struct
import time

import numpy as np


# ---------------------------------------------------------
# CIRCUIT CONSTANTS
# ---------------------------------------------------------

VCC = 5.0
V_BE = 0.7

TAU = 10e3 * 15e-6
CLK = 0.100

FRAME_DT = 0.005

VERSION = 1


# ---------------------------------------------------------
# HASHING
# ---------------------------------------------------------

def double_sha256(data):
    first = hashlib.sha256(data).digest()
    return hashlib.sha256(first).digest()


def leading_zero_bits(digest):
    return 256 - int.from_bytes(digest, "big").bit_length()


def make_target(difficulty):
    return (1 << (256 - difficulty)) - 1


# ---------------------------------------------------------
# PHOTON CIRCUIT
# ---------------------------------------------------------

class PhotonCircuit:

    def __init__(
        self,
        rng,
        mean_photons=40.0,
        threshold=0.45
    ):

        self.rng = rng
        self.lam = mean_photons

        self.threshold = threshold
        self.hysteresis = 0.03

        self.frames = int(round(CLK / FRAME_DT))

        self.alpha = 1.0 - np.exp(-FRAME_DT / TAU)

        self.total_photons = 0
        self.total_measurements = 0

        self.t = 0.0

    def optical_bit(self, probability_one):

        """
        One adaptive photon measurement.

        probability_one controls the relative photon flux
        between channels A and B.

        Photon shot noise determines the measured bit.
        """

        probability_one = float(
            np.clip(probability_one, 0.05, 0.95)
        )

        bias = np.clip(
            (probability_one - 0.5) * 1.8,
            -0.85,
            0.85
        )

        rate_a = self.lam * (1.0 + bias)
        rate_b = self.lam * (1.0 - bias)

        state = False
        vc = 0.0

        for _ in range(self.frames):

            modulation = (
                1.0 + 0.15 * np.sin(2 * np.pi * 0.4 * self.t)
            )

            self.t += FRAME_DT

            nA = self.rng.poisson(rate_a * modulation)
            nB = self.rng.poisson(rate_b * modulation)

            self.total_photons += nA + nB

            signal = (nA - nB) / (nA + nB + 1e-9)

            if state and signal < -self.threshold * 0.15:
                state = False

            elif not state and signal > self.threshold * 0.15:
                state = True

            drive = VCC if state else 0.0

            vc += (drive - vc) * self.alpha

        self.total_measurements += 1

        return int(vc > V_BE)

    def generate_nonce(self, probabilities):

        nonce = 0
        bits = []

        for p in probabilities:

            bit = self.optical_bit(p)

            bits.append(bit)

            nonce = (nonce << 1) | bit

        return nonce, np.asarray(bits, dtype=np.float64)


# ---------------------------------------------------------
# ADAPTIVE PHOTON CONTROLLER
# ---------------------------------------------------------

class AdaptiveController:

    def __init__(
        self,
        nbits,
        learning_rate=0.20,
        exploration=0.08
    ):

        self.nbits = nbits

        self.learning_rate = learning_rate
        self.exploration = exploration

        # Zero logits correspond to equal bit probabilities.
        self.logits = np.zeros(nbits, dtype=np.float64)

        self.reward_baseline = 0.0

        self.best_score = -1
        self.best_nonce = None

        self.updates = 0

    def probabilities(self):

        # Logistic probability model.
        p = 1.0 / (1.0 + np.exp(-self.logits))

        # Preserve exploration.
        p = (
            (1.0 - self.exploration) * p
            + self.exploration * 0.5
        )

        return np.clip(p, 0.05, 0.95)

    def update(self, bits, score, nonce):

        """
        Reward-based stochastic policy update.

        The hash is treated as a black-box reward function.

        REINFORCE-style update:
            delta = reward - baseline
            logits += learning_rate * delta * (bits - p)

        This does not differentiate through SHA-256.
        """

        probabilities = self.probabilities()

        reward = score / 32.0

        advantage = reward - self.reward_baseline

        gradient = bits - probabilities

        self.logits += (
            self.learning_rate
            * advantage
            * gradient
        )

        # Small entropy-preserving decay.
        self.logits *= 0.999

        self.logits = np.clip(
            self.logits,
            -2.5,
            2.5
        )

        self.reward_baseline = (
            0.90 * self.reward_baseline
            + 0.10 * reward
        )

        improved = score > self.best_score

        if improved:

            self.best_score = score
            self.best_nonce = nonce

        self.updates += 1

        return improved, advantage


# ---------------------------------------------------------
# CUSTOM BLOCK HEADER
# ---------------------------------------------------------

def create_block_prefix(difficulty):

    previous_hash = secrets.token_bytes(32)
    merkle_root = secrets.token_bytes(32)

    timestamp = int(time.time())

    prefix = (
        struct.pack(">I", VERSION)
        + previous_hash
        + merkle_root
        + struct.pack(">II", timestamp, difficulty)
    )

    return prefix, previous_hash, merkle_root, timestamp


def make_header(prefix, nonce, nonce_bits):

    nonce_bytes = nonce.to_bytes(
        nonce_bits // 8,
        "big"
    )

    return prefix + nonce_bytes


# ---------------------------------------------------------
# ADAPTIVE POW ENGINE
# ---------------------------------------------------------

def run_pow(args):

    rng = np.random.default_rng(args.seed)

    circuit = PhotonCircuit(
        rng,
        mean_photons=args.photons,
        threshold=args.threshold
    )

    controller = AdaptiveController(
        args.nonce_bits,
        learning_rate=args.learning_rate,
        exploration=args.exploration
    )

    prefix, previous_hash, merkle_root, timestamp = (
        create_block_prefix(args.difficulty)
    )

    target = make_target(args.difficulty)

    print("=" * 72)
    print("PHOTON ADAPTIVE PROOF OF WORK")
    print("=" * 72)

    print("Hash algorithm : Double SHA-256")
    print("Nonce source   : Photon measurements")
    print("Feedback       : Hash leading-zero reward")
    print("Search method  : Adaptive stochastic sampling")
    print("Nonce bits     :", args.nonce_bits)
    print("Difficulty     :", args.difficulty)
    print("Max attempts   :", args.max_attempts)

    print()
    print("BLOCK CHALLENGE")
    print("-" * 50)

    print("Previous hash :", previous_hash.hex())
    print("Merkle root   :", merkle_root.hex())
    print("Timestamp     :", timestamp)
    print("Target        :", f"{target:064X}")

    print()
    print("STARTING PHOTON FEEDBACK LOOP")
    print("-" * 72)

    start = time.perf_counter()

    best_hash = None
    best_nonce = None

    success = False

    for attempt in range(1, args.max_attempts + 1):

        # 1. Read adaptive optical probabilities.
        probabilities = controller.probabilities()

        # 2. Generate nonce directly from photons.
        nonce, bits = circuit.generate_nonce(probabilities)

        # 3. Construct block header.
        header = make_header(
            prefix,
            nonce,
            args.nonce_bits
        )

        # 4. Calculate double SHA-256.
        digest = double_sha256(header)

        hash_value = int.from_bytes(digest, "big")

        # 5. Obtain reward from leading-zero score.
        score = leading_zero_bits(digest)

        # 6. Feed result back into photon controller.
        improved, advantage = controller.update(
            bits,
            score,
            nonce
        )

        if improved:

            best_hash = digest
            best_nonce = nonce

        elapsed = time.perf_counter() - start

        rate = attempt / elapsed if elapsed > 0 else 0.0

        marker = " * BEST" if improved else ""

        print(
            f"Attempt {attempt:5d} | "
            f"nonce={nonce:0{args.nonce_bits // 4}X} | "
            f"zeros={score:3d} | "
            f"reward={score / 32.0:.3f} | "
            f"rate={rate:.2f}/s"
            f"{marker}"
        )

        # 7. Stop immediately on a valid PoW.
        if hash_value <= target:

            success = True

            print()
            print("VALID POW FOUND")

            break

    total_time = time.perf_counter() - start

    # -----------------------------------------------------
    # RESULTS
    # -----------------------------------------------------

    print()
    print("=" * 72)

    if success:

        print("RESULT: BLOCK ACCEPTED")

    else:

        print("RESULT: NO VALID POW FOUND")
        print("Attempt limit reached.")
        print("No sequential nonce search was performed.")

    print("=" * 72)

    print()
    print("BEST CANDIDATE")

    if best_nonce is not None:

        print(
            "Nonce         :",
            f"{best_nonce:0{args.nonce_bits // 4}X}"
        )

        print("Hash          :", best_hash.hex())

        print(
            "Leading zeros :",
            leading_zero_bits(best_hash)
        )

    # -----------------------------------------------------
    # ADAPTIVE STATE
    # -----------------------------------------------------

    final_probabilities = controller.probabilities()

    print()
    print("ADAPTIVE OPTICAL STATE")
    print("-" * 50)

    print(
        "Mean bit probability:",
        f"{np.mean(final_probabilities):.4f}"
    )

    print(
        "Probability range   :",
        f"{np.min(final_probabilities):.4f}",
        "to",
        f"{np.max(final_probabilities):.4f}"
    )

    print(
        "Best observed score :",
        controller.best_score
    )

    print(
        "Feedback updates    :",
        controller.updates
    )

    # -----------------------------------------------------
    # PERFORMANCE
    # -----------------------------------------------------

    print()
    print("PERFORMANCE")
    print("-" * 50)

    print("Attempts          :", attempt)
    print("Nonce increments  : 0")
    print("Nonce enumeration : 0")
    print("Photon measurements:", circuit.total_measurements)
    print("Photon counts     :", circuit.total_photons)
    print("Double SHA-256s   :", attempt)
    print("SHA-256 primitives:", attempt * 2)

    print(f"Elapsed time      : {total_time:.6f} seconds")

    if total_time > 0:

        print(
            f"Attempt rate      : {attempt / total_time:.2f} attempts/s"
        )

        print(
            f"Photon bit rate   : "
            f"{circuit.total_measurements / total_time:.2f} bits/s"
        )

    print()
    print("ADAPTIVE FEEDBACK : ENABLED")
    print("SEQUENTIAL MINING : DISABLED")

    print("=" * 72)

    return success


# ---------------------------------------------------------
# CLI
# ---------------------------------------------------------

def main():

    parser = argparse.ArgumentParser(
        description="Photon-adaptive stochastic Proof of Work"
    )

    parser.add_argument(
        "--nonce-bits",
        type=int,
        default=32
    )

    parser.add_argument(
        "--difficulty",
        type=int,
        default=32
    )

    parser.add_argument(
        "--max-attempts",
        type=int,
        default=500
    )

    parser.add_argument(
        "--photons",
        type=float,
        default=40.0
    )

    parser.add_argument(
        "--threshold",
        type=float,
        default=0.45
    )

    parser.add_argument(
        "--learning-rate",
        type=float,
        default=0.20
    )

    parser.add_argument(
        "--exploration",
        type=float,
        default=0.08
    )

    parser.add_argument(
        "--seed",
        type=int,
        default=None
    )

    args = parser.parse_args()

    if args.nonce_bits not in (8, 16, 32, 64):
        parser.error("Nonce bits must be 8, 16, 32 or 64")

    if not 0 <= args.difficulty <= 256:
        parser.error("Difficulty must be between 0 and 256")

    if args.max_attempts < 1:
        parser.error("Max attempts must be positive")

    if args.photons <= 0:
        parser.error("Photon intensity must be positive")

    if not 0 <= args.threshold <= 1:
        parser.error("Threshold must be between 0 and 1")

    if args.learning_rate <= 0:
        parser.error("Learning rate must be positive")

    if not 0 <= args.exploration <= 1:
        parser.error("Exploration must be between 0 and 1")

    run_pow(args)


if __name__ == "__main__":
    main()
