#!/usr/bin/env python3
"""
Photonic-camera PoW miner (simulation).

Each round:
  1. A nonce r is encoded as an n-pixel secret pattern (the "source").
  2. The AND-gated camera is exposed for F frames; a pixel can only click if
     the source pixel is 1, and then with probability p per frame, plus
     Gaussian sensor noise thresholded at 0.5.
  3. Lit method: cumulative OR over frames recovers the pattern.
  4. The recovered frame is hashed: sha256d(header || frame_bytes).
  5. Stop when the hash, as a 256-bit integer, is below the PoW target.

Note: the sensor only reads back a pattern you chose, so expected rounds are
still ~2^bits, same as brute force, with extra per-round cost F frames.
"""
import argparse
import hashlib
import math
import multiprocessing as mp
import time
from typing import Optional, Tuple

import numpy as np


def sha256d(b: bytes) -> bytes:
    return hashlib.sha256(hashlib.sha256(b).digest()).digest()


class PhotonicSensor:
    def __init__(self, n_pixels: int = 32, p: float = 0.01,
                 noise_sigma: float = 0.08, miss_prob: float = 1e-6,
                 seed: Optional[int] = None):
        self.n, self.p, self.sigma = n_pixels, p, noise_sigma
        self.rng = np.random.default_rng(seed)
        # frames so that P(any lit pixel never clicks) <= miss_prob
        self.frames = math.ceil(math.log(n_pixels / miss_prob) / p)

    def recover(self, secret: np.ndarray) -> np.ndarray:
        R = self.rng.random((self.frames, self.n)) < self.p        # photon arrivals
        X = R & secret.astype(bool)                                # AND gate with source
        S = X.astype(np.float32) + self.rng.normal(
            0, self.sigma, X.shape).astype(np.float32)             # sensor noise
        return (S > 0.5).any(axis=0).astype(np.uint8)              # cumulative OR


def nonce_to_pattern(r: int, n: int) -> np.ndarray:
    return np.array([(r >> i) & 1 for i in range(n)], dtype=np.uint8)


# ---------------------------------------------------------------- workers
_stop = None

def _init(ev):
    global _stop
    _stop = ev


def _worker(args):
    header, target, n, p, sigma, miss, wid, step, seed, max_rounds = args
    sensor = PhotonicSensor(n, p, sigma, miss, seed=seed + wid)
    r, rounds = wid, 0
    while not _stop.is_set() and rounds < max_rounds and r < (1 << n):
        secret = nonce_to_pattern(r, n)
        lit = sensor.recover(secret)
        h = sha256d(header + lit.tobytes())
        rounds += 1
        if int.from_bytes(h, "big") < target:
            _stop.set()
            return r, lit.tobytes(), h.hex(), rounds, sensor.frames
        r += step
    return None, None, None, rounds, sensor.frames


def mine_photonic(header: bytes, bits: int, n_pixels: int = 32, p: float = 0.01,
                  noise_sigma: float = 0.08, miss_prob: float = 1e-6,
                  workers: Optional[int] = None, seed: int = 1,
                  max_rounds: int = 10**9) -> Optional[Tuple]:
    workers = workers or mp.cpu_count()
    target = 1 << (256 - bits)
    ev = mp.Event()
    jobs = [(header, target, n_pixels, p, noise_sigma, miss_prob, w, workers, seed, max_rounds)
            for w in range(workers)]
    t0 = time.time()
    winner, total_rounds, frames = None, 0, 0
    with mp.Pool(workers, initializer=_init, initargs=(ev,)) as pool:
        for res in pool.imap_unordered(_worker, jobs):
            total_rounds += res[3]
            frames = res[4]
            if res[0] is not None and winner is None:
                winner = res
    dt = time.time() - t0
    if winner is None:
        return None
    r, frame, h, _, _ = winner
    return r, frame, h, total_rounds, total_rounds * frames, dt


def mine_baseline(header: bytes, bits: int, n_pixels: int = 32,
                  max_rounds: int = 10**9) -> Optional[Tuple]:
    """Direct hashing of the same nonce->pattern space, no sensor."""
    target = 1 << (256 - bits)
    t0 = time.time()
    for r in range(min(max_rounds, 1 << n_pixels)):
        frame = nonce_to_pattern(r, n_pixels).tobytes()
        h = sha256d(header + frame)
        if int.from_bytes(h, "big") < target:
            return r, frame, h.hex(), r + 1, time.time() - t0
    return None


def verify(header: bytes, bits: int, frame: bytes) -> bool:
    return int.from_bytes(sha256d(header + frame), "big") < (1 << (256 - bits))


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--header", default="George Wagenknecht - 2026")
    ap.add_argument("--bits", type=int, default=32, help="leading zero bits required")
    ap.add_argument("--pixels", type=int, default=32)
    ap.add_argument("--p", type=float, default=0.01, help="photon probability per pixel per frame")
    ap.add_argument("--noise", type=float, default=0.08)
    ap.add_argument("--miss", type=float, default=1e-6, help="allowed probability of missing a lit pixel")
    ap.add_argument("--workers", type=int, default=None)
    ap.add_argument("--seed", type=int, default=1)
    ap.add_argument("--baseline", action="store_true", help="also run direct-hash comparison")
    a = ap.parse_args()

    header = a.header.encode()
    print(f"[*] header={a.header!r} bits={a.bits} pixels={a.pixels} p={a.p} noise={a.noise}")
    res = mine_photonic(header, a.bits, a.pixels, a.p, a.noise, a.miss, a.workers, a.seed)
    if res is None:
        print("[-] no solution found")
        return
    r, frame, h, rounds, frames, dt = res
    print(f"[+] PoW satisfied (nonce {r})")
    print(f"    pattern : {''.join(str(b) for b in frame)}")
    print(f"    hash    : {h}")
    print(f"    rounds  : {rounds} (all workers), sensor frames: {frames:,}, time: {dt:.2f}s")
    print(f"    verified: {verify(header, a.bits, frame)}")

    if a.baseline:
        b = mine_baseline(header, a.bits, a.pixels)
        if b:
            br, bf, bh, brounds, bdt = b
            print(f"[=] baseline direct hashing: nonce {br}, {brounds} hashes, {bdt:.3f}s "
                  f"(photonic overhead ~{frames // max(brounds, 1):,}x in frames)")


if __name__ == "__main__":
    main()
