#!/usr/bin/env python3
"""
RP-GHOST WEBCAM & PHASE-CORRELATION PIPELINE + NEWS HEADLINE CHANNEL
--------------------------------------------------------------------
Adds a NewsAPI.org headline fetcher. Each headline is split into 3-byte
chunks, framed as [8-bit index | 24-bit data | 8-bit CRC-8] (40 slots, same
width as the price frame), sent through the optoelectronic phase channel,
decoded, CRC-checked, retried on failure, and printed as plain text.

Set your key:   export NEWS_API_KEY="your_key_here"   (https://newsapi.org)
Without a key the fetcher falls back to built-in sample headlines.
"""

import hashlib
import json
import math
import os
import queue
import threading
import time
import re
import urllib.request
from collections import deque
from datetime import datetime, timedelta, timezone

import numpy as np

try:
    import cv2
    HAS_OPENCV = True
except ImportError:
    HAS_OPENCV = False

try:
    import websocket
    HAS_WS = True
except ImportError:
    HAS_WS = False

# ============================================================================
# CONFIGURATION & CONSTANTS
# ============================================================================

LAMBDA_BASE = 10000.0
SIGMA_C = 0.005
N_SLOTS = 40
WEBCAM_INDEX = 0
WEBCAM_WIDTH = 640
WEBCAM_HEIGHT = 480
WEBCAM_FPS = 30

NEWS_API_KEY = os.environ.get("NEWS_API_KEY", "")
NEWS_COUNTRY = "au"
NEWS_POLL_SECONDS = 300       # free tier = 100 requests/day; 300 s is safe
NEWS_MAX_BYTES = 96           # max headline length sent over the channel
NEWS_CHUNK_BYTES = 3          # data bytes per 40-bit frame
NEWS_MAX_RETRIES = 4          # re-sends per frame on CRC failure
NEWS_WINDOWS = 2000           # screening decode (fast, every story)
LARGE_DECODE_WINDOWS = 20000  # large decode, IMMINENT stories only (10x the averaging)
LARGE_DECODE_RETRIES = 8      # CRC re-sends per frame during the large decode
AGE_FRESH_SEC = 3600          # page younger than 1 hour  => FRESH
AGE_OLD_SEC = 86400           # page older than 24 hours  => OLD
NEWS_BATCH_SIZE = 25          # stories fetched and decoded per batch
MAX_STORIES = 25              # stories kept in the table (one batch)
TABLE_REPRINT_CYCLES = 1      # reprint full table every N cycles (and whenever new stories arrive)
BLOCK_API = "https://mempool.space/api"   # public Bitcoin block explorer API (no key needed)
BLOCK_POLL_SECONDS = 10       # how often to check for a new chain tip
BLOCK_SIM_INTERVAL = 15       # simulated block interval if the API is unreachable
IMMINENT_WINDOW_SEC = 36000   # story time within the next 10 hours => IMMINENT

SAMPLE_AGES_SEC = [300, 1200, 3600, 10800, 21600, 43200, 90000, 259200,
                   900, 2700, 5400, 14400, 28800, 50000, 70000, 100000, 180000, 600, 7200, 36000, 60000, 3000, 12000, 450000, 1500]  # demo page ages

SAMPLE_HEADLINES = [
    "Markets steady as investors await central bank decision",
    "New study links sleep quality to long-term heart health",
    "City council approves plan for expanded bike lanes",
    "Tech firm unveils faster battery with ten minute charging",
    "Heavy rain expected across the region this weekend",
    "Storm warning issued, landfall expected in 45 minutes",
    "Council to vote on transit budget tomorrow",
    "Power restored to thousands, outage began 2 hours ago",
    "Airline announces new routes across the Pacific",
    "Local bakery wins national award for sourdough",
    "Scientists detect unusual signal from distant galaxy",
    "Home prices cool for third straight month",
    "School board debates later start times for students",
    "Marathon runners brave cold snap in city centre",
    "New museum wing opens to the public at 10 am",
    "Rail strike talks resume in 30 minutes",
    "Wildfire containment reaches 60 percent",
    "Electric bus fleet expands to three more suburbs",
    "Hospital opens new children's ward",
    "Film festival announces lineup for tonight",
    "Farmers report strong harvest despite dry spell",
    "Cyber attack disrupts council services, restored 4 hours ago",
    "Tennis star returns from injury this evening",
    "Bridge repairs to finish in 2 days",
    "Library launches free coding classes",
]


# ============================================================================
# HELPERS & CRC-8
# ============================================================================

def compute_crc8(data_bytes):
    crc = 0x00
    for byte in data_bytes:
        crc ^= byte
        for _ in range(8):
            crc = ((crc << 1) ^ 0x07) & 0xFF if crc & 0x80 else (crc << 1) & 0xFF
    return crc


def format_clock_time(timestamp_ns):
    seconds = timestamp_ns / 1e9
    clock = time.strftime("%H:%M:%S", time.localtime(seconds))
    ms = int((timestamp_ns % 1_000_000_000) // 1_000_000)
    return f"{clock}.{ms:03d}"


def timestamp_to_code(timestamp_ns):
    return ((int(timestamp_ns) // 1_000_000) % 60000) & 0xFFFF


def price_delta_to_code(price_delta):
    cents = max(-32768, min(32767, int(round(float(price_delta) * 100.0))))
    return cents & 0xFFFF


def code_to_signed_price_delta(code):
    value = int(code) & 0xFFFF
    if value >= 0x8000:
        value -= 0x10000
    return value / 100.0


def bits_to_code(bits):
    code = 0
    for bit in bits:
        code = (code << 1) | (int(bit) & 1)
    return code


def int_to_bits(value, width):
    return [(value >> (width - 1 - k)) & 1 for k in range(width)]


def encode_payload_bits(timestamp_ns, price_delta, frame_entropy_hash=0):
    time_code = timestamp_to_code(timestamp_ns) ^ (frame_entropy_hash & 0xFFFF)
    delta_code = price_delta_to_code(price_delta)
    payload = bytearray([(time_code >> 8) & 0xFF, time_code & 0xFF,
                         (delta_code >> 8) & 0xFF, delta_code & 0xFF])
    crc_val = compute_crc8(payload)
    return np.array(int_to_bits(time_code, 16) + int_to_bits(delta_code, 16)
                    + int_to_bits(crc_val, 8), dtype=int)


def decode_payload_bits(bits):
    bits = np.asarray(bits, dtype=int).flatten()
    if len(bits) != N_SLOTS:
        raise ValueError("Invalid payload length")
    timestamp_code = bits_to_code(bits[:16])
    delta_code = bits_to_code(bits[16:32])
    received_crc = bits_to_code(bits[32:])
    payload = bytearray([(timestamp_code >> 8) & 0xFF, timestamp_code & 0xFF,
                         (delta_code >> 8) & 0xFF, delta_code & 0xFF])
    return (timestamp_code, code_to_signed_price_delta(delta_code),
            received_crc == compute_crc8(payload))


def make_payload_tilt(bits, eps_abs):
    bits = np.asarray(bits, dtype=float)
    strength = max(float(eps_abs), 0.25)
    return 2.0 * strength * (bits - 0.5)


# ============================================================================
# TEXT FRAMING (news headlines)
# ============================================================================

def encode_text_frame(index, chunk):
    """40 bits: 8-bit index | 24-bit data (3 bytes) | 8-bit CRC-8 over index+data."""
    chunk = bytes(chunk).ljust(NEWS_CHUNK_BYTES, b"\x00")[:NEWS_CHUNK_BYTES]
    body = bytes([index & 0xFF]) + chunk
    crc = compute_crc8(body)
    return np.array(int_to_bits(body[0], 8)
                    + [b for byte in chunk for b in int_to_bits(byte, 8)]
                    + int_to_bits(crc, 8), dtype=int)


def decode_text_frame(bits):
    bits = np.asarray(bits, dtype=int).flatten()
    index = bits_to_code(bits[:8])
    chunk = bytes(bits_to_code(bits[8 + 8 * i: 16 + 8 * i]) for i in range(NEWS_CHUNK_BYTES))
    received_crc = bits_to_code(bits[32:40])
    ok = received_crc == compute_crc8(bytes([index]) + chunk)
    return index, chunk, ok


def transmit_headline(viewport, headline, windows=NEWS_WINDOWS, max_retries=NEWS_MAX_RETRIES):
    """Sends a headline through the phase channel.
    Returns (plain_text, frames, retries, failed, min_margin_sigma)."""
    raw = headline.encode("utf-8")[:NEWS_MAX_BYTES] + b"\x00"   # null terminator
    chunks = [raw[i:i + NEWS_CHUNK_BYTES] for i in range(0, len(raw), NEWS_CHUNK_BYTES)]
    sigma_z = math.sqrt(1.0 + SIGMA_C ** 2 * LAMBDA_BASE)
    scale = sigma_z / math.sqrt(windows)      # std-dev of each slot's window-average

    received = bytearray()
    retries = failed = 0
    min_margin = float("inf")
    for i, chunk in enumerate(chunks):
        bits = encode_text_frame(i, chunk)
        tilt = make_payload_tilt(bits, 0.02 * sigma_z)
        good = None
        for attempt in range(max_retries):
            Z = viewport.generate_window_block(windows, N_SLOTS, tilt=tilt)
            m = Z.mean(axis=0)
            idx, data, ok = decode_text_frame((m > 0).astype(int))
            if ok and idx == (i & 0xFF):
                good = data
                min_margin = min(min_margin, float(np.min(np.abs(m)) / scale))
                break
            retries += 1
        if good is None:
            failed += 1
            good = b"?" * NEWS_CHUNK_BYTES
        received += good

    text = bytes(received).split(b"\x00", 1)[0].decode("utf-8", errors="replace")
    return text, len(chunks), retries, failed, (0.0 if min_margin == float("inf") else min_margin)


# ============================================================================
# PAGE AGE CHANNEL (publish timestamp -> phase channel -> decoded age)
# ============================================================================

def encode_age_frame(published_ns):
    """40 bits: 32-bit Unix publish time (seconds) | 8-bit CRC-8."""
    secs = int(published_ns // 10**9) & 0xFFFFFFFF
    crc = compute_crc8(secs.to_bytes(4, "big"))
    return np.array(int_to_bits(secs, 32) + int_to_bits(crc, 8), dtype=int)


def decode_age_frame(bits):
    bits = np.asarray(bits, dtype=int).flatten()
    secs = bits_to_code(bits[:32])
    ok = bits_to_code(bits[32:40]) == compute_crc8(secs.to_bytes(4, "big"))
    return secs, ok


def transmit_age(viewport, published_ns, windows=NEWS_WINDOWS, max_retries=NEWS_MAX_RETRIES):
    """Sends a page's publish time through the phase channel.
    Returns (decoded_publish_ns or None, retries, crc_ok, margin_sigma)."""
    if published_ns is None:
        return None, 0, False, 0.0
    bits = encode_age_frame(published_ns)
    sigma_z = math.sqrt(1.0 + SIGMA_C ** 2 * LAMBDA_BASE)
    tilt = make_payload_tilt(bits, 0.02 * sigma_z)
    scale = sigma_z / math.sqrt(windows)
    retries = 0
    for _ in range(max_retries):
        Z = viewport.generate_window_block(windows, N_SLOTS, tilt=tilt)
        m = Z.mean(axis=0)
        secs, ok = decode_age_frame((m > 0).astype(int))
        if ok:
            return secs * 10**9, retries, True, float(np.min(np.abs(m)) / scale)
        retries += 1
    return None, retries, False, 0.0


def format_age(age_sec):
    s = max(0, int(age_sec))
    d, rem = divmod(s, 86400)
    h, rem = divmod(rem, 3600)
    m, sec = divmod(rem, 60)
    if d:
        return f"{d}d {h}h"
    if h:
        return f"{h}h {m}m"
    if m:
        return f"{m}m {sec}s"
    return f"{sec}s"


def age_label(age_sec):
    if age_sec < AGE_FRESH_SEC:
        return "FRESH"
    return "OLD" if age_sec >= AGE_OLD_SEC else "RECENT"


# ============================================================================
# STORY TIME EXTRACTION & STATUS
# ============================================================================

_REL = re.compile(r"\b(?:in|within)\s+(an?|\d+)\s*(second|sec|minute|min|hour|hr|day)s?\b", re.I)
_AGO = re.compile(r"\b(an?|\d+)\s*(second|sec|minute|min|hour|hr|day)s?\s+ago\b", re.I)
_CLOCK_12 = re.compile(r"\b(\d{1,2})(?::(\d{2}))?\s*([ap])\.?m\.?(?!\w)", re.I)
_CLOCK_24 = re.compile(r"\b([01]?\d|2[0-3]):([0-5]\d)\b")
_KEYWORDS = [("this morning", 0, 9), ("this afternoon", 0, 15), ("this evening", 0, 18),
             ("tonight", 0, 20), ("tomorrow", 1, 9)]
_UNIT_SEC = {"second": 1, "sec": 1, "minute": 60, "min": 60, "hour": 3600, "hr": 3600, "day": 86400}


def _qty(tok):
    return 1 if tok.lower() in ("a", "an") else int(tok)


def extract_story_time(text, ref_ns):
    """Finds a time reference in decoded story text. Returns (time_ns, matched_text) or None.
    Clock times are interpreted as local time today."""
    m = _REL.search(text)
    if m:
        return ref_ns + _qty(m.group(1)) * _UNIT_SEC[m.group(2).lower()] * 10**9, m.group(0)
    m = _AGO.search(text)
    if m:
        return ref_ns - _qty(m.group(1)) * _UNIT_SEC[m.group(2).lower()] * 10**9, m.group(0)

    now = datetime.fromtimestamp(ref_ns / 1e9)
    m = _CLOCK_12.search(text)
    if m and 1 <= int(m.group(1)) <= 12:
        hour = int(m.group(1)) % 12 + (12 if m.group(3).lower() == "p" else 0)
        dt = now.replace(hour=hour, minute=int(m.group(2) or 0), second=0, microsecond=0)
        return int(dt.timestamp() * 1e9), m.group(0).strip()
    m = _CLOCK_24.search(text)
    if m:
        dt = now.replace(hour=int(m.group(1)), minute=int(m.group(2)), second=0, microsecond=0)
        return int(dt.timestamp() * 1e9), m.group(0)
    low = text.lower()
    for word, add_days, hour in _KEYWORDS:
        if word in low:
            dt = (now + timedelta(days=add_days)).replace(hour=hour, minute=0, second=0, microsecond=0)
            return int(dt.timestamp() * 1e9), word
    return None


def classify_story_time(story_ns, now_ns, window_sec=IMMINENT_WINDOW_SEC):
    diff = (story_ns - now_ns) / 1e9
    if diff <= 0:
        return "PAST", diff
    return ("IMMINENT" if diff <= window_sec else "UPCOMING"), diff


def human_delta(diff_sec):
    s = int(abs(diff_sec))
    h, rem = divmod(s, 3600)
    m, sec = divmod(rem, 60)
    txt = (f"{h}h " if h else "") + (f"{m}m " if m or h else "") + f"{sec}s"
    return f"in {txt}" if diff_sec > 0 else f"{txt} ago"


def parse_iso_ns(value):
    try:
        dt = datetime.fromisoformat(value.replace("Z", "+00:00"))
        return int(dt.astimezone(timezone.utc).timestamp() * 1e9)
    except Exception:
        return None


def decode_story(viewport, headline, published_ns, ref_ns,
                 windows=NEWS_WINDOWS, max_retries=NEWS_MAX_RETRIES):
    """Sends one headline (+ its publish time) through the phase channel at the given decode size."""
    text, frames, retries, failed, margin_t = transmit_headline(viewport, headline, windows, max_retries)
    found = extract_story_time(text, ref_ns)
    if found:
        story_ns, label = found
        from_text = True
    else:
        story_ns, label, from_text = published_ns, "publish time", False
    pub_decoded_ns, age_retries, age_ok, margin_a = transmit_age(viewport, published_ns, windows, max_retries)
    return {"sent": headline, "text": text, "frames": frames, "retries": retries,
            "failed": failed, "story_ns": story_ns, "label": label, "from_text": from_text,
            "pub_ns": pub_decoded_ns, "age_ok": age_ok, "age_retries": age_retries,
            "windows": windows, "margin": min(margin_t, margin_a) if age_ok else margin_t}


def story_status(story, now_ns):
    """Returns (status, delta_sec or None) evaluated against the current time."""
    if story["story_ns"] is None:
        return "NO EVENT TIME", None
    state, diff = classify_story_time(story["story_ns"], now_ns)
    if not story["from_text"]:
        return "NO EVENT TIME", diff
    return state, diff


def print_story_table(stories, now_ns):
    print(f" [IMMINENT STORIES] {len(stories)} (large decode: {LARGE_DECODE_WINDOWS} windows/frame)")
    for n, s in enumerate(stories, 1):
        state, diff = story_status(s, now_ns)
        integrity = "" if s["failed"] == 0 else f" | {s['failed']} frame(s) unrecoverable"
        print(f"  [{n:02d}] {state} | {format_clock_time(s['story_ns'])} ({human_delta(diff)}) "
              f'| matched "{s["label"]}"{integrity}  <<< IMMINENT')
        print(f"       {s['text']}")
        if s["pub_ns"] is None:
            print("       page age: unknown (no publish time, or CRC failed)")
        else:
            age = (now_ns - s["pub_ns"]) / 1e9
            print(f"       page age: {format_age(age)} old [{age_label(age)}] | published "
                  f"{time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(s['pub_ns'] / 1e9))} | "
                  f"CRC {'PASS' if s['age_ok'] else 'FAIL'}")
        print(f"       large decode: {s['windows']} windows | {s['frames']} frames | "
              f"CRC retries {s['retries']} | min bit margin {s['margin']:.1f} sigma | "
              f"matches screening decode: {'YES' if s.get('quick_match') else 'NO'}")


# ============================================================================
# WEBCAM THREAD
# ============================================================================

class WebcamEntropySource(threading.Thread):
    def __init__(self, camera_index=WEBCAM_INDEX):
        super().__init__(daemon=True)
        self.camera_index = camera_index
        self.frame_queue = queue.Queue(maxsize=2)
        self.running = True
        self.latest_hash = 0
        self.frame_count = 0

    def run(self):
        if not HAS_OPENCV:
            print("[WEBCAM] OpenCV not available. Running in headless pseudo-entropy mode.")
            while self.running:
                time.sleep(1.0 / WEBCAM_FPS)
                dummy = np.random.randint(0, 255, (WEBCAM_HEIGHT, WEBCAM_WIDTH, 3), dtype=np.uint8)
                self.latest_hash = int(hashlib.sha256(dummy.tobytes()).hexdigest()[:4], 16)
                self.frame_count += 1
            return

        cap = cv2.VideoCapture(self.camera_index)
        cap.set(cv2.CAP_PROP_FRAME_WIDTH, WEBCAM_WIDTH)
        cap.set(cv2.CAP_PROP_FRAME_HEIGHT, WEBCAM_HEIGHT)
        cap.set(cv2.CAP_PROP_FPS, WEBCAM_FPS)
        if not cap.isOpened():
            print(f"[WEBCAM] Error: Could not open camera index {self.camera_index}")
            self.running = False
            return
        print(f"[WEBCAM] Opened camera #{self.camera_index} @ {WEBCAM_WIDTH}x{WEBCAM_HEIGHT}")

        while self.running:
            ret, frame = cap.read()
            if not ret:
                time.sleep(0.01)
                continue
            gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
            self.latest_hash = int.from_bytes(hashlib.sha256(gray.tobytes()).digest()[:2], "big")
            self.frame_count += 1
            try:
                self.frame_queue.put_nowait((gray, self.latest_hash))
            except queue.Full:
                try:
                    self.frame_queue.get_nowait()
                except queue.Empty:
                    pass
                self.frame_queue.put_nowait((gray, self.latest_hash))

        cap.release()
        print("[WEBCAM] Released camera stream.")

    def stop(self):
        self.running = False


# ============================================================================
# OPTICAL VIEWPORT
# ============================================================================

class OptoelectronicViewport:
    def __init__(self, lambd=LAMBDA_BASE, sigma_c=SIGMA_C):
        self.lambd = lambd
        self.sigma_c = sigma_c
        print("[OPTICAL] Phase-coherent optical viewport initialized")

    def generate_window_block(self, n_windows, n_slots, tilt=None):
        shared_noise = np.random.normal(0.0, self.sigma_c, size=(n_windows, 1))
        lam = self.lambd * (1.0 + shared_noise)
        counts = np.random.poisson(np.clip(lam, 1.0, None), size=(n_windows, n_slots))
        Z = (counts - self.lambd) / np.sqrt(self.lambd)
        if tilt is not None:
            Z += tilt
        return Z


# ============================================================================
# NEWS FETCHER THREAD (NewsAPI.org)
# ============================================================================

class NewsFetcher(threading.Thread):
    """Polls NewsAPI top-headlines and queues unseen titles for the main loop."""

    def __init__(self, api_key=NEWS_API_KEY, country=NEWS_COUNTRY, poll_seconds=NEWS_POLL_SECONDS):
        super().__init__(daemon=True)
        self.api_key = api_key
        self.country = country
        self.poll_seconds = poll_seconds
        self.headlines = deque()
        self.seen = set()
        self.lock = threading.Lock()
        self.running = True

    def _fetch(self):
        url = f"https://newsapi.org/v2/top-headlines?country={self.country}&pageSize={NEWS_BATCH_SIZE}"
        req = urllib.request.Request(url, headers={"X-Api-Key": self.api_key,
                                                   "User-Agent": "rp-ghost/1.0"})
        with urllib.request.urlopen(req, timeout=10) as resp:
            data = json.loads(resp.read().decode("utf-8"))
        if data.get("status") != "ok":
            raise RuntimeError(data.get("message", "NewsAPI error"))
        return [(a["title"].strip(), parse_iso_ns(a.get("publishedAt") or ""))
                for a in data.get("articles", [])
                if a.get("title") and a["title"] != "[Removed]"]

    def _add(self, titles):
        with self.lock:
            for title, published_ns in titles:
                if title not in self.seen:
                    self.seen.add(title)
                    self.headlines.append((title, published_ns))

    def pop(self):
        with self.lock:
            return self.headlines.popleft() if self.headlines else None

    def pop_batch(self, n=NEWS_BATCH_SIZE):
        with self.lock:
            return [self.headlines.popleft() for _ in range(min(n, len(self.headlines)))]

    def run(self):
        if not self.api_key:
            print("[NEWS] NEWS_API_KEY not set. Using sample headlines.")
            now = time.time_ns()
            self._add([(t, now - age * 10**9) for t, age in zip(SAMPLE_HEADLINES, SAMPLE_AGES_SEC)])
            return
        while self.running:
            try:
                self._add(self._fetch())
            except Exception as e:
                print(f"[NEWS] Fetch failed: {e}")
            for _ in range(self.poll_seconds):
                if not self.running:
                    break
                time.sleep(1)

    def stop(self):
        self.running = False


# ============================================================================
# BINANCE PRICE FETCHER
# ============================================================================

class AsyncPriceFetcher(threading.Thread):
    def __init__(self):
        super().__init__(daemon=True)
        self.url = "wss://stream.binance.com:443/ws/btcusdt@bookTicker"
        self.ticks = queue.Queue(maxsize=1)
        self.running = True
        self.ws = None
        self.received = 0

    def _on_message(self, ws, message):
        try:
            data = json.loads(message)
            if data.get("s") != "BTCUSDT":
                return
            bid, ask = float(data.get("b", 0)), float(data.get("a", 0))
            if bid <= 0 or ask <= 0:
                return
            tick = {"price": (bid + ask) / 2.0, "received_ns": time.time_ns()}
            try:
                self.ticks.put_nowait(tick)
            except queue.Full:
                try:
                    self.ticks.get_nowait()
                except queue.Empty:
                    pass
                self.ticks.put_nowait(tick)
            self.received += 1
        except Exception:
            pass

    def run(self):
        if not HAS_WS:
            print("[FETCH] websocket-client missing. Running with synthetic price simulator.")
            p = 90000.0
            while self.running:
                time.sleep(1.0)
                p += np.random.normal(0, 10)
                try:
                    self.ticks.put_nowait({"price": p, "received_ns": time.time_ns()})
                except queue.Full:
                    pass
            return
        while self.running:
            try:
                self.ws = websocket.WebSocketApp(
                    self.url,
                    on_message=lambda ws, m: self._on_message(ws, m),
                    on_error=lambda ws, e: None,
                    on_close=lambda ws, c, m: None)
                self.ws.run_forever(ping_interval=20, ping_timeout=10)
            except Exception:
                pass
            if self.running:
                time.sleep(3)

    def stop(self):
        self.running = False
        if self.ws:
            self.ws.close()


# ============================================================================
# BLOCKCHAIN: NEXT-BLOCK HASH CHANNEL
# ============================================================================
# The next block hash cannot be known in advance (it is the output of proof of
# work), so the script watches the chain tip and, the moment a new block
# arrives, sends its hash / height / timestamp through the phase channel and
# decodes them back with CRC-8 checking.

def leading_zero_bits(hash_hex):
    n = 0
    for byte in bytes.fromhex(hash_hex):
        if byte == 0:
            n += 8
        else:
            return n + 8 - byte.bit_length()
    return n


def transmit_block_hash(viewport, hash_hex, windows=LARGE_DECODE_WINDOWS, max_retries=LARGE_DECODE_RETRIES):
    """32-byte hash -> 11 frames of [idx|3 bytes|CRC-8]. Returns (decoded_hex, retries, failed, margin)."""
    raw = bytes.fromhex(hash_hex)
    chunks = [raw[i:i + NEWS_CHUNK_BYTES] for i in range(0, len(raw), NEWS_CHUNK_BYTES)]
    sigma_z = math.sqrt(1.0 + SIGMA_C ** 2 * LAMBDA_BASE)
    scale = sigma_z / math.sqrt(windows)
    received = bytearray()
    retries = failed = 0
    min_margin = float("inf")
    for i, chunk in enumerate(chunks):
        bits = encode_text_frame(i, chunk)
        tilt = make_payload_tilt(bits, 0.02 * sigma_z)
        good = None
        for _ in range(max_retries):
            Z = viewport.generate_window_block(windows, N_SLOTS, tilt=tilt)
            m = Z.mean(axis=0)
            idx, data, ok = decode_text_frame((m > 0).astype(int))
            if ok and idx == (i & 0xFF):
                good = data
                min_margin = min(min_margin, float(np.min(np.abs(m)) / scale))
                break
            retries += 1
        if good is None:
            failed += 1
            good = b"\xff" * NEWS_CHUNK_BYTES
        received += good
    decoded = bytes(received)[:len(raw)].hex()
    return decoded, retries, failed, (0.0 if min_margin == float("inf") else min_margin)


def transmit_u32(viewport, value, windows=LARGE_DECODE_WINDOWS, max_retries=LARGE_DECODE_RETRIES):
    """40-bit frame: 32-bit unsigned value | CRC-8. Returns (decoded_value or None, retries, ok, margin)."""
    value &= 0xFFFFFFFF
    bits = np.array(int_to_bits(value, 32) + int_to_bits(compute_crc8(value.to_bytes(4, "big")), 8), dtype=int)
    sigma_z = math.sqrt(1.0 + SIGMA_C ** 2 * LAMBDA_BASE)
    tilt = make_payload_tilt(bits, 0.02 * sigma_z)
    scale = sigma_z / math.sqrt(windows)
    retries = 0
    for _ in range(max_retries):
        Z = viewport.generate_window_block(windows, N_SLOTS, tilt=tilt)
        m = Z.mean(axis=0)
        dbits = (m > 0).astype(int)
        got = bits_to_code(dbits[:32])
        if bits_to_code(dbits[32:40]) == compute_crc8(got.to_bytes(4, "big")):
            return got, retries, True, float(np.min(np.abs(m)) / scale)
        retries += 1
    return None, retries, False, 0.0


class BlockFetcher(threading.Thread):
    """Watches the Bitcoin chain tip (mempool.space REST). Queues each NEW block.
    If the API is unreachable at startup it switches to a clearly-labelled simulation."""

    def __init__(self, base=BLOCK_API, poll_seconds=BLOCK_POLL_SECONDS):
        super().__init__(daemon=True)
        self.base = base
        self.poll_seconds = poll_seconds
        self.tip = None
        self.new_blocks = deque()
        self.lock = threading.Lock()
        self.simulated = False
        self.running = True

    def _get(self, path):
        req = urllib.request.Request(self.base + path, headers={"User-Agent": "rp-ghost/1.0"})
        with urllib.request.urlopen(req, timeout=10) as resp:
            return resp.read().decode("utf-8")

    def _poll(self):
        h = self._get("/blocks/tip/hash").strip()
        if len(h) != 64:
            raise RuntimeError("unexpected tip hash")
        with self.lock:
            if self.tip is not None and self.tip["hash"] == h:
                return
        data = json.loads(self._get(f"/block/{h}"))
        blk = {"hash": h, "height": 976109, "timestamp": int(data["timestamp"]),
               "tx_count": data.get("tx_count"), "simulated": False}
        with self.lock:
            first = self.tip is None
            self.tip = blk
            if not first:
                self.new_blocks.append(blk)

    def _simulate(self):
        print("[BLOCK] Block API unreachable - running SIMULATED chain (not real blocks).")
        self.simulated = True
        height = 900000
        while self.running:
            digest = hashlib.sha256(hashlib.sha256(os.urandom(80)).digest()).hexdigest()
            blk = {"hash": ("0" * 18 + digest)[:64], "height": height, "timestamp": int(time.time()),
                   "tx_count": int(np.random.randint(1500, 4000)), "simulated": True}
            with self.lock:
                first = self.tip is None
                self.tip = blk
                if not first:
                    self.new_blocks.append(blk)
            height += 1
            for _ in range(BLOCK_SIM_INTERVAL):
                if not self.running:
                    return
                time.sleep(1)

    def run(self):
        fails = 0
        while self.running:
            try:
                self._poll()
                fails = 0
            except Exception as e:
                fails += 1
                if fails == 1:
                    print(f"[BLOCK] Poll failed: {e}")
                if self.tip is None and fails >= 3:
                    self._simulate()
                    return
                time.sleep(1 if self.tip is None else self.poll_seconds)
                continue
            for _ in range(self.poll_seconds):
                if not self.running:
                    break
                time.sleep(1)

    def pop_new(self):
        with self.lock:
            return self.new_blocks.popleft() if self.new_blocks else None

    def get_tip(self):
        with self.lock:
            return self.tip

    def stop(self):
        self.running = False


# ============================================================================
# ORCHESTRATOR
# ============================================================================

def main():
    print("=" * 78)
    print(" RP-GHOST PIPELINE (CRC-8) + NEWS HEADLINE DECODER + STORY TIME STATUS")
    print("=" * 78)

    webcam = WebcamEntropySource(WEBCAM_INDEX)
    webcam.start()
    fetcher = AsyncPriceFetcher()
    fetcher.start()
    news = NewsFetcher()
    news.start()
    blocks = BlockFetcher()
    blocks.start()
    viewport = OptoelectronicViewport()

    print("[START] Pipeline running. Press Ctrl+C to exit.\n")

    cycle = 0
    price_history = deque(maxlen=20)
    stories = deque(maxlen=MAX_STORIES)
    announced_tip = None

    try:
        while True:
            cycle += 1
            start_ns = time.time_ns()
            current_time_str = format_clock_time(start_ns)

            try:
                tick = fetcher.ticks.get(timeout=5.0)
                price = tick["price"]
            except queue.Empty:
                price = 90000.0 + cycle * 5.0

            price_history.append(price)
            avg_price = sum(price_history) / len(price_history)
            price_delta = price - avg_price
            frame_hash = webcam.latest_hash

            scheduled_ns = start_ns + 1_000_000_000
            bits = encode_payload_bits(scheduled_ns, price_delta, frame_hash)

            sigma_z = math.sqrt(1.0 + SIGMA_C ** 2 * LAMBDA_BASE)
            tilt = make_payload_tilt(bits, 0.02 * sigma_z)
            Z = viewport.generate_window_block(2000, N_SLOTS, tilt=tilt)

            decoded_bits = (Z.mean(axis=0) > 0).astype(int)
            decoded_code, decoded_delta, crc_valid = decode_payload_bits(decoded_bits)

            minute_start = (int(start_ns) // 60_000_000_000) * 60_000_000_000
            decoded_ns = minute_start + (int(decoded_code) & 0xFFFF) * 1_000_000
            if decoded_ns - start_ns < -30_000_000_000:
                decoded_ns += 60_000_000_000
            elif decoded_ns - start_ns > 30_000_000_000:
                decoded_ns -= 60_000_000_000

            decoded_time = format_clock_time(decoded_ns)
            time_diff_sec = (decoded_ns - start_ns) / 1e9
            exact_bits = int(np.sum(decoded_bits == bits))

            print("-" * 78)
            print(f" [CYCLE #{cycle}] Webcam Entropy Hash: 0x{frame_hash:04X} | Frames: {webcam.frame_count}")
            print(f" BTC Price: ${price:,.2f} (Avg: ${avg_price:,.2f}) | Delta: {price_delta:+.2f}")
            print(f" Current Timestamp: {current_time_str} | Decoded Timestamp: {decoded_time}")
            print(f" Time Difference: {time_diff_sec:+.3f} s (Scheduled Offset: +1.000 s)")
            print(f" CRC-8 Integrity Check: {'PASS' if crc_valid else 'FAIL'}")
            print(f" Phase Bit Recovery: {exact_bits}/{N_SLOTS} verified via Optoelectronic Collapse")

            # ---- News channel: screen 25 headlines, large-decode only the IMMINENT ones ----
            new_items = news.pop_batch(NEWS_BATCH_SIZE)
            skipped = 0
            for headline, published_ns in new_items:
                ref_ns = time.time_ns()
                quick = decode_story(viewport, headline, published_ns, ref_ns)       # pass 1: screening
                if story_status(quick, time.time_ns())[0] != "IMMINENT":
                    skipped += 1
                    continue
                big = decode_story(viewport, headline, published_ns, ref_ns,          # pass 2: large decode
                                   LARGE_DECODE_WINDOWS, LARGE_DECODE_RETRIES)
                big["quick_match"] = (big["text"] == quick["text"])
                if story_status(big, time.time_ns())[0] == "IMMINENT":
                    stories.append(big)
                else:
                    skipped += 1

            if new_items:
                print(f" [NEWS] Screened {len(new_items)} headline(s): "
                      f"{len(new_items) - skipped} imminent (large-decoded), {skipped} skipped")

            # Statuses are live: drop stories that are no longer imminent
            now_ns = time.time_ns()
            live = [s for s in stories if story_status(s, now_ns)[0] == "IMMINENT"]
            expired = len(stories) - len(live)
            stories.clear()
            stories.extend(live)
            if expired:
                print(f" [NEWS] {expired} story(ies) no longer imminent - removed")

            if stories and (new_items or cycle % TABLE_REPRINT_CYCLES == 0):
                print_story_table(stories, time.time_ns())
            elif not stories:
                print(" [IMMINENT STORIES] none" if cycle > 1 or new_items else " [NEWS] Waiting for headlines...")
            # ---- Blockchain: decode the NEXT block hash ----
            blk = blocks.pop_new()
            if blk:
                tag = " (SIMULATED)" if blk["simulated"] else ""
                dec_hash, h_retries, h_failed, h_margin = transmit_block_hash(viewport, blk["hash"])
                dec_height, _, ok_height, m_height = transmit_u32(viewport, blk["height"])
                dec_ts, _, ok_ts, m_ts = transmit_u32(viewport, blk["timestamp"])
                match = (h_failed == 0 and dec_hash == blk["hash"])
                print(f" [BLOCK] NEW BLOCK DETECTED{tag}")
                print(f"   Height:  {dec_height if ok_height else '??'} (CRC {'PASS' if ok_height else 'FAIL'})")
                print(f"   Hash:    {dec_hash}")
                print(f"   Verify:  {'MATCHES chain data' if match else 'MISMATCH / unrecoverable frames: ' + str(h_failed)}"
                      f" | {len(bytes.fromhex(blk['hash'])) // NEWS_CHUNK_BYTES + 1} frames | CRC retries {h_retries}"
                      f" | min bit margin {min(h_margin, m_height, m_ts):.1f} sigma")
                print(f"   PoW:     {leading_zero_bits(dec_hash)} leading zero bits")
                if ok_ts:
                    print(f"   Mined:   {time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(dec_ts))} "
                          f"({format_age(time.time() - dec_ts)} ago, decoded) | tx count: {blk['tx_count']}")
                announced_tip = blk["hash"]
            else:
                tip = blocks.get_tip()
                if tip:
                    first_note = "" if announced_tip else " (current tip)"
                    print(f" [BLOCK] Waiting for next block... tip #{tip['height']} {tip['hash']}...{first_note} "
                          f"mined {format_age(time.time() - tip['timestamp'])} ago"
                          f"{' [SIMULATED]' if tip['simulated'] else ''}")
                else:
                    print(" [BLOCK] Connecting to chain...")
            print("-" * 78)
            time.sleep(1.0)

    except KeyboardInterrupt:
        print("\n[STOP] Shutting down...")
    finally:
        webcam.stop()
        fetcher.stop()
        news.stop()
        blocks.stop()
        webcam.join(timeout=2.0)
        fetcher.join(timeout=2.0)
        news.join(timeout=2.0)
        blocks.join(timeout=2.0)
        print("[DONE] Pipeline successfully terminated.")


if __name__ == "__main__":
    main()
