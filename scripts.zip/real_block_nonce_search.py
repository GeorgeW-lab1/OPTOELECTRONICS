"""
Real Bitcoin genesis block: build the header from REAL public fields and the REAL
coinbase transaction (computing the merkle root ourselves, not given), then brute-force
search for the nonce against the REAL difficulty target. This is literally what mining is;
there is no shortcut, so this is an honest, time-budgeted brute-force search using hashlib.
"""
import hashlib, struct, time

def sha256d(b): return hashlib.sha256(hashlib.sha256(b).digest()).digest()

# ---- REAL, public genesis-block fields (Bitcoin block 0) ----
VERSION   = 1
PREV_HASH = b"\x00" * 32
TIME      = 1231006505                 # 2009-01-03 18:15:05 UTC
BITS      = 0x1d00ffff                  # real difficulty-1 target encoding
KNOWN_NONCE = 2083236893                # public record, used only to report progress %, not fed to the search

# ---- REAL coinbase transaction raw bytes (the block's only transaction) ----
coinbase_hex = (
    "01000000010000000000000000000000000000000000000000000000000000000000000000"
    "ffffffff4d04ffff001d0104455468652054696d65732030332f4a616e2f32303039204368616e"
    "63656c6c6f72206f6e206272696e6b206f66207365636f6e64206261696c6f757420666f722062"
    "616e6b73ffffffff0100f2052a01000000434104678afdb0fe5548271967f1a67130b7105cd6a8"
    "28e03909a67962e0ea1f61deb649f6bc3f4cef38c4f35504e51ec112de5c384df7ba0b8d578a4c"
    "702b6bf11d5fac00000000"
)
coinbase_tx = bytes.fromhex(coinbase_hex)

# merkle root for a single-tx block = sha256d(tx), in internal (little-endian) byte order
merkle_root = sha256d(coinbase_tx)
print("=" * 78)
print(" REAL BLOCK DATA -> MERKLE ROOT -> NONCE SEARCH (Bitcoin genesis block)")
print("=" * 78)
print(f"  Coinbase tx length        : {len(coinbase_tx)} bytes (real raw tx)")
print(f"  Computed TXID (display)   : {coinbase_tx and sha256d(coinbase_tx)[::-1].hex()}")
print(f"  Merkle root (internal)    : {merkle_root.hex()}")
print(f"  Merkle root (display)     : {merkle_root[::-1].hex()}")
print(f"  Expected (from chain data): 3ba3edfd7a7b12b27ac72c3e67768f617fc81bc3888a51323a9fb8aa4b1e5e4a")
print(f"  Merkle root matches chain : {merkle_root.hex() == '3ba3edfd7a7b12b27ac72c3e67768f617fc81bc3888a51323a9fb8aa4b1e5e4a'}\n")

header76 = struct.pack("<I", VERSION) + PREV_HASH + merkle_root + struct.pack("<II", TIME, BITS)

exponent = BITS >> 24
coeff = BITS & 0xffffff
target = coeff * (1 << (8 * (exponent - 3)))
print(f"  Real difficulty target    : {target:#066x}")
print(f"  Expected tries (avg)      : 2^256 / target ≈ {2**256 / target:,.0f}")
print(f"  Known real nonce (public) : {KNOWN_NONCE:,}  (NOT given to the search below)\n")

print("[SEARCH] Brute-forcing nonce with a fixed time budget (hashlib, real target)...")
BUDGET_SECONDS = 20
t0, nonce, checked = time.perf_counter(), 0, 0
found = None
while time.perf_counter() - t0 < BUDGET_SECONDS:
    h = sha256d(header76 + struct.pack("<I", nonce))
    checked += 1
    if int.from_bytes(h[::-1], "big") < target:
        found = nonce
        break
    nonce += 1
elapsed = time.perf_counter() - t0
rate = checked / elapsed

print("\n" + "=" * 78)
print(" RESULT")
print("=" * 78)
print(f"  Hashes tried        : {checked:,} in {elapsed:.1f}s  ({rate:,.0f} h/s, pure Python+hashlib)")
if found is not None:
    print(f"  Nonce FOUND         : {found:,}")
else:
    full_space_est_sec = (2**32) / rate
    pct_of_space = checked / 2**32 * 100
    pct_to_real = checked / KNOWN_NONCE * 100
    print(f"  Nonce NOT found within the {BUDGET_SECONDS}s budget (expected: real nonce is ~{KNOWN_NONCE:,},")
    print(f"  about {pct_to_real:.4f}% of the way through the 32-bit nonce space from 0).")
    print(f"  Searched {pct_of_space:.4f}% of the full 2^32 nonce space.")
    print(f"  At this rate, a full-space search would take ≈ {full_space_est_sec/3600:.1f} hours.")
    print(f"  (This is the real reason mining needs ASICs, not a limitation of the method.)")
