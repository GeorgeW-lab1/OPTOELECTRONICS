import hashlib
import heapq
import json
import math
import threading
import time
import queue
from collections import deque
import tkinter as tk

import numpy as np

try:
    import pyautogui
    HAS_PYAUTOGUI = True
    pyautogui.FAILSAFE = True
    pyautogui.PAUSE = 0.02
except ImportError:
    HAS_PYAUTOGUI = False


# ============================================================================
# KEYBOARD OUTPUT
# ============================================================================

ENABLE_KEYBOARD = False
KEY_HIGH = ("shift", "w")
KEY_LOW = ("shift", "s")
KEYBOARD_ONLY_AFTER_ARM = True
KEYBOARD_REQUIRE_CONFIDENCE = True
KEYBOARD_MIN_DELTA = 0.01
KEYBOARD_COOLDOWN = 0.0
_last_keyboard_action = 0.0


# ============================================================================
# CONFIGURATION
# ============================================================================

LAMBDA = 10000.0
SIGMA_C = 0.005

N_SLOTS = 32
FIELD_BITS = 16
PRICE_DELTA_SCALE = 100.0

REVEAL_DELAY = 2.8
DEFAULT_BATCH_DELAY = 3.0

N_WINDOWS = 2000
N_PERMS = 100
REPORT_EVERY = 25

LEADS = (0, 1, 2, 3, 4)

N_SIGMA = 5.0
MIN_CYCLES = 40
ROLL_CYCLES = 400

Z_MIN = 4.0
JOINT_CONF_MIN = 0.999

DELTA_BUF_LEN = 64
MIN_BUF = 64
ENTROPY_MAX_BITS = 0.25
STREAK = 5
MIN_ABS_DELTA = 2.0


# ============================================================================
# HELPERS
# ============================================================================

def format_clock_time(timestamp_ns):
    seconds = timestamp_ns / 1e9
    clock = time.strftime("%H:%M:%S", time.localtime(seconds))
    ms = int((timestamp_ns % 1_000_000_000) // 1_000_000)
    return f"{clock}.{ms:03d}"


def noise_stats(lambd, sigma_c):
    shared = sigma_c ** 2 * lambd
    var_z = 1.0 + shared
    return var_z, math.sqrt(var_z), shared / var_z


def phi(z):
    return 0.5 * (1.0 + math.erf(z / math.sqrt(2.0)))


def sign_entropy(values):
    n = len(values)
    if not n:
        return 0.0, (0, 0, 0)
    counts = (
        sum(x > 0 for x in values),
        sum(x < 0 for x in values),
        sum(x == 0 for x in values),
    )
    h = 0.0
    for c in counts:
        if c:
            p = c / n
            h -= p * math.log2(p)
    return h, counts


# ============================================================================
# 32-BIT PAYLOAD
# ============================================================================

def timestamp_to_code(timestamp_ns):
    ms = (int(timestamp_ns) // 1_000_000) % 60000
    return ms & 0xFFFF


def price_delta_to_code(price_delta):
    cents = int(round(float(price_delta) * PRICE_DELTA_SCALE))
    cents = max(-32768, min(32767, cents))
    return cents & 0xFFFF


def code_to_signed_price_delta(code):
    value = int(code) & 0xFFFF
    if value >= 0x8000:
        value -= 0x10000
    return value / PRICE_DELTA_SCALE


def encode_payload_bits(timestamp_ns, price_delta):
    time_code = timestamp_to_code(timestamp_ns)
    delta_code = price_delta_to_code(price_delta)
    time_bits = [(time_code >> (15 - k)) & 1 for k in range(16)]
    delta_bits = [(delta_code >> (15 - k)) & 1 for k in range(16)]
    return np.array(time_bits + delta_bits, dtype=int)


def bits_to_code(bits):
    code = 0
    for bit in bits:
        code = (code << 1) | (int(bit) & 1)
    return code


def decode_payload_bits(bits):
    bits = np.asarray(bits, dtype=int).flatten()
    if len(bits) != N_SLOTS:
        raise ValueError("Invalid payload length")
    timestamp_code = bits_to_code(bits[:16])
    delta_code = bits_to_code(bits[16:])
    return timestamp_code, code_to_signed_price_delta(delta_code)


def decode_timestamp_from_code(code, reference_ns):
    minute_start = (int(reference_ns) // 60_000_000_000) * 60_000_000_000
    decoded_ns = minute_start + (int(code) & 0xFFFF) * 1_000_000
    return decoded_ns, format_clock_time(decoded_ns)


def make_payload_tilt(bits, eps_abs):
    bits = np.asarray(bits, dtype=float)
    strength = max(float(eps_abs), 0.25)
    return 2.0 * strength * (bits - 0.5)


# ============================================================================
# OPTICAL CHANNEL
# ============================================================================

class OptoelectronicViewport:
    def __init__(self, lambd=LAMBDA, sigma_c=SIGMA_C):
        self.lambd = lambd
        self.sigma_c = sigma_c

    def generate_window_block(self, n_windows, n_slots, tilt=None):
        shared_noise = np.random.normal(0.0, self.sigma_c, size=(n_windows, 1))
        lam = self.lambd * (1.0 + shared_noise)
        counts = np.random.poisson(np.clip(lam, 1.0, None), size=(n_windows, n_slots))
        Z = (counts - self.lambd) / np.sqrt(self.lambd)
        if tilt is not None:
            Z += tilt
        return Z


# ============================================================================
# ASYNCHRONOUS FORCED REVEAL SCHEDULER
# ============================================================================

class AsyncRevealScheduler(threading.Thread):
    def __init__(self, output_queue):
        super().__init__(daemon=True)
        self.output_queue = output_queue
        self.condition = threading.Condition()
        self.pending = []
        self.sequence = 0
        self.running = True

    def schedule(self, delay_seconds, callback):
        due_perf_ns = time.perf_counter_ns() + int(delay_seconds * 1e9)
        due_wall_ns = time.time_ns() + int(delay_seconds * 1e9)
        with self.condition:
            self.sequence += 1
            heapq.heappush(self.pending, (due_perf_ns, self.sequence, due_wall_ns, callback))
            self.condition.notify()
        return due_wall_ns

    def run(self):
        while self.running:
            item = None
            with self.condition:
                while self.running and not self.pending:
                    self.condition.wait()
                if not self.running:
                    break
                due_ns = self.pending[0][0]
                remaining = (due_ns - time.perf_counter_ns()) / 1e9
                if remaining > 0:
                    self.condition.wait(timeout=remaining)
                    continue
                item = heapq.heappop(self.pending)

            if item is None:
                continue

            due_perf_ns, sequence, due_wall_ns, callback = item
            actual_perf_ns = time.perf_counter_ns()
            actual_wall_ns = time.time_ns()
            try:
                result = callback(due_wall_ns, actual_wall_ns)
                result["scheduled_reveal_ns"] = due_wall_ns
                result["actual_reveal_ns"] = actual_wall_ns
                result["actual_reveal_perf_ns"] = actual_perf_ns
                self.output_queue.put(result)
            except Exception as e:
                print(f"[REVEAL] Callback error: {e}")

    def stop(self):
        with self.condition:
            self.running = False
            self.condition.notify_all()


# ============================================================================
# LEAD-LAG RECORDS
# ============================================================================

class ArmRecord:
    def __init__(self, maxlen=ROLL_CYCLES):
        self.M = deque(maxlen=maxlen)
        self.Y = deque(maxlen=maxlen)
        self.lock = threading.Lock()

    def add(self, col_means, y_bits):
        with self.lock:
            self.M.append(np.asarray(col_means, dtype=float))
            self.Y.append(np.asarray(y_bits, dtype=float))

    def snapshot(self):
        with self.lock:
            return np.array(self.M), np.array(self.Y)

    def __len__(self):
        with self.lock:
            return len(self.M)


# ============================================================================
# COMMITMENT & KEYBOARD
# ============================================================================

def make_commitment(arm, timestamp_ns, price, price_delta):
    if arm == "BEFORE":
        bits = encode_payload_bits(timestamp_ns, price_delta)
        material = (
            bits.tobytes()
            + str(timestamp_ns).encode()
            + repr(price).encode()
            + repr(price_delta).encode()
        )
        return hashlib.sha256(material).hexdigest(), bits

    noise = np.random.normal(0.0, 1.0, size=(256, N_SLOTS))
    return hashlib.sha256(noise.tobytes()).hexdigest(), None


def inject_decoded_direction(arm, decoded_delta, min_z, joint_conf):
    global _last_keyboard_action
    if not ENABLE_KEYBOARD:
        return "DISABLED"
    if not HAS_PYAUTOGUI:
        return "NO_PYAUTOGUI"
    if KEYBOARD_ONLY_AFTER_ARM and arm != "AFTER":
        return "SKIP_BEFORE"
    if KEYBOARD_REQUIRE_CONFIDENCE and (min_z < Z_MIN or joint_conf < JOINT_CONF_MIN):
        return "SKIP_LOW_CONF"
    if abs(decoded_delta) < KEYBOARD_MIN_DELTA:
        return "SKIP_ZERO"

    now = time.monotonic()
    if now - _last_keyboard_action < KEYBOARD_COOLDOWN:
        return "SKIP_COOLDOWN"

    direction, keys = ("HIGH", KEY_HIGH) if decoded_delta > 0 else ("LOW", KEY_LOW)
    try:
        pyautogui.hotkey(*keys)
        _last_keyboard_action = now
        return f"INJECTED_{direction}"
    except Exception as e:
        return f"ERR:{e}"


# ============================================================================
# NON-BLOCKING PIPELINE ENGINE
# ============================================================================

class NonBlockingPipeline:
    def __init__(self, before_log_cb, after_log_cb, status_cb):
        np.random.seed(2026)
        self.before_log = before_log_cb
        self.after_log = after_log_cb
        self.status_cb = status_cb

        self.viewport = OptoelectronicViewport()
        self.input_queue = queue.Queue()
        self.reveal_queue = queue.Queue()
        self.stop_event = threading.Event()

        self.scheduler = AsyncRevealScheduler(self.reveal_queue)
        self.before = ArmRecord()
        self.after = ArmRecord()
        self.delta_buf = deque(maxlen=DELTA_BUF_LEN)

        self.counters = {
            "scheduled": 0, "revealed": 0, "timestamp_hits": 0,
            "within_1ms": 0, "within_10ms": 0, "timestamp_total": 0,
            "delta_exact": 0, "delta_total": 0, "delta_abs_error": 0.0
        }
        self.previous_price = 100000.0

        self.ingest_thread = threading.Thread(target=self._ingest_worker, daemon=True)
        self.decode_thread = threading.Thread(target=self._decode_worker, daemon=True)

    def start(self):
        self.scheduler.start()
        self.ingest_thread.start()
        self.decode_thread.start()

    def submit_price(self, price):
        self.input_queue.put_nowait({
            "price": float(price),
            "received_ns": time.time_ns()
        })

    def _ingest_worker(self):
        while not self.stop_event.is_set():
            try:
                tick = self.input_queue.get(timeout=0.1)
            except queue.Empty:
                continue

            if tick is None:
                break

            price = tick["price"]
            fetch_ns = tick["received_ns"]
            price_delta = price - self.previous_price
            self.previous_price = price

            arm = "BEFORE" if np.random.random() < 0.5 else "AFTER"
            commit_ns = time.time_ns()
            commit_perf_ns = time.perf_counter_ns()
            scheduled_payload_ns = fetch_ns + int(REVEAL_DELAY * 1e9)

            commitment, committed_bits = make_commitment(arm, scheduled_payload_ns, price, price_delta)

            captured = {
                "arm": arm,
                "price": price,
                "price_delta": price_delta,
                "fetch_ns": fetch_ns,
                "commit_ns": commit_ns,
                "commit_perf_ns": commit_perf_ns,
                "commitment": commitment,
                "committed_bits": committed_bits.copy() if committed_bits is not None else None
            }

            def reveal_callback(scheduled_ns, actual_ns, data=captured):
                return {**data, "scheduled_reveal_ns": scheduled_ns, "actual_reveal_ns": actual_ns}

            self.scheduler.schedule(REVEAL_DELAY, reveal_callback)
            self.counters["scheduled"] += 1
            self.status_cb(f"Scheduled: {self.counters['scheduled']} | Revealed: {self.counters['revealed']}")
            self.input_queue.task_done()

    def _decode_worker(self):
        _, sigma_z, _ = noise_stats(LAMBDA, SIGMA_C)
        eps_abs = 0.02 * sigma_z

        while not self.stop_event.is_set():
            try:
                event = self.reveal_queue.get(timeout=0.1)
            except queue.Empty:
                continue

            if event is None:
                break

            try:
                arm = event["arm"]
                price = event["price"]
                price_delta = event["price_delta"]
                scheduled_ns = event["scheduled_reveal_ns"]
                actual_ns = event["actual_reveal_ns"]

                if arm == "BEFORE":
                    Y = event["committed_bits"].copy()
                    payload_timestamp_ns = scheduled_ns
                else:
                    payload_timestamp_ns = actual_ns
                    Y = encode_payload_bits(payload_timestamp_ns, price_delta)

                tilt = make_payload_tilt(Y, eps_abs)
                Z = self.viewport.generate_window_block(N_WINDOWS, N_SLOTS, tilt)
                m = Z.mean(axis=0)
                col_z = m / (Z.std(axis=0, ddof=1) / math.sqrt(N_WINDOWS))

                bit_z = col_z.copy()
                decoded_bits = (bit_z > 0).astype(int)
                decoded_code, decoded_delta = decode_payload_bits(decoded_bits)
                actual_code = timestamp_to_code(payload_timestamp_ns)

                time_error_ms = ((decoded_code - actual_code + 30000) % 60000) - 30000
                exact_bits = int(np.sum(decoded_bits == Y))

                if arm == "BEFORE":
                    self.before.add(m, Y)
                else:
                    self.after.add(m, Y)

                self.counters["revealed"] += 1
                min_z = float(np.abs(bit_z).min())
                joint_conf = float(np.prod([phi(z) for z in np.abs(bit_z)]))
                kb_status = inject_decoded_direction(arm, decoded_delta, min_z, joint_conf)

                log_line = (
                    f"Rev #{self.counters['revealed']} | Price: ${price:,.2f} | "
                    f"Δ: {price_delta:+.2f} | Bits: {exact_bits}/{N_SLOTS} | "
                    f"TErr: {time_error_ms:+d}ms | {kb_status}\n"
                )

                if arm == "BEFORE":
                    self.before_log(log_line)
                else:
                    self.after_log(log_line)

                self.status_cb(f"Scheduled: {self.counters['scheduled']} | Revealed: {self.counters['revealed']}")

            except Exception as e:
                print(f"[DECODE ERROR] {e}")
            finally:
                self.reveal_queue.task_done()

    def stop(self):
        self.stop_event.set()
        self.scheduler.stop()
        self.input_queue.put(None)
        self.reveal_queue.put(None)


# ============================================================================
# UNBLOCKING TKINTER INTERFACE WITH CONFIGURABLE BATCH DELAY
# ============================================================================

class RP_GHOST_GUI:
    def __init__(self):
        self.root = tk.Tk()
        self.root.title("RP-GHOST — Continuous Manual Batch Pipeline")
        self.root.geometry("940x680")

        self.before_queue = queue.Queue()
        self.after_queue = queue.Queue()
        self.status_queue = queue.Queue()

        self.pipeline = NonBlockingPipeline(
            lambda msg: self.before_queue.put_nowait(msg),
            lambda msg: self.after_queue.put_nowait(msg),
            lambda msg: self.status_queue.put_nowait(msg)
        )

        self.batch_stop_event = threading.Event()
        self.batch_stop_event.set()  # Initially stopped
        self.build_interface()
        self.pipeline.start()
        self._poll_ui_queues()

        self.root.protocol("WM_DELETE_WINDOW", self.close)

    def build_interface(self):
        tk.Label(self.root, text="RP-GHOST CONTINUOUS MANUAL BATCH PIPELINE", font=("Arial", 14, "bold")).pack(pady=8)

        # Control Frame
        ctrl_frame = tk.Frame(self.root)
        ctrl_frame.pack(pady=5, fill="x", padx=15)

        self.batch_btn = tk.Button(
            ctrl_frame, text="START CONTINUOUS BATCH", font=("Arial", 10, "bold"),
            bg="#2e7d32", fg="white", width=24, command=self.toggle_continuous_batch
        )
        self.batch_btn.pack(side="left", padx=(0, 8))

        tk.Label(ctrl_frame, text="Batch Delay (s):", font=("Arial", 10, "bold")).pack(side="left", padx=(4, 2))
        self.delay_var = tk.StringVar(value=str(DEFAULT_BATCH_DELAY))
        self.delay_entry = tk.Entry(ctrl_frame, textvariable=self.delay_var, width=6, font=("Consolas", 10), justify="center")
        self.delay_entry.pack(side="left", padx=(0, 10))

        tk.Button(
            ctrl_frame, text="SUBMIT ONCE", font=("Arial", 10, "bold"),
            width=14, command=self.submit_manual_once
        ).pack(side="left", padx=5)

        tk.Button(
            ctrl_frame, text="CLEAR LOGS", font=("Arial", 10, "bold"),
            width=12, command=self.clear_logs
        ).pack(side="left", padx=5)

        # Manual input text box
        tk.Label(self.root, text="Manual Price Batch (one per line or space-separated):", font=("Arial", 9)).pack(anchor="w", padx=15, pady=(5, 0))
        self.text_box = tk.Text(self.root, height=4, font=("Consolas", 10))
        self.text_box.pack(padx=15, pady=3, fill="x")
        self.text_box.insert("1.0", "100000.00\n100001.50\n99999.75\n100002.25")

        # Side-by-side Dual Arm Logs
        panes = tk.Frame(self.root)
        panes.pack(padx=15, pady=5, fill="both", expand=True)

        # BEFORE Arm Pane
        b_frame = tk.Frame(panes)
        b_frame.pack(side="left", fill="both", expand=True, padx=(0, 5))
        tk.Label(b_frame, text="BEFORE ARM (Committed Before Delay)", font=("Arial", 10, "bold"), fg="#1565c0").pack(anchor="w")
        self.before_box = tk.Text(b_frame, height=16, font=("Consolas", 9), state="disabled", bg="#f5f5f5")
        self.before_box.pack(fill="both", expand=True, pady=2)

        # AFTER Arm Pane
        a_frame = tk.Frame(panes)
        a_frame.pack(side="right", fill="both", expand=True, padx=(5, 0))
        tk.Label(a_frame, text="AFTER ARM (Independent Noise / Live Encode)", font=("Arial", 10, "bold"), fg="#c62828").pack(anchor="w")
        self.after_box = tk.Text(a_frame, height=16, font=("Consolas", 9), state="disabled", bg="#f5f5f5")
        self.after_box.pack(fill="both", expand=True, pady=2)

        # Status Bar
        self.status_var = tk.StringVar(value="Pipeline Ready. Set batch delay and click 'Start Continuous Batch'.")
        tk.Label(self.root, textvariable=self.status_var, font=("Arial", 9), anchor="w", relief="sunken", bd=1).pack(fill="x", side="bottom")

    def _get_batch_delay(self):
        try:
            val = float(self.delay_var.get())
            return max(0.05, val)
        except ValueError:
            return DEFAULT_BATCH_DELAY

    def toggle_continuous_batch(self):
        if self.batch_stop_event.is_set():
            self.batch_stop_event.clear()
            self.batch_btn.config(text="STOP CONTINUOUS BATCH", bg="#c62828")
            threading.Thread(target=self._continuous_batch_loop, daemon=True).start()
        else:
            self.batch_stop_event.set()
            self.batch_btn.config(text="START CONTINUOUS BATCH", bg="#2e7d32")
            self.status_var.set("Continuous batch stopped.")

    def _continuous_batch_loop(self):
        batch_num = 0
        while not self.batch_stop_event.is_set():
            raw = self.text_box.get("1.0", "end-1c").replace(",", " ")
            tokens = raw.split()
            if not tokens:
                if self.batch_stop_event.wait(0.5):
                    break
                continue

            batch_num += 1
            for tok in tokens:
                if self.batch_stop_event.is_set():
                    break
                try:
                    val = float(tok)
                    self.pipeline.submit_price(val)
                except ValueError:
                    pass
                # Brief pacing between items within the same batch
                if self.batch_stop_event.wait(0.2):
                    break

            if self.batch_stop_event.is_set():
                break

            delay = self._get_batch_delay()
            self.status_queue.put_nowait(
                f"Batch #{batch_num} submitted | Waiting {delay:.2f}s before next batch... | "
                f"Scheduled: {self.pipeline.counters['scheduled']} | Revealed: {self.pipeline.counters['revealed']}"
            )
            # Interruptible delay between full batch submissions
            if self.batch_stop_event.wait(delay):
                break

    def submit_manual_once(self):
        raw = self.text_box.get("1.0", "end-1c").replace(",", " ")
        tokens = raw.split()
        count = 0
        for tok in tokens:
            try:
                self.pipeline.submit_price(float(tok))
                count += 1
            except ValueError:
                pass
        self.status_var.set(f"Submitted manual batch of {count} values.")

    def _poll_ui_queues(self):
        b_batch = []
        while True:
            try:
                b_batch.append(self.before_queue.get_nowait())
            except queue.Empty:
                break
        if b_batch:
            self.before_box.config(state="normal")
            self.before_box.insert("end", "".join(b_batch))
            self.before_box.see("end")
            self.before_box.config(state="disabled")

        a_batch = []
        while True:
            try:
                a_batch.append(self.after_queue.get_nowait())
            except queue.Empty:
                break
        if a_batch:
            self.after_box.config(state="normal")
            self.after_box.insert("end", "".join(a_batch))
            self.after_box.see("end")
            self.after_box.config(state="disabled")

        try:
            while True:
                status_msg = self.status_queue.get_nowait()
                self.status_var.set(status_msg)
        except queue.Empty:
            pass

        self.root.after(50, self._poll_ui_queues)

    def clear_logs(self):
        for box in (self.before_box, self.after_box):
            box.config(state="normal")
            box.delete("1.0", "end")
            box.config(state="disabled")

    def close(self):
        self.batch_stop_event.set()
        self.pipeline.stop()
        self.root.destroy()


if __name__ == "__main__":
    app = RP_GHOST_GUI()
    app.root.mainloop()
