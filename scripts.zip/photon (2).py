
# ============================================================
# PHOTON SUITE — 512-BIT PRESETS
# Insert after factorise() and before main()
# ============================================================

def generate_512_test_case():
    """
    Generate a 512-bit semiprime N = p*q.

    Construct a base a with:
        a^4 = 1 mod N
        a^2 != 1 mod N

    Its half-order residue is:
        a^2 = 1 mod p
        a^2 = -1 mod q

    This gives the photon suite non-trivial GCD factors.
    """
    try:
        from sympy import randprime
    except ImportError:
        raise RuntimeError(
            "Install SymPy for test-number generation: "
            "pip install sympy"
        )

    while True:
        p = randprime(1 << 255, 1 << 256)
        q = randprime(1 << 255, 1 << 256)

        if p == q or q % 4 != 1:
            continue

        n = p * q

        if n.bit_length() != 512:
            continue

        # Find a quadratic non-residue modulo q.
        for g in range(2, 1000):
            if pow(g, (q - 1) // 2, q) == q - 1:
                root = pow(g, (q - 1) // 4, q)
                break
        else:
            continue

        # CRT:
        # a = -1 mod p
        # a = sqrt(-1) mod q
        rp = p - 1
        rq = root

        a = rp + p * (
            ((rq - rp) * pow(p, -1, q)) % q
        )

        r = 4

        if pow(a, r, n) != 1:
            continue

        if pow(a, r // 2, n) == 1:
            continue

        return {
            "N": n,
            "p": p,
            "q": q,
            "base": a,
            "order": r,
        }


def run_photon_512_preset(
    preset,
    number=None,
    period_provider=None,
    seed=42
):
    """
    Runs both presets through the existing Photon Suite.

    512-test:
        Generates a known-factor test modulus and sends
        its valid base/order through factorise().

    512-unknown:
        Uses a user-supplied modulus and requires an
        external period provider, such as a real hardware
        modular-exponentiation/period-finding backend.
    """

    presets = {
        "512-test": {
            "photons": 50000,
            "dark_rate": 0.01,
            "attempts": 12,
        },
        "512-unknown": {
            "photons": 200000,
            "dark_rate": 0.0025,
            "attempts": 20,
        },
    }

    if preset not in presets:
        raise ValueError(
            "Choose 512-test or 512-unknown"
        )

    config = presets[preset].copy()

    print("\n" + "=" * 65)
    print("PHOTON SUITE — 512-BIT PRESET")
    print("=" * 65)
    print("Preset:", preset)
    print("Photons:", config["photons"])
    print("Dark rate:", config["dark_rate"])
    print("Attempts:", config["attempts"])

    if preset == "512-test":
        test = generate_512_test_case()

        n = test["N"]
        a = test["base"]
        r = test["order"]

        print("Generated modulus bits:", n.bit_length())
        print("Known test period:", r)
        print("Period verified:", pow(a, r, n) == 1)
        print("Half-period:", pow(a, r // 2, n))
        print("Expected factors:", test["p"], test["q"])

        # Run the EXISTING photon pipeline.
        result = factorise(
            n=n,
            photons=config["photons"],
            dark_rate=config["dark_rate"],
            max_attempts=config["attempts"],
            seed=seed,
            supplied_order=r,
            supplied_base=a,
            diagnostics=True,
            preset_name=preset,
        )

        if result is not None:
            assert result[0] * result[1] == n
            print("Photon suite factor verification: PASS")

        return result

    # --------------------------------------------------------
    # UNKNOWN 512-BIT MODULUS
    # --------------------------------------------------------

    if number is None:
        raise ValueError(
            "512-unknown requires number=N"
        )

    n = int(number)

    if n.bit_length() != 512:
        raise ValueError(
            "512-unknown requires an exactly 512-bit modulus"
        )

    if period_provider is None:
        raise RuntimeError(
            "No period-finding backend is connected. "
            "Connect the physical photon/modular-exponentiation "
            "backend through period_provider(n). The suite will "
            "not fabricate or brute-force a 512-bit period."
        )

    # The provider must return (base, period).
    a, r = period_provider(n)

    if not (1 < a < n and 1 < r <= n):
        raise ValueError("Invalid backend base or period")

    if pow(a, r, n) != 1:
        raise ValueError(
            "Backend period failed modular verification"
        )

    print("Backend supplied base:", a)
    print("Backend period verified:", r)

    # Photon measurement and decoding remain in the suite.
    return factorise(
        n=n,
        photons=config["photons"],
        dark_rate=config["dark_rate"],
        max_attempts=config["attempts"],
        seed=seed,
        supplied_order=r,
        supplied_base=a,
        diagnostics=True,
        preset_name=preset,
    )

import sys
if len(sys.argv) > 1 and sys.argv[1] in (
        "512-test",
        "512-unknown",
    ):
    preset = sys.argv[1]
    if preset == "512-test":
            run_photon_512_preset("512-test")

else:
    if len(sys.argv) < 3:
        print("Usage: python photon.py 512-unknown N")
        sys.exit(1)

    n = int(sys.argv[2], 0)
    run_photon_512_preset(
        "512-unknown",
        number=n,
    )

